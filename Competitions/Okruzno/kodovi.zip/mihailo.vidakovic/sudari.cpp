#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    long long x, y;
    long long n, m;
    cin>>n>>m>>x>>y;
    long long k;
    cin>>k;
    char l[n][m];
    for(long long i = 0; i < n; i++)
    {
            for(long long j = 0; j < m; j++)
            {
                    cin>>l[i][j];
            }
    }
    x--;
    y--;
    long long d = 0;
    for(long long i = 0; i < k; i++)
    {
            while(l[x][y] != '#' && x < n && y < m)
            {
                          switch(d){
                                    case(0): {x++; break;}
                                    case(1): {y++; break;}
                                    case(2): {x--; break;}
                                    case(3): {y--; break;}
                          }
                          
            }
            switch(d){
                      case(0): {x--; break;}
                      case(1): {y--; break;}
                      case(2): {x++; break;}
                      case(3): {y++; break;}
            }
            d++;
            if(d == 4)
            d = 0;
    }
    x++;
    y++;
    cout<<x<<" "<<y<<"\n";
    
    

    return EXIT_SUCCESS;
}
