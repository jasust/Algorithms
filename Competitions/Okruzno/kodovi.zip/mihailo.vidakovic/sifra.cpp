#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    long long n, m, k;
    cin>>n>>m>>k;
    long long a[n], sl = n;
    for(long long i = 0; i < n; i++)
    {
            cin>>a[i];
    }
    for(long long i = 0; i < m; i++)
    sl *= n;
    long long c[m], l = 0, push = 1, bn = 0, t = 0, nn = 0, rn = 0, rnn = 0;
    t =  k % n;
    for(long long i = 0; i < m; i++)
    c[i] = a[bn];
    
    for(long long i = 0; i < k / n; i++)
    {
           c[m - 1 - push] = a[bn];
           if(push > 1)
           {
                   for(long long j = m - 2; j < push; j++)
                   {
                            for(long long k = 0; k < n; k++)
                            {
                                     i++;
                                c[k] = a[nn];
                                nn++;
                                if(nn == n - 1)
                                {
                                      nn = 0;
                                }
                            }
                   }
           }
           bn++;
           if(bn == n - 1)
           {
                 rn++;
                 if(rn == n - 1)
                 rn = 0;
                 bn = rn;
                 push++;
           }  
    }
    c[m - 1] = a[t - 1];
    for(long long i = 0; i < m; i++)
    {
             if(i < m - 1) cout<<c[i]<<" ";
             else cout<<c[i];
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
