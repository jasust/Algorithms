#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    bool front = true;
    long long n;
    cin>>n;
    long long s[n][2], f = 0;
    for(long long i = 0; i < n; i++)
    {
            cin>>s[i][0]>>s[i][1];
    }
    for(long long i = 0; i < n; i++)
    {
            front = true;
            for(long long j = i + 1; j < n; j++)
            {
                    if(s[i][0] <= s[j][0] && s[i][1] <= s[j][1])
                    {
                               front = false;
                               break;
                    }
            }
            if(front)
            f++;
    }
    cout<<f<<"\n";
    

    return EXIT_SUCCESS;
}
