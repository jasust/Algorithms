#include <iostream>
using namespace std;

int a[100000];
int b[100000];

int main()
{
    int n, m;
    long long k;
    scanf("%d", &n);
    scanf("%d", &m);
    scanf("%lld", &k);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    k--;
    for (int i = 0; i < m; i++)
    {
        b[i] = k % n;
        k /= n;
    }
    for (int i = m - 1; i >= 0; i--)
        printf("%d ", a[b[i]]);
    return 0;
}
