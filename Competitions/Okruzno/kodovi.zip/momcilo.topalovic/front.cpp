#include <iostream>
#include <algorithm>
#include <queue>
using namespace std;

long long x[1000000], y[1000000];
int flag;
void insert(int i)
{
     int tmpX = x[i];
     int tmpY = y[i];
     int j;
     for(j = i - 1; j >= flag && tmpY > y[i]; j--)
     {
         x[j + 1] = x[j];
         y[j + 1] = y[j];
     }
     x[j + 1] = tmpX;
     y[j + 1] = tmpY;
}
int main()
{
    int n, f = 0;
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
    {
        scanf("%lld", &x[i]);
        scanf("%lld", &y[i]);
        if(x[i] == x[flag])
            insert(i);
        else
            flag = i;
    }
    for(int i = 0; i < n; i++)
    {
        bool flg = false;
        for(int j = i + 1; j < n;j++)
            if(y[j] >= y[i])
            {
                flg = true;
                break;
            }
        if(flg == false)
            f++;
    }
    printf("%d", f);
    return 0;
}
