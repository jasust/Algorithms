#include <iostream>
#include <cstring>
using namespace std;

struct mesto
{
    int X;
    int Y;
    int DIR;
};

int main()
{
    
    int n, m, x, y, dir = 0, count = 0;
    long long k;
    bool flag = false;
    scanf("%d", &n);
    scanf("%d", &m);
    scanf("%d", &x);
    scanf("%d", &y);
    scanf("%lld", &k);
    mesto s[k];
    char polje[500][500];
    for (int i = 0; i < n; i++)
        scanf("%s", &polje[i]);
    x--;
    y--;
    if(k > 50000)
    {   
        while(k > 0)
        {
            if (dir == 0)
                while (x < n - 1 && polje[x + 1][y] == '.')
                    x++;
            else if (dir == 1)
                while (y < m - 1 && polje[x][y + 1] == '.')
                    y++;
            else if (dir == 2)
                while (x > 0 && polje[x - 1][y] == '.')
                    x--;
            else
                while (y > 0 && polje[x][y - 1] == '.')
                    y--; 
            dir+=1;
            dir%=4;
            count++;
            s[count].X = x;
            s[count].Y = y;
            s[count].DIR = dir;
            for (int i = count - 4; i >= 0; i -= 4)
                if (s[i].X == s[count].X && s[i].Y == s[count].Y)
                {
                    int tmp = count - i;
                    while (k - tmp >= i)
                        k -= tmp;
                    flag = true;
                    x = s[k].X;
                    y = s[k].Y;
                    break;
                }
            if(flag)
                break;
            k--;
        }
    }
    else
    {
        while(k>0)
        {
            if (dir == 0)
                while (x < n - 1 && polje[x + 1][y] == '.')
                    x++;
            else if (dir == 1)
                while (y < m - 1 && polje[x][y + 1] == '.')
                    y++;
            else if (dir == 2)
                while (x > 0 && polje[x - 1][y] == '.')
                    x--;
            else
                while (y > 0 && polje[x][y - 1] == '.')
                    y--;
        
            dir += 1;
            dir %= 4;
            k--;
        }
    }
    x++;
    y++;
    printf("%d ", x);
    printf("%d ", y);
    return 0;
}
