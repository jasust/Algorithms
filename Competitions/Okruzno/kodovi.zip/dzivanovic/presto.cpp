#include <cstdio>
#include <algorithm>
using namespace std;
int n,m;
int a[310][310];
int k[310][310];
int r[310][310];
bool cmp(int a, int b) {return a > b;}
int main()
{
    scanf("%d %d",&n,&m);
    for(int i = 0; i <n; i++)
        for(int j = 0; j < m; j++)
    {
        scanf("%d",&a[i][j]);
        k[j][i]=a[i][j];
        r[i][j]=a[i][j];
    }
    for(int i = 0; i < n; i++)
        sort(r[i],r[i]+m);
    for(int i = 0; i < m; i++)
        sort(k[i],k[i]+n);
    /*for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < m; j++)
            printf("%d ",r[i][j]);
        printf("\n");
    }
    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
            printf("%d ",k[i][j]);
        printf("\n");
    }*/
    int mn = 1000000;
    int ii = -1, ij = -1,ik =-1;
    for(int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
    {
        int y = 0;
        int num = 0;
        for(int x = 0; x < m; x++)
        {
            if (x > 0 && r[i][x]!= r[i][x-1])
                num = x;
            while(y < n && k[j][y] <= r[i][x])
                y++;
            if (num + n-y < mn)
            {
                mn = num+n-y;
                ii = i;
                ij =j;
                ik = r[i][x];
            }

        }
    }
    //printf("%d %d %d %d\n",mn,ii,ij,ik);
    printf("%d\n",mn);
    return 0;
}
/*
3 4
1 9 3 0
6 2 7 5
8 4 6 3
2 2
4 5
3 4

3 3
0 0 3
2 3 1
4 2 3
*/
