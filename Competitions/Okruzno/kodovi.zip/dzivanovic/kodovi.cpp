#include <cstdio>
#include <algorithm>
using namespace std;
struct
{
    int p,h;
} a[100010];
int n;
int x;
bool desno;
int l,r;
int num;
long long t;

int main()
{
    scanf("%d %d",&n,&x);
    l = r = -1;
    for(int i  =0 ; i < n; i++)
    {
        scanf("%d %d",&a[i].p,&a[i].h);
        if (a[i].p < x)
            l = i;
        if (a[i].p > x && r == -1)
            r = i;
    }
    desno = true;
    num = 0;
    t = 0;
    while(r < n && l >= 0)
    {
        while(r < n && l >= 0 && x != a[l].p)
        {
            if(desno)
            {
                t+=a[r].p-x;
                num++;
                x = a[r].p;
                desno = false;
                a[r].h--;
                if (a[r].h == 0)
                    r++;
            }
            if(!desno)
            {
                t+=x-a[l].p;
                num++;
                x = a[l].p;
                desno = true;
                a[l].h--;
                if (a[l].h == 0)
                    l--;
            }
        }
        if (r < n && l >= 0)
        {
            if(a[l].h <= a[r].h)
            {
                t+=a[l].h*2ll*(a[r].p-a[l].p);
                num+=a[l].h*2;
                a[r].h-=a[l].h;
                l--;
            }
            else
            {
                t+=a[r].h*2ll*(a[r].p-a[l].p);
                num+=a[r].h*2;
                a[l].h-=a[r].h;
                r++;
            }
        }
    }
    if (r < n)
    {
        t+=a[r].p-x;
        num ++;
    }
    printf("%d\n%lld\n",num,t);
    return 0;
}
/*
3 7
5 2
10 1
12 4

5 13
1 1
4 3
5 5
12 7
17 9

5 6
1 1
4 3
5 5
12 7
17 9
*/
