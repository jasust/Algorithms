#include <cstdio>
using namespace std;

int sol[14];
int sold = -1;
int tren[14];
int sum[14];
int a[14];
int n,k;
void solve(int x,int n,int k)
{
    if (x >= n)
    {
        for(int i = 0; i < k; i++)
            sum[i] = 0;
        for(int i = 0; i < n; i++)
            sum[tren[i]]+=a[i];
        int mn = -1; int mx = 0;
        for(int i = 0; i < k; i++)
            if(sum[i] > mx)
                mx = sum[i];
        for(int i = 0; i < k; i++)
            if(sum[i] < mn || mn == -1)
                mn = sum[i];
        if (mx - mn < sold || sold == -1)
        {
            sold = mx-mn;
            for(int i =0; i < n; i++)
                sol[i] = tren[i];
        }
        return;
    }
    for(int i = 0; i < k; i++)
    {
        tren[x] = i;
        solve(x+1,n,k);
    }
    return;
}
int main()
{
    scanf("%d %d",&n,&k);
    for (int i = 0; i<n; i++)
        scanf("%d",&a[i]);
    solve(0,n,k);
    printf("%d\n",sold);
    for(int i = 0; i < n; i++)
        printf("%d ",sol[i]+1);
    return 0;
}
