#include<cstdio>

using namespace std;

int n,k,a[14],c[14];

bool u[14];

long long sum = 0,avg,b[14];

void minmax(){
    long long min = b[0];
    long long max = b[0];
    for(int i=0;i<k;i++)
        if(b[i]<min)
            min = b[i];
        else if(b[i]>max)
            max = b[i];
    long long mm = max - min;
    printf("%lld\n",mm);
}

int main(){
    scanf("%d%d",&n,&k);
    for(int i=0;i<n;i++)
        scanf("%lld",&a[i]);

    if(k==1){
        for(int i=0;i<n;i++)
            sum+=a[i];
        printf("%lld\n",sum);
        for(int i=0;i<n;i++)
            printf("1 ");
        return 0;
    }

    for(int i=0;i<14;i++)
    {
        u[i] = true;
        b[i] = 0;
    }

    for(int i=0;i<n;i++)
        sum+=a[i];
    avg = (sum / k) + 1;

    for(int j=0;j<k;j++)
    for(int i=0;i<n;i++)
        if(u[i] && a[i]+b[j] <= avg)
        {
            u[i] = false;
            b[j] += a[i];
            c[i] = j + 1;
        }

    for(int i=0;i<n;i++)
    {
        if(u[i])
        {
            long long min = 100000000014;
            int minidx;
            for(int j=0;j<k;j++)
                if(b[j]<min)
                {
                    min = b[j];
                    minidx = j;
                }
            u[i] = false;
            b[minidx] += a[i];
            c[i] = minidx+1;
        }
    }
    minmax();
    for(int i=0;i<n;i++)
        printf("%d ",c[i]);
    return 0;
}
