#include<cstdio>

using namespace std;

int n,m,a[314][314],b[314][314];

int pres(int x, int y){
    int prom = 0;
    for(int i=0;i<n;i++)
        if(a[i][y]>a[x][y])
            prom++;
    for(int i=0;i<m;i++)
        if(a[x][i]<a[x][y])
            prom++;
    return prom;
}

void sol(){
    int min = 90014;
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++){
        b[i][j] = pres(i,j);
        if(b[i][j]<min)
            min = b[i][j];
    }
    printf("%d\n",min);
}

int main(){
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
        scanf("%d",&a[i][j]);
    sol();
    return 0;
}
