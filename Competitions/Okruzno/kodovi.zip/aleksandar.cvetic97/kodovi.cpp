#include<cstdio>

using namespace std;

int n,x,p[100014],h[100014];

int idx,idxl,idxr;

long long time = 0, nakro = 0;

int id(){
    for(int i=0;i<n;i++)
        if(p[i]<=x) continue;
        else return i;
    return n;
}

int main(){
    scanf("%d%d",&n,&x);
    for(int i=0;i<n;i++)
        scanf("%d%d",&p[i],&h[i]);
    idx = id();
    if(idx==n)
    {
        printf("0\n0\n");
        return 0;
    }
    if(idx==0)
    {
        printf("1\n%d\n",p[idx]-x);
        return 0;
    }
    idxl = idx-1;
    idxr = idx;
    time+=p[idxr]-x;
    if(time == 0)
    {
        idxl = idx;
        idxr = idx + 1;
        time+=p[idxr]-x;
    }
    h[idxr]--;
    nakro++;
    time+=p[idxr]-p[idxl];
    if(h[idxr]==0)
        idxr++;

    while(true)
    {
        if(idxl < 0 || idxr > n-1)
        {
            printf("%d\n%d\n",nakro,time);
            return 0;
        }
        if(h[idxl]>h[idxr])
        {
            time+=(2*h[idxr])*(p[idxr]-p[idxl]);
            nakro+=2*h[idxr];
            h[idxl]-=h[idxr];
            h[idxr]=0;
            idxr++;
        }
        else if(h[idxl]<h[idxr])
        {
            time+=(2*h[idxl]-1)*(p[idxr]-p[idxl]);
            nakro+=2*h[idxl];
            h[idxr]-=h[idxl];
            h[idxl]=0;
            idxl--;
            if(idxl>=0)
            {
                time+=p[idxr]-p[idxl];
                nakro++;
                h[idxl]--;
            }
        }
        else
        {
            time+=2*h[idxl]*(p[idxr]-p[idxl]);
            nakro+=2*h[idxr];
            h[idxl]=0;
            h[idxr]=0;
            idxr++;
            idxl--;
        }
    }
    return 0;
}
