#include<cstdio>
#include<cstdlib>
typedef struct
{
	int x;
	int y;
} vojnik;

void sort(vojnik v[],int n)
{
	vojnik p;
	int i,j;
	for(i=n;i>=1;i--)
	{
	for(j=n-1;j>=0;j--)
    {
    if(v[i].x<v[j].x)
    {
    	p=v[j];
    	v[j]=v[i];
    	v[i]=p;
	}
	}
	}
    }
	
int	BR(vojnik v[],int n)
{
	int i,j,br=0,f=0;
	for(i=0;i<n;i++)
	{
		if(br==(n-1))
		{
			f++;
		}
		br=0;
	   for(j=0;j<n;j++)
	   {
	      if((v[i].x>v[j].x)||(v[i].y>v[j].y))
		  {
	      	br++;
		  }
	   }
	      
    }
    return f;
}

int main()
{
	vojnik v[15];
	int n,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %d",&v[i].x,&v[i].y);
	}
	sort(v,n);
	printf("\n%d",BR(v,n));
	return 0;
}

