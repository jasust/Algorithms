#include <iostream>
#include <algorithm>

using namespace std;
int n,x,p[100005],h[100005],c[100005],d[100005];
long long t=0,s=0,w=0;
int f(int p[],int h[],int c[],int d[],int y);
int g(int p[],int h[],int c[],int d[]);

int main()
{
    int i;
    cin>>n>>x;
    for(i=0;i<n;i++)
        { cin>>p[i]>>h[i];
        w+=h[i];
        }

    s=g(p,h,c,d);
    t=c[0]-x;
    for(i=1;i<s;i++)
            {
                t+=abs(c[i]-c[i-1]);

            }

    cout<<s<<endl<<t;
    return 0;

}
int f(int p[],int h[],int c[],int d[],int y)
{
    int i;
    for(i=0;i<n;i++)
        if(p[i]>=x)
    {
        c[0]=p[i];
        d[0]=h[i]-1;
        y++;
        return i;
    }
}
int g(int p[],int h[],int c[],int d[])
{
    int i,j=1,k=1,m,y=0;
            m=f(p,h,c,d,y);
        c[1]=p[m-1];
        d[1]=h[m-1]-1;
        y++;
    for(i=2;i<=w;i++)
    {
                      if((m-j)<0 || (m+k)>n ) { return y;  }
        if(i%2==1)
        {
            if(d[i-2]==0)
            { c[i]=p[m-j];
              d[i]=h[m-j]-1; j++;
              y++; }
              else
              {
                  c[i]=c[i-2];
                  d[i]=d[i-2]-1;
                  y++;
              }

        }
        else
        {
            if(d[i-2]==0)
            { c[i]=p[m+k];
             d[i]=h[m+k]-1; k++;
             y++; }
             else
             {
                 c[i]=c[i-2];
                 d[i]=d[i-2]-1;
                 y++;
             }

        }
    }
    return y;
}
