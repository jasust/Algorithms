#include <iostream>

using namespace std;
void quickSort(int w[],int first,int last);
int pivot(int w[],int first,int last);
void swapp(int &m,int &n);

int n,k,a[20],m,b[20],s=0,r,c[20];

int main()
{
    int i,j,p;
    cin>>n>>k;
    for(i=0;i<n;i++)
    {
     cin>>a[i];
     s+=a[i];
    }
    m=s/k;
    b[0]=1;
    p=1;
if(k==1)
    for(i=0;i<n;i++)
{
    b[i]=1;
}
        for(i=0;i<n;i++)
    {
        if(b[i]==0)
        {
            if(p<k) { p++; b[i]=p; }
            else { p--; b[i]=p; }

        }
        for(j=i+1;j<n;j++)
        {
            if(((a[j]+a[i])==m) && b[j]==0 && b[i]!=0) { b[j]=b[i]; break; }
        }

    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<k;j++)
        {
            if(b[i]==(j+1)) c[j]+=a[i];
        }
    }
    quickSort(c,0,k-1);
    r=c[k-1]-c[0];
    cout<<r<<endl;
    for(i=0;i<n;i++)
        cout<<b[i]<<" ";

    return 0;
}

void quickSort(int w[],int first,int last)
{
    int pivotElement;
    if(first<last)
    {
        pivotElement=pivot(w,first,last);
        quickSort(w,first,pivotElement-1);
        quickSort(w,pivotElement+1,last);
    }
}
int pivot(int w[],int first,int last)
{
    int p=first;
    int pivotElement=w[first];
    for(int i=first+1;i<=last;i++)
    {
        if(w[i]<=pivotElement)
        {
            p++;
            swapp(w[i],w[p]);
        }
    }
    swapp(w[p],w[first]);
    return p;
}
void swapp(int &m,int &l)
{
    int temp=m;
    m=l;
    l=temp;
}
