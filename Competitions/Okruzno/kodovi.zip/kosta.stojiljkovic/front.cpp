#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define MAXN 1000100

using namespace std;


int x[MAXN];
int y[MAXN];
int n;
int xtr;
int ymax;
int ymaxtr;
int rez;



int main()
{
    cin>>n;
    for(int i=0;i<n;i++)
    {
            cin>>x[i]>>y[i];
    }
    
    xtr=x[n-1];
    
    
    for(int i=n-1;i>=0;i--)
    {
            if(x[i]==xtr)
            {
                         if(y[i]>ymaxtr)
                         ymaxtr=y[i];
            }                        
            else
            {
                if(ymaxtr>ymax)
                {
                               rez++;  
                               ymax=ymaxtr;       
                }
                xtr=x[i];
                ymaxtr=y[i];
               if(i==0)
            {
                 if(ymaxtr>ymax)
              {
                             rez++;  
                             ymax=ymaxtr;       
              }                        
             }
               
            }
    }   
    
        
        
        cout<<rez;
        
    
    

    return 0;
}
