#include <cstdlib>
#include <iostream>
#include <stdio.h>

#define MAXL 510

using namespace std;


int poslx;
int posly;
int n,m;
int br=0;
int x,y;
char tr,sl,pr;
int xp=1,yp;
int skretanja=-1;
long long k;
char a[MAXL][MAXL];
int b[MAXL][MAXL];



void skreni()
{
              if(xp==1)
              {
                      xp=0;
                      yp=1;
                      return;
              }
              if(xp==-1)
              {
                      xp=0;
                      yp=-1;
                      return;
              }
              if(yp==1)
              {
                      xp=-1;
                      yp=0;
                      return;
              }
              if(yp==-1)
              {
                      xp=1;
                      yp=0;
                      return;
              }
              
              
}

int main()
{
    cin>>n>>m>>x>>y>>k;
    
    for(int i=1;i<n+1;i++)
    for(int j=1;j<m+1;j++)
    {
            cin>>a[i][j];

    } 

    
    while(k>0)
    {
              
              b[x][y]++;
              tr=b[x][y];
              
            if(tr==2 && pr==2 && skretanja==-1)
            {
                    skretanja=0;
           }
          if(tr==3 && pr==3 && skretanja!=-1)
          {
                    k=k%skretanja;
                    
                    if(k==0)
                    {
                            x=poslx;
                            y=posly;
                            break;
                    }
                    
                  
           }
              
              sl=a[x+xp][y+yp];
              
              if(sl=='.')
              {
                         pr=tr;
                         
                         x=x+xp;
                         y=y+yp;
              }
              else
              {
                  poslx=x;
                  posly=y;
                  pr=tr;
                  skreni();
                  if(skretanja!=-1)
                  skretanja++;
                  k--;
              }


              
    }
    
    cout<<x<<" "<<y;
    
    return 0;
}
