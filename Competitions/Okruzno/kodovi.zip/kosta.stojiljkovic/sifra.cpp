#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define MAXN 100100

using namespace std;

int m,n;
long long k;
int tra=0;
int trp=0;
int v=0;
int samo1=false;
int a[MAXN];
int r[10];
int br=9;
int rez;

void razdvoji()
{
     while(br>=0)
     {
                 r[br]=k%10;
                 br--;
                 k=k/10;
     }
     
}


int main()
{
    cin>>n>>m>>k;
    
    for(int i=0;i<n;i++)
    {
            cin>>a[i];
    }
    
    if(m==1)
    {
            rez=a[k-1];
            cout<<rez;
    }
    if(m==10)
    {
             razdvoji();
             for(int i=0;i<10;i++)
             {
                     cout<<r[i]<<" ";
             }
    }
  
    

    return 0;
}
