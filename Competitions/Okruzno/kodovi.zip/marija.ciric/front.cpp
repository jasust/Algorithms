#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
int n,x[1000005],y[1000005],brojac,brojac2;
int main(){
    scanf("%d",&n);
    brojac=0;
    brojac2=0;
    for(int i=1;i<=n;i++){
        scanf("%d %d",&x[i],&y[i]);
    }
    for(int d=n;d>=1;d--){
        for(int s=n;s>=1;s--){
            if(x[d]>x[s] or y[d]>y[s]) brojac++;
           }
        if(brojac==n-1) brojac2++;
        brojac=0;
    }
    printf("%d\n",brojac2);
return 0;
}
