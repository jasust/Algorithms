#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
int n,m,k,a[100005],v;
int main(){
    v=1;
    scanf("%d %d %d",&n,&m,&k);
    for(int p=1;p<=m;p++){
        v=v*n;
    }
    for(int i=1;i<=n;i++){
        scanf("%d",&a[i]);
    }
    sort(a+1,a+1+n);
    printf("%d\n",a[k]);
return 0;
}
