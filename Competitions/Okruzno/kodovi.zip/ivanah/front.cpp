#include<cstdio>
#include<algorithm>
using namespace std;

int N,i,b;
long long int x[100005],y[100005],by;

int main()
{
    scanf("%d",&N);
    for(i=1;i<=N;i++)
    {
        scanf("%lld %lld",&x[i],&y[i]);
    }
    b=0;
    by=0;
    for(i=N;i>=1;i--)
        {
            if(y[i]>by) b++;
            by=y[i];
        }



    printf("%d",b);
return 0;
}
