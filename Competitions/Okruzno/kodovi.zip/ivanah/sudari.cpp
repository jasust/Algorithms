#include<cstdio>
using namespace std;

int n,m,y,x,k,i,j;
char c;

int main()
{
    scanf("%d %d",&n,&m);
    scanf("%d %d",&y,&x);
    scanf("%d",&k);
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%c",&c);

        }
    }


return 0;
}
