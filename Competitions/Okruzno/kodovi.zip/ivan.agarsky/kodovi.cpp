#include <cstdlib>
#include <iostream>
#include <algorithm>

using namespace std;

long long int pi[100000000];
long long int hi[100000000];
int main(int argc, char *argv[])
{
    int n,i=0,j=0,br=0;
    long long int x=0,sumalevo=0,sumadesno=0,brojkodova=0,vreme=0;
    scanf("%d",&n);
    scanf("%lld",&x);
    
    
    for(i=0;i<n;i++)
    {
     scanf("%lld",&pi[i]);
     scanf("%lld",&hi[i]);
    }
    
    for(j=0;j<n;j++)                
    {
    if(pi[j]>x){br=j;break;  }                            
                    
    } 
    
    
    i=0;j=0;
    for(i=0;i<n;i++)
    {
     if(i<br)sumalevo+=hi[i];
     else sumadesno+=hi[i];                
    }
    
    
    while(sumalevo!=0 && sumadesno!=0)
    {
    sumadesno--;
    sumalevo--;
    brojkodova+=2;
    }
    if(sumalevo==0 && sumadesno!=0)brojkodova++;
    
    printf("%lld\n",brojkodova);
    printf("34");                      
                

    
    
    return 0;
}
