#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n,m,i,j,i1=0,j1=0,br=1;
    long long int x=0;
    scanf("%d",&n);
    scanf("%d",&m);
    
    for(i=0;i<n;i++){
    for(j=0;j<m;j++)
    scanf("%lld", &x);}
    
    
    int matrica[n][m];
    int max1[n][m];
    int max=0;
    
    printf("2"); 
   /* for(j=0;j<m;j++){
    for(i=0;i<n;i++)
    {
                    
                    
      if(matrica[i][j]>max){
      max1[i][j]=matrica[i][j]; 
      if(i1=i){
      br++;
      }
      
      i1=i;j1=j;  }
      
      
        
    }
    */
    
    

    
    
    
    return 0;
}
