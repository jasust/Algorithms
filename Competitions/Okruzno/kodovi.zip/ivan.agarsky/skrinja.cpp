#include <cstdlib>
#include <iostream>
#include <algorithm>



using namespace std;
      
long long int x[100000000];
int perica[14];
int perica1[5];
int perica2[5];
int perica3[5];
int main(int argc, char *argv[])
{
    int n,k,i=0,j=0,m,h,v,br;
    scanf("%d",&n);
    scanf("%d",&k);
    if(k==1)printf("0");
    else{
    
    for(i=0;i<n;i++)
    {
    scanf("%lld",&x[i]);                
    }
    sort(x,x+n);
    i=0;
    perica[0]=x[0]+x[n-1];
    j=(n-2)/(k-1);
    h=(n-2)%(k-1);
    br=1;
    for(m=1;m<=k;m++)
    {
                     for(v=br;v<=j+br;v++)
                     {
                     perica[m]+=x[v];
                                     
                     }
        br+=j;           
                    
    }
    i=0;
    
      perica[m]+=x[br]; 
                         
    
    sort(perica,perica+k);
    
    
    printf("%d\n", x[0]);
    
    
    
}
    return 0;
}
