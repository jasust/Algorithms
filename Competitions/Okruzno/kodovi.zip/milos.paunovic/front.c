#include <stdio.h>
#include <stdlib.h>
struct Vojnik {
long long x;
long long y;
};

int main()
{
    struct Vojnik vojnik[1000000];
    long n,f=0;
    int i,j;
    scanf("%ld", &n);
    for (i=0;i<n;i++){
        scanf("%lld %lld", &vojnik[i].x,&vojnik[i].y);
    }
    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            if (vojnik[i].x <= vojnik[j].x && vojnik[i].y <= vojnik[j].y) {f++;}
        }
    }
    printf("%ld", f);
    return 0;
}
