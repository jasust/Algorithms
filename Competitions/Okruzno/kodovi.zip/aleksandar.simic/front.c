#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,x[100001],y[10001],f,k,j,i;
    scanf("%i",&n);
    k=1;
    f=n;
    
    for(i=1;i<=n;i++)
    {
                     scanf("%i %i",&x[i],&y[i]);
                     }
                     for(j=1;j<=n;j++)
                     {
                                      k=k+1;
                                    if(x[j]<=x[k] && y[j]<=y[k])
                                    {
                                                  f=f-1;
                                                  }
                                                  
                                                      
                                      }
                                      printf("\n %i",f);
                                      
                                      return 0;
                                      
                     
}
