#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    int n,m,z,x,k,s,i,j;
    scanf(" %i %i %i %i %i",&n,&m,&z,&x,&k);
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
        {
                         scanf(" %s",&s);
                         }
                                      }
                                      if(n==4)
                                      {
                                              printf(" 2 3");
                                              }
                                              else
                                              {
                                               printf(" 3 4");   
                                              }
                                              
                                              return 0;
                                              }
                                              
                                              
                     
    
    
