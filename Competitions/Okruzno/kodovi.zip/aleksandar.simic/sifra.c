#include<stdio.h>
#include<stdlib.h>
int main()
{
    int  n,m,i,a[1000001],j,l[100001],p,r,k;
    
    scanf("%i %i %i",&n,&m,&k);
    for(i=1;i<=n;i++)
    {
                     scanf(" %i", &a[i]);
                     }
                  for(j=2;j<=m;j++)
                  {
                                   l[j]=n*n ;
                                   }
                                   
                                   for(p=m;p>1;p--)
                                   {
                                                   
                                                   if(p==m)
                                                   {
                                                   if(k%l[p]==0)
                                                   {
                                                                printf("\n %i",a[n]);
                                                                }
                                                                else
                                                                {
                                                                    r=k%l[p];
                                                                   printf("\n %i",a[r]); 
                                                                }
                                                                
                                                   }
                                                   else
                                                   {
                                                      if(k%l[p]==0)
                                                   {
                                                                printf(" %i",a[n]);
                                                                }
                                                                else
                                                                {
                                                                    r=k%l[p];
                                                                   printf(" %i",a[r]); 
                                                                } 
                                                   }
                                                  
                                                          
                                                          
                                                   }
                                            if(k%n==0)
                                                   {
                                                          printf(" %i",a[n]);
                                                          
                                                          }
                                                          else
                                                          {
                                                              r=k%n;
                                                               printf(" %i",a[r]);
                                                          }         
                                                   
                              
                                   
                                        
                                        return 0;
                                        }
                                        
                                        
