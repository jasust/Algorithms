#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{   long long n,m,x,y,k,p=1,i;
    scanf("%lld%lld%lld%lld%lld",&n,&m,&y,&x,&k);
    y--;x--;
    char a[n][m];
    for(int i=0;i<n;i++)
      {for(int j=0;j<m;j++)
        {cin>>a[i][j];}
      }
      i=0;
      while(i<k)
      {if(p==1)
        {if(a[y+1][x]=='#' || y==n-1)
            {p++;i++;
            if(i==k)
              {break;}
            }
         else
         {y++;}
        }
       if(p==2)
         {if(a[y][x+1]=='#' || x==m-1)
           {p++;i++;
           if(i==k)
              {break;}
           }
           else
           {x++;}
         }
         if(p==3)
         {if(a[y-1][x]=='#' || y==0)
           {p++;i++;
           if(i==k)
              {break;}
           }
           else
           {y--;}
         }
         if(p==4)
         {if(a[y][x-1]=='#' || x==0)
           {p=1;i++;
           if(i==k)
              {break;}
           }
           else
           {x--;}
         }
      }
    printf("%lld %lld\n",y+1,x+1);
    return 0;
}
