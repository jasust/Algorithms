#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{   long long n,br=0,f=0;
    scanf("%lld",&n);
    long long x[n],y[n];
    for(int i=0;i<n;i++)
      {scanf("%lld%lld",&x[i],&y[i]);}
    for(int i=0;i<n;i++)
      {for(int j=0;j<n;j++)
        {if(x[i]<=x[j] && y[i]<=y[j] && i!=j)
          {br=1;}
        }
        if(br==0)
          {f++;}
        br=0;
      }
      printf("%lld\n",f);
    return 0;
}
