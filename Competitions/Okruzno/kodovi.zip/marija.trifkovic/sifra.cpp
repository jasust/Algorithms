#include <cstdlib>
#include <iostream>
#include <math.h>
using namespace std;

int main(int argc, char *argv[])
{   long long n,m,k,p,j;
    scanf("%lld%lld%lld",&n,&m,&k);
    long long a[n],b[m];
    for(int i=0;i<n;i++)
      {scanf("%lld",&a[i]);}
      if(k%n==0)
      {k-=n;}
    for(int i=1;i<=m;i++)
      {//if(i==1)
      //{p=pow(n,m-i);
        // j=(k/p)%n;b[i-1]=a[j];}
      if(i<m)
        {p=pow(n,m-i);
         j=(k/p)%n;
         //if(k%n==0)
         //{if(j=0)j=n-1;
         //else j--;}
         b[i-1]=a[j];}
       if(i==m)
         {j=k%n-1;
          if(k%n==0)
             {j=n-1;}
          b[i-1]=a[j];
         }
      printf("%lld ",b[i-1]);
      }
    return 0;
}
