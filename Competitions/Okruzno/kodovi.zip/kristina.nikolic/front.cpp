 #include <iostream>
#include <stdio.h>

using namespace std;
/*typedef struct
{
    double x;
    double y;
}tacka;*/
long  x [1010];
long y [1010];

int main()
{
int n,k;
long maxx,maxy,maxx1,maxy1,c,v;
k=1;
c=-1;
v=-1;
   maxx1=0;
    maxy1=0;
scanf("%d",&n);
for (int i=1,j=1;i<=n;i++,j++)
    {
      scanf("%ld%ld",&x[i],&y[j]);
    }
    maxx = x[1];
    maxy = y[1];
    for (int i=1;i<=n;i++)
    {
       if (x[i]>=maxx && y[i]>=maxy)
          {
              maxx=x[i];
              maxy=y[i];
          }
    }
    for (int i=1;i<=n;i++)
    {
           if (x[i]>maxx && maxx1<x[i] && c!=y[i])
          {
              maxx1=x[i];
              k++;
              c=y[i];
          }
          if (y[i]>maxy && maxy1<y[i] && v!=x[i])
          {
              maxy1=y[i];
              k++;
               v=x[i];

          }
    }
printf("%d",k);
return 0;
}
