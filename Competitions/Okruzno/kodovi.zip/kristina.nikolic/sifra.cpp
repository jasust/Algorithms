#include <iostream>
#include <stdio.h>

using namespace std;


long int  niz [101000];
int main()
{
    int m;
long long  n,k;
scanf("%lld%d%lld",&n,&m,&k);
for (int i=1;i<=n;i++)
{
    scanf("%ld",&niz[i]);
}
printf("%ld",niz[k]);
      return 0;
}

/*long int niz[101000];
int main()
{
    long long  n,k,m;
scanf("%lld%lld%lld",&n,&m,&k);
for (int i=1;i<=n;i++)
{
    scanf("%ld",&niz[i]);
}long int  niz [101000];
    niz2[i]=

    return 0;
}*/



