#include<cstdio>
#include<cstdlib>
int x[1000005],y[1000005],i,n,brojac,fx,fy;
int main ()
{
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        scanf("%d %d",&x[i],&y[i]);
    }
    fx=x[n];
    fy=y[n];
    brojac=1;


    for (i=n;i>=2;i--)
    {



        if ((fx>x[i-1]) and (fy<y[i-1])) { brojac++; fx=x[i-1]; fy=y[i-1];}
        if ((fx==x[i-1]) and (fy<y[i-1])) {fx=x[i-1]; fy=y[i-1];}


    }
    printf("%d",brojac);
    return 0;
}
