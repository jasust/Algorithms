#include<cstdio>
#include<cstring>
int n,m,lav[500][500],i,j,r,v,k,brojac,w,x,y,p;
char c[500];
int main ()
{
    scanf("%d %d",&n,&m);
    scanf("%d %d",&r,&v);
    scanf("%d",&k);
    for (i=0;i<=n-1;i++)
      {
      scanf("%s",&c);
      for (j=0;j<=m-1;j++)
        if (c[j]=='#') lav[i][j]=0;
           else lav[i][j]=1;
      }

brojac=0;
x=r;
y=v;
w=3;
            while (w>2)
      {
          if (brojac%4==0)
            if (lav[x+1][y]==0)
              brojac++; else x=x+1;

 if (brojac==k) w=1;
        if (brojac%4==1)
            if (lav[x][y+1]==0) brojac++;  else y=y+1;

 if (brojac==k) w=1;
        if (brojac%4==2)
            if (lav[x-1][y]==0) brojac++;else x=x-1;
 if (brojac==k) w=1;
        if (brojac%4==3)
            if (lav[x][y-1]==0) brojac++;
        else y=y-1;
        if (brojac==k) w=1;





      }

printf("%d %d\n",x,y);
return 0;
      }


