#include <iostream>
using namespace std;

long long x = 0,vreme = 0,kodovi = 0,kl = 0,kd = 0;

int n,first = 1,pd = 0;

struct s
{
    long long p,h;
}g[1000000];



int main()
{
    cin >> n >> x;
    for(int i = 0;i<n;i++)
    {
        cin >> g[i].p >> g[i].h;
        if(g[i].p < x)
        {
            kl += g[i].h;
        }
        else
        {
            if(first)
            {
                pd = i;
                first = 0;
            }
            kd += g[i].h;
        }
    }
    if(kd <= kl)
    {
        kodovi = 2*kd;
        kl = kd;
        int i = pd;
        while(kd > 0)
        {
            if(g[i].h <= kd)
            {
                vreme += 2 * (g[i].p - x) * g[i].h;
                kd -= g[i].h;
                i++;
            }
            else
            {
                vreme += 2 * (g[i].p - x) * kd;
                kd -= kd;
                i++;
            }
        }
        i = pd-1;
        while(kl > 0)
        {
            if(g[i].h < kl)
            {
                vreme += 2 * (x - g[i].p) * g[i].h;
                kl -= g[i].h;
                i--;
            }
            else
            {
                vreme += 2 * (x - g[i].p) * (kl-1);
                vreme += x - g[i].p;
                kl -= kl;
                i--;
            }
        }

    }
    else
    {
        kodovi = 1 + 2*kl;
        kd = kl + 1;
        int i = pd;
        while(kd > 0)
        {
            if(g[i].h < kd)
            {
                vreme += 2 * (g[i].p - x) * g[i].h;
                kd -= g[i].h;
                i++;
            }
            else
            {
                vreme += 2 * (g[i].p - x) * (kd-1);
                vreme += g[i].p - x;
                kd -= kd;
                i++;
            }
        }
        i = pd - 1;
        while(kl > 0)
        {
            if(g[i].h <= kl)
            {
                vreme += 2 * (x - g[i].p) * g[i].h;
                kl -= g[i].h;
                i--;
            }
            else
            {
                vreme += 2 * (x - g[i].p) * kl;
                kl -= kl;
                i--;
            }
        }
    }
    cout << kodovi << endl;
    cout << vreme;
    return 0;
}
