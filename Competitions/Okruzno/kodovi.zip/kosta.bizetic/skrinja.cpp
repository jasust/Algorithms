#include <iostream>
#include <algorithm>
using namespace std;

int n,k,s[13],minimum = 0,minko[13];

int minim(int a, int b)
{
    if(a < b) return a;
    return b;
}

void f(int red,int niz[],int ko[])
{
    if(red == n)
    {
        int mini = niz[0],maxi = niz[0];
        for(int i = 0;i < k;i++)
        {
            if(niz[i] > maxi)maxi = niz[i];
            if(niz[i] < mini)mini = niz[i];
        }
        if(maxi - mini < minimum)
        {
            minimum = maxi - mini;
            for(int j = 0;j<n;j++)
            {
                minko[j] = ko[j];
            }
        }
        return;
    }
    else
    {
        int ogr = minim(red+1,k);
        for(int i = 0;i<ogr;i++)
        {
            int a[13],b[13];
            for(int j = 0;j<k;j++)
            {
                a[j] = niz[j];
            }
            for(int j = 0;j<n;j++)
            {
                b[j] = ko[j];
            }
            a[i] += s[red];
            b[red] = i+1;
            f(red+1,a,b);
        }
    }
}

int main()
{
    cin >> n >> k;
    for(int i = 0;i<n;i++)
    {
        cin >> s[i];
        if(s[i] > minimum) minimum = s[i];
    }
    if(k > n)
    {
        cout << minimum << endl;
        for(int i = 0;i<n;i++)
        {
            cout << i+1 << " ";
        }
        return 0;
    }
    int a[13],b[13];
    for(int i = 0;i<13;i++)
    {
        a[i] = 0;
        b[i] = 0;
    }
    f(0,a,b);
    cout << minimum << endl;
    for(int i = 0;i<n;i++)
    {
        cout << minko[i] << " ";
    }
    return 0;
}
