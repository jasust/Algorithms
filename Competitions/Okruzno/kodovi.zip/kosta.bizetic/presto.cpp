#include <iostream>
#include <algorithm>
using namespace std;

int a[310][310],n,m,b[310][310],minimum;

struct s
{
    int k = 0,vr = 0;
}niz[310];

int cmp1(s a,s b)
{
    if(a.vr <= b.vr) return 1;
    else return 0;
}

int cmp2(s a,s b)
{
    if(a.vr >= b.vr) return 1;
    else return 0;
}

int main()
{
    cin >> n >> m;
    minimum = n + m;
    for(int i = 0;i<n;i++)
    {
        for(int j = 0;j<m;j++)
        {
            cin >> a[i][j];
        }
    }
    for(int i = 0;i<n;i++)
    {
        for(int j = 0;j<m;j++)
        {
            niz[j].vr = a[i][j];
            niz[j].k = j;
        }
        sort(niz,niz+m,cmp1);
        int p = 0;
        for(int j = 0;j<m;j++)
        {
            if(niz[j].vr != niz[p].vr)
            {
                p = j;
            }
            b[i][niz[j].k] = p;
        }
    }
    for(int j = 0;j<m;j++)
    {
        for(int i = 0;i<n;i++)
        {
            niz[i].vr = a[i][j];
            niz[i].k = i;
        }
        sort(niz,niz+n,cmp2);
        int p = 0;
        for(int i = 0;i<n;i++)
        {
            if(niz[i].vr != niz[p].vr)
            {
                p = i;
            }
            b[niz[i].k][j] += p;
            if(b[niz[i].k][j] < minimum)
            {
                minimum = b[niz[i].k][j];
            }
        }
    }
    cout << minimum;
    return 0;
}
