#include <cstdlib>
#include <iostream>
#include <cstdio>
using namespace std;
int c[100][100];
int main(int argc, char *argv[])
{
    int n,m,min=50,k,i,j,a[100][100];
    scanf("%d",&n);
    scanf("%d",&m);
    for(i=0;i<n;i++)
    for(j=0;j<m;j++)
    scanf("%d",&a[i][j]);
    for(i=0;i<n;i++)
    {
    for(j=0;j<m;j++)
    {
     for(k=0;k<m;k++)
     {
      if(k!=j && a[i][k]<a[i][j])
      {
      c[i][j]++;        
      }               
     }               
     } 
     }
     for(j=0;j<m;j++)
    {
    for(i=0;i<n;i++)
    {
     for(k=0;k<n;k++)
     {
      if(k!=i && a[k][j]>a[i][j])
      {
      c[i][j]++;        
      }               
     }               
     } 
     }
     for(i=0;i<n;i++)
     for(j=0;j<m;j++)
     {
                     if(c[i][j]<min)
                     min=c[i][j];
                    
     }
     printf("%d",min);
    return 0;
}
