#include <cstdlib>
#include <iostream>
#include <cstdio>
using namespace std;

int main(int argc, char *argv[])
{
    int n,x,hmin[10000],hmax[100000],a,max[100000],min[100000],bmax=0,bmin=0,h,p,i,k=0;
    long long int t=0,izlaz,br1=0,br2=0;
    scanf("%d",&n);
    scanf("%d",&x);
    for(i=0;i<n;i++)
    {
                    scanf("%d",&p);
                    scanf("%d",&h);
                    if(p<x)
                    {
                    min[bmin]=p;
                    hmin[bmin]=h;
                    bmin++;
                    br1=br1+h;
                    }
                    if(p>x)
                    {
                    max[bmax]=p;
                    hmax[bmax]=h;
                    bmax++;
                    br2=br2+h;
                    }
    }
    if(br1==0)
    {
      izlaz=1;
      t=max[0]-x;        
    }
    else
    {
    if(br1>=br2)
    {
     izlaz=br2*2; 
    for(i=0;i<bmax;i++)
     {
     t=t+(hmax[i]*2)*(max[i]-x);                            
     }
     i=bmin-1;
     while(k!=br2)
     {
     if(hmin[i]+k<br2)
     {
     t=t+(hmin[i]*2)*(x-min[i]);
     k=k+hmin[i];
     i--;           
     }
     else
     {
      t=t+(br2-k)*(x-min[i]);
      k=br2;   
     }        
     }
    }
    
    if(br1<br2)
    {
               izlaz=br1*2+1;   
    for(i=0;i<bmin;i++)
     {
     t=t+(hmin[i]*2)*(x-min[i]);                          
     } 
     i=0;
     while(k!=(br1+1))
     {
     if(hmax[i]+k<br1)
     {
     t=t+(hmax[i]*2)*(max[i]-x);
     k=k+hmax[i];
     i++;       
     }
     else
     {
      t=t+(br1+1-k)*(max[i]-x)+max[i]-x;
      k=br1+1;   
     }
             
}
    }
}
    printf("%lld\n",izlaz);
    printf("%lld",t);
    return 0;
}
