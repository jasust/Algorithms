#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;

int main(int argc, char *argv[])
{
    int n,k,i,x,y,c,d,a[100];
    scanf("%i",&n);
    scanf("%i",&k);
    for(i=1;i<=n;i++)
    {
    scanf("%i",&a[i]);
     }
if(n==2)
{
i=1;
 x=a[1]-a[2];
 if(x<0)
 printf("%i\n",x*(-1));
 else
 printf("%i\n",x);   
 printf("%i %i",i,i+1);    
}
if(n==3)
{
       if(k==2)
       {
       i=1;
      x=a[1]+a[3]-a[2];
      y=a[1]+a[2]-a[3];
      c=a[2]+a[3]-a[1];
      d=min(x,y);
      x=min(d,c);
      printf("%i\n",abs(x));
      if(x==c)
      printf("%i %i %i",i,i+1,i+1); 
      else
      {
       if(d==y)
       {
               i=1;
        printf("%i %i %i",i,i,i+1);        
       }
       else
       {
           i=1;
       printf("%i %i %i",i,i+1,i); 
       }   
      }
           
       }
       if(k==3)
       {
       i=1;
       x=max(a[1],a[2]);
       y=max(x,a[3]);
       c=min(a[1],a[2]);
       d=min(c,a[3]);
       x=y-d;
       printf("%i\n",abs(x));
       printf("%i %i %i",i,i+1,i+2);  
       } 
}
    return 0;
}
