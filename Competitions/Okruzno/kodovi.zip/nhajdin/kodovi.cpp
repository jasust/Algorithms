// kodovi.cpp : Defines the entry point for the console application.
//

#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

vector <int> Px;
vector <int> Ph;
int Delta, TrgtIdx, N;
bool END=false;

void findR(int X)
{
	int i=0;
	X++;
	while(X>Px[i] || Ph[i]==0)
	{
		i++;
		if(i>N-1)
		{
			END=true;
			break;
		}
	}
	TrgtIdx=i;
	Delta= Px[i]-X+1;
}

void findL(int X)
{
	int i=N-1;
	X--;
	while(X<Px[i] || Ph[i]==0)
	{
		i--;
		if(i<0)
		{
			END=true;
			break;
		}
	}
	TrgtIdx=i;
	Delta= X-Px[i]+1;
}


int main()
{
	int X, t=0, B=0;
	cin>>N>>X;

	bool Dir=true;




	for(int n=0; n<N; n++)
	{
		int tmpx, tmph;
		cin>>tmpx>>tmph;
		Px.push_back(tmpx);
		Ph.push_back(tmph);
	}

	while(true)
	{
		if(Dir)
		{
			findR(X);
			if(END) break;
			t+=Delta;
			X+=Delta;
			Ph[TrgtIdx]--;
			B++;
			Dir=false;
		}
		else
		{
			findL(X);
			if(END) break;
			t+=Delta;
			X-=Delta;
			Ph[TrgtIdx]--;
			B++;
			Dir=true;
		}
	}

	cout<<B<<'\n'<<t;

	for(;;);
	
	return 0;
}

