// Skrinja.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <cstdlib>

using namespace std;

int PP[13], OPP[13];	
long Poglavlje[13];
long SumPerica[13];
int N, K, MAX=999999;


int MxDiff()
{
	int max=SumPerica[0];
	int min=SumPerica[0];

	for(int i=1; i<K; i++)
		{if(max<SumPerica[i])
		max=SumPerica[i];}

	
	for(int i=1; i<K; i++)
		{if(min>SumPerica[i])
		min=SumPerica[i];}

	return max-min;

}

void SumOfPrc()
{
	for(int i=0; i<N; i++)
		SumPerica[i]=0;

	for(int i=0; i<N; i++)
		SumPerica[PP[i]]+=Poglavlje[i];

}

void Btrack(int Step)
{
	if(Step<N)
	{
		for(int i=0; i<K; i++)
		{
			PP[Step]=i;
			Btrack(Step+1);
		}
	}
	else
	{
		SumOfPrc();
		if(MxDiff()<MAX)
		{
			MAX=MxDiff();
			for(int i=0; i<N; i++)
			{
				OPP[i]=PP[i];
			}
		}
	}

}


int main()
{

	cin>>N>>K;

	for(int i=0; i<N; i++)
	{
		cin>>Poglavlje[i];
		PP[i]=0;
	}

	Btrack(0);

	cout<<MAX<<'\n';

	for(int i=0; i<N; i++)
		cout<<OPP[i]+1<<' ';

	return 0;
}

