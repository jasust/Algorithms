#include <cstdio>
#include <algorithm>
using namespace std;

int n, m, j, i, br = 0, h[303][303], a[90004], b[90004];

int main()
{
    scanf("%d%d", &n, &m);
    for (i=0; i<n; i++)
    for (j=0; j<m; j++) { scanf("%d", &h[i][j]); a[br++] = h[i][j]; }
    sort(a,a+br);
    b[0] = 1;
    for (i=1; i<br; i++) if (a[i]==a[i-1]) b[i]=b[i-1]; else b[i]=b[i-1]+1;
    for (i=0; i<n; i++)
    for (j=0; j<m; j++) 
    { 
        int l = 0, r = br-1;
        while (l<=r)
        {
              int mid = (l+r)>>1;
              if (h[i][j]==a[mid]) { h[i][j]=b[mid]; break; }
              if (h[i][j]>a[mid]) l = mid+1; else r = mid - 1;
        }
    }
    
    //aaa, nemam vremena
    printf("0"); 
    
    
    return 0;   
    
}
