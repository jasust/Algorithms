#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>

int a[301][301];
using namespace std;

int main()
{
    int N,M,br1=0,br=M*N;
    scanf("%d%d",&N,&M);
    for(int i=0;i<N;i++)
       for(int j=0;j<M;j++)
          scanf("%d",&a[i][j]);
for(int i=0;i<N;i++)
    for(int j=0;j<M;j++)
    {
            br1=0;
            for(int i1=0;i1<M;i1++)
                    if(a[i][i1]<a[i][j])
                      br1++;
            for(int i2=0;i2<N;i2++)
                    if(a[i2][j]>a[i][j])
                      br1++;
            if(br1<br)
              br=br1;
    }
    printf("%d",br);
    return 0;
} 
 
