#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>

long long N,X,a[100000],b[100000],c[100000];

using namespace std;

int main()
{
    int q=0;
    long long br;
    c[0]=0;
    scanf("%lld %lld",&N,&X);
    
    if(N==2)
    {
            for(int i=1;i<=N;i++)
            scanf("%lld%lld",&a[i],&b[i]);
            if(X<a[1])                        //ako se nalazi sa leve strane
            {
                                              printf("1\n");
                                              printf("%lld",a[1]-X);
            }
            else
            {
                if(b[2]>b[1])//ako ide levo
                {
                              printf("%lld\n",(b[1]*2+1));
                              printf("%lld",b[1]*2*(a[2]-a[1])+a[2]-X);
                }
                else
                {
                              printf("%lld\n",b[2]*2);
                              printf("%lld",b[1]*2*(a[2]-a[1])+a[2]-X-b[1]*(a[2]-a[1]));
                }
            }
    }
    else
    {
        for(int i=1;i<=N;i++)
       {
            scanf("%lld%lld",&a[i],&b[i]);
            c[i]=c[i-1]+b[i];
            if(q==0)
            {
                    if(a[i]>X)
                    {
                              c[i]=b[i];
                              br=i-1;
                              q=1;
                    }
            }
       }
       if(c[br]<c[N])//ide na levo
       {
                    printf("%lld\n",2*c[br]+1);
                    printf("1");
       }
       else
       {
           printf("%lld",2*c[N]);
           printf("2");
       }
    }
    return 0;
}
