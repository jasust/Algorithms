#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>

int a[14],b[14],c[14],r[14],razsljika=100000000;
int min,max,N,K;

void Sta_mi_gledas_kod()
{
     min=100000000;max=0;
    for(int i=0;i<N;i++)
    {
            b[c[i]]+=a[i];
    }
    for(int i=0;i<K;i++)//min i max
    {
            if(b[i]>max)max=b[i];
            if(b[i]<min)min=b[i];
    }
    if(max-min<razsljika)
      {
                         razsljika=max-min;
                         for(int i=0;i<14;i++)
                         {
                                 r[i]=c[i];
                         }
      }
}
void Da_me_pitas_ni_sam_ne_znam_sta_sam_pisao(int W)
{
     for(int i=0;i<K;i++)
     {
             c[W]=i;
             if(W==N-1)
               Sta_mi_gledas_kod();
             else
             {
                    Da_me_pitas_ni_sam_ne_znam_sta_sam_pisao(W+1);
             }
     }
}
/*
void f()
{
     for(int j=0;j<N;j++)
        Da_me_pitas_ni_sam_ne_znam_sta_sam_pisao(j);
}
*/
//i+1

using namespace std;

// ZNACI PRESTANI DA BULJIS VISE!!!

int main()
{
    for(int i=0;i<14;i++)
    {a[i]=0;b[i]=0;r[i]=0;}
    scanf("%d%d",&N,&K);
    for(int i=0;i<N;i++)
       scanf("%d",&a[i]);
    Da_me_pitas_ni_sam_ne_znam_sta_sam_pisao(0);
    printf("%d\n",razsljika);
    for(int i=0;i<N;i++)
    {
            printf("%d ",r[i]);
    }
    for(;;);
}
