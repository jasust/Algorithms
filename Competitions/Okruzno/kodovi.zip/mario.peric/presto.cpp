#include <iostream>
#include <stdio.h>
//
using namespace std;

int N, M;
long long H[305] [305];
int A[305] [305];

int brRed(int x, int y)
{
    int i, k;
    k = 0;
    for (i = 0; i < N; i++)
    {
        if ((i != x) && (H[i][y] > H[x][y]))
        {
            k+=1;
        }
    }
    return k;
}

int brKol(int x, int y)
{
    int i, k = 0;
    k = 0;
    for (i = 0; i < M; i++)
    {
        if ((i != y) && (H[x][i] < H[x][y]))
        {
            k+=1;
        }
    }
    return k;
}

int minN()
{
    int k = 305;
    int i, j;
    for (i = 0; i < N; i++)
        for (j = 0; j < M; j++)
            if (A[i][j] < k)
                k = A[i][j];
    return k;
}

int main()
{
    int i, j;
    scanf("%d %d", &N, &M);
    for (i = 0; i < N; i++)
        for (j = 0; j < M; j++)
        {
            scanf("%lld",&H[i][j]);
        }
     for (i = 0; i < N; i++)
     {
        for (j = 0; j < M; j++)
        {
            A[i][j] = brRed(i,j) + brKol(i,j);
        }
     }
    int stanje = minN();
    printf("%d",stanje);
    return 0;
}
