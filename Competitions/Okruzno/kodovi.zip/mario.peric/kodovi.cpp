#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <math.h>

using namespace std;

struct code
{
    long long P;
    long long H;
};

code A[100005];
int N;
long long X;
long long br, put;

int sledeci(int x)
{
    int i;
    for (i = 0; i < N; i++)
        if ((A[i].H > 0) && (A[i].P > x))
            return i;
    return -1;
}

int prethodni(int x)
{
    int i;
    for (i = N; i >= 0; i--)
        if ((A[i].H > 0) && (A[i].P < x))
            return i;
    return -1;
}

void Rekurzija(bool desno)
{
    if (desno)
    {
        int sled = sledeci(X);
        A[sled].H--;
        put += A[sled].P - X;
        br++;
        X = A[sled].P;
        if (prethodni(X) != -1)
            Rekurzija(!desno);
    }
    else
    {
        int pret = prethodni(X);
        A[pret].H--;
        put += X - A[pret].P;
        br++;
        X = A[pret].P;
        if (sledeci(X) != -1)
            Rekurzija(!desno);
    }

}

int main()
{
    br = 0;
    put = 0;
    int i;
    scanf("%d %lld", &N , &X);
    for (i = 0; i < N; i++)
    {
        scanf("%lld %lld",&A[i].P, &A[i].H);
    }
    Rekurzija(true);
    printf("%lld\n%lld",br,put);
    return 0;
}
