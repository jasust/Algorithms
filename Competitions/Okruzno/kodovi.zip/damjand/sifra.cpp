#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <math.h>
using namespace std;

int main()
{
    int n,m,i=0;
    int k;
    scanf("%d %d %d",&n,&m,&k);
    int a[n];
    while(i<n)
    {
        scanf("%d",&a[i]);
        i++;
    }
    sort(a,a+n);
    i=0;
    while(++i>m)
    {printf("%d",a[i]);}
    return 0;
}
