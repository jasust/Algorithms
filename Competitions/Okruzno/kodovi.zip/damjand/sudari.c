#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
int main()
{

    int n,m,x,y,k,i=0,j=0;
    scanf("%d %d",&n,&m);
    scanf("%d %d",&y,&x);
    scanf("%d",&k);
    char a[1000][1000];
    while(i<n)
    {
        while(j<m)
            {scanf("%c",&a[i][j]);
            }
        i++;
        j=0;
    }
    while(1)
    {
        while(a[y+1][x]=='.')
        {
            y++;
        }
        k--;
        if(k==0)
            goto next;
        while(a[y][x+1]=='.')
        {
            x++;
        }
        k--;
        if(k==0)
            goto next;
        while(a[y-1][x]=='.')
        {
            y--;
        }
        k--;
        if(k==0)
            goto next;
        while(a[y][x-1]=='.')
        {
            x--;
        }
        k--;
        if(k==0)
           goto next;
    }
    next:
        x++;
        y++;
    printf("%d %d",y,x);
    return 0;



}
