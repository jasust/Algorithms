#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    int n,i=0;
    scanf("%d",&n);
    int x[n],y[n];
    while(i<n)
    {
        scanf("%d %d",&x[i],&y[i]);
        i++;
    }
    i=0;
    int j,m=0;;
    while(i<n)
    {j=i+1;
        while(j<n)
        {
            if(y[j]>=y[i])
            {
                goto next;
            }
            j++;
        }
        m++;
        next:
        i++;
    }
    printf("%d",m);
    return 0;
}
