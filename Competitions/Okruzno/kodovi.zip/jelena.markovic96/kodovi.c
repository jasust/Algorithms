#include <stdio.h>
#include <stdlib.h>

typedef struct stub
{
    unsigned long koordinata;
    unsigned long velicina;
} Stub;

int main()
{
    Stub a[100000];
    unsigned long i,n,x,minp,maxp;
    long long broj_kod,broj_sek;
    char p;
    broj_kod=0;
    broj_sek=0;
    scanf("%ld%ld\n",&n,&x);
    for (i=1;i<=n;i++)
       scanf("%ld%ld",&a[i].koordinata,&a[i].velicina);
    /*for (i=1;i<=n;i++)
      printf("%ld %ld\n",a[i].koordinata,a[i].velicina);*/
    i=1;
    while (a[i].koordinata<x)
          i++;
    minp=i-1;
    maxp=i;
      //printf("%lld ",broj_sek);

    broj_sek+=a[maxp].koordinata-x;
    p='t';
   // printf("%ld %ld %lld ",a[maxp].koordinata,x,broj_sek);
    while ((minp>=1) && (maxp<=n))
    {
                  if (a[minp].velicina > a[maxp].velicina)
                  {
                      broj_kod+=2*a[maxp].velicina;
                      a[minp].velicina-=a[maxp].velicina;
                      broj_sek+=(2*a[maxp].velicina-1)*(a[maxp].koordinata-a[minp].koordinata);
                      maxp++;
                      if (maxp<=n)
                        broj_sek+=a[maxp].koordinata-a[minp].koordinata;
                  }
                  if (a[minp].velicina < a[maxp].velicina)
                  {
                        broj_kod+=2*a[minp].velicina+1;
                        a[maxp].velicina-=a[minp].velicina+1;
                        broj_sek+=(2*a[minp].velicina)*(a[maxp].koordinata-a[minp].koordinata);
                        minp--;
                        if (minp>=1)
                            broj_sek+=a[maxp].koordinata-a[minp].koordinata;
                  }
                  if (a[minp].velicina==a[maxp].velicina)
                  {
                       broj_kod+=2*a[minp].velicina-1;
                       broj_sek+=(2*a[minp].velicina-1)*(a[maxp].koordinata-a[minp].koordinata);
                       minp--;
                       maxp++;
                  }
                  p='n';
    }

    printf("%lld\n%lld",broj_kod,broj_sek);
    return 0;
}
