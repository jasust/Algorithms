#include <stdio.h>
#include <stdlib.h>

void komb(int *b,int n,int k)
{
    int i;
    b[1]++;
    for(i=1;i<=n;i++)
      if (b[i]==k)
    {
        b[i]=1;
        b[i+1]++;
    }
}
int main()
{
    int n,k,i,j,pozmax,pozmin;
    long vred,vred_min;
    vred_min=100000001;
     int *a;
    int b[13],bpravo[13],pp[13];
    scanf("%d%d",&n,&k);
   for (i=1;i<=n;i++)
        scanf("%d",&a[i]);
    for(i=1;i<=n+1;i++)
        b[i]=1;
    while (b[n+1]!=2)
    {
        komb(b,n,k);
        for(j=1;j<=n;j++)
            pp[j]=0;
        for(i=1;i<=n;i++)
         {
            switch (b[i])
          case 1:pp[1]+=a[n-i+1];
             break;
           case 2:pp[2]+=a[n-i+1];
             break;
           case 3:pp[3]+=a[n-i+1];
             break;
           case 4:pp[4]+=a[n-i+1];
             break;
           case 5:pp[5]+=a[n-i+1];
             break;
           case 6:pp[6]+=a[n-i+1];
             break;
           case 7:pp[7]+=a[n-i+1];
             break;
            case 8:pp[8]+=a[n-i+1];
             break;
            case 9:pp[9]+=a[n-i+1];
             break;
            case 10:pp[10]+=a[n-i+1];
             break;
             case 11:pp[10]+=a[n-i+1];
             break;
             case 12:pp[10]+=a[n-i+1];
             break;
               case 13:pp[10]+=a[n-i+1];
             break;}
        pozmin=1;
        pozmax=1;
        while (j<=n)
        {
            if (pp[j]<pp[pozmin])
              pozmin=j;
            if (pp[j]<pp[pozmax])
              pozmax=j;
            j++;
        }
        vred=pp[pozmax]-pp[pozmin];
        if (vred<vred_min)
        {
            vred_min=vred;
            for(j=1;j<=n;j++)
                bpravo=pp[j];
        }

    }
    printf("%ld",vred_min);
    for(j=1;j<=n;j++)
        printf("%d",pp[j]);
    return 0;
}
