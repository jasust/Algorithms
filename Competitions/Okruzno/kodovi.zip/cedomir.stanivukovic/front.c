#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int X,Y,n,i,j;
    scanf("%d",&n);
for(i=0;i<n;i++){
    for(j=i+1;j>n;j++);
    scanf("%d",&X);
    scanf("%d",&Y);}{
if(y[i]<y[n])
printf("%d \n",X);
printf("%d \n",Y);
    return 0;
}
