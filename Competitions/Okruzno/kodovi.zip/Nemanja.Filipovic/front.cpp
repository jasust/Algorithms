#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;


typedef struct{
        long int x;
        long int y;
        } vojnik;
vojnik niz[1000001];

int main()
{
    long int n;
    long long cnt = 0;
    scanf("%ld", &n);
    for(long long i = 0; i<n; i++){
             scanf("%ld%ld", &niz[i].x, &niz[i].y);
             }
    for(long long i = 0; i < n; i++){
             bool exists = true;
             for(long long j = i+1; j < n; j++){
                           if(niz[i].y <=  niz[j].y && niz[i].x <= niz[j].x){
                                       exists = false;
                                       break;
                           }
                      }
             if(exists) cnt++;
             }
    printf("%lld", cnt);
    return 0;    
}
