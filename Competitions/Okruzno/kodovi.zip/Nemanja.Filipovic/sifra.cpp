#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;
long int nums[100001];
long int outs[100001];
int main()
{
    unsigned long long int n,m;
    unsigned long long int k;
    cin >> n;
    cin >> m;
    cin >> k;
    
    k--;
    for(int i = 0; i < n; i++)
          scanf("%ld", &nums[i]);  
    
    for(int i = 0; i < m; i++){
            
              outs[i] = nums[k%n];
              k = (long int) (k / n);

            }
    for(int i = m - 1; i >= 0; i--)
            printf("%ld ", outs[i]);
    return 0;
}
