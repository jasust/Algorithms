#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;
typedef struct{
               int x;
               int y; 
               int step;
        
        } visited;
visited lst[4];
char matrix[501][501];
int dirx[] = {0,1,0,-1};
int diry[] = {1,0,-1,0};
int main()
{
    for(int i = 0; i < 4; i++){
              lst[i].x = -1;
              lst[i].y = -1;
              lst[i].step = -1;   
            }
    int n ,m;
    int y, x;
    int startx, starty;
    unsigned long long k;
    scanf("%d%d%d%d", &n, &m, &y, &x);
    cin >> k;
    
    for(int i = 0; i < n; i++)
            for(int j = 0; j < m; j++)
                      scanf(" %c ", &matrix[i][j]);
    int dir = 0;
    x--;
    y--;
    startx = x;
    starty = y;
    unsigned long long int cnt = 0;
    for(;;){
              y+=diry[dir];
              x+=dirx[dir];
              if(y > m || x > n || matrix[y][x] != '.'){
                     cnt++;
                     y-=diry[dir];
                     x-=dirx[dir];
                     dir = (dir + 1) % 4;
                     if(x == lst[dir].x && y == lst[dir].y && lst[dir].step !=-1)
                          cnt+=(unsigned long long int) (cnt - (unsigned long long int) lst[dir].step)*
                          ((unsigned long long int) ((k - cnt) / ((unsigned long long int) cnt- (unsigned long long int)lst[dir].step)));
                     
                     lst[dir].x = x;
                     lst[dir].y = y;
                     lst[dir].step = cnt;
                     if(cnt == k) break;
                   }
              
            
            }
    
    x++;
    y++;
    printf("%d %d",y,x);
    
    return 0;
}
