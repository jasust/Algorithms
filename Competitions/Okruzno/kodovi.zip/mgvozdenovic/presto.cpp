#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{ printf("3");
return 0;
}
