#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{
    int n,a1=0,b1=0;
    long int x, p[10000],h[10000],a[10000],b[10000],ha[10000],hb[10000];
    long long sec=0,br=0,levi,desni;
    scanf("%d %ld",&n,&x);
    for(int i=0;i<n;i++)
    scanf("%ld %ld",&p[i],&h[i]);
    for(int i=0;i<n;i++)
    {
    if(p[i]<x) {a[a1]=x-p[i]; ha[a1]=h[i];a1++;levi+=h[i];}
    else {b[b1]=p[i]-x;hb[b1]=h[i];b1++;desni+=h[i];}}
    if(levi<desni)
    br=2*levi+1; 
    else br=2*desni;
    if(levi<desni)
     {for(int i=0;i<=a1;i++)
      sec+=2*a[i]*ha[i];
       long int j=0;
       
      for(int k=0;k<=b1;k++)
       {if(j>levi) break;
        if(j+hb[k]>levi)
        sec+=2*(levi-j)*b[k]+b[k]; 
        if(j+hb[k]==levi)
       { sec+=2*hb[k]*b[k]+b[k+1];break;}
        if(j+hb[k]<levi) 
        sec+=2*hb[k]*b[k]; 
        j+=hb[k];}   
        }
    if(levi==desni)
        {for(int i=0;i<=a1;i++)
         sec+=2*a[i]*ha[i];
         for(int j=0;j<=b1;j++)
         sec+=2*hb[j]*b[j];
         sec-=a[0];}
    if(levi>desni)
      {for(int i=0;i<=b1;i++)
       sec+=2*hb[i]*b[i];
      
       long int j=0;
       for(int k=a1;k>=0;k--)
        {if(j>desni) break; 
        if(j+ha[k]>desni)sec+=2*(desni-j)*a[k]-a[k];
        if(j+ha[k]==desni) {sec+=2*ha[k]*a[k]-a[k]; break;}
        if(j+ha[k]<desni) sec+=2*ha[k]*a[k];
        j+=ha[k];}
        }
  printf("%lld\n",br);
  printf("%lld\n",sec);
      
      return 0;
      }
