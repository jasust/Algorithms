#include <stdio.h>
int main ()
{
    long long N, i=0, j=0, x[1000000], y[1000000], F=0, m=0, n=0, h=0, g=0, t=0;
    scanf("%lld", &N);
    
    
    for(i=0; i<N; i++)
    {
             scanf("%lld %lld", &x[i], &y[i]);
    }    
    
    
    for(i=0; i<N; i++)
    {
             j=j+1;
                      if(y[i]>y[j])
                      F=F+1;
                      
                      
                      
                            
                
             
             
             
             
    }
    
   
    
    
    if(N==1)
    F=1;
    
    
    printf("%lld", F);    
    return 0;
}
