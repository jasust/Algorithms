#include <stdio.h>
#include <iostream>

using namespace std;
int main()
{
   unsigned n,k,a[10000],br=0;
   cin >> n >> k;
   for(int i=0;i<n;i++)
    cin>> a[i];
   for(int i=0;i<n;i++)
    br+=a[i];
   if(k==1)
   {
    cout << br << endl;
    for(int i=0;i<n;i++)
     cout << 1 << ' ';
   }
   system("PAUSE");    
}   
