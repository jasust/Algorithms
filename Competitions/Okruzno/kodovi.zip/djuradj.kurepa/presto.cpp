#include <stdio.h>
#include <iostream>
#include <cmath>

int h[10000][10000]; 
int n,m;


int nesto(int p,int q)
{
int br=0;    
for(int i=1;i<=m;i++)
 if(h[p][q]>h[p][i])
  br++;
return br;
}  
  

using namespace std;
int main()
{
    int k[10000],max,p,q;
    cin >> n >> m;
    for(int i=1;i<=n;i++)
     for(int j=1;j<=m;j++)
      cin >> h[i][j];
    for(int i=1;i<=m;i++)
    {
            max=h[1][i];
            p=1;
            q=i;
            for(int j=2;j<=n;j++)
             if(max<h[j][i])
             {
              max=h[j][i];
              p=j;
              q=i;
             }                  
             k[i]=nesto(p,q);
    }
    max=k[1];
    for(int i=2;i<=m;i++)
     if(max>k[i])
      max=k[i];
    printf("%d\n",max);
    system("PAUSE");           
}                    
      
      
 
