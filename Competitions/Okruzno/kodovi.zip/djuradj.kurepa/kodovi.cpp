#include <stdio.h>
#include <iostream>
#include <string>
#include <cmath>

int p[100000],h[100000];


int pozicija(int x, int n)
{
    for(int i=0;i<n;i++)
     if(p[i]>x && p[i-1]<x)
      return i;
}      

int nesto(int n, int x, int i, int *br, int *vreme)
{
    bool z=true;
    int j=i-1;
    int m=1;
  
    while(m)
     if(z)
         if(h[i])
         {
           h[i]--;
           *br=*br+1;
           *vreme=*vreme+abs(p[i]-x);           
           x=p[i];
           z=false;
         }
         else
          {
           i=i+1;
           if(i==n+1)
            return 0;
           else
           {
            h[i]--;
            *br=*br+1;
            *vreme=*vreme+abs(p[i]-x);           
            x=p[i];
            z=false;
           }
          }
     else
      if(h[j])
      {
              
              h[j]--;
              *br=*br+1; 
              *vreme=*vreme+abs(p[j]-x);
              x=p[j];
              z=true;
      }
       else
       {
           j--;
           if(j==0)
            return 0;
           else
           {
               h[j]--;
               *br=*br+1;
               vreme=vreme+abs(p[j]-x);
               x=p[j];
               z=true;
           }
       }
}     
            
                   
                    
            
using namespace std;
int main()
{
    int n,x,br=0,i,j,vreme=0;
    cin >> n >> x;
    for(i=1;i<=n;i++)
    {
            cin >> p[i];
            cin >> h[i];
    }       
    i=pozicija(x,n);
               
    j=nesto(n,x,i,&br,&vreme);
    printf("%d\n%d",br,vreme);
    system("PAUSE");
    return 0;
}
