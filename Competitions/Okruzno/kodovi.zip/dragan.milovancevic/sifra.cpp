#include <stdio.h>

int a[100000], s[100000], q;
long long int k;
int n, m;

void f()
{
    long long int p=1, o=0;
    for(int i=0; i<m; ++i)
    {
        if(p<9223372036854775807/n)
        {
            s[i]=((k-1)/p)%n;
            o+=s[i];
            p*=n;
        }
        else
        {
            p=-1;
            q=i;
            break;
        }
        if(p==-1)
        {
            for(int i=q; i<m; ++i)
                s[i]=1;
        }
    }
}

int main()
{
    scanf("%d%d%lld", &n, &m, &k);
    for(int i=0; i<n; ++i)
    {
        scanf("%d", &a[i]);
    }
    f();
    for(int i=m-1; i>-1; --i)
    {
        printf("%d ", a[s[i]]);
    }
    return 0;
}
