#include <stdio.h>

int x[1000000], y[1000000];

int main()
{
    int n, r, ym;
    scanf("%d", &n);
    for(int i=0; i<n; ++i)
    {
        scanf("%d%d", &x[i], &y[i]);
    }
    ym=y[n-1];
    r=1;
    for(int i=n-2; i>-1; --i)
    {
        if(x[i]!=x[i+1])
             if(y[i]>ym)
             {
                 ++r;
                 ym=y[i];
             }
        else
        {
            if(y[i]>ym)
             {
                 ym=y[i];
             }
        }
    }
    printf("%d", r);
    return 0;
}
