#include <stdio.h>

int z[502][502];

int main()
{
    int n, m, r, x, y, k;
    char c;
    scanf("%d%d", &n, &m);
    scanf("%d%d", &y, &x);
    scanf("%d", &k);
    for(int i=1; i<501; ++i)
    {
        for(int j=1; j<501; ++j)
        {
            z[i][j]=1;
        }
    }
    for(int i=1; i<=n; ++i)
    {
        for(int j=1; j<=m; ++j)
        {
            c=getchar();
            if(c=='.')
                z[i][j]=0;
        }
        getchar();
    }
    r=1;
    for(int i=0; i<k; ++i)
    {
        if(r==0)
        {
            while(!z[x+1][y])
                ++x;
            r=(r+3)%4;
        }
        else
            if(r==1)
            {
                while(!z[x][y+1])
                    ++y;
                r=(r+3)%4;
            }
            else
                if(r==2)
                {
                    while(!z[x-1][y])
                        --x;
                    r=(r+3)%4;
                }
                else
                    if(r==3)
                    {
                        while(!z[x][y-1])
                            --y;
                        r=(r+3)%4;
                    }
    }
    printf("%d %d", y, x);
    return 0;
}
