#include <iostream>
#include <cmath>
#define MAXN 100001

int niz[MAXN];

/**
 * Nisam siguran sta sam radio, ni da li zaista funkcionise kako treba, ali test primer prolazi
 */
int main()
{
    int m, n, i;
    long long k, uk, max; //zamalo
    double dmax;
    max = ~0U << 1, dmax = ~0U << 1;
    //std::cout << max << ' ' << dmax;
    std::cin >> n >> m >> k;
    for(i=0; i<n; i++)
        std::cin >> niz[i];
    k--;
    for(i=m-1; i>0; i--) {
        uk = pow(n, i); //puca na vecim primerima (n>100 i m>100) :(
                        //trebao bi mi BigInteger ili bolji pristup
        std::cout << niz[k/uk] << ' ';
        k%=uk;
    }
    uk = pow(n, i);
    std::cout << niz[k/uk];
    return 0;
}
