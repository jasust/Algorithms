#include <iostream>
#define MAXMN 500
//#define DEBUG
#define GORE 0
#define DESNO 1
#define DOLE 2
#define LEVO 3

//nepotrebno (x i y se mogu deklarisati i unutar Drejka), 
//ocekivao sam da ce biti korisnije
typedef struct {
    int x, y;
} Tacka;

typedef struct {
    Tacka poz;
    int smer;
} Drejko;

bool matrica[MAXMN][MAXMN];

bool idiNapred(Drejko* d, int maxx, int maxy) {
    switch(d->smer) {
    case GORE:
        if(d->poz.y==0 || !matrica[d->poz.y-1][d->poz.x])
            return false;
        else {
            d->poz.y--;
            return true;
        }
    case DOLE:
        if(d->poz.y==maxy || !matrica[d->poz.y+1][d->poz.x])
            return false;
        else {
            d->poz.y++;
            return true;
        }
    case LEVO:
        if(d->poz.x==0 || !matrica[d->poz.y][d->poz.x-1])
            return false;
        else {
            d->poz.x--;
            return true;
        }
    case DESNO:
        if(d->poz.x==maxx || !matrica[d->poz.y][d->poz.x+1])
            return false;
        else {
            d->poz.x++;
            return true;
        }
    default:
        #ifdef DEBUG
            std::cerr << "wtf" << "\t" << d->smer;
        #endif // DEBUG
        return false;
    }
}

void skreni(Drejko* d) {
    d->smer = (d->smer + 3)%4;
    #ifdef DEBUG
    std::cout << "sada idem " << d->smer << '\n';
    #endif // DEBUG
}

int main()
{
    int n, m;
    long long k, sudara=0;
    char in;
    Drejko d;
    d.smer = DOLE;
    std::cin >> n >> m >> d.poz.y >> d.poz.x >> k;
    d.poz.y--, d.poz.x--;
    for(int i=0; i<n; i++)
        for(int j=0; j<m; j++) {
            std::cin >> in;
            matrica[i][j] = in=='.';
    }
    while(sudara<k) {
        if(!idiNapred(&d, m-1, n-1)) {
            #ifdef DEBUG
            std::cout << "Skrecem na " << d.poz.x << ", " << d.poz.y << '\n';
            #endif // DEBUG
            sudara++;
            skreni(&d);
        }
    }
    std::cout << d.poz.y+1 << ' ' << d.poz.x+1;
    return 0;
}
