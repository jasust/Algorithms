#include <iostream>
#include <algorithm>
#define MAXN 1000005

struct Tacka {
 int x, y;
 /*bool operator<(Tacka* t) {
    return t->y < y;
 }
 bool operator==(Tacka* t) {
    return t->y == y;
 }
 bool operator>(Tacka* t) {
    return t->y > y;
 }*/
};

//---
//A imao sam toliko lepih ideja, samo nijednu nisam prebacio u kod koji radi brze od bruteforce
//---

/*Tacka vojnici[MAXN];
Tacka** sortedX[MAXN];
Tacka* sortedY[MAXN];
bool used[MAXN];

int compY(const void* el1, const void* el2) {
    Tacka* t1 = (Tacka*)el1, *t2 = (Tacka*)t2;
    if(t1->y >  t2->y) return 1;
    else return -1;
}

//Nadam se da cu jednog dana shvatiti zasto std::sort ni qsort nisu radili kako treba ovde
//za obicno sortiranje (bez modifikacije)
void sort(int n) {
    for(int i=0; i<n; i++)
        for(int j=0; j<i; j++)
            if(sortedY[i]->y < sortedY[j]->y ||
                (sortedY[i]->y == sortedY[i]->y && sortedY[i]->x > sortedY[i]->x)) {
                std::swap(sortedY[i], sortedY[j]);
                sortedX[i] = &sortedY[j];
        }
}

int main()
{
    int n, front;
    std::cin >> n;
    for(int i=0; i<n; i++) {
        std::cin >> vojnici[i].x >> vojnici[i].y;
        sortedY[i] = &vojnici[i];
    }
    front = n;
    sort(n);
    for(int i=0; i<n; i++) {
        front = front - (*countX[i] - sortedY[0]) + std::count(used, used + i + 1, true);
    }
    return 0;
}*/

Tacka vojnici[MAXN];
bool used[MAXN];

/**
 * Bruteforce, nazalost.
 */
int main() {
    int n, pozadi=0;
    std::cin >> n;
    for(int i=0; i<n; i++) {
        std::cin >> vojnici[i].x >> vojnici[i].y;
        for(int j=i-1; j>=0; j--) {
            if(vojnici[j].y <= vojnici[i].y && !used[j]) {
                pozadi++;
                used[j] = true;
            }
        }
    }
    std::cout << n-pozadi;
}
