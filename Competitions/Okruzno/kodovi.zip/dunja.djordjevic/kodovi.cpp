#include <iostream>
using namespace std;
int main ()
{
    int n;
    long long x,i,j,vreme, br_kodova,k;
    bool smer;
    long long p[1000],h[1000],niz[1000];
    cin>>n>>x;

    for (i=1; i<=n; i++)
    {
        cin>>p[i]>>h[i];

    }



    for (i=1; i<=n; i++)
    {
        niz[p[i]-p[1]]=h[i];

    }

    vreme=0;
    br_kodova=0;

    if (x>p[n])
    {
        br_kodova=0;
        vreme=0;

    }
    if (x<p[1])
    {
        vreme=vreme+p[1]-x;
        br_kodova=1;

    }

    else //ako je x u intervalu od prve do poslednje gomile
    {

        smer=true;// idi u desno
        while ((x>p[1])&&(x<p[n]))
        {

            if (smer==true) //kreci se desno i dalje
            {

                if (niz[x-p[1]+1]>0)
                {

                    niz[x-p[1]+1]--;
                    vreme++;
                    br_kodova++;
                    smer=false; //pokupi i promeni smer

                }
                else
                {
                    smer=true; //i dalje desno
                    x++;
                    vreme++;
                }

            }
            else
            {
                if (smer==false) //ako se krece u levo
                {

                   if (niz[x-p[1]-1]>0)
                   {
                        niz[x-p[1]-1]--;
                        vreme++;
                        br_kodova++;
                        smer=true; //pokupi i okreni se na desno
                    }
                    else
                    {
                        smer=false; //i dalje levo
                        x--;
                        vreme++;
                    }
                }


            }

        }


    }

   cout << br_kodova<<"\n"<<vreme;
    return 0;



}
