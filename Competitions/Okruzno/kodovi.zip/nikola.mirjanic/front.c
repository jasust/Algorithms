#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x[1000], y[1000];
    int n, i, t;
    int br, max;
    scanf("%d", &n);
    for(i=0;i<n;i++){
    scanf("%d%d", &x[i], &y[i]);
    }
    //for(i=0;i<n-1;i++){
    //for(j=i+1;j<n;j++){
    //if(a[i]>=a[j]){
    //    t=a[i];
    //    a[i]=a[j];
    //    a[j]=t;
    //}}}
  br=0;

    for(i=0;i<n;i++){
            if((x[i]<=x[i+1])&&(y[i]<=y[i+1])){
                br++;
                }

            }
printf("%d", br);


    return 0;
}
