#include <cstdlib>
#include <cstdio>

using namespace std;

int main()
{
   int ;
   scanf("", &);

   printf("", );

   return 0;
}
