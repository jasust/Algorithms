#include <cstdlib>
#include <cstdio>

#define MAX 1000001

using namespace std;

//==========VARIJABLE==========
long long num, posS;
long long pos[MAX], val[MAX];

//==========FUNKCIJE==========

//binarna pretraga
long long bin_pret(long long poz)
{
   long long l = 0, d = num-1, s;
   long long lastl = l, lastd = d;

   while( l != d )
   {
      s = (l+d)/2;

      if( pos[s] == poz )
         return s;
      else if( pos[s] < poz )
         l = s;
      else
         d = s;

      if( lastl == l && lastd == d )
         return d;

      lastl = l;
      lastd = d;
   }
}

inline long long math_max(long long a, long long b)   {return a > b ? a : b;}
inline long long math_min(long long a, long long b)   {return a < b ? a : b;}
inline long long math_abs(long long a)                {return a > 0 ? a : -a;}
//==========MAIN==========
int main()
{
   //unos
   scanf("%lld%lld", &num, &posS);
   for(register long long i = 0; i < num && i < MAX; i++)
      scanf("%lld%lld", &pos[i], &val[i]);

/*
   //provera
   printf("%lld %lld\n", num, posS);
   for(register long long i = 0; i < num && i < MAX; i++)
      printf("%lld %lld\n", pos[i5 2
0 1
1 1
2 1
3 1
4 1
], val[i]);
*/

   long long l, d;
   d = bin_pret(posS);
   l = d-1;

/*
   //provera
   printf("l = %10lld; d = %10lld\n", l, d);
*/



   long long stolen = 0, inc_stolen = 0, time = posS-d, pravac = 1;
   while( d < num && l >= 0 )
   {
      if( val[l] == math_min(val[l], val[d]) )
      {
         stolen += inc_stolen = 2*val[l];
         if( val[l] != val[d] )
            stolen++;

         val[d] -= val[l];
         val[l] = 0;

         time += inc_stolen*( pos[d]-pos[l] );

         l--;
      }
      else
      {
         stolen += inc_stolen = 2*val[d];
         if( val[l] != val[d] )
            stolen++;

         val[l] -= val[d];
         val[d] = 0;

         time += inc_stolen*( pos[d]-pos[l] );

         d++;
      }
/*
      //provera
      printf("-----\ninc_stolen = %lld\ntime = %lld\nl = %lld\nd = %lld\n", inc_stolen, time, l, d);
*/
   }



   printf("%lld %lld", stolen, time);


   return 0;
}

/*
TEST PRIMERI:

3 7
5 2
10 1
12 4

5 2
0 1
1 1
2 1
3 1
4 1

*/
