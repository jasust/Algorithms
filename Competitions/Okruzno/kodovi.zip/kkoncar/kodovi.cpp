
#include <stdio.h>

using namespace std;

int main()
{
    int n, x, smer = 1;
    int broj_kodova = 0, proteklo_vreme = 0;

    scanf("%d %d", &n, &x);
    int p[n], h[n];

    int x_osa[100000];
    for (int i = 0; i < n; i++)
    {
        scanf("%d %d", &p[i], &h[i]);
        x_osa[p[i]] = h[i];
    }

    while(true)
    {
        if (x + smer > p[n - 1] || x + smer < p[0])
            break;
        else
        {
            x += smer;
            proteklo_vreme++;

            if(x_osa[x] > 0)
            {
                x_osa[x]--;
                broj_kodova++;

                smer = smer * (-1);
            }
            if((x_osa[p[n-1]] == 0  && smer == 1) || (x_osa[p[0]] == 0 && smer == -1))
                break;
        }
    }

    printf("%d \n%d", broj_kodova, proteklo_vreme);

    return 0;
}
