#include <iostream>
#include <stdio.h>
#include <cmath>

using namespace std;

int main()
{
    int n,k, sredina;
    long suma = 0;
    scanf("%d %d", &n, &k);

    char broj_strana[n + 1];
    int resenje[n];
    for(int i = 0; i < n; i++)
    {
        scanf("%c", broj_strana);
        suma += broj_strana[i] - '0';
    }
    sredina = round((float)suma / k);

    int findindex = find(broj_strana, '5');
    if(findindex != string::npos)
        cout << "nadjen";

    return 0;
}
