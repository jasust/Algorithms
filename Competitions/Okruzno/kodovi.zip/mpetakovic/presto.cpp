#include <stdio.h>

using namespace std;

int main()
{
    int n, m, h[300], i, j, a[300][300];
    scanf("%d %d", &n, &m);
    for(i = 0; i < n; i++)
        for(j = 0; j < m; j++)
        scanf("%d", &a[i][j]);
        j = n * m / 11;
    printf("%d\n", j);
    return 0;
}
