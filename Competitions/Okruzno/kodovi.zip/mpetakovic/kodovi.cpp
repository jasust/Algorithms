#include <stdio.h>

using namespace std;

int main()
{
    int n, x, i, ap, av, l = 0, d = 0;
    unsigned long long broj;
    scanf("%d %d", &n, &x);
    for(i = 0; i < n; i++)
    {
        scanf("%d %d", &ap, &av);
        if(ap < x)
            l += av;
        else
        d += av;
    }
    if(d > l)
        broj = 2 * l + 1;
    else
        broj = 2 * d;
        unsigned long long r = n * n * x / 2 - n + 1;
        printf("%llu\n", broj);
        if(d == 0)
        printf("0\n");
        else
        printf("%llu\n", r);
    return 0;
}
