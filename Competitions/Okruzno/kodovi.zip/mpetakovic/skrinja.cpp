#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

bool cmp(std::pair<int, int> a, std::pair<int, int> b)
{
    return a.first < b.first;
}

int main()
{
    int n;
    int k;
    std::cin >> n >> k;
    std::priority_queue< std::pair < int, std::vector<int> > > real_heap;
    //std::priority_queue<int> heap;
    std::vector < std::pair < int , int > > chapters(n);
    for ( int i = 0; i < n; i++) {
        std::cin >> chapters[i].first;
        chapters[i].second = i;
    }

    std::vector < std::pair < int, int > > new_chapters = chapters;
    std::sort(new_chapters.begin(), new_chapters.end(), cmp);

    std::pair< int, std::vector < int > > new_peasant;

    for ( int i = k - 1; i >= 0; i--) {

        new_peasant.first = 0;
        real_heap.push(new_peasant);

    }

    for ( int i = new_chapters.size() - 1; i >= 0; i--)
    {
        new_peasant = real_heap.top();
        real_heap.pop();
        new_peasant.first -= new_chapters[i].first;
        new_peasant.second.push_back(new_chapters[i].second);
        real_heap.push(new_peasant);
    }

    int min = -real_heap.top().first;
    int max = min;

    std::vector<int> pages(k);
    std::vector < std::vector < int > > results(k);
    for ( int i = 0; i < k; i++)
    {
        new_peasant = real_heap.top();
        pages[i] = -new_peasant.first;
        if ( pages[i] > max)
            max = pages[i];

        results[i] = new_peasant.second;
        real_heap.pop();
    }
    std::vector < int > finished(n);
    int i=0;
    while ( i < n) {

        for ( int j = 0; j < k; j++)
            for ( int q = 0; q < results[j].size(); q++ ){
                finished[results[j][q]] = j + 1;
                i++;
            }

    }

    /*
    for ( int q = 0; q < n; q++ ) {
        for ( int i = 0; i < k; i++)
        {
           for ( int j = 0; j < results[i].size(); j++)
                if(results[i][j] == chapters[q])
                    finished[q] = i + 1;
        }
    }*/

    std::cout << max - min << std::endl;
    for ( int i = 0; i < n; i++)
        std::cout << finished[i] << " ";

}
