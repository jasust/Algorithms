#include <iostream>
#include <stdio.h>
#include <math.h>

using namespace std;
int a[100000];
int sifra[100000];
int r=0;
void provali( long long k, long long stp,int n,int m)
{
    if(m==0)
    {
        sifra[r]=a[k-1];
        r++;
        return;
    }
    sifra[r]=a[k/stp];
    r++;
    k=k%stp;
    stp=(long long)pow(n,m-1);
    m--;
    provali(k,stp,n,m);
}
int main()
{
    long long k,stpnm;
    int n,m;
    scanf("%d%d%lld",&n,&m,&k);
    m--;
    stpnm=(long long)pow(n,m);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    provali(k,stpnm,n,m);
    for(int i=0;i<r;i++)
    {
        printf("%d ",sifra[i]);
    }
    return 0;
}
