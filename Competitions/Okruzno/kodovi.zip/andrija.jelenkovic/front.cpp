#include <iostream>
#include <stdio.h>

using namespace std;
int x[1000000],y[1000000];
bool onfront[1000000];
int main()
{
    int n,f=0;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d%d",&x[i],&y[i]);
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(x[i]<=x[j] && y[i]<=y[j] && i!=j)
            {
                onfront[i]=false;
                j=n;
            }
            else
                onfront[i]=true;

        }

        if(onfront[i])
        {
            f++;
        }
    }

    printf("%d",f);
    return 0;
}
