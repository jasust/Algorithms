#include <iostream>
#include <stdio.h>
using namespace std;
int l[500][500];
int main()
{
    int n,m,x,y,s=1; long long k;
    char c;
    scanf("%d%d%d%d%lld",&n,&m,&y,&x,&k);
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cin>>c;
            if(c=='#')
                l[i][j]=1;
            else
                l[i][j]=0;
        }
    }
    while(k>0)
    {
        switch(s)
        {
            case 1:
                {
                    while(l[y-1][x-1]==0 && y<=n)
                        {y++;}
                    s++;
                    y--;
                    break;
                }

            case 2:
                {
                    while(l[y-1][x-1]==0 && x<=m)
                        {x++;}
                    s++;
                    x--;
                    break;

                }
            case 3:
                {
                    while(l[y-1][x-1]==0 && y>=0)
                        {y--;}
                    s++;
                    y++;
                    break;
                }
            case 4:
                {
                    while(l[y-1][x-1]==0 && x>=0)
                        {x--;}
                    s=1;
                    x++;
                    break;

                }
        }
        k--;
    }
    printf("%d %d",y,x);
    return 0;
}
