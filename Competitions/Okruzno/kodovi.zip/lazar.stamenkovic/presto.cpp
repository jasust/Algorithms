#include<stdio.h>
#include<algorithm>
struct mat{
    int x;
    bool k,r;
};
int main()
{
    int i,j,n,m,kmin=300,rmin=300,xmin[300],xmax[300],izmene;
    mat h[300][300];
    scanf("%d%d",&n,&m);
    for(i=0;i<n;i++)
        for(j=0;j<m;j++) {scanf("%d",&h[i][j].x);h[i][j].k=false;h[i][j].r=false;}
    for (i=0;i<m;i++)
    {
        xmax[i]=h[1][i].x;
        for(j=1;j<n;j++)
        {
            if(h[j][i].x>xmax[i]) xmax[i]=h[j][i].x;
        }
    }
    for(i=0;i<m;i++)
        for(j=0;j<n;j++)
    {
        if(h[j][i].x==xmax[i]) h[j][i].k=true;
    }
    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
        {
            if(h[i][j].k)
            {
                //printf("it works");
                izmene=0;
                for(int e=0;e<m;e++)
                {
                    if(h[i][j].x>h[i][e].x) izmene++;
                }
        //printf("%d\n",izmene);
        if(izmene<kmin) kmin=izmene;}
        }
    printf("%d",kmin);
}
