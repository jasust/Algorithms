#include<stdio.h>
#include<algorithm>
struct mat{
    int x;
    bool k,r;
};
int main()
{
    int n,k,a[13],minx,maxx,i;
    scanf("%d%d",&n,&k);
    minx=maxx=0;
    for (i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
        if(a[i]>maxx) maxx=a[i];
        if(a[i]<minx) minx=a[i];
    }
    printf("%d",maxx-minx);
}

