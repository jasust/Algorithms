#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,x,p[100000],h[100000],i;
    long long s1,s2;
    scanf("%d%d",&n,&x);
    for(i=0;i<n;i++) scanf("%d%d",&p[i],&h[i]);
    i=0;
    s1=0;
    s2=0;
    while(x>p[i])
    {
        s1+=h[i];
        i++;
    }
    int k=i;
    while(i<n)
    {
        s2+=h[i];
        i++;
    }
    //for(i=0;i<n;i++) p[i]=abs(p[i]-x);
    long long a,b;
    a=s1;
    b=s2;
    i=k;
    //bool f=true;
    long long vreme=0;
    while((i<n)&&(a))
    {
        if(h[i]<=a+1)
        {
            a=a-h[i];
            vreme+=h[i]*2*abs(p[i]-x);
            i++;
        }
        else
        {
            vreme+=((a+1)*2-1)*abs(p[i]-x);
            a=0;
        }
        //printf("%lld\n%lld\n",vreme,a);
    }
    i=k-1;
    //printf("%lld\n%lld\n",vreme,a);
    while((i>=0)&&(b))
    {
        if(h[i]<=b)
        {
            b=b-h[i]-1;
            vreme+=h[i]*2*abs(p[i]-x);
            i--;
        }
        else
        {
            vreme+=((b)*2-1)*abs(p[i]-x);
            b=0;
        }
        //printf("%lld\n%lld\n",vreme,b);
    }
    if(s1>s2) printf("%lld\n",2*s2);
    else printf("%lld\n",2*s1+1);
    printf("%lld",vreme);
}
