#include <stdio.h>
#include <stdlib.h>

int main()
{
   int N,F,i,n; // broj vojnika N .. broj vojnika na frontu F
   int x,y;

   scanf("%d",&N);
  scanf("%d %d",&x , &y);
   for(i=0;i<n;i++)

   {
( F =(  (x + y )));

        switch (x){
            case 1 : 1 < x < 20 ;
            case 2 : x > 20 ;
        }
        switch  (y) {
            case 1 : 1 < y < 20 ;
            case 2 : y > 20 ;break;
      } }
        printf("%d",&F);
        return 0;


        }



