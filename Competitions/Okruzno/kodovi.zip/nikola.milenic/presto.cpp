#include <stdio.h>
using namespace std;
int a[330][330], i, j, k, n, m, sol, min;
int main(){
    min=100000;
    scanf("%d%d", &n, &m);
    for (i=0; i<n; i++)
        for (j=0; j<m; j++){
            scanf("%d", &a[i][j]);
        }
    for (i=0; i<n; i++)
        for (j=0; j<m; j++){
            sol=0;
            for (k=0; k<n; k++) if(a[k][j]>a[i][j]) sol++;
            for (k=0; k<m; k++) if(a[i][k]<a[i][j]) sol++;
            if (sol<min) min=sol;
        }
    printf("%d", min);
    return 0;
}
