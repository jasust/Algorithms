#include <stdio.h>
#include <algorithm>
using namespace std;
long long s, t;
int n, x, P[110000], H[110000], dir, l, d, i;
bool inf;
int main(){
    d=-1;
    l=n;
    scanf("%d%d", &n, &x);
    for(i=0;i<n;i++){
        scanf("%d%d", &P[i], &H[i]);
        if(P[i]<x) l=i;
        if(d==-1 && P[i]>x) d=i;
    }
    t=0;
    s=0;
    dir=0;
    inf=false;
    if (x<P[0]) printf("1\n%d\n", P[0]-x); else {
    while (!inf){
        printf("%d %d\n", l, d);
        if(dir==0){
            if(H[d]>H[l]){
                s+=H[l]*2+1;
                t+=P[d]-x+(P[d]-P[l])*H[l]*2;
                H[d]-=H[l]+1;
                H[l]=0;
                l--;
                x=P[d];
                dir=1;
                if (l<0) inf=true;
            } else {
                s+=H[d]*2;
                t+=P[d]-x+(P[d]-P[l])*(H[d]*2-1);
                H[l]-=H[d];
                H[d]=0;
                d++;
                x=P[l];
                if (d>=n) inf=true;
            }
        }else{
            if(H[l]>H[d]){
                s+=H[d]*2+1;
                t+=x-P[l]+(P[d]-P[l])*H[d]*2;
                H[l]-=H[d]+1;
                H[d]=0;
                d++;
                x=P[l];
                dir=0;
                if (d>=n) inf=true;
            } else {
                s+=H[l]*2;
                t+=x-P[l]+(P[d]-P[l])*(H[l]*2-1);
                H[d]-=H[l];
                H[l]=0;
                l--;
                x=P[d];
                if (l<0) inf=true;
            }

        }


    }
    printf("%lld\n%lld\n", s, t);
    }
    return 0;
}
