#include <stdio.h>
using namespace std;
int i, j, k, n, s, p[100], c[100], b[100], a[100], min, max;
int main(){
    scanf("%d%d", &n, &k);
    for (i=0; i<n; i++){
        scanf("%d", &a[i]);
        b[i]=i;
    }
    for (i=1; i<=k; i++) p[i]=0;
    for (i=0; i<n-1; i++)
        for (j=i+1; j<n; j++)
            if (a[i]<a[j]){
            s=a[i];
            a[i]=a[j];
            a[j]=s;
            s=b[i];
            b[i]=b[j];
            b[j]=s;
            }
    for (i=0; i<n; i++){
        min=1;
        for (j=2; j<=k; j++){
            if (p[j]<p[min]) min=j;
        }
        p[min]+=a[i];
        c[b[i]]=min;
    }
    min=1;
    max=1;
        for (j=2; j<=k; j++){
            if (p[j]<p[min]) min=j;
            if (p[j]>p[max]) max=j;
        }
    printf("%d\n", p[max]-p[min]);
    for (i=0; i<n; i++){
    printf("%d ", c[i]);
    }
    return 0;
}
