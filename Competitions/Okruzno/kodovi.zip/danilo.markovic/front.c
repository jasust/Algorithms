#include <stdio.h>
#define VOJNICI 100000

int main()
{
    long long x[VOJNICI], y[VOJNICI], maxY = -1;
    long int n, ukupno = 0, trenutno[VOJNICI];
    scanf("%ld", &n);
    int i = 0;
    for(; i < n; ++i)
    {
          scanf("%lld", &x[i]);
          scanf("%lld", &y[i]);
    }
    
    i = x[n - 1];
    for(; i >= 0; --i)
    {
          int brojac = 0;
          long int j = n - 1;
          short int manje = 0;
          for(; j >= 0; --j)
          {
                if(x[j] == i)
                {
                   manje = 1;        
                   trenutno[brojac] = j;
                   ++brojac;        
                }
                else if(manje == 1)
                     break;      
           }
           short int post = 0;
           j = 0;
           for(; j < brojac; ++j)
           {
                 if(y[trenutno[j]] > maxY)
                 {
                       maxY = y[trenutno[j]]; 
                       post = 1;           
                 }
           }
           if(post == 1)
           ++ukupno;
    
    }
    
    printf("%i", ukupno);	
  return 0;
}
