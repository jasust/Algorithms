#include<cstdlib>
#include<cstdio>

using namespace std;

int N, M, K, niz[100005];

int main() {

    scanf("%d %d %d", &N, &M, &K);
    for(int i=1; i<=N; i++)
        scanf("%d", &niz[i]);
    printf("%d\n", niz[K]);
    return 0;
}
