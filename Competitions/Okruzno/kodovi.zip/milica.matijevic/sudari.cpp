#include<cstdlib>
#include<cstdio>

using namespace std;

int k, n, m, pom=1, i, j;
char nesto[10][10], L[505][505];
bool pok=true, pok1=true;

int main() {

    scanf("%d %d", &n, &m);
    scanf("%d %d", &i, &j);
    scanf("%d", &k);
    i--; j--;
    for(int i=0; i<n; i++)
        scanf("%s", &L[i]);
    while(pom<=k) {
        if(pom%2!=0 && pok==true && pom<=k) {
            while(L[i+1][j]!='#' && i!=n-1 && pom<=k) i++;
            pok=false;
            pom++;
//            printf("i=%d j=%d pom=%d\n", i, j, pom);
        }
        if(pom%2!=0 && pok==false && pom<=k) {
            while(L[i-1][j]!='#' && i!=0 && pom<=k) i--;
            pok=true;
            pom++;
//            printf("i=%d j=%d pom=%d\n", i, j, pom);
        }
        if(pom%2==0 && pok1==true && pom<=k) {
            while(L[i][j+1]!='#' && j!=m-1 && pom<=k) j++;
            pok1=false;
            pom++;
//            printf("i=%d j=%d pom=%d\n", i, j, pom);
        }
        if(pom%2==0 && pok1==false && pom<=k) {
            while(L[i][j-1]!='#' && j!=0 && pom<=k) j--;
            pok1=true;
            pom++;
//            printf("i=%d j=%d pom=%d\n", i, j, pom);
        }
    }
    i++; j++;
    printf("%d %d\n", i, j);
    return 0;

}
