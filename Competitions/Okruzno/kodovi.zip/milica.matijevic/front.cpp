#include<cstdio>
#include<algorithm>
#include<cstdlib>

using namespace std;

int N;
struct slog {int x, y;} tacka[100006];
bool cmp(slog a, slog b) {
    return a.x>b.x || (a.x==b.x && a.y>b.y);
}

int main() {

    scanf("%d", &N);
    for(int i=1; i<=N; i++)
        scanf("%d %d", &tacka[i].x, &tacka[i].y);
    sort(tacka+1, tacka+N+1, cmp);
//    for(int i=1; i<=N; i++) printf("%d %d\n", tacka[i].x, tacka[i].y);
    int brojac=1;
    for(int i=2; i<=N; i++)
        if(tacka[i].x<tacka[i-1].x && tacka[i].y>tacka[i-1].y) brojac++;
        else break;
    printf("%d\n", brojac);
    return 0;
}
