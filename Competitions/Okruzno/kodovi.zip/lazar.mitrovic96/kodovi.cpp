#include <iostream>

using namespace std;

long long abs(long long a) //jer smo tako u mogucnosti
{
    if (a<0) return -a;
    else return a;
}
long long n, x,koraci,vrednost;
int main()
{
cin>>n>>x;
long long nizvr[n];
long long poz[n];

for (int i=0;i<n;i++)
    cin>>poz[i]>>nizvr[i];
//ucitao nizove

bool ispadni = false;
int smer = 1;
int i;
int prosao = 0;
while (!ispadni)
    {
        if (smer == 1) i=0;
        else i=n-1;

        while ((i>=0) && (i<n))
        {
            if ((poz[i]>x) && (smer==1) && (nizvr[i]!=0)) break; // ako je sklepto udesno
            else if ((poz[i]<x) && (smer==-1) && (nizvr[i]!=0)) break; //ako je sklepto ulevo
            else i = i+smer;
        }// prosetao se perica
        if ((i<0) || (i==n))
            {ispadni = true;} // ako se limesiro
        else
            {
                koraci = koraci + abs((poz[i]-x)); // i kad ne gledam po koraku te znaaaaam
                vrednost++;
                nizvr[i]--;
                smer = -smer;
                x=poz[i]; // cepaj dalje majstore
            }
    prosao ++;
    }
    cout<<vrednost<<endl<<koraci;
    return 0;
}
