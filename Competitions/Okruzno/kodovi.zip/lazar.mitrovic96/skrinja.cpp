#include <iostream>
#include <algorithm>

using namespace std;

int kombinacija[14];
int cuv[14];
int k;
int n;
long long niz[14];
long long sume[15];
    long long minimum=0;
    long long maksimum=0;
    long long diverzitet=9999999;


long long abso(long long a)
{
    if (a<0) return -a;
    else return a;
}

long long mini()
{
long long    minim = 9999999;
    for (int i = 1; i<=k; i++)
    {
        if (sume[i]<minim) minim = sume[i];
    }
    return minim;
}
long long maxi()
{
   long long maxim = -9999999;
    for (int i = 1; i<=k; i++)
    {
        if (sume[i]>maxim) maxim = sume[i];
    }
    return maxim;
}

void ispis()
{
   for (int j = 0; j<n;j++)
            {
                cout<<cuv[j]<<" ";
            }
}
void spoji()
{
   for (int j = 0; j<n;j++)
            {
                cuv[j] = kombinacija[j];
            }
}
bool dodaj()
    {
        int j;
        kombinacija[0]= kombinacija[0]+1;
        if(kombinacija[0]>k)
        {
            kombinacija[0]=1;
            for (j = 1; j<n;j++)
            {
                kombinacija[j] = kombinacija[j] +1;
                if (kombinacija[j]>k) kombinacija[j] = 1;
                else break;
            }
            if (j==n) return false;
        }
        return true;
    }
int main()
{
    cin>>n>>k;
    for (int i = 0; i<n;i++)
    {
        cin>>niz[i];
        kombinacija[i]=1;
    }


    while (dodaj())
    {
        for (int i = 1; i<=k; i++)
            sume[i] = 0;

       //insert logic here
         for (int j = 0; j<n;j++)
            {
                sume[kombinacija[j]] = sume[kombinacija[j]] + niz[j];
            }
        minimum = mini();
        maksimum = maxi();
        if (abso(maksimum-minimum)<diverzitet) {diverzitet = abso(maksimum-minimum);
        spoji();}

    }
    cout<<diverzitet<<endl;
    ispis();
    return 0;
}
