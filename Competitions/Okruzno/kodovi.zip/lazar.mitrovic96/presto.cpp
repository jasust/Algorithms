#include <iostream>
#include <algorithm>

using namespace std;


long long nizred[300];
long long nizcol[300];
long long z[300];
int n,m;

bool cmpr (long long a, long long b)
{
if (nizred[a]<nizred[b]) {return true;}
else return false;
}

bool cmpc (long long a, long long b)
{
if (nizcol[a]>=nizcol[b]) {return true;}
else return false;
}

int nadjiunizured (long long x)
{
    for (int i=0; i<m;i++)
        if (nizred[z[i]]==x) return i;
    return -1;
}

int nadjiunizucol (long long x)
{
    for (int i=0; i<n;i++)
        if (nizcol[z[i]]==x) return i;
    return -1;
}


int main()
{
    cin>>n>>m;
    long long h[n][m];
    for (int i=0; i<n; i++)
    {
        for (int j=0;j<m;j++)
        {
            cin>>h[i][j];
        }
    }

    //optimizacija na nivou

    long long minred[301][301];
    long long maxcol[301][301];

    //izdeklarisao

    //sad cepaj redove
     for (int i=0; i<n; i++)
        {
            for (int j=0;j<m;j++)
                {

                nizred[j]=h[i][j];
                z[j]=j;
                }

                sort(z,z+m,cmpr);
            for (int j=0;j<m;j++)
            {
                minred[i][j]=nadjiunizured(nizred[j]); // ne valja
            }
        }
// iscepao sad cepaj kolone
for (int j=0; j<m; j++)
        {
            for (int i=0;i<n;i++)
                {
                nizcol[i]=h[i][j];
                z[i]=i;
                }

                sort(z,z+n,cmpc);

            for (int i=0;i<m;i++)
                maxcol[i][j]=nadjiunizucol(nizcol[i]); //ovo ne valja
        }
// iscepao aj sad spoji i ispisi min
long long minimum = minred[0][0] + maxcol[0][0];
long long trenutno=0;
    for (int i=0; i<n; i++)
    {
        for (int j=0;j<m;j++)
        {
        trenutno = minred[i][j] + maxcol[i][j];
        if (trenutno<minimum) minimum = trenutno;
        }
    }

    //ispisi minred
   /* cout<<endl;
    cout<<endl;
    for (int i=0; i<n; i++)
    {
        for (int j=0;j<m;j++)
        {
        cout<<minred[i][j]<<" ";
        }
        cout<<endl;
    }

    //ispisi maxcol
cout<<endl;
cout<<endl;
    for (int i=0; i<n; i++)
    {
        for (int j=0;j<m;j++)
        {
        cout<<maxcol[i][j]<<" ";
        }
        cout<<endl;
    }
*/

    cout << minimum;
    return 0;
}
