#include<cstdio>
#include<algorithm>
#include<cstdlib>
using namespace std;

struct slog {int x,y;};
slog zz[1000005],res[1000005];
bool sortslog (slog a, slog b) {return (a.x<b.x)||((a.x==b.x)&&(a.y<b.y));}
bool sortslogy (slog a, slog b) {return (a.y<b.y)||((a.y==b.y)&&(a.x<b.x));}

int cnt,n,br;

int main() {
 //freopen("front.in","r",stdin);
 scanf("%d", &n);
 for (int i=1;i<=n;i++)
   scanf("%d %d", &zz[i].x,&zz[i].y);
 sort(zz+1,zz+n+1,sortslogy);
 //for (int i=1;i<=n;i++) printf("%d%d ",zz[i].x,zz[i].y);
 //printf("\n");
 for (int i=1;i<=n;i++)
  if (zz[i].y!=zz[i+1].y)
  {br++; res[br].x=zz[i].x; res[br].y=zz[i].y;}
 //br++; res[br].x=zz[n].x; res[br].y=zz[n].y;
 sort(res+1,res+br+1,sortslog);
 for (int i=1;i<=br;i++) {
   //printf("%d%d ", res[i].x,res[i].y);
   if ((res[i].y>res[i+1].y)&&(res[i].x!=res[i+1].x)) {cnt++;  } }
 printf("%d", cnt);
return 0;
}
