#include<cstdio>
#include<cstdlib>
int a[10000],n,m;
long long k;

int main() {
 scanf("%d %d %lld", &n,&m,&k);
 for (int i=1;i<=n;i++)
  scanf("%d", &a[i]);
 if (m==1) printf("%d", a[k]);
 return 0;
}
