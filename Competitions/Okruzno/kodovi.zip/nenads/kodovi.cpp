#include<cstdio>
int n,m,a[1000000001],h[1000000001],td,sacuvaj,i,j,z,asdf,s,l;
int main(){
td=1;
scanf("%d%d",&n,&m);
for(i=1;i<=n;i++) scanf("%d%d",&a[i],&h[i]);
for(i=1;i<=n;i++) if(a[i]>=m){sacuvaj=i;for(j=i;j<=n;j++){for(z=j+1;z<=n+1;z++){asdf=a[j];a[j]=a[z];a[z]=asdf;asdf=h[j];h[j]=h[z];h[z]=asdf;}}}
h[sacuvaj]=0;
sacuvaj++;
while(1==1){
if((sacuvaj<a[1])||(sacuvaj>a[n])) break;
if((h[sacuvaj]==0)&&(td==1)) {sacuvaj++;l++;}
else if((h[sacuvaj]!=0)&&(td==1)){h[sacuvaj]--;s++;td=2;l++;}
else if((h[sacuvaj]==0)&&(td==2)) {sacuvaj--;s++;l++;}
else {h[sacuvaj]--;s++;td=1;l++;}}
printf("\n%d\n%d",s,l);
return 0;
}
