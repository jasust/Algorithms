#include<cstdio>
int n,m,s,i,j,a[300][300],mincol[300],maxrow[300];
int main(){
scanf("%d%d",&n,&m);
s=14;
for(i=1;1<=n;i++){
    for(j=1;j<=m;j++){
        scanf("%d",&a[i,j]);}}
for(i=1;i<=1;i++){mincol[i]=1000000000;}
for(i=1;i<=1;i++){maxrow[i]=0;}
while(s=14){
for(i=1;1<=n;i++){
    for(j=1;j<=m;j++){
        if((a[i,j]) < mincol[i])mincol[i]=a[i,j];}}
 for(j=1;j<=m;j++){
    for(i=1;1<=n;i++){
        if(a[i,j]>maxrow[i])maxrow[i]=a[i,j];}}
for(i=1;i<=1;i++){
    for(J=1;J<=1;J++){if((a[i,j]==mincol[j]) && (a[i,j]==maxrow[i])) s=0;}
printf("%d",s);
return 0;
}
