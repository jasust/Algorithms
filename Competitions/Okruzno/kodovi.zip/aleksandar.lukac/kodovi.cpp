#include <iostream>
#include <cstdio>

using namespace std;

struct kod
{
    unsigned long long poz;
    unsigned long long vred;
};


unsigned long long x;
unsigned int n;
unsigned int brlevi=0, brdesni=0;
bool kraj=false;

kod levi[100005], desni[100005];

int main()
{
    cin >> n >> x;
    for(int i=0;i<n;i++)
    {
        long long poz, vred;
        scanf("%lld %lld",&poz, &vred);
        if(poz<x)
        {
            levi[brlevi].poz=poz;
            levi[brlevi].vred=vred;
            brlevi++;
        }
        else
        {
            desni[brdesni].poz=poz;
            desni[brdesni].vred=vred;
            brdesni++;
        }
    }
    for(int j=brlevi-1;j>=0;j--)
    {
        kod t=levi[j];
        levi[j]=levi[brlevi-1-j];
        levi[brlevi-1-j]=t;
    }
    bool desno=true;
    long long trpoz=x;
    long long vreme=0;
    long long brkod=0;
    while(!kraj)
    {
        if(desno)
        {
            bool ima=false;
            for(int i=0;i<brdesni;i++)
            {
                if(desni[i].vred!=0)
                {
                    vreme+=desni[i].poz-trpoz;
                    trpoz=desni[i].poz;
                    brkod++;
                    desni[i].vred--;
                    ima=true;
                    break;
                }
            }
            if(!ima)
            {
                kraj=true;
                break;
            }
        }
        else
        {
            bool ima=false;
            for(int i=0;i<brlevi;i++)
            {
                if(levi[i].vred!=0)
                {
                    vreme+=trpoz-levi[i].poz;
                    trpoz=levi[i].poz;
                    brkod++;
                    levi[i].vred--;
                    ima=true;
                    break;
                }
            }
            if(!ima)
            {
                kraj=true;
                break;
            }
        }
        desno=!desno;
    }
    cout << brkod << endl;
    cout << vreme;
    return 0;
}
