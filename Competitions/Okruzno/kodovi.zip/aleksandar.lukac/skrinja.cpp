#include <iostream>
#include <algorithm>

using namespace std;

int n,k;
long long a[15],b[15],c[15];
long long minrazlika=100000000;
long long zbir=0;
long long prosek;


int main()
{
    cin >> n >> k;
    for(int i=0;i<n;i++)
    {
        cin >> a[i];
        zbir+=a[i];
        b[i]=a[i];
        c[i]=-1;
    }
    prosek=zbir/k;
    if(zbir-prosek*k>(k/2))
        prosek++;
    sort(b,b+n);
    for(int i=0;i<n;i++)
    {
        if(c[i]==-1)
        {
            c[i]=b[i]+b[n-i-1];
            c[n-i-1]=c[i];
        }
    }
    int max=0;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(c[i]-c[j]>max)
                max=c[i]-c[j];
        }
    }
    cout << max;
}
