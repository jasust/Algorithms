#include <iostream>

using namespace std;

int n,m;
long long h[305][305];
long long minn[305], maxm[305];
long long zamena[305][305];
int unix,uniy;
int minpromena;

void prodji(int x,int y)
{
        for(int i=0;i<m;i++)
        {
            if(h[x][i]<h[x][y])
                zamena[x][y]++;
        }
        for(int i=0;i<n;i++)
        {
            if(h[i][y]>h[x][y])
                zamena[x][y]++;
        }
        if((x==0)&&(y==0))
        {
            minpromena=zamena[x][y];
            unix=x;
            uniy=y;
        }
        if(zamena[x][y]<minpromena)
        {
            minpromena=zamena[x][y];
            unix=x;
            uniy=y;
        }

        if(y==m-1){
            if(x!=n-1)
                prodji(x+1,0);
        }
        else
            prodji(x,y+1);
}

int main()
{
    cin >> n >> m;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cin >> h[i][j];
            zamena[i][j]=0;
            if(i==0)
                maxm[j]=h[i][j];
            if(j==0)
                minn[i]=h[i][j];
            if(h[i][j]<minn[i])
                minn[i]=h[i][j];
            if(h[i][j]>maxm[j])
                maxm[j]=h[i][j];
        }
    }
    prodji(0,0);
    if(minpromena>1)
    {
            for(int i=0;i<n;i++)
            {
                for(int j=0;j<m;j++)
                {
                    if(maxm[j]<=minn[i]){
                        cout << "1";
                        return 0;
                    }
                }
            }
    }
    cout << minpromena;
    return 0;
}
