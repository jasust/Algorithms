#include <cstdio>
#include <cstring>
#include <cstdlib>
using namespace std;
int n,m,x,y,i,j,dir;
char lav[505][505],s[505];
long long k;
int main(){

 scanf("%d %d",&n,&m);
 scanf("%d %d",&x,&y);
 scanf("%lld",&k);
 for (i=1;i<=n;i++){
  scanf("%s",&s);
  for (j=0;j<m;j++)
   lav[i][j+1]=s[j];
 }

/* for (i=1;i<=n;i++){
  for (j=1;j<=m;j++)
   printf("%c",lav[i][j]);
  printf("\n");
 }
*/
 while (k>0){
  if (dir==0)
   while (lav[x+1][y]=='.'){ //dole
    x++;
   }

   else if (dir==1)
         while (lav[x][y+1]=='.'){ //desno
          y++;
         }

         else if (dir==2)
               while (lav[x-1][y]=='.'){ //gore
                x--;
               }

               else while (lav[x][y-1]=='.'){ //levo
                     y--;
                    }

  k--;
  dir=(dir+1)%4;
 }

 printf("%d %d\n",x,y);

return 0;
}

/*

4 5
2 1
4
...#.
.#...
....#
#....
*/
