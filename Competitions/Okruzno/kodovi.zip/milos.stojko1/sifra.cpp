#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;
int n,m,k,a[100005],i;
int main(){

 scanf("%d %d %d",&n,&m,&k);
 for (i=1;i<=n;i++)
  scanf("%d",&a[i]);

 sort(a+1,a+n+1);
 printf("%d\n",a[k]);


return 0;
}
