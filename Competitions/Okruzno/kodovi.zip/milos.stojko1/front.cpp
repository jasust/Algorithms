#include <cstdio>
#include <cstdlib>
using namespace std;
int n,x[1000005],y[1000005],i,j,rez2,f;
bool c,c2;
int main(){

 scanf("%d",&n);

 for (i=1;i<=n;i++){
  scanf("%d %d",&x[i],&y[i]);
 }
 for (i=1;i<=n;i++){
  c=true;
  for (j=1;j<=n;j++)
   if (i!=j)
    if ((x[i]<=x[j] and y[i]<=y[j])){
     c=false;
     break;
    }
   if (c){
    f++;
   }
 }

 printf("%d\n",f);



return 0;
}

/*
6
0 1
1 5
3 5
3 2
4 4
5 1
*/
