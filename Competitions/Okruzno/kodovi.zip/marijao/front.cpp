#include <iostream>
using namespace std;
int main ()
{
    long long F, n, i, x[100],  y[100], a, b, c, d;
    cin>>n;
   for (i=0; i<n; i++)
    cin>>x[i];
   for (i=0; i<n; i++)
    cin>> y[i];
    if (x[a]==x[b])
        F++;
    if (y[c]==y[d])
        F++;
    if(x[a]==x[b] && y[c]==y[d])
        F--;
    cout<<F;
return 0;
}
