#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

int main()
{
    //Radjena disjunktna grupa gde vazi N <= 3, primeri gde je N > 3 nece raditi!
    int N, K;
    scanf("%d %d", &N, &K);

    int nizPoglavlja[N];
    for(int i = 0; i < N; i++)
    {
        scanf("%d", &nizPoglavlja[i]);
    }

    int najmanjaRazlika;
    int nizPodele[N];

    if(K == 1)
    {
        najmanjaRazlika = 0;
        for(int i = 0; i < N; i++)
        {
            nizPodele[i] = 1;
        }

        //resenje
        printf("%d\n", najmanjaRazlika);
        for(int i = 0; i < N; i++)
        {
            printf("%d ", nizPodele[i]);
        }
    }

    if(K == 2)
    {
        int minRazlika1, minRazlika2, minRazlika3;
        if(N == 1)
        {
            najmanjaRazlika = 0;
            for(int i = 0; i < N; i++)
            {
                nizPodele[i] = 1;
            }
        }
        else if(N == 2)
        {
            najmanjaRazlika = abs(nizPoglavlja[1] - nizPoglavlja[2]);
            for(int i = 0; i < N; i++)
            {
                nizPodele[i] = i + 1;
            }

        }
        else if(N == 3)
        {
            minRazlika1 = abs(nizPoglavlja[0] + nizPoglavlja[1] - nizPoglavlja[2]);
            minRazlika2 = abs(nizPoglavlja[0] + nizPoglavlja[2] - nizPoglavlja[1]);
            minRazlika3 = abs(nizPoglavlja[1] + nizPoglavlja[2] - nizPoglavlja[0]);

            int minovi[] = {minRazlika1, minRazlika2, minRazlika3};
            int elements = sizeof(minovi)/sizeof(minovi[0]);
            sort(minovi, minovi + elements);

            najmanjaRazlika = minovi[0];

            if(najmanjaRazlika == minRazlika1)
            {
                nizPodele[0] = 1;
                nizPodele[1] = 1;
                nizPodele[2] = 2;
            }
            else if(najmanjaRazlika == minRazlika2)
            {
                nizPodele[0] = 1;
                nizPodele[1] = 2;
                nizPodele[2] = 1;
            }
            else if(najmanjaRazlika == minRazlika3)
            {
                nizPodele[0] = 2;
                nizPodele[1] = 1;
                nizPodele[2] = 1;
            }
        }
    }

    if(K >= 3)
    {
        int minRazlika1, minRazlika2, minRazlika3, minRazlika4, minRazlika5, minRazlika6;
        if(N == 1)
        {
            najmanjaRazlika = 0;
            for(int i = 0; i < N; i++)
            {
                nizPodele[i] = 1;
            }
        }
        else if(N == 2)
        {
            najmanjaRazlika = abs(nizPoglavlja[1] - nizPoglavlja[2]);
            for(int i = 0; i < N; i++)
            {
                nizPodele[i] = i + 1;
            }

        }
        else if(N == 3)
        {
            minRazlika1 = abs(nizPoglavlja[0] + nizPoglavlja[1] - nizPoglavlja[2]);
            minRazlika2 = abs(nizPoglavlja[0] + nizPoglavlja[2] - nizPoglavlja[1]);
            minRazlika3 = abs(nizPoglavlja[1] + nizPoglavlja[2] - nizPoglavlja[0]);

            int minovi[] = {minRazlika1, minRazlika2, minRazlika3};
            int elements = sizeof(minovi)/sizeof(minovi[0]);
            sort(minovi, minovi + elements);

            int najmanjaRazlika1 = minovi[0];

            if(najmanjaRazlika1 == minRazlika1)
            {
                nizPodele[0] = 1;
                nizPodele[1] = 1;
                nizPodele[2] = 2;
            }
            else if(najmanjaRazlika1 == minRazlika2)
            {
                nizPodele[0] = 1;
                nizPodele[1] = 2;
                nizPodele[2] = 1;
            }
            else if(najmanjaRazlika1 == minRazlika3)
            {
                nizPodele[0] = 2;
                nizPodele[1] = 1;
                nizPodele[2] = 1;
            }

            int minoviAkoGledamoSvuTrojicu[] = {nizPoglavlja[0], nizPoglavlja[1], nizPoglavlja[2]};
            int elements1 = sizeof(minoviAkoGledamoSvuTrojicu)/sizeof(minoviAkoGledamoSvuTrojicu[0]);
            sort(minoviAkoGledamoSvuTrojicu, minoviAkoGledamoSvuTrojicu + elements1);

            int najmanjaRazlika2 = (minoviAkoGledamoSvuTrojicu[2] - minoviAkoGledamoSvuTrojicu[0]);

            if(najmanjaRazlika1 < najmanjaRazlika2)
            {
                najmanjaRazlika = najmanjaRazlika1;
            }
            else
            {
                najmanjaRazlika = najmanjaRazlika2;
                nizPodele[0] = 1;
                nizPodele[1] = 2;
                nizPodele[2] = 3;
            }
        }
    }

    printf("%d\n", najmanjaRazlika);
    for(int i = 0; i < N; i++)
    {
        printf("%d ", nizPodele[i]);
    }

    return 0;
}
