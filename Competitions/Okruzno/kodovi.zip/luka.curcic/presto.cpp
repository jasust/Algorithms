#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

int main()
{
    int N, M;
    scanf("%d %d", &N, &M);

    double basta[N][M];

    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < M; j++)
        {
            scanf("%lf", &basta[i][j]);
        }
    }

    double maybePresto;
    double maybePresto2;
    int brojacManjih = 0;
    int brojacVecih = 0;
    int minBrojacManjih = 0;
    int minBrojacVecih = 0;

    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < M; j++)
        {
            maybePresto = basta[i][j];
            int K = i;
            for(int L = 0; L < M; L++)
            {
                if(basta[K][L] < maybePresto)
                {
                    brojacManjih++;
                }
            }
            if(minBrojacManjih < brojacManjih)
            {
                minBrojacManjih = brojacManjih;
            }
            brojacManjih = 0;
            continue;
        }
    }

    for(int j = 0; j < M; j++)
    {
        for(int i = 0; i < N; i++)
        {
            maybePresto2 = basta[i][j];
            int K = j;
            for(int L = 0; L < N; L++)
            {
                if(basta[L][K] > maybePresto2)
                {
                    brojacVecih++;
                }
            }
            if(minBrojacVecih < brojacVecih)
            {
                minBrojacVecih = brojacVecih;
            }
            brojacVecih = 0;
            continue;
        }
    }

    printf("%d", minBrojacVecih + minBrojacManjih);
    return 0;
}
