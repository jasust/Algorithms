#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

int main()
{
    int N, X;
    scanf("%d %d", &N, &X);

    int pozicijeP[N];
    int velicinaGomileH[N];
    for(int i = 0; i < N; i++)
    {
        scanf("%d %d", &pozicijeP[i], &velicinaGomileH[i]);
    }

    bool desno = true;
    long long brojacSekundi = 0;
    long long brojacKodova = 0;
    int drzacPozicije;

    for(int i = 0; i < N; i++)
    {
        while(desno)
        {
            X++;
            brojacSekundi++;
            if(X == pozicijeP[i] && velicinaGomileH[i] != 0)
            {
                velicinaGomileH[i]--;
                desno = false;
                i = 0;
                brojacKodova++;
            }
            else if(X > pozicijeP[i])
            {
                break;
            }
            else if(X < pozicijeP[i])
                continue;
        }

        while(!desno)
        {
            X--;
            brojacSekundi++;
            if(X == pozicijeP[i] && velicinaGomileH[i] != 0)
            {
                velicinaGomileH[i]--;
                desno = true;
                i = 0;
                brojacKodova++;
            }
            else if(X < pozicijeP[i])
            {
                break;
            }
            else if(X > pozicijeP[i])
                continue;
        }
    }

    brojacSekundi -= (N + abs(pozicijeP[N-1] - pozicijeP[0]));

    printf("%lld\n%lld", brojacKodova, brojacSekundi);

    return 0;
}
