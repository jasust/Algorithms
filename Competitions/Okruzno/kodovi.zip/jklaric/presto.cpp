#include <cstdio>
#include <algorithm>
#include <cstdlib>

bool cmp(int a,int b)
{
     return a<b;
}

int min[301][301];
int max[301][301];
int a[301][301];

int main()
{

int n,m;



scanf("%d%d",&n,&m);



for(int i=0;i<n;i++)
for(int j=0;j<m;j++)
scanf("%d",&a[i][j]);




int br=0;

for(int i=0;i<m;i++)
{
    for(int j=0;j<n;j++)
    {   br=0;
            for(int k=0;k<n;k++)
            {
            if(a[j][i]<a[k][i])
            br++;  
            }
            

    min[j][i]=br;          
    }       
  
}



for(int i=0;i<n;i++)
{
    for(int j=0;j<m;j++)
    {   br=0;
            for(int k=0;k<m;k++)
            {
            if(a[i][j]>a[i][k])
            br++;  
            }
            

     max[i][j]=br;          
    }       
  
}
/*
for(int i=0;i<n;i++)
{
    printf("\n");
    for(int j=0;j<m;j++)
    printf("%d ",min[i][j]);
}

printf("\n");

for(int i=0;i<n;i++)
{
    printf("\n");
    for(int j=0;j<m;j++)
    printf("%d ",max[i][j]);
}

printf("\n");

for(int i=0;i<n;i++)
{
    printf("\n");
    for(int j=0;j<m;j++)
    printf("%d ",max[i][j]+min[i][j]);
}
*/
int rez=300*300;

for(int i=0;i<n;i++)
{
   // printf("\n");
    for(int j=0;j<m;j++)
    if(max[i][j]+min[i][j]<rez)
    rez=max[i][j]+min[i][j];
}


printf("%d",rez);

return 0;
}
