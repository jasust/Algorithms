#include <cstdio>
#include <algorithm>
#include <cstdlib>

long long a[14];
int b[14];
long long c[14];
int d[14];

bool cmp(int a, int b)
{
     return a>b;
}

int  main()
{
     
int n,k;
scanf("%d%d",&n,&k);


for(int i=0;i<n;i++)
{
        scanf("%lld", &a[i]);
        b[i]=i+1;
        
}    

for(int i=0;i<k;i++)
{
c[i]=0;
d[i]=i+1;
}
std::sort(a,a+n,cmp);    

if(n<k)
{     
      printf("%d\n",a[0]);
      for(int i=0;i<n;i++)
      if(n<k)printf("%d ",i);
      else printf("%d",0);
      return 0;
}
     
if(n==k)
{
 printf("%d",a[0]-a[n-1]);
 for(int i=0;i<n;i++)
 printf("%d ",i);
 return 0;      
}
     
for(int i=0;i<n;i++)
for(int j=i+1;j<n;j++)
if(a[i]<a[j])
{
             long long pom=a[i];
             a[i]=a[j];
             a[j]=pom;
             
            int g=b[i];
             b[i]=b[j];
             b[j]=g;

}




int knj=0;
while(knj<n)
{



 for(int i=0;i<k;i++)
 {
         c[i]+=a[knj];
         printf("%lld %lld\n",c[i],a[knj]);
        // printf("%d ",d[b[knj]]);
        
         knj++;



 }   
 
  
 
for(int i=0;i<k;i++)
for(int j=i+1;j<k;j++)
if(a[i]>a[j])
{
             long long pom=c[i];
             c[i]=c[j];
             c[j]=pom;
             
             pom=d[i];
             d[i]=d[j];
             d[j]=pom;

} 
            
   
            
}

for(int i=0;i<n;i++)
 {
        
         printf("%lld ",c[i]);
      
        
} 
     
     scanf("%d",&k);
 return 0;    
     
}
