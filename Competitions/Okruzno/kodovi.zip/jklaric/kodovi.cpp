#include <cstdio>
#include <cstdlib>



int p[100001];
int h[100001];

int main()
{
    int n, x;
    
    scanf("%d%d",&n,&x);
    
   
    
    
    for(int i=0;i<n;i++)
    scanf("%d%d",&p[i],&h[i]);
   //  scanf("%d",&p[i]);
    int l=0;
    int d=n;
    int s;
   
    while(l<=d)
    {
       s=(l+d)/2;
       
       if(p[s-1]<x && p[s]>x)
       {
       break;
     /*
       printf("%d", s);
       scanf("%d",&n);
       return 0;
       */
       }
       if(p[s]<x)
       {
        l=s+1;
       }
       
       else
       d=s-1;    
               
               
               
    }
    
    long long sec=0;
    
    
    
    sec+=p[s]-x;
    long long kr=1;
    h[s]--;
    
 
    
    l=s-1;
    d=s;
    
    
    
    if(s==0)
    {
    printf("%lld\n",kr);
    printf("%lld",sec);
    return 0;        
            
    }
   
    while(true)
    {
    
    
    
    if(h[l]<=h[d])
    { 
    
        if(s==l)
        {
                s=d;
                kr++;
                h[d]--;
                sec+=p[d]-p[l];
        }
    
   
    
    
    kr+=h[l]*2;
    h[d]-=h[l];
   
   
     sec+=2*h[l]*(p[d]-p[l]);
  
    
    s=d;
    h[l]=0;
    l--;
    
    
   
   
   }     
   
   else
   {
                
       if(s==d)
        {
                s=l;
                kr++;
                h[l]--;
                sec+=p[d]-p[l];
        }
   
   
   kr+=h[d]*2;
   h[l]-=h[d];
   
   
   
   sec+=2*h[d]*(p[d]-p[l]);
   
   
    
    
    s=l;
    h[d]=0;
    d++;
    
  
   
   
       
   }
    
    
    
    if(l<0)
    break;
    
    if(d>n-1)
    break;
    
    
} 
    
   
    

   printf("%lld\n",kr);
   printf("%lld",sec);

   
  
    
    
    return 0;
}
