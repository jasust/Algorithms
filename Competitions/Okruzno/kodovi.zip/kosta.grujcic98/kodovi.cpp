#include <iostream>
#include <stdio.h>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <string>
#include <string.h>
#include <iterator>
#include <algorithm>
#include <vector>
#include <stack>
typedef long long int ll;
using namespace std;

ll kodTotal, timeTotal, leva, desna, curSum;
ll saLeve, saDesne;
int n, x, curX, curH;
vector<pair<int,int> > posLeva;
vector<pair<int,int> > posDesna;

int main()
{
    scanf ("%d%d", &n, &x);
    for (int i=0;i<n;i++)
    {
        scanf ("%d%d", &curX, &curH);
        if (curX<x)
        {
            leva+=1ll*curH;
            posLeva.push_back(make_pair(curX-x, curH));
        }
        else
        {
            desna+=1ll*curH;
            posDesna.push_back(make_pair(curX-x, curH));
        }
    }

    saDesne=min(leva, desna); //ide cik cak, dakle ne moze da opici u tu stranu ako tu nema vise cega god
    kodTotal=2*saDesne;
    saLeve=saDesne;
    if (desna>leva)
    {
        saDesne++;
        kodTotal++; //posto krece u desno, ako levo vise nema nicega, a desno ima, moze jos jedan zdesna
    }
    //printf ("%I64d", kodTotal);

    for (int i=0;i<posDesna.size();i++)
    {
        ll pot=min(saDesne-curSum, 1ll*posDesna[i].second);
        curSum+=pot;
        timeTotal+=pot*2ll*posDesna[i].first;
        if (curSum==saDesne)
        {
            if (saDesne>saLeve) timeTotal-=1ll*posDesna[i].first;
            break;
        }
    }
    curSum=0ll;
    for (int i=posLeva.size()-1;i>=0;i--)
    {
        ll pot=min(saLeve-curSum, 1ll*posLeva[i].second);
        curSum+=pot;
        timeTotal+=pot*2ll*(-1)*posLeva[i].first;
        if (curSum==saLeve)
        {
            if (saLeve==saDesne) timeTotal+=1ll*posLeva[i].first;
            break;
        }
    }
    cout << kodTotal << endl << timeTotal;

    return 0;
}
