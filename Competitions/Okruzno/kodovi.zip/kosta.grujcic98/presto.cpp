#include <iostream>
#include <stdio.h>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <string>
#include <string.h>
#include <iterator>
#include <algorithm>
#include <vector>
#include <stack>
typedef long long int ll;
using namespace std;

//sta dobijem dobio sam fejlah

vector<pair<int,int> > curH;
int n, m, forLeft, forRight, curLeft, curRight, sol=10000010, curAnsFirst, curAnsSecond;
int a[310][310];

int main()
{
    scanf ("%d%d", &n, &m);
    for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) scanf ("%d", &a[i][j]);
    for (int i=1;i<=n;i++)
    {
        for (int j=1;j<=m;j++)
        {
            forLeft=0; forRight=0; curLeft=0; curRight=0; curAnsFirst=0; curAnsSecond=0;
            curH.clear();
            curH.push_back(make_pair(a[i][j], 0));

            //fiksiram red soritam po koloni, svi ovi brojevi treba da su veci= od a[i][j] => idu desno
            for (int newJ=1;newJ<=m;newJ++)
            {
                if (newJ!=j && a[i][j]!=a[i][newJ])
                {
                    curH.push_back(make_pair(a[i][newJ], 2));
                    forRight++;
                }
                else if (a[i][newJ]==a[i][j]) curH.push_back(make_pair(a[i][newJ], 0));
            }

            //fiksiram kolonu sorturam po redu, svi ovi brojevi treba da su manji= od a[i][j] => idu levo
            for (int newI=1;newI<=n;newI++)
            {
                if (newI!=i && a[i][j]!=a[newI][j])
                {
                    curH.push_back(make_pair(a[newI][j], 1));
                    forLeft++;
                }
                else if (a[newI][j]==a[i][j]) curH.push_back(make_pair(a[newI][j], 0));
            }
            sort(curH.begin(), curH.end());
            for (int q=0;q<curH.size();q++)
            {
                if (curH[q].second==0) break;
                if (curH[q].second==1) curLeft++;
                else curRight++;
            }
            int cntLeft=0, cntRight=0;
            for (int q=0;q<n;q++)
            {
                if (curH[q].second==0) curAnsSecond++;
                else if (curH[q].second==1) cntLeft++;
                else cntRight++;
            }
            curAnsFirst=forLeft-curLeft+curRight; //swapujem pogresno pozicionirane
            curAnsSecond+=(curLeft-cntLeft+cntRight);
            sol=min(sol, min(curAnsFirst, curAnsSecond));
        }
    }
    printf ("%d", sol);

    return 0;
}
