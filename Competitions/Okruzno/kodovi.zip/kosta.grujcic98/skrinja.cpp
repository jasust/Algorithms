#include <iostream>
#include <stdio.h>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <string>
#include <string.h>
#include <iterator>
#include <algorithm>
#include <vector>
#include <stack>
typedef long long int ll;
using namespace std;

//ladno ne znam da napravim komparator za pq, fft

priority_queue<pair<ll,int> > pq;
int n, k, a;
ll ans;
vector<pair<ll,int> > glupSam;
vector<pair<ll,int> > brStr;
int poglavlje[20];

int main()
{
    scanf ("%d%d", &n, &k);
    for (int i=1;i<=k;i++) pq.push(make_pair(0ll, i));
    for (int i=1;i<=n;i++)
    {
        scanf ("%d", &a);
        brStr.push_back(make_pair(1ll*a, i));
    }
    sort (brStr.begin(), brStr.end());
    reverse (brStr.begin(), brStr.end());
    for (int i=0;i<n;i++)
    {
        glupSam.clear();
        for (int j=0;j<k;j++)
        {
            glupSam.push_back(pq.top());
            pq.pop();
        }
        sort(glupSam.begin(), glupSam.end());
        //puts ("");
        //puts ("");
        //puts ("");
        //for (int i=0;i<k;i++) printf ("%I64d ", glupSam[i].first);
        glupSam[0].first+=brStr[i].first;
        poglavlje[brStr[i].second]=glupSam[0].second;
        for (int i=0;i<k;i++) pq.push(glupSam[i]);
        glupSam.clear();
    }
    for (int i=0;i<k;i++)
    {
        glupSam.push_back(pq.top());
        pq.pop();
    }
    sort (glupSam.begin(), glupSam.end());
    ans=glupSam[k-1].first-glupSam[0].first;
    cout << ans << endl;
    for (int i=1;i<=n;i++)
    {
        if (i!=n) printf ("%d ", poglavlje[i]);
        else printf ("%d", poglavlje[i]);
    }

    return 0;
}
