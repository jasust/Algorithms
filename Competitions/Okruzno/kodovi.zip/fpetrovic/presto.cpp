#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);

    int polja[n][m];

    //POPUNJAVANJE
    for(int x = 0; x < n; x++) {
        for(int y = 0; y < m; y++) {
            scanf("%d", &polja[x][y]);
        }
    }


    int promene = 1000;
    //PROVERAVANJE REDOM
 int brojac = 0;
    for(int x = 0; x < n; x++) {

        int xPos, yPos = 0;
        int min = polja[x][0];
        for(int y = 0; y < m; y++) {
            if(polja[x][y] < min)
            {
                min = polja[x][y];
                xPos = x;
                yPos = y;
            }
        }
        for(int z = 0; z < n; z++) {
            if(polja[z][yPos] > min)
            {
                brojac++;
            }

        }
        if(brojac < promene)
            promene = brojac;
    }


    printf("%d", promene);








    return 0;
}
