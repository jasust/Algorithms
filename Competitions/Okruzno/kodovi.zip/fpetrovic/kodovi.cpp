#include <iostream>
#include <stdio.h>

using namespace std;

bool beskonacnost(int smer, long long minKod, long long maxKod) {
    if((smer == 1 && maxKod == 0) || (smer == 0 && minKod == 0))
        return true;
    return false;
}

int proveri(long long xOse[], long long kolKod[], int xOsa, int n) {
    int brojac = 0;
    while(brojac < n) {
        if(xOse[brojac] == xOsa && kolKod[brojac] > 0)
            return brojac;
        brojac++;
    }
    return -1;
}

int main()
{
    long long n;
    long long x;

    int smer = 1;

    scanf("%lld %lld", &n, &x);
    long long xOse[n];
    long long kolKod[n];

    int brojac = 0;
    while(brojac < n) {
        scanf("%lld %lld", &xOse[brojac], &kolKod[brojac]);
        brojac++;
    }


    int sekunde = 0;
    int xOsa = x;
    int ukradeni = 0;
    while(!beskonacnost(smer, kolKod[0], kolKod[n - 1])) {
        sekunde++;
        if(smer == 1)
            xOsa++;
        else
            xOsa--;
        int cur = proveri(xOse, kolKod, xOsa, n);
        if(cur != -1) {
            kolKod[cur]--;
            ukradeni++;
            if(smer == 1)
                smer = 0;
            else
                smer = 1;
        }
    }
    cout << ukradeni << "\n";
    cout << sekunde;

    return 0;
}
