#include <iostream>
#include<stack>
#include<stdio.h>
#include<algorithm>
using namespace std;
int strana[14];
int index[14];
int dodela[14];
int perice[14];
int indxper[14];

int main()
{
int n,k;
scanf("%d%d",&n,&k);
for(int i=0;i<n;i++){
    scanf("%d",&strana[i]);
    index[i]=i;
}
for(int i=0;i<k;i++)indxper[i]=i+1;
int p=0;

for(int i=0;i<n;i++){
    for(int j=i+1;j<n;j++){
        if(strana[i]<strana[j]){
        p=strana[i];
        strana[i]=strana[j];
        strana[j]=p;
        p=index[i];
        index[i]=index[j];
        index[j]=p;
        }
    }
}

int min_raz=0;
int br=0;
while(br<n){
  //  sort(perice,perice+k);
  for(int q=0;q<k;q++){
    for(int w=q+1;w<k;w++){
        if(perice[q]>perice[w]){
            p=perice[q];
        perice[q]=perice[w];
        perice[w]=p;
        p=indxper[q];
        indxper[q]=indxper[w];
        indxper[w]=p;

        }
    }
   }

    perice[0]+=strana[br];
//dodela[br]=index perice koji je uzeo ovo
dodela[index[br]]=indxper[0];
    br++;
}
sort(perice,perice+k);
printf("%d",perice[k-1]-perice[0]);
printf("\n");
//dodela[i]
for(int i=0;i<n;i++)printf("%d ",dodela[i]);

    return 0;
}
