#include <iostream>
#include<stdio.h>
#include<cmath>
#include<algorithm>
using namespace std;
int p[100000],h[100000];
 int  n,x;
int veci(){
    // pozicija prvog veceg
for(int i=0;i<n;i++){
    if(h[i]>0&&p[i]>x){
        return i;

    }

}
return -1;
}

int manji(){
for(int i=n;i>=0;i--){
    if(h[i]>0&&p[i]<x)return i;

}
return -1;
}

// mionimum trazim
int minimum(int a,int b){
if(a>b)return b;
else return a;
}
int main()
{

    scanf("%d%d",&n,&x);
    for(int i=0;i<n;i++){
        scanf("%d%d",&p[i],&h[i]);

    }
    long long  kodovi=0;
    long long t=0;
    int smer=0;
    int tups=0;
    int tdowns=0;
     int upp=veci();
        int down=manji();
        int pom=0;
        t+=p[upp]-x;
    while(true){

//cout<<upp<<endl<<down<<endl;
        kodovi+=2*minimum(h[upp],h[down]);
       // cout<<kodovi<<endl;
        if(h[down]>h[upp])smer=1;
        else if (h[down]<h[upp])smer=0;
        pom=minimum(h[upp],h[down]);
        h[upp]-=pom;
        h[down]-=pom;
      //  cout<<h[down]<<endl<<h[upp]<<endl<<" "<<endl;
      t+=(p[upp]-p[down])*pom;
      tups=upp;
      tdowns=down;
        if(h[upp]==0)upp++;
        if(h[down]==0)down--;
// e sada treba da odredim vreme za koje izdadje, a to ce biti tesko ja mislim
if(smer==1)t+=p[tups]-p[down];
else t+=p[upp]-p[tdowns];

        //t+=(p[upp]-p[down])*(kodovi-1);
        if(h[0]==0)break;
        if(h[n-1]==0)break;
// e sad ovo radi iz nekog random razloga, ne znam koji je



    }
   // cout<<smer<<endl;
    if(h[0]==0&&smer==1)printf("%lld\n%lld",kodovi,t+2);
    else if (h[n-1]==0&&smer==0)printf("%lld\n%lld",kodovi,t+2);
    else printf("%lld\n%lld",kodovi+1,t+2);

    return 0;
}
