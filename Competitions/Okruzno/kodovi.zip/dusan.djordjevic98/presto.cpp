#include <iostream>
#include<stdio.h>
#include<cmath>
#include<algorithm>
using namespace std;
void getvect(){

}

int mat[300][300];
int main()
{
int n,m;
cin>>n>>m;
for(int i=0;i<n;i++){
    for(int j=0;j<m;j++){
       cin>>mat[i][j];
    }
}

cout<<1;
    return 0;
}
