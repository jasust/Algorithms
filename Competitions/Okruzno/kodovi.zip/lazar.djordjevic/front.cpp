#include <cstdlib>
#include <iostream>


using namespace std;

int main()
{
    int n, x, y, i, j, br;
    cin>>n;
    int front[n][2];
    j=br=0;
    for (i=0; i<n; i++)
    {
       cin>>x;
       cin>>y;
        if(i==0)
        {
         front [j][1]=x;
         front [j][2]=y;
         br++;         
         continue;
        }  
           
          if(y>=front[j][2]) 
           {
              front[j][1]=x;
              front[j][2]= y;                             
           }
        else
        { 
         
              j++;
              front[j][1]=x;
              front[j][2]= y;
              br++;                             
                   
         }
        
    }
    cout<<br;    
    return 0;
}
