#include <stdio.h>
using namespace std;
int p[100000],h[100000],n,x,index;
int main()
{
    int left,right;
    short turn;
    long long time,num;
    time=num=0;
    scanf("%d%d",&n,&x);
    index=n;
    for(int i=0;i<n;i++)
    {
            scanf("%d%d",&p[i],&h[i]);
            if(p[i]>x && index==n) index=i;
    }
    if(index==n) printf("0\n0");
    else
    {
        if(index==0) printf("1\n%d",p[0]-x);
        else
        {
            left=index-1;
            right=index;
            turn=1;
            while(1)
            {
                    if(turn)
                    {
                         if(right==n) break;
                         if(left==-1)
                         {
                                     time+=(p[right]-x);
                                     num+=1;
                                     break;
                         }
                         num+=1;
                         time+=(p[right]-x);
                         x=p[right];
                         turn=0;
                         h[right]-=1;
                         if(h[right]==0) {right+=1;continue;}
                         else
                         {
                             if(h[left]<=h[right])
                             {
                               x=p[left];
                               time+=((long long)(2*(p[right]-p[left])-1));
                               num+=((long long)(2*h[left]-1));
                               h[right]-=(h[left]-1);
                               turn=1;
                               left-=1;
                               continue;
                             }    
                             else
                             {
                               turn=0;
                               time+=((long long)(2*(p[right]-p[left])));
                               num+=((long long)(2*h[right]));
                               h[left]-=(2*h[right]);
                               x=p[right];
                               right+=1;
                               continue;
                             }
                          }
                     }
                     else
                     {
                         if(left==-1) break;
                         if(right==n)
                         {
                                     time+=(x-p[left]);
                                     num+=1;
                                     break;
                         }
                         num+=1;
                         time+=((long long)(x-p[left]));
                         x=p[left];
                         turn=1;
                         h[left]-=1;
                         if(h[left]==0) {left-=1;continue;}
                         else
                         {
                             if(h[right]<=h[left])
                             {
                                  turn=0;
                                  num+=((long long)(2*(h[right])-1));
                                  time+=((long long)(2*(p[right]-p[left])-1));
                                  h[left]-=(h[right]-1);
                                  x=p[right];
                                  right+=1;
                                  continue;
                             }
                             else
                             {
                                  turn=1;
                                  time+=((long long)(2*(p[right]-p[left])));
                                  num+=((long long)(2*h[left]));
                                  h[right]-=h[left];
                                  x=p[left];
                                  left-=1;continue;
                              }
                          }
                     }
              }
              printf("%lld\n%lld",num,time);
         }
    }
    return 0;
}
