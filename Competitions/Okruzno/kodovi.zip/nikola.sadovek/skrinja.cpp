#include <stdio.h>
#include <algorithm>
#include <iostream>
using namespace std;
int a[13],b[13],c[13],d[13],t=100000000,n,k;
void f(int index)
{
     if(index==n)
     {
                 for(int i=0;i<n;i++)
                 for(int i=1;i<=k;i++) c[i]=0;
                 for(int i=0;i<n;i++)
                 {
                         c[b[i]]+=a[i];
                 }
                 int u,s;
                 for(int i=1;i<=k;i++)
                 {
                         if(i==0) u=s=c[i];
                         else
                         {
                             if(c[i]>s) s=c[i];
                             if(c[i]<u) u=c[i];
                         }
                 }
                 if(s-u>t) 
                 {
                           t=s-u; 
                           for(int i=0;i<n;i++) d[i]=b[i];
                 }
                 return;
     }
     for(int i=1;i<=k;i++)
     {
             b[index]=i;
             f(index+1);
     }
}
int main()
{
    scanf("%d%d",&n,&k);
    for(int i=0;i<n;i++) scanf("%d",&a[i]);
    f(0);
    printf("%d\n",t);
    for(int i=0;i<n;i++) printf("%d ",d[i]);
    return 0;
}
