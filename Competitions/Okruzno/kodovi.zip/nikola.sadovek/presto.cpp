#include <stdio.h>
using namespace std;
int a[100][100];
int main()
{
    int n,m,x,min,br=0;
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++) for(int j=0;j<m;j++) scanf("%d",&a[i][j]);
    for(int i=0;i<n;i++){ for(int j=0;j<m;j++)
    {
            x=0;
            for(int k=0;k<n;k++) if(a[i][j]<a[k][j]) x++;
            for(int k=0;k<m;k++) if(a[i][j]>a[i][k]) x++;
            if(i==0 && j==0) min=x;
            else if(min>x) x=min;
    }
    }
    printf("%d",min);
    return 0;
}
