// ddjokic

#include <cstdio>
#define MAX_N 10000

#define DESNO +1
#define LEVO -1

using namespace std;

long long N, X;
long long a, b;
long long H[MAX_N];
long long P[MAX_N];
int o; // Orijentacija
long long K, T;


int main() {

    scanf("%lld %lld", &N, &X);

    a = b = -1;

    for (int i = 0; i < N; i++)
    {
        scanf("%lld %lld", P+i, H+i);
        if (a==-1 && P[i] >= X) {a = i-1; b = i;}
    }

    if (X > P[N-1]) {printf("0\n0\n"); return 0;}
    if (X < P[0]) {printf("1\n%lld\n", P[0]-X); return 0;}

    o = DESNO;
    T = 0;

    while(1)
    {
        if ( H[a] > H[b] )
        {
            if (o == DESNO)
            {
                K+=2*H[b]; T+= 2*(H[b])*(P[b]-P[a]) - (X - P[a]);
                H[a]-=H[b]; H[b]=0;
            }
            else if (o==LEVO)
            {
                K+=2*H[b]+1;T+= 2*(H[b])*(P[b]-P[a]) + (X - P[a]);
                H[a]-=H[b]; H[b]=0;
                H[a]--;
                if (H[a]==0) a--;
            }

            b++;
            X = P[a];
            o = DESNO;
        }
        else if (H[a] < H[b]) 
        {
            if (o == LEVO)
            {
                K+=2*H[a]; T+= 2*(H[a])*(P[b]-P[a]) - (P[b] - X);
                H[b]-=H[a]; H[a]=0;
            }
            else if (o== DESNO)
            {
                K+=2*H[a]+1;T+= 2*(H[a])*(P[b]-P[a]) + (P[b] - X);
                H[b]-=H[a]; H[a]=0;
                H[b]++;
                if (H[b]==0) b++;
            }

            a--;
            X = P[b];
            o = LEVO;
        }
        else if (H[a] == H[b])
        {
            K += 2*H[a];

            if (o == LEVO)
            {
                T+= 2*(H[a])*(P[b]-P[a]) - (P[b] - X);
                X = P[b];
            }
            else if (o== DESNO)
            {
                T+= 2*(H[a])*(P[b]-P[a]) - (X - P[a]);
                X = P[a];
            }

            H[a] = 0;
            H[b] = 0;

            a--;
            b++;
        }

        if ( (a < 0 && o == LEVO) || (b > N-1 && o == DESNO) ) { printf("%lld\n%lld\n", K, T); return 0; }
    }
}
