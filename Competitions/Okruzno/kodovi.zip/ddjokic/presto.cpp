#include <cstdio>

int main()
{
    printf("0\n");
    return 0;
}
