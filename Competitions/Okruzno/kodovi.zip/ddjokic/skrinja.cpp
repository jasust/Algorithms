// ddjokic
#include <stdio.h>

int N, K;

int p[14];
long long sum[14];
int SOL;
long long A[14];
int opt[14];

void doSomeStuff()
{
    for (int i = 1; i <= K; i++)
    {
        sum[i] = 0;
        for (int j = 1; j <= N; j++) if (i==p[j]) sum[i]+=A[j];
    }

    long long mx, mn;

    mx = sum[1];
    mn = sum[1];

    for (int i = 2; i <= K; i++)
    {
        if (mn > sum[i]) mn = sum[i];
        if (mx < sum[i]) mx = sum[i];
    }

    if ( mx - mn < SOL ) {SOL = mx - mn; for (int i = 1; i <= N; i++) opt[i]=p[i]; }

}

int bt(int level)
{
    for (int i = 1; i <= K; i++)
    {
        p[level] = i;
        if ( level<=N-1 ) bt(level+1); else doSomeStuff();
    }
}

int main()
{
    scanf("%d %d", &N, &K);

    for (int i = 1; i <= N; i++) {scanf("%lld", A+i); SOL += A[i];}

    bt(1);

    printf("%d\n", SOL);
    for (int i = 1; i <= N-1; i++) printf("%d ", opt[i]);
    printf("%d\n", opt[N]);

    return 0;
}
