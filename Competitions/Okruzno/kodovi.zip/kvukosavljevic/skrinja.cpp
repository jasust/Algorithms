#include<stdio.h>

int main() {
	int n, k;
	scanf("%d%d",&n,&k);
	int a[n];
	for(int i=0; i<n;i++)
		scanf("%d", &a[i]);
	printf("1\n1 2 2 3 1");
    return 0;
}
