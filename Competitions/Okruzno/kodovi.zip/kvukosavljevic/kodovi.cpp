#include <stdio.h>

int main() {
    long long n, x, c = 0, t = 0, ix, time;
	short dir = 1;
    scanf("%lld%lld",&n, &x);
	long long p[n], h[n];
	for(int i=0; i<n; i++) {
		scanf("%lld%lld", &p[i], &h[i]);
		if(p[i]>=x && x>p[i-1])
			ix=i;
	}
	while(1) {
		x += dir;
		t++;
		if(x>p[n-1] || x<p[0]) {
			break;
		}
		if(x == p[ix] && h[ix] <= 0) {
			ix += dir;
		}
		if(x == p[ix] && h[ix] > 0) {
			h[ix]--;
			c++;
			dir *= -1;
			ix += dir;
			time = t;
		}
	}
	printf("%lld\n%lld", c, time);
    return 0;
}
