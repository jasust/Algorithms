#include<stdio.h>

int main() {
	int n, m, s;
	scanf("%d%d",&n,&m);
	s=n*m;
	int a[n][m];
	for(int i=0; i<n;i++)
		for(int j=0; j<m; j++)
			scanf("%d", &a[i][j]);
	for(int i=0; i<n;i++)
		for(int j=0; j<m; j++){
			int ls=0;
			for(int o=0; o<n;o++)
				if(a[o][j] > a[i][j])
					ls++;
			for(int p=0; p<m; p++)
				if(a[i][p] < a[i][j])
					ls++;
			if(ls<s)
				s=ls;
		}
	printf("%d", s);
    return 0;
}
