#include <iostream>
using namespace std;
int main()
{   long  x[400][400];
    long red[400][400],kol[400][400],mini;
int n,m;
    int i,j,l;
    cin>>n>>m;
    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
            cin>>x[i][j];
    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
        { red[i][j]=1;
        for(l=1;l<=m;l++)
            if(x[i][l]<x[i][j])
            red[i][j]++;
        }
    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
        {
            kol[i][j]=1;
            for(l=1;l<=n;l++)
            if(x[l][j]>x[i][j])
            kol[i][j]++;
        }
        mini=kol[1][1]+red[1][1];
    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
            if(mini>kol[i][j]+red[i][j])
                mini=kol[i][j]+red[i][j];
    cout<<mini-2;
    return 0;


}
