#include <iostream>

using namespace std;

int main()
{  long long x,n,sk;
    int p[100010],h[100010],sl=0,sd=0,i,k=0,vl=0,vd=0,v=0,br,j;
    cin>>n>>x;
    for(i=1;i<=n;i++)
    {
        cin>>p[i]>>h[i];
        if(p[i]<x)
         {
             sl=sl+h[i];
         }
         else
         if(!k)
        {
            k=i;
            sd=sd+h[i];
        }
        else
            sd=sd+h[i]*p[i]*2;
    }
    vd=vd-(x-p[i]);
    if(sl<sd)
    {
        sk=sl*2+1;

    }
    else
    {
        sk=sd*2;
    }
    i=k;
    vd=sk;
    j=k+1;
    for(br=1;1;br++)
    {
        if (br%2)
        {
            v=v+(p[j]-x)*2;
            h[j]--;
            if(h[j]=0)
                j++;
            vd--;
            if(!vd)
                break;
        }
        else
        {
            v=v+(x-p[i])*2;
            h[i]--;
            if(h[i]=0)
                i--;
                vd--;
            if(!vd)
                break;
        }
    }
    cout<<sk<<endl<<v;
    return 0;
}
