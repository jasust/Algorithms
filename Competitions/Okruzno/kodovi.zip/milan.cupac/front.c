#include <iostream>
#include<stdio.h>


using namespace std;

int main(int argc, char *argv[])
{
    int n,i,j,m,k=0;
    int x[100],y[100];
    scanf("%d",&n);
    for(i=0;i<n;++i)
                  scanf("%d%d",&x[i],&y[i]);
    for(i=0;i<n;++i){
         m=0;
         for(j=0;j<n;++j){
              if(x[i]<=x[j] && y[i]<=y[j] && i!=j)
                     ++m;
         }
         if(m==0){
                  ++k;
         }
    }
    printf("%d\n",k); 
    return 0;        
    system("PAUSE");
    return EXIT_SUCCESS;
}
