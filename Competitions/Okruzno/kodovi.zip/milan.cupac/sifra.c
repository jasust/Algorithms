#include <stdio.h>
#include<math.h>


int power(int a,int b){
    int i=1,k=1;
    while(i<=b){
             k*=a;
             i++;
    }
    return k;
} 

int main(int argc, char *argv[])
{
    int n,m,i,v,j,l=0,c[1000];
    long long int k;
    long int a[100000];
    scanf("%d%d%lld",&n,&m,&k);
    for(i=0;i<n;++i)
                    scanf("%ld",&a[i]);
    for(i=0;i<m;++i){
                     c[i]=(k%power(n,i+1));
                     if(c[i]==0)
                             c[i]=power(n,i+1)-1;
                     else
                         c[i]-=1;
                     c[i]/=power(n,i);

    }
    --i;
    while(i>=0){
                printf("%d ",a[c[i]]);
                i--;
    }
    scanf("%d",&v);
    return 0;               
}
