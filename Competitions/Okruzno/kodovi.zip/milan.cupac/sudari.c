#include<stdio.h>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int i,j,n,m,y,x,l;
    long long int k;
    char a[100][100],v;
    scanf("%d%d%d%d%lld",&n,&m,&y,&x,&k);
    for(i=1;i<=n;++i){
         scanf("%c",&v);
         for(j=1;j<=m;++j){
              scanf("%c",&a[i][j]);
         }
    }
    for(l=0;l<k;++l){
         if(l%2==0){
                    if(l%4==0){
                    for(i=y;i<=n;++i){
                         if(a[i][x]=='#'){
                              y=i-1;
                              break;
                         }
                         else
                             y=n;
                    }
                    }
                    else{
                         for(i=y;i>0;--i){
                              if(a[i][x]=='#'){
                                   y=i+1;
                                   break;
                         }
                         else
                             y=1;
                    }
         } 
         }               
         else{
                    if(l%4==1){
                    for(i=x;i<=m;++i){
                         if(a[y][i]=='#'){
                              x=i-1;
                              break;
                         }
                         else
                             x=m;
                    }
         }
                    else{
                    for(i=x;i>0;--i){
                         if(a[y][i]=='#'){
                              x=i+1;
                              break;
                         }
                         else
                             x=1;
                    }
         }
    }
    }
    printf("%d %d\n",y,x);
    system("PAUSE");
    return EXIT_SUCCESS;
    return 0;
}
