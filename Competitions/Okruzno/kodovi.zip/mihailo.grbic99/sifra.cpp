#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;
long a[100000];
int main(int argc, char *argv[])
{
    long long n,m;
    long long k,t=1;
    
    long x;
    scanf("%lld %lld %lld",&n,&m,&k);
    for(int i=0;i<n;i++){
      scanf("%ld",&a[i]);        
    }
    for(int j=0;j<m-1;j++){
        t*=n;        
      }
    for(int i=m-1;i>=0;i--){
      x=a[((k-1)/t)%n];
      t/=n;
      printf("%ld ",x);        
    }
    
    
    
    
    
    
    
    return 0;
}
