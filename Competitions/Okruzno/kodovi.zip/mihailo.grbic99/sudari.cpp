#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char *argv[])
{
    bool iso=false;
    char a[500][500],e;
    int n,m,x,y,dir=0,br=0,q,r;
    long long k;
    scanf("%d %d",&n,&m);
    scanf("%d %d",&y,&x);
    scanf("%lld",&k);
    for(int i=0;i<n;i++){
      scanf("%d",&e);
      for(int j=0;j<m;j++){
        scanf("%c",&a[i][j]);        
      }           
    }
   
    
    x--;
    y--;
    while(br<k){
      iso=false;
      br++;
      
      if(dir==3){                 
        while((a[y][x]!='#')&&(x>-1)){
          x--;                             
        }
        dir=0;
        x++;
        iso=true;
      }
            
      if(dir==2){                 
        while((a[y][x]!='#')&&(y>-1)){
          y--;                             
        }
        dir++;
        y++;
      }
      
      if(dir==1){                 
        while((a[y][x]!='#')&&(x<m)){
          x++;                             
        }
        dir++;
        x--;
      } 
      
      if((dir==0)&&(iso==false)){ 
                       
        while((a[y][x]!='#')&&(y<n)){
          y++; 
                                      
        }
        
        dir++;
        y--;
      }
      
               
    }
    x++;
    y++;
    printf("%d %d",y,x);
    
    return 0;
}
