#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;
long a[1000000];
int main(int argc, char *argv[])
{
    long x,y,prex=-1;
    int n,br=0;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
      scanf("%ld",&x); 
      scanf("%ld",&y);
      for(int j=br-1;j>=0;j--){
        if(a[j]<=y){
          br--;              
        }else{
          break;      
        }        
      }
      if(x!=prex){
        prex=x;
        a[br]=y;
        br++;            
      }        
    }
    printf("%d",br);
    
    
    
    return 0;
}
