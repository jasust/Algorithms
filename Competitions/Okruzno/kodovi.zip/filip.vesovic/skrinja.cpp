//PRISLA JE SAMAA STA SAM MOGAO JAAA
#include <cstdio>
#include <vector>
//KAD HTJELAAA JEE SVEE DA MI DAAAA
#include <algorithm>
using namespace std;
pair<int,int> a[15];
int sum[15];
int podeliti[15];
int solution[15];
int sol=2*1000*1000*1000;
int n,k;
void solve()
{
    int bitmask=(1<<n)-1;
    for(int bit=0; bit<bitmask; bit++)
    {
        vector<int> podela;
        int cur=0;
        for(int i=0; i<n; i++)
        {
            cur++;
            if(bit&(1<<i))
            {
                podela.push_back(cur);
                cur=0;
            }
        }
        if(cur!=0)podela.push_back(cur);
        if(podela.size()==k)
        {
            for(int i=0; i<k; i++)sum[i]=0;
            int cur=0;
            int dx=1;
            for(int i=0; i<n; i++)
            {
                sum[cur]+=a[i].first;
                podeliti[a[i].second]=cur;
                podela[cur]--;
                do
                {
                    cur+=dx;
                    if(cur==k)
                    {
                        dx*=-1;
                        cur--;
                    }
                    if(cur==-1)
                    {
                        dx*=-1;
                        cur++;
                    }
                }
                while(podela[cur]==0&&i!=n-1);

            }
            int minn=2*1000*1000*1000,maxx=0;
            for(int i=0; i<k; i++)
            {
                minn=min(minn,sum[i]);
                maxx=max(maxx,sum[i]);
            }
            if(maxx-minn<sol)
            {
                sol=maxx-minn;
                for(int i=0; i<n; i++)solution[i]=podeliti[i];
            }
             //  printf("DEBUG: %d\n",maxx-minn);
            //    for(int i=0;i<k;i++)printf("%d ",sum[i]);
          //     printf("\n");
        }
    }

}

int main()
{
    scanf("%d%d",&n,&k);
    for(int i=0; i<n; i++)
    {
        int tmp;
        scanf("%d",&tmp);
        a[i]=make_pair(tmp,i);
    }
    sort(a,a+n);
    reverse(a,a+n);
    if(k>=n)
    {
        printf("%d\n",a[0]);
        for(int i=0; i<n; i++)printf("%d ",i+1);
        printf("\n");
        return 0;
    }
    solve();
    printf("%d\n",sol);
    for(int i=0;i<n;i++)printf("%d ",solution[i]+1);
    printf("\n");
    return 0;
}
