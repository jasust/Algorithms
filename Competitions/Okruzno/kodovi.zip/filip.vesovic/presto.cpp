#include <cstdio>
#include <algorithm>
#include <iostream>
#define DEBUG true
using namespace std;
int a[310][310];
int red[310][310];
int kolona[310][310];
int n,m;
int solve(int i,int j)
{
    int ret=0;
    ret+=(lower_bound(red[i],red[i]+m,a[i][j])-red[i]);
    // printf("%d\n",ret);
    ret+=n-(upper_bound(kolona[j],kolona[j]+n,a[i][j])-kolona[j]);

    for(int k=0; k<m; k++)
    {
        int num=red[i][k];
        if(num!=a[i][j])
        {
            int curr=1;
            curr+=(lower_bound(red[i],red[i]+m,num)-red[i]);
            if(num>a[i][j])curr--;
            curr+=n-(upper_bound(kolona[j],kolona[j]+n,num)-kolona[j]);
            if(num<a[i][j])curr--;

            ret=min(ret,curr);
        }
    }
    for(int k=0; k<n; k++)
    {
        int num=kolona[i][k];
        if(num!=a[i][j])
        {
            int curr=1;
            curr+=(lower_bound(red[i],red[i]+m,num)-red[i]);
            if(num>a[i][j])curr--;
            curr+=n-(upper_bound(kolona[j],kolona[j]+n,num)-kolona[j]);
            if(num<a[i][j])curr--;

            ret=min(ret,curr);
        }
    }
//printf("I: %d J :%d %d\n",i,j,ret);
    return ret;
}
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=0; i<n; i++)
        for(int j=0; j<m; j++)
        {
            scanf("%d",&a[i][j]);
            red[i][j]=a[i][j];
            kolona[j][i]=a[i][j];
        }
    for(int i=0; i<n; i++)sort(red[i],red[i]+m);
    for(int i=0; i<m; i++)sort(kolona[i],kolona[i]+n);

    int sol=999999;
    for(int i=0; i<n; i++)
        for(int j=0; j<m; j++)
        {
            sol=min(sol,solve(i,j));
        }
    printf("%d\n",sol);
    return 0;
}
