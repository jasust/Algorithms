//DAJ MI BAR DVA MINUTA SAM DVA MINUTA TRAZIM
#include <cstdio>
#include <vector>
//ZAR NE VIDIS DA LUD SAM I TI MI TREBAS DA SE SPASIMM
using namespace std;
#define MAXN 100010
//DAJ MI, JER DUGUJESSS POSLE SVEGA BAR TOLIKOO
long long P[MAXN],H[MAXN];
long long abs(long long x)
//I DOBRO ZNAS BAS KAO JA DA NIKO VOLETII TE NECEE KAOO JAAA KAOO JAAa
{
    if(x<0)return -x;
    return x;
}
vector<int> leftside;
vector<int> rightside;
int main()
{
    int n;
    long long x;
    scanf("%d%lld",&n,&x);
    for(int i=0; i<n; i++)
    {
        scanf("%lld%lld",&P[i],&H[i]);
    }
    for(int i=0; i<n; i++)
    {
        if(P[i]>x)rightside.push_back(i);
    }
    for(int i=n-1; i>=0; i--)
    {
        if(P[i]<x)leftside.push_back(i);
    }
    long long rightcode=0;
    long long leftcode=0;
    for(int i=0; i<rightside.size(); i++)rightcode+=H[rightside[i]];
    for(int i=0; i<leftside.size(); i++)leftcode+=H[leftside[i]];
///   printf("LEVA STRANA %lld DESNA STRANA %lld\n",leftcode,rightcode);
    long long sol=0;
    long long getleft=0,getright=0;
    bool levi=false;
    if(leftcode<rightcode)
    {
        sol=2*min(leftcode,rightcode)+1;
        getleft=leftcode;
        getright=leftcode+1;
        levi=false;
    }
    else
    {
        sol=2*min(leftcode,rightcode);
        getleft=leftcode;
        getright=leftcode;
        levi=true;
    }
    printf("%lld\n",sol);
    long long seconds=0;
    long long lastleft=0,lastright=0;
    for(int i=0; i<rightside.size(); i++)
    {
        long long h=H[rightside[i]];
        long long p=P[rightside[i]];
        long long minn=min(getright,h);
        getright-=minn;
        if(minn>0)lastright=p;
        seconds+=2*abs(p-x)*minn;
    }
    for(int i=0; i<leftside.size(); i++)
    {
        long long h=H[leftside[i]];
        long long p=P[leftside[i]];
        long long minn=min(getleft,h);
        getleft-=minn;
        if(minn>0)lastleft=p;
        seconds+=2*abs(p-x)*minn;
    }
    if(levi)seconds-=abs(lastleft-x);
    else seconds-=abs(lastright-x);
    printf("%lld\n",seconds);

    return 0;
}
