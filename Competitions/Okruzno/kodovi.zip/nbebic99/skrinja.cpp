#include <cstdio>
#include <cstring>

using namespace std;

int a[13] = {0};

int acum[13];

int p[13] = {0};

int mucenje[13];

int A, P;

int curmin, curmax;

int mnraz = 200000000;

int dobitna[13];

int ccc()
{
    curmin = p[0];
    curmax = p[0];
    for (int i = 1; i < P; i++)
    {
        if (p[i] > curmax) curmax = p[i];
        if (p[i] < curmin) curmin = p[i];
    }
}

void fin()
{
    ccc();
    if (curmax - curmin < mnraz)
    {
        mnraz = curmax - curmin;
        //for (int i = 0; i < P; i++) dobitna[i] = p[i];
        memcpy(dobitna, mucenje, sizeof(int) * A);
    }
}

void bt(int g)
{
    if (g == A)
    {
        fin();
        return;
    }

    ccc();
    if (acum[g] + curmin + mnraz <= curmax) return;

    for (int i = 0; i < P; ++i)
    {
        p[i] += a[g];
        mucenje[g] = i + 1;
        bt(g+1);
        p[i] -= a[g];
        if (mnraz == 0) return;
        if (mnraz == 1 && acum[0] % P != 0) return;
    }
}

int main()
{
    scanf("%i %i", &A, &P);
    for (int i = 0; i < A; i++)
    {
        scanf("%i", &(a[i]));
    }
    acum[A-1] = a[A-1];
    for (int i = A-2; i > 0; --i)
    {
        acum[i] = acum[i + 1] + a[i];
    }

    if (A <= P)
    {
        for (int i = 0; i < A; i++)
        {
            dobitna[i] = i + 1;
        }
        curmin = 2000000;
        curmax = -1;
        for (int i = 0; i < A; i++)
        {
            if (a[i] < curmin) curmin = a[i];
            if (a[i] > curmax) curmax = a[i];
        }

        if (A < P) curmin = 0;
        mnraz = curmax - curmin;
    }
    else
    {
        bt(0);
    }

    printf("%i\n%i", mnraz, dobitna[0]);
    for (int i = 1; i < A; i++)
    {
        printf(" %i", dobitna[i]);
    }

    return 0;
}
/*
5 3
1 3 2 5 3

13 13
5 7 12 4 98 51 75 84 12 5 95 32 15

8 8
1 2 3 4 5 6 7 8
*/
