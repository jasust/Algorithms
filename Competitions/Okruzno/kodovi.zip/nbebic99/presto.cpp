#include <cstdio>

using namespace std;

int h[300][300], minn = 700;

int main()
{
    int n = 300, m = 300;

    scanf("%i %i", &n, &m);

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            scanf("%i", &(h[i][j]));
            //h[i][j] = (i * 31 + j) % 64;
        }
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            int mxx = 0;
            for (int k = 0; k < n; k++)
            {
                if (h[k][j] > h[i][j]) mxx++;
            }

            for (int k = 0; k < m; k++)
            {
                if (h[i][k] < h[i][j]) mxx++;
            }

            if (minn > mxx)
            {
                minn = mxx;
            }
        }
    }

    printf("%i", minn);

    return 0;
}

/*
3 4
1 9 3 0
6 2 7 5
8 4 6 3
*/
