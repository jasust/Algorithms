#include <cstdio>

using namespace std;

#define m(a,b) ((a)<(b)?(a):(b))

int p[100000], h[100000];

int main()
{
    int n, x;

    int gr = -1;

    scanf("%d %d", &n, &x);

    long long az = 0, bz = 0;

    for (int i = 0; i < n; i++)
    {
        scanf("%d %d", &(p[i]), &(h[i]));

        if (p[i] < x)
        {
            az += h[i];
        }
        else
        {
            if (gr == -1) gr = i;
            bz += h[i];
        }
    }

    long long dpok = 0, lpok = 0;

    bool dposle = false;

    if (bz <= az)
    {
        lpok = bz;
        dpok = bz;
        dposle = true;
    }
    else
    {
        dpok = az + 1;
        lpok = az;
        dposle = false;
    }

    long long pokupljeno = lpok + dpok;

    long long vreme = 0;

    int llast = 0;

    if (gr > 0)
    {
        int pos = gr - 1;

        while (lpok > 0 && pos >= 0)
        {
            vreme += 2 * (x - p[pos]) * m(lpok, h[pos]);

            if (dposle && (x - p[pos]) * m(lpok, h[pos]) > 0)
            {
                llast = (x - p[pos]);
            }

            lpok -= m(lpok, h[pos]);

            --pos;
        }
    }

    int pos = gr;

    while (dpok > 0 && pos < n)
    {
        vreme += 2 * (p[pos] - x) * m(dpok, h[pos]);

        if (!dposle && ((p[pos] - x) * m(dpok, h[pos]) > 0))
        {
            llast = (p[pos] - x);
        }

        dpok -= m(dpok, h[pos]);

        ++pos;
    }

    printf("%lld %lld", pokupljeno, vreme - llast);

    return 0;
}
/*
3 7
5 2
10 1
12 4
*/
