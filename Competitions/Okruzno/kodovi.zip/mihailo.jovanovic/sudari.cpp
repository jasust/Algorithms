#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n,m;
    scanf("%d %d", &n, &m);
    int x,y;
    scanf("%d %d", &x, &y);
    x--;
    y--;
    int k;
    scanf("%d", &k);
    string a[n][m];
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < m; j++)
        {
            scanf("%s", &a[i][j]);        
        }        
    }
    bool ponavljanje =false;
    int smer= 0;
    int x1 = 0,x2 = 0;
    int znj = 0;
    while(!ponavljanje)
    {
        if(smer == 0)
        {
           x++;
           if(a[x][y] == "#")
           {
               x--;
               smer = 1;
               k--;
               znj++;
           }        
        }
        if(smer == 1)
        {
           y++;
           if(a[x][y] == "#")
           {
               y--;
               smer = 2;
               k--;
               znj++;
           }        
        } 
        if(smer == 2)
        {
           x--;
           if(a[x][y] == "#")
           {
               x++;
               smer = 3;
               k--;
               znj++;
           }        
        } 
        if(smer == 3)
        {
           y--;
           if(a[x][y] == "#")
           {
               y++;
               smer = 0;
               k--;
               znj++;
           }        
        }
        if(k==0)break;
        if(znj<2)
           znj = 0;
        else
        {
            x1 = x;
            x2 = y;
            while(a[x][y] != "#")
            {
                if(smer == 1)
                {
                   y++;
                   duzina++;     
                }
                else if(smer == 2)
                {
                   x--;
                   duzina++;  
                }
                else if(smer == 3)
                {
                   y--;
                   duzina++;  
                }  
                else if(smer == 0)
                {
                   x++;
                   duzina++;  
                }                
            }
            k-=2;
            ponavljanje = true;
        }                   
    }
    if(k > 0)
    {
        int znj2 = k/2;
        if(znj2 == 0)
        {
           printf("%d %d", x,y);        
        }   
        else
        {
               
        }
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
