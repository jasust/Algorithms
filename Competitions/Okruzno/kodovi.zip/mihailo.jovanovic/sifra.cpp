#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int m,n,k;
    scanf("%d" , &n);
    scanf("%d" , &m);
    scanf("%d" , &k);
    int a[n];
    for(int i = 0; i < n; i++)
    {
       scanf("%d", &a[i]);        
    }
    int b[m];
    int mod = 1;
    for(int i = m - 1; i >= 0; i--)
    {
        int t = (k % mod);
        if(t == 0)
        {
            int g = (k / mod) - 1;
            g = g % n;  
            b[i] = a[g];
        }
        else
        {
            int g = (k / mod);
            g = g % n;
            b[i] = a[g];
        }
        mod *= n; 
    }
    for(int i = 0; i < m; i++)
    {
        printf("%d ", b[i]);        
    }
    
    return 0;
}
