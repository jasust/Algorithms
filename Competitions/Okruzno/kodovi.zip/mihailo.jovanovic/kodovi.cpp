#include <cstdlib>
#include <iostream>

using namespace std;

int bs(int x, int a[],int l,int d)
{
   if(l==d)
   {   
      if(a[d] == x) return d;
      else return 0;
   }
   else
   {
      if(x < a[d / 2]) 
      {
           return bs(x,a,l,l + ((d - l)/2));
      }        
      else
      {
          return bs(x,a,l + ((d - l)/2),d);    
      }    
   }
}

int main(int argc, char *argv[])
{
    int n, x;
    scanf("%d", &n);
    scanf("%d", &x);
    int a[n];
    int p[n];
    for(int i = 0; i < n; i++)
    {
       scanf("%d", &a[i]);
       scanf("%d", &p[i]);        
    }
    int k = 1;
    int rez = 0;
    int vreme = 0;
    for(int i = 0; i > -1; i++)
    {
       if((x > a[n-1] && k > 0) || (x < a[0] && k < 0))
       {
          vreme = i;
          break;   
       }
       else
       {        
          x+=k;
          int v = bs(x,a,0,n-1);
          if(v != 0)
          {
             if(p[v] != 0)
             {
                 rez++;
                 k*=-1;       
             }                
          }            
       }
    }
    printf("%d %d", rez, vreme);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
