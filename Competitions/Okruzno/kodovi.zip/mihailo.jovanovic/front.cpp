#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n;
    scanf("%d", &n);
    int v[n][2];
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &v[i][0]);
        scanf("%d", &v[i][1]);
    }
    
    for(int i = 0; i < n; i++)
    {
              
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
