#include <iostream>
using namespace std;

char matrica[500][500];
int drejko[2];
int arrX,arrY;

void hodaj(char smer){
    if(smer=='D'){
        int proba=drejko[1]+1;
        if(proba<arrY){
            if(matrica[proba][drejko[0]]=='.'){
                drejko[1]=proba;
                hodaj('D');
            }
        }
    }else if(smer=='U'){
        int proba=drejko[1]-1;
        if(proba>=0){
            if(matrica[proba][drejko[0]]=='.'){
                drejko[1]=proba;
                hodaj('U');
            }
        }
    }else if(smer=='R'){
        int proba=drejko[0]+1;
        if(proba<arrX){
            if(matrica[drejko[1]][proba]=='.'){
                drejko[0]=proba;
                hodaj('R');
            }
        }
    }else if(smer=='L'){
        int proba=drejko[0]-1;
        if(proba>=0){
            if(matrica[drejko[1]][proba]=='.'){
                drejko[0]=proba;
                hodaj('L');
            }
        }
    }
}
int main()
{
    //Input
    cin>>arrY;
    cin>>arrX;
    cin>>drejko[1];
    cin>>drejko[0];
    drejko[1]--;drejko[0]--;
    long int brojSudara;
    cin>>brojSudara;
    for(int i=0;i<arrY;i++){
        for(int z=0;z<arrX;z++){
            cin>>matrica[i][z];
        }
    }
    char smer[]={'D','R','U','L'};
    int counter=0;

    for (long int sudar=0; sudar<brojSudara; sudar++){
        if(counter>4)
            counter=0;
        hodaj(smer[counter]);
        counter++;
    }
    cout<<drejko[1]+1<<" "<<drejko[0]+1;
    return 0;
}
