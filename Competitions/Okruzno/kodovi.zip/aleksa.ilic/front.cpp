#include <iostream>

using namespace std;
int main(){
    //Input begin
     unsigned long int length;
     cin>>length;
     unsigned long int arr[length][2];

    for( unsigned long int i=0; i<length; i++){
        cin>>arr[i][0];
        cin>>arr[i][1];
    }
    //Input end
    unsigned long int counter=0;

    for( unsigned long int i=0; i<length; i++){
        for ( unsigned long int z=0; z<length; z++){
            if(z<=i)
                continue;
            if(arr[i][0]<arr[z][0] && arr[i][1]<arr[z][1]){
                break;
            }
            if(z==(length-1)){
                counter++;
            }
        }
    }
    cout<<counter;

   return 0;
}
