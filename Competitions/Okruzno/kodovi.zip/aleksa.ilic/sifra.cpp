#include <iostream>
#include <cstdlib>
using namespace std;
typedef unsigned short int USHORT;

long int arr[100000];

long int niz[100000];
long int K;
long int nizLength;
long int arrLength;
long int counter =0;
void push(long int);


int main(){
    //Input start
    long int N,M;
    cin >>N;
    cin >>M;
    cin >>K;

    for(long int i=0; i<N;i++){
        cin>>arr[i];
    }
    //Input end
    for(long int i=0;i<M;i++){
        niz[i]=arr[0];
    }

    nizLength=M;
    arrLength=N;

    push(0);
    return 0;
}
void push(long int pushnum){
    int diff=abs(pushnum-nizLength);
    for(long int i=0;i<arrLength;i++){
        niz[pushnum]=arr[i];
        if(diff>1){
            push(pushnum+1);
        }else{
            counter++;
            if(counter==K){
                for(long int z=0;z<nizLength;z++){
                    cout<<niz[z];
                    if(z!=(nizLength-1)){
                        cout<<" ";
                    }
                }
                exit(0);
            }
        }

    }

}
