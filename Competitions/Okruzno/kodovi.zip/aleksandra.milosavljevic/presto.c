#include <stdio.h>

int main()
{
    int n,m,i,j;long int h[305][305], res,min[305],max[305];
    scanf("%d %d",&n,&m);
    for (i=1;i<=n;i++)
    for (j=1;j<=m;j++)
    scanf("%ld",&h[i][j]);
    for (i=1;i<=n;i++)
    {
        min[i]=1000000005;
        for (j=1;j<=m;j++)
        if (min[i]>h[i][j]) min[i]=h[i][j];
    }
    for (j=1;j<=m;j++)
    {
        max[j]=0;
        for (i=1;i<=n;i++)
        if (h[i][j]>max[j]) max[j]=h[i][j];
    }
    for (i=1;i<=n;i++)
    for (j=1;j<=m;j++)
    if (min[i]==max[j])
        {
            res=0;
            break;
        }
    printf("%ld",res);

    return 0;
}
