#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

int main()
{
    long int a[20],s;float p;int n,k,i;
    scanf("%d %d",&n,&k);
    for (i=1;i<=n;i++) scanf("%ld",&a[i]);
    int cmp(int,int);
    sort(a+1,a+n+1,cmp);
    long int min=100005;
    for (i=1;i<=n;i++)
    {
        s+=a[i];
        if (a[i]<min) min=a[i];
    }
    p=s/n;
    printf("%ld",abs(ceil(p)-min));
    for (i=1;i<=n;i++) printf("%ld",a[i]%k);
    return 0;
}

int cmp(int x,int y)
{
    if (x>y) return 0;
    return 1;
}
