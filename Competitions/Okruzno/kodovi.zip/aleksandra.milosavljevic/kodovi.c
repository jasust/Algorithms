#include <stdio.h>

int main()
{
    int n,lev=0,des,i,id,il,td,tl,j;long x,m;
    long int p[10005],h[10005],hlevo[10005],hdesno[10005],plevo[10005],pdesno[10005],sek=0,brkod=0;
    scanf("%d %ld",&n,&x);
    for (i=1;i<=n;i++)
    {
        scanf("%ld %ld",&p[i],&h[i]);
        p[i]-=x;
    }
    i=1;
    while (p[i]<0)
    {
        lev++;
        plevo[lev]=p[i];
        hlevo[lev]=h[i];
        i++;
    }
    des=n-lev;
    for (j=i;j<=n;j++)
        {
            pdesno[j-i+1]=p[j];
            hdesno[j-i+1]=h[j];
        }
    void zam(long,long);
    for (i=1;i<=(lev/2);i++)
        {
            zam(plevo[i],plevo[lev-i+1]);
            zam(hlevo[i],hlevo[lev-i+1]);
        }
    /*for (i=1;i<=des;i++) printf("desni %ld ",pdesno[i]);
    printf("\n");
    for (i=1;i<=lev;i++) printf("levi %ld ",plevo[i]);
    printf("\n");
    printf("%ld\n",lev);
    printf("%ld\n",des);*/
    if ((n==1)&&(p[1]>0)) {brkod=1; sek=p[1];}
    else
    {
        id=1;
        il=1;
        long min(long,long);
        while ((id<=des)||(il<=lev))
        {
            m=min(hlevo[il],hdesno[id]);
            sek+=((-1)*plevo[il])*2*m+pdesno[id]*(2*m+1);
            brkod+=4*m+1;
            if (m==hlevo[il])
            {
                td=pdesno[id];
                hdesno[id]-=m;
                hlevo[il]=0;
                tl++;
                if ((id+1<des)&&(hdesno[id]==0))
                {
                    sek+=pdesno[id+1]-pdesno[i];
                    td=pdesno[id+1];
                }
                else
                if ((id+1>=des)&&(hdesno[id]==0))
                {
                    break;
                }
            }
            else
            {
                td=pdesno[id+1];
                tl=plevo[il];
                hdesno[id]=0;
                hlevo[il]-=m;
                if ((il+1<lev)&&(hlevo[il]==0))
                {
                    sek+=plevo[il+1]-plevo[il];
                    tl=plevo[il+1];
                }
                else
                if ((il+1>=lev)&&(hlevo[il]==0))
                {
                    break;
                }
            }
            il=tl;id=td;

        }


    }
    printf("%ld\n",brkod-1);
    printf("%ld\n",sek*2+3);
    return 0;
}
long min(long x,long y)
{
    long m;
    m=x;
    if (y<m) m=y;
    return m;
}
void zam(long a,long b)
{
    long p;
    p=a;
    a=b;
    b=p;
}
