#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
int main()
{
int n,f,brojac;
scanf("%d",&n);
int a[n];
int b[n];
brojac=0;
f=0;
for(int i=0;i<n;i++)
{
        scanf("%d%d",&a[i],&b[i]);
}

for(int i=0;i<n;i++)
{
        for(int j=0;j<n;j++)
        {
                if((a[i]>a[j])||(b[i]>b[j]))
                brojac=brojac+1;
        }
if(brojac==n-1)
f=f+1;
brojac=0;
}
printf("%d",f);
return 0;
}
                           
