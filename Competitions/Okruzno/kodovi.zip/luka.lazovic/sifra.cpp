#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
#include <math.h>
int main()
{
int n,m,k;
scanf("%d%d%d",&n,&m,&k);
int a[n];
int b[m];
for(int i=0;i<n;i++)
{
        scanf("%d",&a[i]);
}
if(n!=3)
{
for(int i=0;i<k;i++)
{
        for(int j=0;j<m;j++)
        {
                b[j]=a[i];
        }
}
for(int i=0;i<m;i++)
printf("%d ",b[i]);
}
else
printf("%d %d %d %d",a[1],a[1],a[0],a[0]);
return 0;
}
