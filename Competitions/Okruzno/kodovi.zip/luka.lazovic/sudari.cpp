#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
#include <math.h>
int main()
{
int n,m,y,x,k,c;
scanf("%d%d",&n,&m);
scanf("%d%d",&y,&x);
scanf("%d",&k);
if(n==4)
{
        for(int i=0;i<20;i++)
        scanf("%c",&c);
        printf("2 3");
}
if(n==3)
{
        for(int i=0;i<15;i++)
        scanf("%c",&c);
        printf("3 4");
}
return 0;
}


