//FORG1VEN JE PICKA
//ISTVUD KLINTE
//FNC HYPE
#include <cstdio>
#include <algorithm>

using namespace std;

struct node
{
    int val,x,y;
    inline bool operator < (const node &cpr) const
    {
        return val<cpr.val;
    }
};

int vals[305][305];

node red[305][305];
node kolona[305][305];

node spoji[605];

int n,m;



int main()
{
    //freopen("in.txt","r",stdin);
    scanf("%d%d",&n,&m);
    for (int i=1; i<=n; i++)
        for (int j=1; j<=m; j++)
            scanf("%d",&vals[i][j]);
    for (int i=1; i<=n; i++)
        for (int j=1; j<=m; j++)
        {
            red[i][j].val=vals[i][j];
            red[i][j].x=i;
            red[i][j].y=j;

            kolona[j][i].val=vals[i][j];
            kolona[j][i].x=i;
            kolona[j][i].y=j;
        }
    for (int i=1; i<=n; i++)
        sort(red[i]+1,red[i]+1+m);
    for (int j=1; j<=m; j++)
        sort(kolona[j]+1,kolona[j]+1+n);

    int ret=n*m;
    for (int x=1; x<=n; x++)
        for (int y=1; y<=m; y++)
        {
            for (int i=1; i<n; i++)
                if (kolona[y][i].val==kolona[y][i+1].val)
                    if (kolona[y][i].x==x)
                        swap(kolona[y][i],kolona[y][i+1]);
            for (int j=m; j>1; j--)
                if (red[x][j].val==red[x][j-1].val)
                    if (red[x][j].y==y)
                        swap(red[x][j],red[x][j-1]);

            int p1,p2,o;
            p1=1;
            p2=1;
            o=1;
            while (p1<=m || p2<=n)
            {
                if ((red[x][p1].val<kolona[y][p2].val && p1<=m) || p2>n)
                {
                    spoji[o]=red[x][p1];
                    o++;
                    p1++;
                }
                else
                {
                    if (kolona[y][p2].x!=x)
                    {
                        spoji[o]=kolona[y][p2];
                        o++;
                    }
                    p2++;
                }
            }
            o--;
            /*
            printf("%d %d\n",x,y);
            for (int i=1; i<=o; i++)
                printf("%d ",spoji[i].val);
            printf("\n");
            */
            /*
            for (int i=1; i<=o; i++)
            {
                printf("%d",spoji[i].val);
                if (spoji[i].y==y)
                    printf("-");
                if (spoji[i].x==x)
                    printf("+");
                printf(" ");
            }
            printf("\n");
            */
            int m,z,p;
            m=z=p=0;
            for (int i=1; i<=o; i++)
            {
                if (spoji[i].x==x && spoji[i].y==y)
                    z=max(m,z)+1;
                if (spoji[i].x!=x && spoji[i].y==y)
                    m=m+1;
                if (spoji[i].x==x && spoji[i].y!=y)
                    p=max(max(m,z),p)+1;
            }
            ret=min(ret,o-max(max(m,z),p));
            //printf("%d %d %d\n",x,y,o-max(max(m,z),p));
        }
    printf("%d\n",ret);
}
