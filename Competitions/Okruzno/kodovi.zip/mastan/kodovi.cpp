//FORG1VEN JE PICKA
//ISTVUD KLINTE
//FNC HYPE
#include <cstdio>
#include <algorithm>

using namespace std;

int vals[100005];
int pl[100005];
int n,x;

int main()
{
    //freopen("in.txt","r",stdin);
    scanf("%d%d",&n,&x);
    for (int i=1; i<=n; i++)
        scanf("%d%d",&pl[i],&vals[i]);
    int l,r;
    r=1;
    while (pl[r]<=x && r<=n)
        r++;
    l=r-1;
    //printf("%d %d\n",l,r);
    long long cnt;
    long long tme;
    cnt=0;
    tme=0;
    while (l>=1 && r<=n)
    {
        tme+=pl[r]-x;
        x=pl[r];
        long long add,atm;
        add=min(vals[l],vals[r]);
        atm=pl[r]-pl[l];

        cnt+=add*2;
        tme+=2*atm*add;
        vals[l]-=add;
        vals[r]-=add;

        if (vals[r]==0)
        {
            tme-=x-pl[l];
            x=pl[l];
        }
        if (vals[r]==0)
            r++;
        if (vals[l]==0)
            l--;
    }
    if (r<=n)
    {
        cnt++;
        tme+=pl[r]-x;
    }
    printf("%lld\n%lld\n",cnt,tme);

}
