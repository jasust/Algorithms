//FORG1VEN JE PICKA
//ISTVUD KLINTE
//FNC HYPE
#include <cstdio>
#include <algorithm>

using namespace std;

int vals[13];
int sum[1<<13];
int sol[13][1<<13];
int bck[13][1<<13];

int n,k;

int who[13];
int pl[13];
int pcn;


int main()
{
    //freopen("in.txt","r",stdin);
    scanf("%d%d",&n,&k);
    for (int i=0; i<n; i++)
        scanf("%d",&vals[i]);
    sum[0]=0;
    for (int msk=0; msk<1<<n; msk++)
        for (int i=0; i<n; i++)
            if ((msk&(1<<i))==0)
                sum[msk|(1<<i)]=sum[msk]+vals[i];
    for (int msk=0; msk<1<<n; msk++)
    {
        sol[0][msk]=sum[msk];
        bck[0][msk]=msk;
    }
    for (int it=0; it<k-1; it++)
        for (int msk=0; msk<1<<n; msk++)
            //if (sol[it][msk]!=0)
            {
                pcn=0;
                for (int i=0; i<n; i++)
                    if ((msk&(1<<i))==0)
                        pl[pcn++]=i;
                int nm=0;
                for (int itt=1; itt<=1<<pcn; itt++)
                {
                    if (min(sol[it][msk],sum[nm])>sol[it+1][msk|nm])
                    {
                        sol[it+1][msk|nm]=min(sol[it][msk],sum[nm]);
                        bck[it+1][msk|nm]=nm;
                    }
                    int i=0;
                    do
                    {
                        nm^=1<<pl[i];
                        i++;
                    } while ((itt&(1<<(i-1)))==0);
                }
            }
    int cur=(1<<n)-1;
    int mn,mx;
    mx=0;
    mn=2000000000;
    for (int it=k-1; it>=0; it--)
    {
        //printf("%d %d\n",it,sum[bck[it][cur]]);
        for (int i=0; i<n; i++)
            if ((1<<i)&bck[it][cur])
                who[i+1]=it+1;
        mn=min(mn,sum[bck[it][cur]]);
        mx=max(mx,sum[bck[it][cur]]);
        cur^=bck[it][cur];
    }
    printf("%d\n",mx-mn);
    for (int i=1; i<=n; i++)
        printf("%d ",who[i]);
}
