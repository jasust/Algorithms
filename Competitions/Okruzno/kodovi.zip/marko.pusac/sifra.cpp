#include <cstdio>
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    int n,m,k,a[100001],i,s,h,j;
    
    cin>>n>>m>>k;
    
    for(i=1;i<=n;i++)
    {
                     cin>>a[i];
    }
    
    i=m-1;
    
    while(i>=1)
    {
               h=n;
               
               for(j=1;j<i;j++)
               {
                               h*=n;
               }
               if(k%h==0)
               {
                               s=k/h;
               }
               else
               {
                   s=k/h+1;
               }
               s%=n;
               
               if(s==0)
                       s=n;
               
               cout<<a[s]<<" ";
               
               i--;
    }
    
    s=k%n;
    
    if(s==0)
            s=n;
            
    cout<<a[s];

    return 0;
}
