#include <cstdio>
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n,i,k=0,f=0,j;
    
    cin>>n;
    
    int x[100000],y[100000];
    
    for(i=0;i<n;i++)
    {
                   cin>>x[i]>>y[i];
    }
    
    for(i=0;i<n;i++)
    {
                      for(j=0;j<n;j++)
                      {
                                      if(i==j)
                                      {
                                              continue;
                                      }
                                        if(y[i]<=y[j] && x[i]<=x[j])
                                        {
                                                      k=1;
                                                      break;
                                        }
                      }
                      if(k==1)
                             k=0;
                      else
                          f++;                 
    }
    
    cout<<f;
    
    return 0;
}
