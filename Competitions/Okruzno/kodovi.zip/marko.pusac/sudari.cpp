#include <cstdio>
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n,m,i,j,x,y;
    char a[502][502]={'#'},p='j';
    long int k,s=0;
    
    cin>>n>>m;
    cin>>y>>x;
    cin>>k;
    
    for(j=1;j<=n;j++)
    {
                     for(i=1;i<=m;i++)
                     {
                                      cin>>a[j][i];
                     }
    }
    
    while(s!=k)
    {
              switch(p)
              {
                       case 'j':if(a[y+1][x]=='.')
                                {
                                                  y++;
                                }else
                                {
                                     s++;
                                     p='i';
                                }break;
                       case 'i':if(a[y][x+1]=='.')
                                {
                                                  x++;
                                }else
                                {
                                     s++;
                                     p='s';
                                }break;
                       case 's':if(a[y-1][x]=='.')
                                {
                                                  y--;
                                }else
                                {
                                     s++;
                                     p='z';
                                }break;
                       case 'z':if(a[y][x-1]=='.')
                                {
                                                  x--;
                                }else
                                {
                                     s++;
                                     p='j';
                                }break;
              }
    }
    
    cout<<y<<' '<<x;

    return 0;
}
