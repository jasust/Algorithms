#include <stdio.h>
#include <stdlib.h>
#define max 300
#define MAXLONG 1000000001

 long long a[max][max], b[max][max], c[max][max], min, mx, koliko, minova, mxova;
   // koliko ce da predstavlja broj obelezenih polja u b i c
  // trebalo bi da su dovoljna 32 bita za 10^9 ali ipak stavljam 64
 
int main(int argc, char *argv[])
{
  int n, m, i, j;
  scanf("%d %d", &n, &m);
  if(m==1 || n==1) printf("0");
  else
  {
       
       
       
  for(i=0; i<n; i++)
      for(j=0; j<m; j++)
      {
          scanf("%lld", &a[i][j]);
          b[i][j]=-1;
          c[i][j]=-1;
      }
  // pri ucitavanju niza a, b i c postavim na -1 da bih posle mogao da proverim da li su obelezeni 
  for(i=0; i<n; i++)
  {
           koliko=0;
           while(koliko<m)
           {
               min=MAXLONG;
               minova=0;
               for(j=0; j<m; j++)
               {
                   if((a[i][j] < min) && (b[i][j] == -1)) {min=a[i][j]; minova=1;}
                   else if((a[i][j]== min) && (b[i][j] == -1)) minova+=1;
               }
               for(j=0; j<m; j++)
                        if((a[i][j]==min) && (b[i][j] == -1))
                                          b[i][j]=koliko;
               koliko+= minova;
           }
  }

    for(i=0; i<m; i++)
  {
           koliko=0;
           while(koliko<n)
           {
               mx=-1;
               mxova=0;
               for(j=0; j<n; j++)
               {
                   if(a[j][i] > mx && c[j][i] == -1) {mx=a[j][i]; mxova=1;}
                   else if(a[j][i]== mx && c[j][i] == -1) mxova+=1;
               }
               for(j=0; j<n; j++)
                        if((a[j][i]==mx) && (c[j][i] == -1))
                                          c[j][i]=koliko;
               koliko+= mxova;
           }
  }
  min = 300;
  for(i=0; i<n; i++)
      for(j=0; j<m; j++)
          if(b[i][j] + c[i][j] < min) min = b[i][j] + c[i][j];
  printf("%lld", min);  
}
//  system("PAUSE");	
  return 0;
}
