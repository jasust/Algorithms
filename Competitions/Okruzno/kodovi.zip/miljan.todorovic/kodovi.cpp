#include<stdio.h>
#include<stdlib.h>

    long long n, x, i;
    long long levo=0, desno=0, a, b, zbir;

int main()
{
    scanf("%lld, %lld", &n, &x);
    for(i=0; i<n; i++)
    {
        scanf("%lld %lld", &a, &b);
        if(a>x) desno = desno + b;
            else levo = levo + b;
    }
    if(levo>=desno) printf("%lld\n", 2*desno);
    if(desno>levo) printf("%lld\n", 2*levo + 1);
//    printf("%d", desno);
    system("pause");
}
