#include <stdio.h>
#include <math.h>

int main(){
    int m, k, i, n, b, j, i1;
    b = 0;
    scanf("%d",&n);
    int f[n];
    scanf("%d",&m);
    int w[m];
    scanf("%d",&k);
    for(i=0;i<n;i++){
        scanf("%d",&f[i]);
    }
    for(i=0;i<m;i++){
        w[i] = f[0];
    }
    if(m==1){
        for(i=0;(b!=k)&&(i<n);i++){
            w[0] = f[i];
            b++;
        }
        printf("%d",w[0]);
    } else if (m==2){
        for(j=0;j<pow(n,m);j++){
            for(i=0;(b!=k)&&(i<n);i++){
                w[1] = f[i];
                b++;
            }
            w[0] = f[j+1];
            w[1] = f[0];
        }
        for(i=0;i<m;i++){
            printf("%d ",w[i]);
        }
    }
    return 0;
}
