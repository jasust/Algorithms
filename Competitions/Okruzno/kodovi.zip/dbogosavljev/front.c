#include <stdio.h>
int main(){
    long int n, v, x, y, x1, y1, i;
    scanf("%d",&n);
    scanf("%d",&x);
    scanf("%d",&y);
    x1 = x;
    y1 = y;
    for(i=1;i<n;i++){
        scanf("%d",&x);
        scanf("%d",&y);
        if((x1>=x)&&(y1>=y)){
            v++;
        }
        x1 = x;
        y1 = y;
    }
    printf("%d\n",v);
    return 0;
}
