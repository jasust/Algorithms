#include <cstdio>

using namespace std;

long vojnici[1000001][2];
int main()
{
    long n;
    scanf("%ld", &n);
    for (long i=1;i<=n;i++)
    {
        scanf("%ld", &vojnici[i][0]);
        scanf("%ld", &vojnici[i][1]);
    }
    long maxy=-1;
    long cv=-1;
    long bv=0;
    for (long i=n;i>=1;i--)
    {
        if (vojnici[i][1]>maxy)
        {
            maxy=vojnici[i][1];
            if (vojnici[i][0]!=cv)
            {
                cv=vojnici[i][0];
                bv++;
            }
        }
    }
    printf("%ld", bv);
    return 0;
}
