#include <cstdio>

using namespace std;

long long n,m,k;
long long brojke[100001];

long long pov (long long base, long long power, long long maxi)
{
    long long r=1;
    for(long long i=1;i<=power;i++)
    {
        r*=base;
        if (r>=maxi) return -1;
    }
    return r;
}
int main()
{
    scanf("%lld", &n);
    scanf("%lld", &m);
    scanf("%lld", &k);
    for (long long i=1;i<=n;i++) scanf("%lld", &brojke[i]);
    for (long long i=1;i<=m;i++)
    {
        long long bv=pov(n, m-i, k);
        long long accec;
        if (bv==-1)
        {
            accec=1;
        }
        else if (k%bv==0) accec=k/bv;
        else accec=k/bv+1;
        k-=(accec-1)*bv;
        printf("%lld ", brojke[accec]);
    }
    return 0;
}
