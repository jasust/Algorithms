#include <cstdio>

using namespace std;

char lavirint[505][505];
long long n,m;
char heading = 'D';
void switchHeading()
{
    if (heading=='D') heading='R';
    else if (heading=='R') heading='U';
    else if (heading=='U') heading='L';
    else heading = 'D';
}
long long deltaX()
{
    if (heading=='U') return -1;
    if (heading=='D') return 1;
    return 0;
}
long long deltaY()
{
    if (heading=='R') return 1;
    if (heading=='L') return -1;
    return 0;
}
bool willCrash(long long x, long long y)
{
    return x>n || y>m || x<1 || y<1 || lavirint[x][y]=='#';
}
struct crash
{
    long long x, y;
    char direction;
    void upd(long long xn, long long yn, char dn)
    {
        x=xn;
        y=yn;
        direction=dn;
    }
};
crash cs[100000];
long long ncr=0;
void addCrash(long long x, long long y, char direction)
{
    ncr++;
    cs[ncr].upd(x,y,direction);
}
long long crashHappened(long long x, long long y, char direction)
{
    for(long long i=1;i<=ncr;i++)
    {
        if (cs[i].direction==direction && cs[i].x==x && cs[i].y==y) return i;
    }
    return 0;
}
int main()
{
    long long x,y;
    long long k;
    scanf("%lld", &n);
    scanf("%lld", &m);
    scanf("%lld", &x);
    scanf("%lld", &y);
    scanf("%lld", &k);
    for (long long i=1;i<=n;i++)
    {
        scanf("%s", &lavirint[i][1]);
    }
    while(true)
    {
        if (willCrash(x+deltaX(), y+deltaY()))
        {
            long long kpc=crashHappened(x,y,heading);
            if (kpc!=0)
            {
                long long bss=k-1;
                long long crc=ncr-kpc+1;
                long long xc=cs[kpc+(bss%crc)].x;
                long long yc=cs[kpc+(bss%crc)].y;
                printf("%lld %lld", xc, yc);
                return 0;
            }
            else
            {
                addCrash(x,y, heading);
                switchHeading();
                k--;
                if (k==0)
                {
                    printf("%lld %lld", x, y);
                    return 0;
                }
                continue;
            }
        }
        else
        {
            x+=deltaX();
            y+=deltaY();
            continue;
        }
    }
}
