#include <cstdio>
#include <algorithm>

using namespace std;

const int N = 305;
int board[N][N];
int o_board[N][N], f_board[N][N];
int max_h[N], max_v[N];

struct entry { int x, i; } ;
entry _entry(int x, int i) { entry e; e.x = x; e.i = i; return e; } // no c++11
bool operator<(entry a, entry b) { return a.x < b.x; }
entry e[N];

void order(int a[], int res[], int n)
{
	for(int i = 0; i < n; i++)
		e[i] = _entry(a[i], i);
	sort(e, e + n);
	for(int i = 0; i < n; i++)
		res[e[i].i] = i ? (e[i].x == e[i - 1].x ? res[e[i - 1].i] : i) : i;
}

int tmp[N], tmp_o[N];

int main()
{
	//freopen("test.in", "r", stdin);

    int n, m;
    scanf("%i %i", &n, &m);
    for(int i = 0; i < n; i++)
		for(int j = 0; j < m; j++)
			scanf("%i", &board[i][j]);

	for(int i = 0; i < n; i++)
		order(board[i], o_board[i], m);
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++) tmp[j] = -board[j][i];
		order(tmp, tmp_o, n);
		for(int j = 0; j < n; j++) f_board[j][i] = tmp_o[j];
	}

	for(int i = 0; i < n; i++)
		for(int j = 0; j < m; j++)
		{
			max_h[i] = max(max_h[i], board[i][j]);
			max_v[j] = min(max_v[j], board[i][j]); // da, pogresno se zove
		}

	int res = 1 << 30;
	for(int i = 0; i < n; i++)
		for(int j = 0; j < m; j++)
			res = min(res, min(f_board[i][j] + o_board[i][j], max_h[i] <= max_v[j] ? 1 : (1 << 30)));

	printf("%i\n", res);

    return 0;
}
