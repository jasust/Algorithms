// promeniti ime zadatka u "optimizovanje"
#include <cstdio>
#include <queue>

using namespace std;

const int N = 15;
int val[N], n, k;

inline int min(int x, int y) { return x < y ? x : y; }
inline int max(int x, int y) { return x < y ? y : x; }

int get_res(int lo, int mid, int amid, int hi)
{
	int l = min(min(lo, mid), min(amid, hi)), h = max(max(lo, mid), hi);
	return h - l;
}

int global_res = 1 << 30;
long long res_id; // perfect hash, manje-vise; kopiranje niza je sporo
int res_last;
int cnt = 0;

void gen(int depth, int mass[], long long id, int lim)
{
	if(depth == n - 2)
	{
	//	for(int i = 0; i < k; i++) printf("%6i", mass[i]); printf("  #  ");
		int lo, mid, amid, hi;
		lo = mid = hi = amid = 0;
		for(int i = 0; i < k; i++)
		{
			if(mass[lo] > mass[i]) lo = i;
			if(mass[hi] < mass[i]) hi = i;
		}
		for(int i = 0; i < k; i++)
			if((mid == lo || mass[mid] > mass[i]) && i != lo) mid = i;
		for(int i = 0; i < k; i++)
			if((mass[amid] > mass[i] || amid == mid || amid == lo) && i != lo && i != mid) amid = i;

		lo = mass[lo]; mid = mass[mid]; hi = mass[hi];
		amid = mass[amid];

		cnt++;

		//if(lo == 1009 && mid == 1010) printf("%i %i\n", amid, hi);

		int my_a = get_res(lo + val[n - 1] + val[n - 2], mid, amid, hi);
		int my_b = get_res(lo + val[n - 1], mid + val[n - 2], amid, hi);
		int my_c = get_res(lo + val[n - 2], mid + val[n - 1], amid, hi);

		int my = my_a; int my_last = 0;
        if(my_b < my) { my = my_b; my_last = 1; }
        if(my_c < my) { my = my_c; my_last = 2; }

		if(my < global_res) { global_res = my; res_id = id; res_last = my_last;}
	//	printf("%i %i -> %i\n", lo, hi, my);
	}
	else
	{
		for(int i = 0; i <= lim && i < k; i++)
		{
			mass[i] += val[depth];
			gen(depth + 1, mass, id * (depth + 1LL) + (long long) i, max(lim, i + 1));
			mass[i] -= val[depth];
		}
	}
}

void decode_id(long long id, int res[])
{
	for(int i = n - 3; i >= 0; i--)
	{
		res[i] = id % (i + 1LL);
		id /= i + 1LL;
	}
}

int total_res = 1 << 30, total_own[N];
void total_gen(int depth, int own[])
{
	if(depth == n)
	{
		int sum[N] = {0};
		for(int i = 0; i < n; i++) sum[own[i]] += val[i];

		int lo = 0, hi = 0;
		for(int i = 0; i < k; i++) if(sum[i] < sum[lo]) lo = i;
		for(int i = 0; i < k; i++) if(sum[i] > sum[hi]) hi = i;

		//for(int i = 0; i < n; i++) printf("%i%c", own[i], i == n - 1 ? '\n': ' ');
		//printf("%i %i\n", sum[hi], sum[lo]);

		if(total_res > sum[hi] - sum[lo])
		{
			total_res = sum[hi] - sum[lo];
			for(int i = 0; i < n; i++) total_own[i] = own[i];
		}
	}
	else
	{
        for(int i = 0; i < k; i++)
		{
			own[depth] = i;
			total_gen(depth + 1, own);
		}
	}
}

void total_bruteforce()
{
	if(k > n)
	{
		int mv = 0;
		for(int i = 0; i < n; i++) mv = max(mv, val[i]);
		printf("%i\n", mv);
		for(int i = 0; i < n; i++) printf("%i%c", i + 1, i == n - 1 ? '\n': ' ');
	}
	else
	{
		int tmp[N] = {0};
		total_gen(0, tmp);
		printf("%i\n", total_res);
		for(int i = 0; i < n; i++) printf("%i%c", total_own[i] + 1, i == n - 1 ? '\n' : ' ');
	}
}

int main()
{
	//freopen("test.in", "r", stdin);
//	freopen("test.out", "w", stdout);
	scanf("%i %i", &n, &k);
	for(int i = 0; i < n; i++) scanf("%i", &val[i]);

	if(n < 6) { total_bruteforce(); return 0; } // optimizacije, ..., nesto sad ne radi
	if(k < 4) { total_bruteforce(); return 0; } // ne bi trebalo da je bitno, ali za svaki slucaj

	int tmp[N] = {0};
	gen(0, tmp, 0, 0);
	printf("%i\n", global_res);
	int res[N] = {0};
	decode_id(res_id, res);

	int mass[N] = {0};
	for(int i = 0; i < n - 2; i++) mass[res[i]] += val[i];
    int lo = 0, mid = 0;
    //for(int i = 0; i < k; i++) printf("%3i", res[i]); printf("\n");
    //for(int i = 0; i < k; i++) printf("%3i", mass[i]); printf("\n\n");
    for(int i = 1; i < k; i++) if(mass[i] < mass[lo]) lo = i;
    for(int i = 1; i < k; i++) if((mid == lo || mass[i] < mass[mid]) && i != lo) mid = i;
	//printf("%i %i\n", lo, mid);

	if(res_last == 0)
	{
		res[n - 2] = lo;
		res[n - 1] = lo;
	}
	else if(res_last == 1)
	{
		res[n - 2] = mid;
		res[n - 1] = lo;
	}
	else
	{
		res[n - 2] = lo;
		res[n - 1] = mid;
	}

    for(int i = 0; i < n; i++) printf("%i%c", res[i] + 1, i == n - 1 ? '\n' : ' ');

	//total_bruteforce();

    return 0;
}
// konacno
