#include <cstdio>

using namespace std;

const int N = 100005;
int pos[N], val[N];

int main()
{
	//freopen("test.in", "r", stdin);

    int n, x;
    scanf("%i %i", &n, &x);
    for(int i = 0; i < n; i++)
		scanf("%i %i", &pos[i], &val[i]);

	long long n_left = 0, n_right = 0;
	for(int i = 0; i < n; i++)
		(pos[i] < x ? n_left : n_right) += val[i];

    if(n_right < n_left) n_left = n_right;
    else if(n_right - 1 > n_left) n_right = n_left + 1;
    bool out_r = n_right <= n_left;

	long long cnt = n_left + n_right;
    long long time = 0;
    int s = 0;
    while(pos[s] < x) s++;

//	printf("leaving %s\n", out_r ? "right" : "left");

    for(int i = s; n_right; i++)
	{
		if(val[i] > n_right) val[i] = n_right;
		n_right -= val[i];
		//printf("getting %i codes @ pos %i (dist %i)\n", val[i], pos[i], pos[i] - x);
		time += 2LL * (long long)(pos[i] - x) * (long long)val[i];
		if(!n_right && !out_r) time -= pos[i] - x;
	}

	for(int i = s - 1; n_left; i--)
	{
		if(val[i] > n_left) val[i] = n_left;
		n_left -= val[i];
		//printf("getting %i codes @ pos %i (dist %i)\n", val[i], pos[i], x - pos[i]);
		time += 2LL * (long long)(x - pos[i]) * (long long)val[i];
		if(!n_left && out_r) time -= x - pos[i];
	}

	printf("%lld\n%lld\n", cnt, time);

    return 0;
}
