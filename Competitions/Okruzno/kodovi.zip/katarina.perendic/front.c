#include <stdio.h>
#include <stdlib.h>

int main()
{
  int n,mat[1000][2],i,j,da=0,ne=0;
  scanf("%d",&n);
  for(i=0;i<n-1;i++)
      for(j=0;j<1;j++)
           scanf("%d",&mat[i][j]);
           
   for(i=0;i<n;i++)
       for(j=0;j<1;j++)
      if((mat[i][j]<mat[i+1][j]) && (mat[i][j+1]<=mat[i+1][j+1]))ne++;
      else da++;
                   
  printf("%d",da-1);
                  

  return 0;
}
