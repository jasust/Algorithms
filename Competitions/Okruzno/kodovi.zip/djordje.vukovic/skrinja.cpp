#include <cstdio>
#include <algorithm>

using namespace std;

struct kogde
{
    int perc;
    long pogl;
};

bool uporedi(long a,long b)
{
    return a>b;
}

int main()
{
    int n,k;
    scanf("%d %d", &n,&k);
    long a[15];
    long per[15];
    long per2[15];
    kogde kraj[15];
    for ( int i=0;i<n;++i ) scanf("%ld",&a[i]);
    for ( int i=0;i<n;++i ) kraj[i].pogl=a[i];
    for ( int i=0;i<n;++i ) kraj[i].perc=0;
    sort (a,a+n,uporedi);
    if (k==1)
    {
        printf("0\n");
        for ( int i=0;i<n;++i ) printf("1 ");
    }
    else if (k==n)
    {
        printf("%ld\n", a[0]-a[n-1]);
        for ( int i=1;i<=n;++i ) printf("%d ", i);
    }
    else
    {
       for ( int i=1;i<=k;++i ) {per[i]=a[i]; per2[i]=a[i];}
       int i=0,p=0;
       for ( int j=1;j<=k;++j)
       {
       gore:
       while (a[j]!=kraj[i].pogl) ++i;
       if (kraj[i].perc!=0) {++i; goto gore;}
       kraj[i].perc=j;
       i=0;
       }
       for ( int j=1;j<=n-k;++j)
       {
           gore1:
           while (a[k+j]!=kraj[i].pogl) ++i;
           if (kraj[i].perc!=0) {++i; goto gore1;}
           while (per[1]!=per2[p]) ++p;
           per2[p]+=a[k+j];
           per[1]+=a[k+j];
           kraj[i].perc=p;
           sort(per,per+k);
           i=0;
           p=0;
       }
       printf("%ld\n", per[0]-per[k-1]);
       for ( int r=0;r<n;++r ) printf("%d ",kraj[r].perc);
    }
    return 0;
}
