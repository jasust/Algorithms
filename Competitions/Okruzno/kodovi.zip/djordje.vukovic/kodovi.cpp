#include <cstdio>

using namespace std;

struct gomila
{
    long p;
    long h;
};

int main()
{
    long n,x,s=0,k=0;
    scanf("%ld %ld", &n,&x);
    gomila* a=new gomila[n];
    for ( long i=0;i<n;++i ) scanf("%ld %ld", &a[i].p,&a[i].h);
    long i=0;
    while ( x>a[i].p ) ++i;
    if (i==0) printf("1\n%ld",a[0].p-x);
        else
        {
            while ((i>=0) && (i<n))
            {
                ++k;
                if (a[i].p>x)
                    {
                        s+=a[i].p-x;
                        x=a[i].p;
                        --a[i].h;
                        --i;
                        while ((a[i].h==0) && (i>=0)) --i;
                    }
                     else
                        {
                            s+=x-a[i].p;
                            x=a[i].p;
                            --a[i].h;
                            ++i;
                            while ((a[i].h==0) && (i<n)) ++i;
                        }
            }
            printf("%ld\n%ld", k,s);
        }
    return 0;
}
