#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int n, m;
long long k;
int lav[501][501];

int main() {

    int x, y;
    cin >> n >> m;
    cin >> y >> x;  
    cin >> k;
    
    string inp;
    for (int i = 1; i <= n; i++) {
            cin >> inp;
            for(int j = 1; j <= m; j++) {
                    if(inp[j-1] == '#') {
                           lav[i][j] = 1;
                    } else
                    if(inp[j-1] == '.') {
                           lav[i][j] = 0;
                    }
            }
    }
    
    char dir = 'd';
    int kt = 0;
    int tX = x, tY = y;
    while (kt < k) {
             if(dir == 'd') {
                    if(lav[tY + 1][tX] == 1 || tY == n) {
                              kt++;
                              dir = 'r';          
                    } else {
                           tY++;
                    }
             } else
             if(dir == 'u') {
                    if(lav[tY - 1][tX] == 1 || tY == 1) {
                              kt++;
                              dir = 'l';          
                    } else {
                           tY--;
                    }
             } else
             if(dir =='r') {
                    if(lav[tY][tX + 1] == 1 || tX == m) {
                              kt++;
                              dir = 'u';          
                    } else {
                           tX++;
                    }
             } else
             if(dir == 'l') {
                    if(lav[tY][tX - 1] == 1 || tX == 1) {
                              kt++;
                              dir = 'd';          
                    } else {
                           tX--;
                    }
             }
                    
    }
    
    printf("%d %d", tY, tX);
    return 0;

}
