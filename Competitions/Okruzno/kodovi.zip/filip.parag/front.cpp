#include <iostream>
#include <fstream>
using namespace std;

int n, f = 0;
int *x, *y, *m;

int main() {

    cin >> n;
    x = new int [n + 1];
    y = new int [n + 1];
    
    m = new int [n + 1];
    
    for (int i = 0; i < n; i++) {
        m[i] = 0;    
    }
    
    for (int i = 0; i < n; i++) {     
        cin >> x[i] >> y[i];
        if (m[x[i]] < y[i]) {
           m[x[i]] = y[i];
        }
    }
    
    for (int i = 0; i < n; i++) {
        int r = 0;
        int rx = 0;
        for (int j = i + 1; j < n; j++) {
            if (m[j] >= m[i]) {
               r++;
            } else {
              r--;
            }
            rx--;
        }
        if (r == rx) {
           f++;
        }
    }
    
    cout << f;
    return 0;

}
