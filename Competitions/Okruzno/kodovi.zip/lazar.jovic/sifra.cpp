#include<stdio.h>   
#include<stdlib.h>
#include<math.h>
#include<time.h>
int main()
{int n,m,k,a[100000],i,j,b[100000];
 scanf("%d %d %d\n",&n,&m,&k);
 for(i=0;i<n;i++)
  scanf("%d",&a[i]);
 for(i=0,j=m;i<m;i++,j--)
  b[j]=a[(int)(pow(n,i)+0.0001)%k%m];
 for(i=0;i<n;i++)
   printf("%d\n",&b[i]);
 //system("pause");
 return 0;
}
