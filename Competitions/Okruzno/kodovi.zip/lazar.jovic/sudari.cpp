#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
main()
{int n,m,x,y,k,i,j;
 char a[500][500];
 scanf("%d%d\n%d%d\n%d",&n,&m,&x,&y,&k);
 for(i=0;i<n;i++)
  for(j=0;j<m;j++)
   scanf("%c",&a[i][j]);
 system("pause");
 return 0;
}
