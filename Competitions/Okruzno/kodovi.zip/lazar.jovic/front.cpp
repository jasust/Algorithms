#include<stdio.h>   
#include<stdlib.h>
#include<math.h>
#include<time.h>
int x[1000000],y[1000000];
int main()
{int n,i,br=1,a,b;
 scanf("%d\n",&n);
 for(i=0;i<n;i++)
  {scanf("%d",&x[i]);
   scanf("%d",&y[i]);
  }
 a=x[n-1];
 b=y[n-1];
 for(i=n;i>0;i--)
  if((x[i-1]<a)&&(y[i-1]>b))
  {br++;
   a=x[i-1];
   b=y[i-1]; 
  }
 printf("%d\n",br);
 //system("pause");
 return 0;
}
