#include <cstdlib>
#include <iostream>
#include <algorithm>

using namespace std;
int x,y,*ym,n,b,lx,ly;
int main()
{
    cin>>n;
    lx=ly=0;
    ym=new int[n];
    for (int i=0;i<n;i++){
        cin>>x>>y;;

        if (lx<x){
        lx=x;
        ly=0;
        } 
        if ((lx==x)&&(ly<=y)){    
           ym[lx]=y;
           ly=y;
        }       
    } 
for (int i=0;i<lx-1;i++){
    if (ym[lx-i-1]>ym[lx-i])
    b++; 
    }
    cout<<b;
    delete ym;
    return 0;
}
