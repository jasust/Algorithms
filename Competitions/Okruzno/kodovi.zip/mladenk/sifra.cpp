#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;
int n,m,*x,*r;
long long k,c,p;
void rek (int p,int b){
         for (int i=p;i<n;i++){
             r[b]=x[i];
             if (b==m-1)
                c++;
             if (c==k){
             for (int j=0;j<m;j++)
             cout<<r[j]<<" ";
             }
             if((b+1<m)&&(c<=k))    
             rek(0,b+1);
                   
             }                   
     }

int main(int argc, char *argv[])
{
    cin>>n>>m>>k;
    r=new int[m];
    x=new int[n];
    for (int i=0;i<n;i++)
    cin>>x[i];
    p=1;
    for(int i=0;i<m-1;i++)
    p=p*n;
    c=p;
    p=(k-1)/p;
    c=p*c;
    rek (p,0);
	delete x,r;
    return 0;
}
