#include <cstdlib>
#include <iostream>

using namespace std;
long long c,k;
char p[501][501];
int x,y,n,m,prav;

void kret1 (int yk,int xk){
           if (((y+yk<n+1)&&(y+yk>0))&&((x+xk<m+1)&&(x+xk>0))){
           if (p[y+yk][x+xk-1]!='#'){
              x=x+xk;
              y=y+yk;}
           else {
                c++;
                prav++;     
           }}
           else {
                c++;
                prav++;} 
     }

void kret(){
     while (c!=k){
           if (prav<5){
           if (prav==1)
           kret1(1,0);  
           else if (prav==2)
           kret1(0,1);
           else if (prav==3)
           kret1(-1,0);
           else if (prav==4)
           kret1(0,-1);   
           }else prav=1;
     }
     }

int main(int argc, char *argv[])
{   
    cin>>n>>m;
    cin>>y>>x;
    cin>>k;
    for (int i=1;i<n+1;i++)
    cin>>p[i];
    prav=1;
    c=0;
    kret();
    cout<<y<<" "<<x;
    return 0;
}
