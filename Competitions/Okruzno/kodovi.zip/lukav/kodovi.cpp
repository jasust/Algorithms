#include <iostream>
#include <stdio.h>
using namespace std;
long long n,x, p[100005], a[100005],r,s,t,suma;
void radi(long long pl, long long pd, bool desno)
{
    if(desno)
    {
        if(pl==-1)
        {
            s++;
            return;
        }
        if(a[pl]>=a[pd])
        {
            r+=(a[pd]*2-1)*(p[pd]-p[pl]);
            s+=2*a[pd]-1;
            a[pl]=a[pl]-a[pd]+1;
            radi(pl,pd+1,0);
        }
        else
        {
            r+=2*a[pl]*(p[pd]-p[pl]);
            s+=2*a[pl];
            a[pd]=a[pl]-a[pd];
            radi(pl-1,pd,1);
        }
    }
    else
    {
        if(pd==n)
        {
            s++;
            return;
        }
        if(a[pd]>=a[pl])
        {
            r+=(a[pl]*2-1)*(p[pd]-p[pl]);
            s+=2*a[pl]-1;
            a[pd]=a[pd]-a[pl]+1;
            radi(pl-1,pd,1);
        }
        else
        {
            r+=2*a[pd]*(p[pd]-p[pl]);
            s+=2*a[pd];
            a[pl]=a[pd]-a[pl];
            radi(pl,pd+1,0);
        }
    }
}
int main()
{
    scanf("%lld %lld", &n, &x);
    for(long long i=0;i<n;i++)
    {
        scanf("%lld %lld", &p[i], &a[i]);
        suma+=a[i];
    }

   for(long long i=0;i<n;i++)
    {
        if(p[i]>x)
        {
            t=i;
            r+=p[i]-x;
            break;
        }
    }
    radi(t-1,t,1);
    /*
    long long s1=0,s2;
    for(long long i=t;i<n;i++)
        s1+=a[i];
    s2=suma-s1;
    if(s1<=s2)
    {
        s=2*s1;

    }
    else
    {
        s=2*s2+1;
    }
    */
    cout<<s<<endl<<r;
    return 0;
}
/*
3 7
5 2
10 1
12 4
*/
