#include <iostream>
#include <stdio.h>
using namespace std;
int m,n,r;
long long a[301][301];
int main()
{
    cin>>m>>n;
    r=m*n;
    for(int i=0;i<m;i++)
    for(int j=0;j<n;j++)
        cin>>a[i][j];
    for(int i=0;i<m;i++)
    for(int j=0;j<n;j++)
    {
        long long minr=1000000000,maxk=0;
        for(int j1=0;j1<n;j1++)
            if(j1!=j)
                minr=min(minr,a[i][j1]);
        for(int i1=0;i1<m;i1++)
            if(i1!=i)
                maxk=max(maxk,a[i1][j]);
        int m11=1,m12=1,m2=0;
        for(int j1=0;j1<n;j1++)
            if(j1!=j&&a[i][j1]<maxk)
            {
                m11++;
            }
        for(int i1=0;i1<m;i1++)
            if(i1!=i&&a[i1][j]>minr)
            {
                m12++;
            }
        for(int j1=0;j1<n;j1++)
            if(j1!=j&&a[i][j1]<a[i][j])
            {
                m2++;
            }
        for(int i1=0;i1<m;i1++)
            if(i1!=i&&a[i1][j]>a[i][j])
            {
                m2++;
            }
        r=min(min(min(m11,m12),m2),r);
    }
    cout<<r;
    return 0;
}
/*
3 4
1 9 3 0
6 2 7 5
8 4 6 3
*/
