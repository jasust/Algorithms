#include <iostream>
#include <stdio.h>

using namespace std;
int n,k,ind[14];
long long a[14], pom[14], r[14],m1=1300000001,r1[14];
void proveri()
{
    long long max1=0,min1=1300000001;
    for(int i=0;i<k;i++)
    {
        max1=max(pom[i],max1);
        min1=min(pom[i],min1);

    }
    if(max1-min1<m1)
    {
        m1=max1-min1;
        for(int i=0;i<n;i++)
            r1[ind[i]]=r[i];
    }
}
void radi (int l, int d, int t)
{
    if(l>d)
    {
        proveri();
        return;
    }
    if(l==d)
    {
        pom[t]+=a[l];
        r[l]=t;
        radi(l+1,d,t);
        pom[t]-=a[l];
    }
    if(l<d)
    {
        pom[t]+=a[l];
        r[l]=t;
        radi(l+1,d,t);
        pom[t]+=a[d]-a[l];
        r[d]=t;
        radi(l,d-1,t);
        pom[t]-=a[d];
        if(pom[t]!=0&&t+1<k)
            radi(l,d,t+1);
    }
}
int main()
{
    cin>>n>>k;
    long long max1=0,min1=100000001;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        ind[i]=i;
        max1=max(a[i],max1);
        min1=min(a[i],min1);
    }

    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(a[j]<a[i])
            {
                int p=a[i];
                a[i]=a[j];
                a[j]=p;
                p=ind[i];
                ind[i]=ind[j];
                ind[j]=p;
            }
        }
    }
    if(k>n)
    {
        cout<<max1<<endl;
        for(int i=1;i<=n;i++)
            cout<<i<<" ";
        return 0;
    }
    if(k==n)
    {
        cout<<max1-min1<<endl;
        for(int i=1;i<=n;i++)
            cout<<i<<" ";
        return 0;
    }
    radi(0,n-1,0);
    cout<<m1<<endl;
    for(int i=0;i<n;i++)
        cout<<r1[i]+1<<" ";
    return 0;
}
/*
13 6
12 14 18 10 16 5 20 18 32 41 33 12 19
*/
