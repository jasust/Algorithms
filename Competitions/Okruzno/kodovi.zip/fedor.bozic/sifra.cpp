#include<iostream>

using namespace std;

int main()
{
    int i,j;
    int n;
    int m;
    int k;
    int tmp;

    cin >> n;
    cin >> m;
    cin >> k;

    int rezultat[m];
    int niz[n];
    int delimit[m];

    for(i=0;i<n;i++)
    {
        cin >> niz[i];
    }
    for(i=0;i<m;i++)
    {
        delimit[i] = 1;
    }
    for(i=1;i<m;i++)
    {
        delimit[i] = delimit[i-1]*n;
    }
    for(i=0;i<m;i++)
    {
        if(i==0)
        {
           if(k%n-1 == -1)
           {
               rezultat[i] = niz[n-1];
           }
           else
           {
               rezultat[i] = niz[k%n-1];
           }
        }
        else
        {
        /*if(k%n==0)
        {
            cout << "a: ";
            cout << (k+(k/delimit[i])%n-1)%n << endl;
            rezultat[i] = niz[(k+(k/delimit[i])%n-1)%n];
        }
        else
        {
            cout << "b: ";
            cout << (k+(k/delimit[i]+1)%n)%n << endl;
            rezultat[i] = niz[(k+(k/delimit[i]+1)%n-1)%n];
        }*/
        tmp = k/delimit[i];
        if(k%delimit[i] != 0)
        {
            tmp++;
        }
        tmp = tmp%n-1;
        if(tmp == -1)
        {
            tmp = n-1;
        }
        //cout << tmp << endl;
        rezultat[i] = niz[tmp];
        }
    }

    for(i=m-1;i>=0;i--)
    {
        cout << rezultat[i] << " ";
    }
    return 0;
}
/*
3 4 37
6 11 533
*/
