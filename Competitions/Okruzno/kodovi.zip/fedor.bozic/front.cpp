#include<iostream>

using namespace std;

int main()
{
    int maxx=0,maxy=0;
    int tmpx=0,tmpy=0;
    bool ispred = false;
    bool found = false;
    int f=0;
    int i,j;
    int n;
    int tmp = 0;
    cin >> n;

    int xi[n];
    int yi[n];

    for(i=0;i<n;i++)
    {
        cin >> xi[i];
        cin >> yi[i];
    }

    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(xi[i] <= xi[j] && yi[i] <= yi[j] && i!=j)
            {
                ispred = true;
            }
        }
        if(ispred == false)
        {
           f++;
        }
        ispred = false;
    }

    /*for(i=0;i<n;i++)
    {
        if(xi[i] > maxx)
        {
            maxx = xi[i];
        }
        if(yi[i] > maxy)
        {
            maxy = yi[i];
        }
    }

    for(i=0;i<n;i++)
    {
        if(xi[i] == maxx && yi[i] >= tmpy)
        {
            tmpy = yi[i];
        }
        if(yi[i] == maxx && xi[i] >= tmpx)
        {
            tmpx = xi[i];
        }
    }

    for(i=tmpx+1;i<maxx;i++)
    {
        for(j=0;j<n;j++)
        {
            if(xi[j] == i && yi[j] > tmp)
            {
                tmp  = yi[i];
                f++;
            }
        }
        if(found == true)
        {
            break;
        }
    }

    for(i=tmpx+1;i<maxx;i++)
    {
        for(j=0;j<n;j++)
        {
            if(xi[j] == i && yi[j] < tmp)
            {
                tmp  = yi[j];
                f++;
            }
        }
    }*/

    cout << f;
    return 0;
}
/*
6
0 1
1 5
3 5
3 2
4 4
5 1

8
2 6
3 5
3 3
4 4
5 4
6 2
7 3
8 1
*/
