#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>

using namespace std;
int n, k;
int a[100], perice[100], given[100], pozicija[100];
bool used[100];

int main()
{
    scanf("%i%i", &n, &k);
    for(int i = 0; i < n; i++) {
        scanf("%i", &a[i]);
        pozicija[i] = a[i];
        used[i] = false;
    }

    for(int i = 0; i < n; i++) {
        for(int j = i + 1; j < n; j++) {
            if(a[i] < a[j]) {
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }

    for(int i = 0; i < k; i++) perice[i] = 0;

    for(int i = 0; i < n; i++) {
        int temp = 0;
        for(int j = 1; j < k; j++) {
            if(perice[j] < perice[temp]) {
                temp = j;
            }
        }
        perice[temp] = perice[temp] + a[i];
        given[i] = temp + 1;
    }

    int minimum, maximum;
    minimum = perice[0];
    maximum = perice[0];

    for(int i = 0; i < k; i++) {
        if(perice[i] > maximum) maximum = perice[i];
        if(perice[i] < minimum) minimum = perice[i];
    }

    //for(int i = 0; i < n; i++) printf("%i ", pozicija[i]);

    int delta = maximum - minimum;
    printf("%i\n", delta);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            if(pozicija[i] == a[j] && used[j] == false) {
                printf("%i ", given[j]);
                used[j] = true;
                break;
            }
        }
    }
    return 0;
}
