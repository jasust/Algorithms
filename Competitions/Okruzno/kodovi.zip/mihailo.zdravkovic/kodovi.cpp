#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
using namespace std;

long long n, x;
long long codes = 0, seconds = 0;

struct node {
    long long data;
    long long pozicija;
};

node gomile[11000];

int main()
{
    scanf("%lld%lld", &n, &x);
    int levi = -1, desni = n;
    for(int i = 0; i < n; i++) {
        //cin >> gomile[i].pozicija;
        //cin >> gomile[i].data;
        scanf("%lld%lld", &gomile[i].pozicija, &gomile[i].data);
        if(gomile[i].pozicija > x && desni == n) {
            desni = i;
            levi = i-1;
        }
    }
    seconds = gomile[levi].pozicija - x;
    while(levi != -1 && desni != n) {
        //cout << levi << " " << desni << endl;
        if(gomile[levi].data < gomile[desni].data) {
        codes = codes + (2 * gomile[levi].data);
        seconds = seconds + ((gomile[desni].pozicija - gomile[levi].pozicija) * 2 * gomile[levi].data);
        gomile[desni].data = gomile[desni].data - gomile[levi].data;
        gomile[levi].data = 0;
        levi--;
        } else {
            if(gomile[levi].data > gomile[desni].data) {
                codes = codes + (2 * gomile[desni].data);
                seconds = seconds + ((gomile[desni].pozicija - gomile[levi].pozicija) * 2 * gomile[desni].data);
                gomile[levi].data = gomile[levi].data - gomile[desni].data;
                gomile[desni].data = 0;
                desni++;
            } else {
                if(gomile[levi].data == gomile[desni].data) {
                    codes = codes + (2 * gomile[desni].data);
                    seconds = seconds + ((gomile[desni].pozicija - gomile[levi].pozicija) * 2 * gomile[desni].data);
                    gomile[levi].data = 0;
                    gomile[desni].data = 0;
                    desni++;
                    levi--;
                }
            }
        }
    }
    if(desni != n) {
        seconds = seconds + (gomile[desni].pozicija - gomile[levi+1].pozicija);
        codes++;
    }
    //cout << codes << endl;
    //cout << seconds;
    printf("%lld\n%lld", codes, seconds);
    return 0;
}
