#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>

using namespace std;

int mat[300][300], kolone[300][300], redovi[300][300];
int n, m;

void procesiraj() {
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            kolone[i][j] = 0;
            for(int k = 0; k < n; k++) {
                if(mat[k][j] > mat[i][j]) {
                    kolone[i][j]++;
                }
            }
            redovi[i][j] = 0;
            for(int k = 0; k < m; k++) {
                if(mat[i][k] < mat[i][j]) {
                    redovi[i][j]++;
                }
            }
        }
    }
}

void nadjiOptimalnoResenje() {
    int minimum = 1000000;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            if(kolone[i][j] + redovi[i][j] < minimum) {
                minimum = kolone[i][j] + redovi[i][j];
            }
            //cout << kolone[i][j] << " ";
        }
        //cout << endl;
    }
    printf("%i", minimum);
}

int main()
{
    scanf("%i%i", &n, &m);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            scanf("%i", &mat[i][j]);
        }
    }
    procesiraj();
    nadjiOptimalnoResenje();
    return 0;
}
