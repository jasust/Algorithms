int main()
{
    int n, k;
    scanf("%d %d", &n, &k);

    long long a[13], b[13];
    int i,j;
    long long razlika;

    for(i=0; i<n; i++)
    {
        scanf("%lld", &a[i]);
        b[i] = a[i];
    }

    for(i=0; i<n; i++)
        for(j=i; j<n; j++)
            if(b[i] > b[j])
            {
                long long p = b[i];
                b[i] = b[j];
                b[j] = p;
            }


    if(n <= k)
    {
        if(n == k)
            printf("%d \n", b[n-1] - b[0]);
        else
            printf("%d \n", b[n-1]);
        for(i=0; i<n; i++)
            printf("%d ", i);
    }

    else
    {
        if(n == 3)
            if(k == 2)
            {
                razlika = b[2] - b[1] - b[0];
                if(razlika<0) razlika = -razlika;

                printf("%lld \n", razlika );
                if(b[2] == a[0])
                    printf("2 1 1");
                else if(b[2] == a[1])
                    printf("1 2 1");
                else
                    printf("1 1 2");
            }
        else if(k == 1)
        {
            printf("0 \n 1 1 1");
        }
    }

    return 0;
}
