int main()
{
    int n,m;
    scanf("%d %d", &n, &m);

    long long h[n][m], redmin[n], kolonamax[m], Nmin[n] = 0, Nmax[m] = 0;
    int i,j;


    for(i=0; i<n; i++)
    {
        for(j=0; j<m; j++)
        {
            scanf("%lld", &h[i][j]);

            if( j==0 )
                redmin[i] = h[i][0];
            else if( i==0 )
                kolonamax[j] = h[0][j];
            else
            {
                if(kolonamax[j] < h[i][j])
                {
                    kolonamax[j] = h[i][j];
                    Nmax = 0;
                }
                else if(kolonamax[j] == h[i][j])
                    Nmax ++;

                if(redmin[i] > h[i][j])
                {
                    redmin[i] = h[i][j];
                    Nmin = 0;
                }
                else if(redmin[i] == h[i][j])
                    Nmin ++;
            }
        }
    }
    for(i=0; i<n; i++)
    {
        for(j=0; j<m; j++)
        {
            if(kolonamax[j] == redmin[i])
        }
    }
}
