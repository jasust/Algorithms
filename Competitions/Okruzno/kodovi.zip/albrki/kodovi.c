int main()
{
    int n;
    long long x;
    scanf("%d%lld", &n, &x);
    int granica[2];
    int i;

    long long p[n], h[n];
    for(i=0; i<n; i++)
    {
        scanf("%lld %lld", &p[i], &h[i]);

        if(i == 0 && p[i] > x)
        {
            granica[0] = -1;
            granica[1] = 0;
        }
        else if(i == n-1 && p[i] < x)
        {
            granica[0] = n-1;
            granica[1] = n;
        }
        else if(p[i-1] <= x && p[i] >= x)
        {
            granica[0] = i-1;
            granica[1] = i;
        }
    }
    long long Nk = 0, t = 0;

    int pravac = 1;
    int pomeraj [2];
    pomeraj[0] = -1;
    pomeraj[1] = 1;

    while( granica[pravac] != -1 && granica[pravac] != n )
    {
        if(x == p[ granica[ pravac ]] )
        {
            Nk ++;
            h[granica[pravac]] --;
            pravac = (pravac+1) % 2;

            if(h[granica[pravac]] == 0)
            {
                granica[pravac] += pomeraj[pravac];
            }
        }
        x += pomeraj[pravac];
        t ++;
    }

    printf("%lld\n%lld", Nk, t-1);

    return 0;
}
