#include<stdio.h>
#include<stdlib.h>

long long unsigned k;
int br[100005];
int main()
{
    int n,m,maxk;
    scanf("%d %d %llu",&n,&m,&k);
    maxk=n;
    for(int oo=1;oo<m;oo++)
    maxk=maxk*n;
    int sifra[m];
    for(int tra;tra<m;tra++)
    sifra[tra]=0;
    for(int i=0;i<n;i++)
    scanf("%d",&br[i]);
    int ref[n];
    for(int j;j<n;j++)
    ref[j]=0;
    for(int ajde=1;m<=ajde;ajde++)
    {
    while(1)
    {
            if((sifra[ajde]+(maxk/(n*ajde)))>=k)
            sifra[ajde]=sifra[ajde]+(maxk/n);
            else break;
            }
            }
    for(int ha=0;ha<m;ha++)
    ref[ha]=br[sifra[ha]];
    for(int st=0;st<m;st++)
    printf("%d ",ref[st]);
    
    
    
   return 0;
}
    
    
    
    
