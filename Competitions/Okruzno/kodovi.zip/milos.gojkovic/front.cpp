#include<cstdio>
//#include<stdlib.h>
//#include<math.h>
unsigned x[1000005],y[1000005];
int main()
{
      int n,i,j=0,front=1,refx=0,refy=0,radi=0;
      scanf("%d",&n);
      for(i=0;i<n;i++)
      scanf("%d %d",&x[i],&y[i]);
      int a,b,c;
      for(a=0;a<n-1;a++)
      for(b=0;b<n-1;b++)
      if(x[a]==x[b])
      if(y[a]<y[b])
      {
                   c=y[a];
                   y[a]=y[b];
                   y[b]=c;
                   }
      for(radi=1;radi<n;radi++)
      if(x[radi-1]<=x[radi] && y[radi-1]>=y[radi])
      front++;
      else front=1;
      printf("%d",front);
      //system("pause");
      return 0;
      }
      /*
      6
      0 1
      1 5
      3 5
      3 2
      4 4
      5 1
      
      */
      
      

            
      
