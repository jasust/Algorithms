#include <cstdlib>
#include <iostream>

using namespace std;
int kvadrat(int broj,int stepen)
{ 
    int t = 1;
    while(stepen>0)
{
    if(stepen%2==0) 
    {
    broj=broj*broj;
    stepen=stepen/2;
    }
    else
    {
        t*=broj;
        stepen--;
        }               
}
    
    return t;
    }
int main(int argc, char *argv[])
{
    int n,m,c = 1,k;
    scanf("%d %d %d",&n,&m,&k);
    int niz1[n],niz[m];
    for(int i = 0;i<n;i++)
    {
            scanf("%d",&niz1[i]);
            }
    for(int s = 0;s<m;s++)
            {
                niz[s]=niz1[0];    
                    
                    }
    k=k-1;
    niz[m-1]=niz1[k%n];
    for(int i = m-2;i>=0;i--)
    {
            niz[i]=niz1[(k/kvadrat(n,c))%n];
            c++;
            } 
    for(int i = 0;i<m;i++)
    {
            printf("%d ",niz[i]);
            }    
    return EXIT_SUCCESS;
}
