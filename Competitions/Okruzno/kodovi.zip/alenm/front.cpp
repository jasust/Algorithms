#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int x[100000];
    int y[100000];
    for(int i=0; i<n; i++)
    {
        cin>>x[i];
        cin>>y[i];
    }
    int q=0;

    for(int ii=n-1, i=ii-1; ii>=0; ii--,i--)
    {



                if( y[ii] > y[i])
                {
                    q++;
                y[i] = y[ii];

                }



    }

    cout<<q;

    return 0;
}
