#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>

//using namespace std;

#define MAX 200000

int vece( int x, int y )
{
    if( x > y )
        return x;
    else
        return y;
}


int main()
{
    int n = 0, i = 0, j = 0;
    scanf("%d\n", &n);

    int x[MAX], y[MAX];

    for( i = 0; i < n; ++i )
    {
         scanf("%d %d\n", &x[i], &y[i]);
    }
    
    int h = x[i];
    
    int F = 0;
    
    for( i = n - 1; i >= 0; --i )
    {
         int t = 1;
         if( y[i] <= h )
             continue;
         for( j = i - 1; j >= 0; --j )
         {    
              if( x[i] > x[j] )
                  break;
              else if( y[i] < y[j] )
              {
                   t = 0;
                   break;
              }
         }
         h = vece( y[i], h );
         F += t;
    }
    printf("%d", F );

    return 0;
}
