#include <cstdlib>
#include <iostream>
#include <stdio.h>
//using namespace std;
#define MAX 100000

int mbroj( int n, long long int *k )
{
    int broj = *k % n;
    *k = *k / n + ( *k % n > 0 );
    if( broj == 0 )
        return n;
    return broj;
    
}

int main()
{
    int n = 0, m = 0;
    long long int k = 0;
    scanf("%d %d %lld\n", &n, &m, &k );
    int i = 1, a[MAX+1];
    for( i = 1; i <= n; ++i )
    {
         scanf("%d", &a[i]);
    }
    
    int R[m+1];
    
    long long int kami = 0;
    for( i = m; i >= 1; --i )
    {
         kami = mbroj( n, &k );
         R[i] = a[kami];  
    }
    for( i = 1; i <= m; ++i )
    {
         if( i != 1 )
         {
             printf( " %d", R[i] );
         }
         else
         {
             printf( "%d", R[i] );
         }
    }
    return 0;
}
