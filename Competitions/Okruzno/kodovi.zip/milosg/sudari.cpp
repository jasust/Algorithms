#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

#define MAX 500

int lavirint[MAX+2][MAX+2] = {0};
long long int k = 0;

void Upis( int m, int n, int glavni[MAX+2][MAX+2] )
{
     int i = 0, j = 0;
     for( i = 1; i <= m; ++i )
     {
          
          for( j = 1; j <= n; ++j )
          {
               char c = 0;
               scanf("%c", &c );
               
               if( c == '#' )
                   glavni[i][j] = 0;
               else
                   glavni[i][j] = 1;
          }
          getchar();
     }
}

void kretanje( int *x, int *y, int *smer )
{
     int a = 0, b = 0;
     if( *smer == 12 )
     {
         b = *y;
         for( a = *x; ; --a )
         {
              if( !lavirint[a][b] )
                  break;
         }
         ++a;
         *smer = 9;
     }
     else if( *smer == 9 )
     {
          a = *x;
          for( b = *y; ; --b )
          {
               if( !lavirint[a][b] )
                   break;
          }
          ++b;
          *smer = 6;
     }
     else if( *smer == 6 )
     {
         b = *y;
         for( a = *x; ; ++a )
         {
              if( !lavirint[a][b] )
                  break;
         }
         --a;
         *smer = 3;
     }
     else
     {
         a = *x;
         for( b = *y; ; ++b )
         {
              if( !lavirint[a][b] )
                  break;
         }
         --b;
         *smer = 12;
     }
     --k;     
     *x = a;
     *y = b;
     
}


int main()
{
    int m = 0, n = 0;
    scanf("%d %d\n", &m, &n );
    
    int x = 0, y = 0;
    scanf("%d %d\n", &x, &y );
    
    scanf("%lld\n", &k );
    
    Upis( m, n, lavirint );
    int i = 0, j = 0;
    
    int smer = 6;
    
    while( k > 0 )
    {
           kretanje( &x, &y, &smer );
    }
    printf("%d %d", x, y );
    
    return 0;
}
