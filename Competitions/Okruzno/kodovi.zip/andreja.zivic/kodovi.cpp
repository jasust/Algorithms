#include <cstdio>

const int maxn = 1e5;

int n,x,p[maxn],h[maxn],l,r,s;
long long sol,t;

int main()
{
    scanf("%d %d", &n, &x);
    for (int i=0; i<n; i++) scanf("%d %d", &p[i], &h[i]);

    if (x < p[0])
    {
        printf("1\n");
        printf("%d", p[0]-x);
        return 0;
    }

    for (int i=1; i<n; i++)
    {
        l = i-1;
        r = i;
        if ((x>p[l]) && (x<p[r])) break;
    }

    s = 1;

    while ((r<n) && (l>=0))
    {
        if ((h[l]>=h[r]) && (s == 1))
        {
            t += 2*(p[r]-p[l])*h[r]-(x-p[l])+1;
            sol += 2*h[r];
            h[l] = h[l] - h[r];
            if (h[l] == 0) l--;
            x = p[l]+1;
            r++;
            continue;
        }

        if ((h[l]>h[r]) && (s == 0))
        {
            t += 2*(p[r]-p[l])*h[r]+(x-p[l])+1;
            sol += 2*h[r] + 1;
            h[l] = h[l] - h[r] - 1;
            if (h[l] == 0) l--;
            x = p[l]+1;
            r++;
            s = 1;
            continue;
        }

        if ((h[l]<=h[r]) && (s == 0))
        {
            t += 2*(p[r]-p[l])*h[l]-(p[r]-x)+1;
            sol += 2*h[l];
            h[r] = h[r] - h[l];
            if (h[r] == 0) r++;
            x = p[r]-1;
            l--;
            continue;
        }

        if ((h[l]<h[r]) && (s == 1))
        {
            t += 2*(p[r]-p[l])*h[l]+(p[r]-x)+1;
            sol += 2*h[l] + 1;
            h[r] = h[r] - h[l] - 1;
            if (h[r] == 0) r++;
            x = p[r]-1;
            l--;
            s = 0;
            continue;
        }

    }
    t--;

    printf("%lld\n%lld", sol, t);
    return 0;

}
