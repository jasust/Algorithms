#include <cstdio>
#include <algorithm>

using namespace std;

const int maxn = 15;

int n, k, sol, a[maxn], b[maxn], c[maxn], d[maxn],  idx[maxn], bidx[maxn], pok;

int maksimum(int a, int b)
{
    if (a>b) return a;
    else return b;
}

int main()
{
    scanf("%d %d", &n, &k);
    for (int i=0; i<n; i++) scanf("%d", &a[i]);

    sol = 0;

    if (k > n)
    {
        for (int i=0; i<n; i++) sol = maksimum(sol, a[i]);
        printf("%d\n", sol);

        for (int i=0; i<n; i++) printf("%d ", i+1);
        return 0;
    }

    for (int i=0; i<n; i++)
    {
        idx[i] = i;
        d[i] = a[i];
    }

    for (int i=0; i<n; i++)
        for (int j=i+1; j<n; j++)
        if (a[i]>a[j])
        {
            int p = a[i];
            a[i] = a[j];
            a[j] = p;
            p = idx[i];
            idx[i] = idx[j];
            idx[j] = p;
        }

    for (int i=0; i<k; i++)
    {
        b[i] = a[n-i-1];
        c[idx[n-i-1]] = i+1;
        bidx[i] = i+1;
    }

    pok = k+1;

    while (pok <= n)
    {
        for (int i=0; i<k; i++)
            for (int j=i+1; j<k; j++)
            if (b[i]>b[j])
            {
                int p = b[i];
                b[i] = b[j];
                b[j] = p;
                p = bidx[i];
                bidx[i] = bidx[j];
                bidx[j] = p;
            }
        b[0] += a[n-pok];
        c[idx[n-pok]] = bidx[0];
        pok++;
    }

    sort(b, b + k);

    printf("%d\n", b[k-1]-b[0]);
    for (int i=0; i<n; i++) printf("%d ", c[i]);
    return 0;

}
