#include <cstdio>

const int maxn = 301;

int n, m, a[maxn][maxn], dp[maxn][maxn], dp1[maxn][maxn], b[maxn], d[maxn], sol, p, p1;

int minimum(int a, int b)
{
    if (a<b) return a;
    else return b;
}

int main()
{
    scanf("%d %d", &n, &m);
    for (int i=0; i<n; i++)
        for (int j=0; j<m; j++) scanf("%d", &a[i][j]);

    for (int i=0; i<n; i++)
    {
        for (int j=0; j<m ;j++)
        {
            b[j] = a[i][j];
            d[j] = j;
        }

        for (int i1=0; i1<m; i1++)
            for (int j1=i1+1; j1<m; j1++)
            {
                if (b[i1]>b[j1])
                {
                    int p = b[i1];
                    b[i1] = b[j1];
                    b[j1] = p;
                    p = d[i1];
                    d[i1] = d[j1];
                    d[j1] = p;
                }
            }

        for (int j=0; j<m; j++)
        {
            for (int j1=0; j1<m; j1++)
                if (b[j1]<b[j]) continue;
                else
                {
                    p = j1;
                    break;
                }
                dp[i][d[j]] = p;
        }

    }

    for (int i=0; i<m; i++)
    {
        for (int j=0; j<n ;j++)
        {
            b[j] = a[j][i];
            d[j] = j;
        }

        for (int i1=0; i1<n; i1++)
            for (int j1=i1+1; j1<n; j1++)
            {
                if (b[i1]>b[j1])
                {
                    int p = b[i1];
                    b[i1] = b[j1];
                    b[j1] = p;
                    p = d[i1];
                    d[i1] = d[j1];
                    d[j1] = p;
                }
            }

        for (int j=0; j<n; j++)
        {
            p1 = 0;
            for (int j1=0; j1<n; j1++)
            {
                p = j1;
                if (b[j1]<=b[j]) continue;
                else
                {
                    p1 = 1;
                    break;
                }
            }
            if (p1 == 1) p--;
            dp[d[j]][i] += n-p-1;
        }

    }

    sol = 1000;

    for (int i=0; i<n; i++)
        for (int j=0; j<m; j++)  sol = minimum(sol, dp[i][j] + dp1[i][j]);

    printf("%d", sol);
    return 0;
}
