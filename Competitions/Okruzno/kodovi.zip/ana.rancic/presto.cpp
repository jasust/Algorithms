#include<stdio.h>
#include<stdlib.h>
#include<math.h>




int Kolona(int h[][300], int n, int kol, int ind)
{
	int i,br=0;
	for(i=0;i<n;i++)
	{
		if(h[i][kol]>h[ind][kol])
			br++;
	}
	return br;
}

int Vrsta(int h[][300], int red, int m, int ind)
{
	int i,br=0;
	for(i=0;i<m;i++)
	{
		if(h[red][i]<h[red][ind])
			br++;
	}
	return br;
}

int main()
{
	int n,m, h[300][300],i,j,min;
	scanf("%d %d", &n, &m);
	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
			scanf("%d", &h[i][j]);
	min=Kolona(h,n,1,1)+Vrsta(h,1,m,1);
	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
		{
			m=Kolona(h,n,j,i)+Vrsta(h,i,m,j);
			if(m<min)
				min=m;
		}
	printf("%d", min);
	return 0;
}
