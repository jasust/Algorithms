#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int pveci[100000], pmanji[100000], hmanji[100000], hveci[100000];

int main()
{
	long long s,sek;
	int n, indv, indm, x, i, h, j, p, smanji, sveci;
	scanf("%d %d", &n, &x);
	indv=0;
	indm=0;
	smanji=0;
	sveci=0;
	for(i=0; i<n; i++)
	{
		scanf("%d %d", &p, &h);
		if(h!=0)
		{
			if(p>x)
			{
				pveci[indv]=p;
				hveci[indv]=h;
				sveci=sveci+h;
				indv++;
			}
			else
			{
				pmanji[indm]=p;
				hmanji[indm]=h;
				smanji=smanji+h;
				indm++;
			}
		}
	}
	int k;
	for(i=0;i<indm/2;i++)
	{
		k=pmanji[i];
		pmanji[i]=pmanji[indm-1-i];
		pmanji[indm-1-i]=k;
		k=hmanji[i];
		hmanji[i]=hmanji[indm-1-i];
		hmanji[indm-1-i]=k;
	}
	sek=0;
	s=0;
	int in=0;
	if(smanji==sveci)
	{
		s=2*smanji;
		for(i=0;i<indm;i++)
			sek=sek+hmanji[i]*2*abs(x-pmanji[i]);
		sek=sek-abs(x-pmanji[i-1]);
		for(i=0;i<indv;i++)
			sek=sek+hveci[i]*2*abs(x-pveci[i]);
	}
	else if(smanji<sveci)
	{
		s=2*smanji+1;
		for(i=0;i<indm;i++)
			sek=sek+hmanji[i]*2*abs(x-pmanji[i]);
		for(i=0;i<smanji;i++)
		{
			if(hveci[in]==0)
			{
				in++;
				hveci[in]--;
				sek=sek+2*abs(x-pveci[in]);
			}
			else
			{
				sek=sek+2*abs(x-pveci[in]);
				hveci[in]--;
			}
		}
		if(hveci[in]==0)
		{
			in++;
			sek=sek+abs(x-pveci[in]);
		}
		else
			sek=sek+abs(x-pveci[in]);
	}
	else
	{
		s=sveci*2;
		for(i=0;i<indv;i++)
			sek=sek+hveci[i]*2*abs(x-pveci[i]);
		for(i=0;i<sveci-1;i++)
		{
			if(hmanji[in]==0)
			{
				in++;
				hmanji[in]--;
				sek=sek+2*abs(x-pmanji[in]);
			}
			else
			{
				hmanji[in]--;
				sek=sek+2*abs(x-pmanji[in]);
			}
		}
		if(hmanji[in]==0)
		{
			in++;
			sek=sek+abs(x-pmanji[in]);
		}
		else
			sek=sek+abs(x-pmanji[in]);
	}
	printf("%lld\n%lld", s,sek);
	return 0;
}