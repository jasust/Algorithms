#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    long X;
    long Y;
    int f;
} Vojnik;

Vojnik *vojnici;
int N;

int jeNaFrontu(Vojnik *v, int ind)
{
    int i;

    for(i = 0; i < N; i++)
    {
        if(i == ind) continue;
        if(vojnici[i].f) continue;
        if(v->X <= vojnici[i].X && v->Y <= vojnici[i].Y)
        {
            v->f = 1;
            return 0;
        }
    }

    return 1;
}

int main()
{
    int i, br = 0;

    scanf("%d", &N);
    vojnici = calloc(N, sizeof(Vojnik));

    for(i = 0; i < N; i++)
    {
        scanf("%ld %ld", &vojnici[i].X, &vojnici[i].Y);
        vojnici[i].f = 0;
    }

    for(i = 0; i < N; i++)
    {
        if(jeNaFrontu(&vojnici[i], i))
        {
            br++;
        }
    }

    printf("%d", br);

    free(vojnici);
    return 0;
}
