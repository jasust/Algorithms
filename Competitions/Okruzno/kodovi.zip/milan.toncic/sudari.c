#include <stdio.h>
#include <stdlib.h>

#define MAX     510

#define DOWN    0
#define RIGHT   1
#define UP      2
#define LEFT    3

char MAPA[MAX][MAX];
int N, M;
int X, Y;
long long K;
int DIR;

int pomeriSe()
{
    switch(DIR)
    {
    case DOWN:
        if(Y+1 >= N) return 1;
        if(MAPA[Y+1][X] == '#') return 1;

        Y += 1;
        break;
    case RIGHT:
        if(X+1 >= M) return 1;
        if(MAPA[Y][X+1] == '#') return 1;

        X += 1;
        break;
    case UP:
        if(Y-1 < 0) return 1;
        if(MAPA[Y-1][X] == '#') return 1;

        Y -= 1;
        break;
    case LEFT:
        if(X-1 < 0) return 1;
        if(MAPA[Y][X-1] == '#') return 1;

        X -= 1;
        break;
    }

    return 0;
}

int main()
{
    int i;

    DIR = 0;

    scanf("%d %d", &N, &M);
    scanf("%d %d", &Y, &X);
    scanf("%lld", &K);

    X--;
    Y--;

    for(i = 0; i < N; i++)
    {
        scanf("%s", MAPA[i]);
    }

    while(K)
    {
        if(pomeriSe())
        {
            K--;
            DIR++;
            if(DIR > 3) DIR = 0;
        }
    }

    printf("%d %d", Y+1, X+1);

    return 0;
}
