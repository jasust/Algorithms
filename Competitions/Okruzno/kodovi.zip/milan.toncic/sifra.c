#include <stdio.h>
#include <stdlib.h>

#define MAXN 100000

long A[MAXN];
int P[MAXN];

int N, M, K;

void dodaj()
{
    int i;
    P[M-1]++;
    for(i = M-1; i >= 0; i--)
    {
        if(P[i] == 0) continue;
        if(P[i] > N-1)
        {
            if(i-1 < 0) continue;
            else
            {
                P[i] = 0;
                P[i-1]++;
            }
        }
        else
        {
            break;
        }
    }
}

int main()
{
    int i;

    scanf("%d %d %d", &N, &M, &K);
    for(i = 0; i < N; i++)
    {
        scanf("%ld", &A[i]);
    }

    for(i = 1; i < K; i++)
    {
        dodaj();
    }

    for(i = 0; i < M; i++)
    {
        printf("%d ", A[P[i]]);
    }

    return 0;
}
