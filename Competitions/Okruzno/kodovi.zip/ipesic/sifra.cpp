#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n,m,k,r;
    cin>>n>>m>>k;
    r=k;
    int a[n];
    for(int i=0;i<n;i++)
    {
            cin>>a[i];
            }
            int b[m];
            for(int i=m-1;i>=0;i--)
            {
               int c;
               c=r%n;
               if(c==0)
               {
                       b[i]==a[n-1];
                       }     
                       else
                       {
                           b[i]=a[c-1];
                       }
                       r=(r-c)/n+1;
            }
            for(int i=0;i<m;i++)
            {
                    cout<<b[i]<<endl;
                    }
            
int izlaz;
cin>>izlaz;
}
