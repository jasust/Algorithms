#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n,m,c;
    cin>>n;
    c=1;
    int a[n],b[n];
    for(int i=0;i<n;i++)
    {
            cin>>a[n];
            cin>>b[n];
            }
    m=b[n-1];
            for(int i=n-2;i>=0;i--)
            {
             if(b[i]>m)
             {
                       m=b[i];
                       c=c+1;
                       }       
                    }
                    cout<<c;
int izlaz;
cin>>izlaz;
}
