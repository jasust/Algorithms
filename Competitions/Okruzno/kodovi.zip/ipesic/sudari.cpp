#include <cstdlib>
#include <iostream>
#include <string>


int main(int argc, char *argv[])
{
    int n,m,y,x,k;
    cin>>n>>m>>y>>x>>k;
    char a[n][m];
    for(int i=0;i<n;i++)
{
    for(int j=0;j<m;j++)
    {
            cin>>a[i][j];
            }
            
}
int s,v,l,g;
s=0;
v=0;
l=1;
g=1;
int f[100000],b[100000],c[100000],p,q,r;
f[0]=x-1;
b[0]=y-1;
c[0]=1;
p=y-1;
q=x-1;
r=1;
while(s<k&&v==0)
{
                if(g<1000000)
                {
 if(r==1)
 {
         if(p==n-1)
         {
                 s=s+1;
                 r=3;
                 f[g]=p;
                 b[g]=q;
                 c[g]=3;
                 g=g+1;
                 
                 }
                 else
                 {
                     if(a[p+1][q]==#)
                     {
                                     s=s+1;
                                     r=3;
                                     f[g]=p;
                                     b[g]=q;
                                     c[g]=3;
                                     g=g+1;
                                     }
                                     else
                                     {
                                         p=p+1;
                                         f[g]=p;
                                         b[g]=q;
                                         c[g]=1;
                                         g=g+1;
                                     }
                 }
         }
         
         if(r==2)
         {
                 if(p==0)
                 {
                 f[g]=p;
                 b[g]=q;
                 c[g]=4;
                 r=4;
                 g=g+1;
                 s=s+1;
                 }
                 else
                 {
                     if(a[p-1][q]==#)
                     {
                                    f[g]=p;
                 b[g]=q;
                 c[g]=4;
                 r=4;  
                 g=g+1;
                 s=s+1; 
                                     }
                                     else
                                     {
                                         p=p-1;
                                         f[g]=p;
                                         b[g]=q;
                                         c[g]=r;
                                         g=g+1;
                                     }
                 }
                 }
                       if(r==3)
                       {
                               if(q==m-1)
                               {
                                         f[g]=p;
                                         b[g]=q;
                                         c[g]=2;
                                         g=g+1;
                                         s=s+1;
                                         r=2;
                                         }
                                         else
                                         {
                                             if(a[p][q+1]==#)
                                             {
                                                  f[g]=p;
                                         b[g]=q;
                                         c[g]=2;
                                         g=g+1;
                                         s=s+1;
                                         r=2;           
                                                             }
                                                             else
                                                             {
                                                                 q=q+1;
                                                                 f[g]=p;
                                                                 b[g]=q;
                                                                 c[g]=r;
                                                                 g=g+1;
                                                             }
                                         }
                                         if(r==4)
                                         {
                                                 if(q==0)
                                                 {
                                                         r=1;
                                                         f[g]=p;
                                                         b[g]=q;
                                                         c[g]=r;
                                                         s=s+1;
                                                         g=g+1;
                                                         }
                                                         else
                                                         {
                                                             if(a[p][q-1]==#)
                                                             {
                                                                          r=1;
                                                         f[g]=p;
                                                         b[g]=q;
                                                         c[g]=r;
                                                         s=s+1;
                                                         g=g+1;  
                                                                          }
                                                                          else
                                                                          {
                                                                              q=q-1;
                                                                              f[g]=p;
                                                                              b[g]=q;
                                                                              c[g]=r;
                                                                          }
                                                         }
                                                         
                                                 }
                                         
                                         
                               }
                               else
                               {
                               int t;
                               t=g-1;
                               while(t>=0&&v==0)
                                   {
                                           if(f[g]==f[t]&&b[g]==b[t]&&c[g]==c[t])
                                           {
                                                                                 v=v+1;
                                                                                 }
                                           }
                               }
}            
         if(s==k)
         {
                 cout<<f[g]<<b[g];
                 }       
                 
                 
                     
                 
int izlaz;
cin>>izlaz;
}
