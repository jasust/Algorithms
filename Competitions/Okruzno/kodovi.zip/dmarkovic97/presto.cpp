#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

int n, m;
long long basta[301][301];
int izmene;

void racunajIzmene(int i, int j)
{
    long long jniz[301];
    long long iniz[301];
    long long niz[602];
    int l, d;
    int gran;
    int tmpIzmene;
    tmpIzmene=0;

    gran=0;
    for(int tmpi=0; tmpi<n; tmpi++)
    {
        if(tmpi==i)
        {
            gran++;
        }
        else
        {
            jniz[tmpi-gran]=basta[tmpi][j];
        }
    }

    gran=0;
    for(int tmpj=0; tmpj<m; tmpj++)
    {
        if(tmpj==j)
        {
            gran++;
        }
        else
        {
            iniz[tmpj-gran]=basta[i][tmpj];
        }
    }
    sort(jniz, jniz+n);
    sort(iniz, iniz+m);

    for(int tmpi=0; tmpi<n-1; tmpi++)
    {
        niz[tmpi]=jniz[tmpi];
    }

    niz[n-1]=basta[i][j];

    for(int tmpj=0; tmpj<m; tmpj++)
    {
        niz[tmpj+n]=iniz[tmpj];
    }

    int tmpj=n+m-1;
    int tmpi=0;
    bool ip=true;
    while((tmpi!=tmpj)&&(tmpj-tmpi>2))
    {
        if(niz[tmpi]>=niz[tmpj])
        {
            l=tmpi;
            d=tmpj;
            tmpi=tmpj;
        }

        if(ip)
        {
            tmpi++;
            ip=false;
        }
        else
        {
            tmpj--;
            ip=true;
        }
        if(i==n-2)
        {
            ip=false;
        }
        if(j==n)
        {
            ip=true;
        }
    }
    if(tmpi!=tmpj)
    {
        if((niz[n-1]>=niz[n-2])&&(niz[n-1]<=niz[n]))
        {
            tmpIzmene=0;
        }
        else
        {
            tmpIzmene=1;
        }
    }
    else
    {
        int tmpl=l+1;

        while(tmpl!=d)
        {
            if((niz[tmpl]<niz[l])||(niz[tmpl]>niz[d]))
            {
                tmpIzmene++;
            }
        }
    }

    if(tmpIzmene<izmene)
    {
        izmene=tmpIzmene;
    }

}



int main()
{
    scanf("%i%i", &n, &m);
    izmene=100000;

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            scanf("%lld", &basta[i][j]);
        }
    }

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            racunajIzmene(i, j);
        }
    }

    printf("%i\n", izmene);

    return 0;
}

/*
3 4
1 9 3 0
6 2 7 5
8 4 6 3
*/
