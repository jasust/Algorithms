#include <iostream>
#include <stdio.h>
#include <stdlib.h>

int n;
long long x, pozx, sekunde, kodovi;
bool nadjenx;

struct gomila
{
    long long poz;
    long long kod;
};

gomila niz[100001];

void racunajIzmedju(long long levi, long long desni, bool desno)
{
    if((levi<0)||(desni>n))
    {
        return;
    }

    if(desno)
    {
        if(niz[desni].kod>niz[levi].kod)
        {
            kodovi=kodovi+(2*niz[levi].kod+1);
            sekunde=sekunde+((2*niz[levi].kod+1)*(niz[desni].poz-niz[levi].poz));

            niz[desni].kod=niz[desni].kod-niz[levi].kod-1;
            niz[levi].kod=0;

            racunajIzmedju(levi-1, desni, false);

        }
        else
        {
            kodovi=kodovi+(2*niz[desni].kod);
            sekunde=sekunde+((2*niz[desni].kod)*(niz[desni].poz-niz[levi].poz));

            niz[levi].kod=niz[levi].kod-niz[desni].kod;
            niz[desni].kod=0;

            racunajIzmedju(levi, desni+1, true);
        }
    }

    else
    {
        if(niz[levi].kod>niz[desni].kod)
        {
            kodovi=kodovi+(2*niz[desni].kod+1);
            sekunde=sekunde+((2*niz[desni].kod+1)*(niz[desni].poz-niz[levi].poz));

            niz[levi].kod=niz[levi].kod-niz[desni].kod-1;
            niz[desni].kod=0;

            racunajIzmedju(levi, desni+1, true);

        }
        else
        {
            kodovi=kodovi+(2*niz[levi].kod);
            sekunde=sekunde+((2*niz[levi].kod)*(niz[desni].poz-niz[levi].poz));

            niz[desni].kod=niz[desni].kod-niz[levi].kod;
            niz[levi].kod=0;

            racunajIzmedju(levi-1, desni, false);
        }
    }
}

int main()
{
    long long tmppoz, tmpkod;
    nadjenx=false;
    kodovi=1;
    sekunde=0;

    scanf("%i", &n);
    scanf("%lld", &x);

    for(int i=0; i<=n; i++)
    {
        scanf("%lld%lld", &tmppoz, &tmpkod);
        if((x<tmppoz)&&!nadjenx)
        {
            nadjenx=true;
            pozx=i;
            niz[i].poz=x;
            niz[i].kod=0;
            i++;
        }

        niz[i].poz=tmppoz;
        niz[i].kod=tmpkod;
    }

    sekunde = niz[pozx+1].poz-x;
    niz[pozx+1].kod--;

    racunajIzmedju(pozx-1, pozx+1, false);

    printf("%lld\n%lld\n", kodovi, sekunde);

    return 0;
}

/*
3 7
5 2
10 1
12 4
*/
