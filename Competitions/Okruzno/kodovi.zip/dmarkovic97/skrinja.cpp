#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

int n, k;
long long ukupnoStr, prosekStr, ostatakStr;
long long razlika;
bool visak;
long long stranaPerice[14];

struct poglavlja
{
    int mesto;
    long long strane;
    int perica;
};

poglavlja niz[14];

bool cmpStrane(poglavlja a, poglavlja b)
{
    return a.strane>b.strane;
}

bool cmpMesto(poglavlja a, poglavlja b)
{
    return a.mesto<b.mesto;
}

void nadjiRaspored(long long trenRazlika)
{
    razlika=trenRazlika;

    for(int j=0; j<k; j++)
    {
        stranaPerice[j]=0;
    }

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<k; j++)
        {
            if(((stranaPerice[j])<(prosekStr-trenRazlika))&&((stranaPerice[j]+(niz[i].strane))<=(prosekStr+trenRazlika)))
            {
                stranaPerice[j]=stranaPerice[j]+niz[i].strane;
                niz[i].perica=j+1;
                break;
            }
        }
    }

    long long minp, maxp;
    minp=0;
    maxp=ukupnoStr;
    for(int j=0; j<k; j++)
    {
        if(stranaPerice[j]>maxp)
        {
            maxp=stranaPerice[j];
        }
        if(stranaPerice[j]<minp)
        {
            minp=stranaPerice[j];
        }
    }

    if((2*razlika)>=maxp-minp)
    {
        return;
    }
    else
    {
        nadjiRaspored(trenRazlika+1);
    }
}

int main()
{
    scanf("%i%i", &n, &k);

    visak=false;
    ukupnoStr=0;
    razlika=0;

    for(int i=0; i<n; i++)
    {
        scanf("%lld", &niz[i].strane);
        niz[i].mesto=i;
        ukupnoStr=ukupnoStr+niz[i].strane;
    }

    prosekStr=ukupnoStr/k;
    ostatakStr=ukupnoStr%k;
    sort(niz, niz+n, cmpStrane);

    for(int i=0; i<n; i++)
    {
        niz[i].perica=(i%k)+1;
    }

    if(k>=n)
    {
        if(k==n)
        {
            razlika=niz[0].strane-niz[n-1].strane;
        }
        else
        {
            razlika=niz[0].strane;
        }
    }
    else
    {
        nadjiRaspored(0);
    }

    sort(niz, niz+n, cmpMesto);

    printf("%lld\n", razlika);
    for(int i=0; i<n; i++)
    {
        printf("%i ", niz[i].perica);
    }
    printf("\n");

    return 0;
}

/*
5 3
1 3 2 5 3
*/
