#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

int main(int argc, char *argv[])
{
    int n;
    bool desno=true,prvi=true;
    int br=0;
    long long x,d,l,p=0;
        scanf("%d %lld", &n, & x);
    long long a[n];
    int b[n];
    for(int i=0;i<n;i++)
    {
    scanf("%lld %d", &a[i], &b[i]);
    if(x<a[i]&&prvi)
    {
             d=i;
             l=i-1;
             prvi=false;
              }
    }
    while(true)
    { 
               if((desno&&x>=a[n-1])||(!desno&&x==a[0])) break;
               if(desno)
               {
                        p+=a[d]-x;
                        b[d]--;
                        x=a[d];
                         br++;
                        if(b[d]==0)
                        {
                        for(int i=d;i<n-1;i++)
                                {
                                 b[i]=b[i+1];
                                 a[i]=a[i+1];       
                                }
                        n--;
                        }
                        desno=!desno;
               }
                        
                        else
                        {
                            
                            p+=x-a[l];
                            b[l]--;
                            x=a[l];
                            br++;
                            if(b[l]==0)
                            {
                                        for(int i=l;i<n-1;i++)
                                        {
                                            b[i]=b[i+1];
                                            a[i]=a[i+1];
                                        }   
                                l--;
                                d--;                         
                                n--;
                            }   
                            desno=!desno;                                                      
                        }                                
               }
    
    printf("%d \n%lld \n", br, p);
}
