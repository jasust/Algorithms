#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <string>


using namespace std;

int main(int argc, char *argv[])
{
    int n,m;
    scanf("%d %d", &n, &m);
    long int basta[n][m];
    int x=n+m, tr;
      for(int i=0;i<n;i++)
              for(int j=0;j<m;j++)
                      cin>>basta[i][j];
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
    {
            tr=0;
            for(int k=0;k<n;k++)if(basta[k][j]>basta[i][j])tr++;
            for(int k=0;k<m;k++)if(basta[i][k]<basta[i][j])tr++;
            if(tr<x)x=tr;
            }
    printf("%d", tr);
}
