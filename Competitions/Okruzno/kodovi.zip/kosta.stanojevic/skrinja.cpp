#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;


int n, k;
string s="";
int best[0];
long long c;

long int razlika(long long u[], int a[])
{
     long long s1=0;
     long long k1[k];
     for(int i=0;i<n;i++)
     for(int j=0;j<k;j++)
             if(a[i]==j)k1[j]+=u[i];
     long long min=k1[0], max=k1[0];
     for(int i=1;i<k;i++)
     {
             if(k1[i]>max)max=k1[i];
             if(k1[i]<min)min=k1[i];
             }    
             return max-min;
     }


void dodeli(long long a[], int h, int best[], int tr[])
{
     if(h==n)
     { int x=razlika(a,tr);
             if(x<razlika(a,best))
             {
             for(int i=0;i<n;i++)best[i]=tr[i];
             c=x;
             }
   return;
             }           
      for(int i=0;i<k;i++)
         {
                         tr[h]=i;
                         dodeli(a,h+1,best,tr);
                         }                
     }







int main(int argc, char *argv[])
{
   
   
   scanf("%d %d", &n, &k);
   int best[n];
   int tr[n];
   long long a[n];
   for(int i=0;i<n;i++)cin>>a[i];
   printf("%lld", c);
    for(int i=0;i<n;i++)printf("%d", best[i]);
    system("PAUSE");
    return EXIT_SUCCESS;
}
