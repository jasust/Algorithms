#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{int n,m,min,br=0;
int a[300][300],b[300][300];
cin>>n>>m;
min=n+m;
for(int i=0;i<n;i++){for(int j=0;j<m;j++){cin>>a[i][j];b[i][j]=0;}}

for(int i=0;i<n;i++){
        for(int j=0;j<m-1;j++){
                for(int k=j;k<m;k++){if(a[i][j]>a[i][k]){b[i][j]++;}else{if(a[i][j]<a[i][k]){b[i][k]++;}}}
                }
}

for(int i=0;i<m;i++){
        for(int j=0;j<n-1;j++){
                for(int k=j;k<n;k++){if(a[j][i]<a[k][i]){b[j][i]++;}else{if(a[j][i]>a[k][i]){b[k][i]++;}}}
                }
}

for(int i=0;i<n;i++){for(int j=0;j<m;j++){if(b[i][j]<min){min=b[i][j];}}}
cout<<min;

   
    return 0;
}
