#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;

int deg(int a, int b){int br=1;
for(int i=0;i<b;i++){br*=a;}
return br;}

int main(int argc, char *argv[])
{int n,k,a[13],b[13],c[13],limit,rekord=99999999,ispis[13];
for(int i=0;i<13;i++){b[i]=0;}
cin>>n>>k;
for(int i=0;i<n;i++){cin>>a[i];}
if(k==1){cout<<0<<"\n";for(int i=0;i<n-1;i++){cout<<1<<" ";}cout<<1;}
else if(k==n){int max=a[0],min=a[0];for(int i=1;i<n;i++){if(a[i]>max){max=a[i];}if(a[i]<min){min=a[i];}}
cout<<max-min<<"\n";
for(int i=0;i<n-1;i++){cout<<i+1<<" ";}cout<<n;

}
else if(k>n){int max=0;for(int i=0;i<n;i++){if(a[i]>max){max=a[i];}}
cout<<max<<"\n";

for(int i=0;i<n-1;i++){cout<<i+1<<" ";}cout<<n;
}
else{
     limit=deg(k,n);
     b[0]=-1;
for(int i=0;i<limit;i++){
        for(int i=0;i<13;i++){c[i]=0;}
        for(int z=0;b[z]==k;z++){b[z]=0;b[z+1]++;}
        for(int j=0;j<n;j++){c[b[j]]+=a[j];}
        int max=c[0],min=c[0];
        for(int z=1;z<k;z++){if(c[z]>max){max=c[z];}else if(c[z]<min){min=c[z];}}
        if(max-min<rekord){rekord=max-min;
        for(int z=0;z<n;z++){ispis[z]=b[z];}
        if(rekord==0){break;}
        }
b[0]++;

}
     
     cout<<rekord<<"\n";
     for(int i=0;i<n-1;i++){cout<<ispis[i]+1<<" ";}cout<<ispis[n-1]+1;
     
     }




   
    return 0;
}
