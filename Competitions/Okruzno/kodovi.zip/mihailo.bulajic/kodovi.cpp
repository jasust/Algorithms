#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{int n,indl,indr,put;
unsigned long long br1=0,br2=0;
unsigned int x;
bool pronadjen=false;
cin>>n>>x;
unsigned int p[n];
unsigned int h[n];
for(int i=0;i<n;i++){
        cin>>p[i]>>h[i];
        if(p[i]<x){br1+=h[i];}
        else{br2+=h[i];}
        if(!pronadjen && p[i]>x){indr=i;indl=i-1;pronadjen=true;}
        }
//cout<<indl<<" "<<indr<<"\n";
if(br1<br2){br1=(br1*2)+1;
           }
else br1=br2*2;
 cout<<br1<<"\n";
//prvi korak
br2=0;


br2+=p[indr];
br2-=x;

//kraj prvog koraka

while(true){
            put=min(h[indl],h[indr]);
            br2=br2+put*(p[indr]-p[indl])*2; 
            
            h[indl]-=put;
            h[indr]-=put;
            if(h[indr]==0){indr++;
            if(indr==n){br2-=(p[indr-1]-p[indl]);break;}
            else br2+=p[indr]-p[indr-1];}
            if(h[indl]==0){indl--;if(indl<0){break;}}
            
           
            }
          cout<<br2;

    
    return 0;
}
