#include<stdio.h>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int main()
{int n,k,i,a[13];
 scanf("%d%d",&n,&k);
 for(i=0;i<n;i++)
 scanf("%d",&a[i]);
 if(n==1 && k>1)
 {printf("%d\n",a[0]);
  printf("1");
} if(n==1 && k==1)
  {printf("0\n");
  printf("1");}
  if(n==2 && k==1)
  {printf("0\n");
   printf("1 1");
} if(n==2 && k==2)
  { printf("%d\n",max(a[1]-a[0],a[0]-a[1]));
    printf("1 2");
  }
  if(n==2 && k>2)
  { printf("%d\n",max(a[1],a[0]));
    printf("1 2");
  }
  if(n==3 && k==1)
  {printf("0\n");
  printf("1 1 1");}
  return 0;

}
