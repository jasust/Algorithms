#include<stdio.h>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int h[300][300],b[300][300],mini=90000;
int main()
{ int n,m,i,j,k;
  scanf("%d%d",&n,&m);
  for(i=0;i<n;i++)
  for(j=0;j<m;j++)
  {scanf("%d",&h[i][j]);
   b[i][j]=0; }
  for(i=0;i<n;i++)
  for(j=0;j<m;j++)
  { for(k=0;k<n;k++)
    if(h[k][j]>h[i][j])
    b[i][j]++;
    for(k=0;k<m;k++)
    if(h[i][k]<h[i][j])
    b[i][j]++;
    if(mini>b[i][j])
    mini=b[i][j];
}
printf("%d",mini);
return 0;
    
    
}
