#include<stdio.h>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
typedef struct tacka{
       long long int x;
       long long int br;
       }tacka;
       tacka niz[100000];
int main()
{ long long int n,simcord,i,sumalevih=0,sumadesnih=0,ukupnasuma=0,brcode=0,k=0,l,d,sec=0,st=0;
 scanf("%lld%lld",&n,&simcord);
 k=0;
 for(i=0;i<n;i++)
    { scanf("%lld %lld",&niz[i].x,&niz[i].br);
      ukupnasuma+=niz[i].br;
      if(niz[i].x>simcord && k==0)
      {
        d=i;
        l=i-1;
        k=1;
        }
        else if(niz[i].x<simcord)
        sumalevih+=niz[i].br;
      }
      //printf("%I64d %I64d\n",l,d);
      sumadesnih=ukupnasuma-sumalevih;
      if(sumadesnih>sumalevih)
      brcode=2*sumalevih+1;
      else if(sumadesnih==sumalevih)
      brcode=sumalevih*2;
      else brcode=sumadesnih*2;
      if(d<n)
      sec+=(niz[d].x-simcord);
      st=1;
      while(l>=0 && d<n)
      {
                 if(st==1)
                 {if(niz[l].br<niz[d].br)
                 { sec+=((niz[d].x-niz[l].x)*2*niz[l].br);
                  niz[d].br-=niz[l].br;
                  l--;}
                  else if(niz[l].br>=niz[d].br)
                       { sec+=((niz[d].x-niz[l].x)*(2*niz[d].br-1));
                         niz[l].br-=(niz[d].br-1);
                         st=0;
                         d++;
                         }
                  }
                  else if(st==0)
                  {if(niz[l].br>niz[d].br)
                 { sec+=((niz[d].x-niz[l].x)*2*niz[d].br);
                  niz[l].br-=niz[d].br;
                  d++;}
                  else if(niz[l].br<=niz[d].br)
                       { sec+=((niz[d].x-niz[l].x)*(2*niz[l].br-1));
                         niz[d].br-=(niz[l].br-1);
                         st=1;
                         l--;
                         }
                 }
                 }
                 printf("%lld\n%lld",brcode,sec);
                 return 0;
}
