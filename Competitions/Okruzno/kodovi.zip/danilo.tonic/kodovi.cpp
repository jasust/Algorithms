#include <iostream>

using namespace std;
long long int x,p[100000],h[100000];
int i,n,a=0,b=0,t=0,k=0,y=0,q;
int main()
{
    cin >>n >>x;
    for (i=1;i<=n;i++)
    {
        cin >>p[i] >>h[i];
        if (p[i]<x) {a=a+h[i];y++;}
        else b=b+h[i];
    }
    if (b>a) {b=a+1; k=1;}
    else a=b;
    q=a+b;
    i=y+1;
    while (b>0)
    {
        if (h[i]<b)
            {
                b=b-h[i];
                t=t+(p[i]-x)*2*h[i];
            }
        else
        {
            t=t+(p[i]-x)*2*b;
            b=0;
        }
        i++;
    }
    if (k==1) t=t-(p[i-1]-x);
    i=y;
    while (a>0)
    {
        if (h[i]<a)
            {
                a=a-h[i];
                t=t+(x-p[i])*2*h[i];
            }
        else
        {
            t=t+(x-p[i])*2*a;
            a=0;
        }
        i--;
    }
    if (k==0) t=t-(x-p[i+1]);
    cout <<q <<endl <<t;

    return 0;
}
