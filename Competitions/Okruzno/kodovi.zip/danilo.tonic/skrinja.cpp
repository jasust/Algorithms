#include <iostream>
using namespace std;
int a[13],b[13],c[13],mx=0,mn=100000001,i,j,n,k,r,t;
int main()
{
    cin >>n >>k;
    for (i=1;i<=n;++i)
    {
        cin >>a[i];
        b[i]=i;
    }
    for (i=1;i<n;i++)
        for (j=i+1;j<=n;j++)
            if (a[j]>a[i]) {swap(b[i],b[j]); swap(a[i],a[j]);}
    for (i=1;i<=k;i++) c[b[i]]=i;
    for (i=k+1;i<=n;i++)
    {
        a[k]+=a[i];
        c[b[i]]=c[b[k]];
        for (t=1;t<k;t++)
            for (j=t+1;j<=k;j++)
                if (a[j]>a[t]) {swap(b[t],b[j]); swap(a[t],a[j]);}
    }
    for (i=1;i<=k;i++)
    {
        if (mx<a[i]) mx=a[i];
        if (mn>a[i]) mn=a[i];

    }
    r=mx-mn;
    cout <<r <<endl;
    for (i=1;i<=n;i++) cout<<" "<<c[i];

    return 0;
}
