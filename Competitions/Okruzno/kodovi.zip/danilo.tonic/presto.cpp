#include <iostream>

using namespace std;
int h[90000],x[90000],y[90000],a[90000],b[90000],h2[90000],m,n,i,j,t,mn,k=0;
int main()
{
    cin >>n >>m;
    for (i=1;i<=n*m;i++) {cin >>h[i]; h2[i]=h[i]; a[i]=i; b[i]=i;}
    for (i=1;i<=n;i++)
        for (j=1;j<m;j++)
            for (t=j+1;t<=m;t++) if (h[(i-1)*m+t]>h[(i-1)*m+j]) {swap(a[(i-1)*m+t],a[(i-1)*m+j]); swap(h[(i-1)*m+t],h[(i-1)*m+j]);}

    i=1;
    while (i<=n)
    {
        j=1;
        k=0;
        while (j<=m)
        {
            k++;
            x[a[(i-1)*m+j]]=m-k;
            while (h[(i-1)*m+j]==h[(i-1)*m+j+1] && j+1<=m) {x[a[(i-1)*m+j]]=m-k; j++;}
            j++;
        }
        i++;
    }


    for (i=1;i<=m;i++)
        for (j=1;j<n;j++)
            for (t=j+1;t<=n;t++) if (h2[(j-1)*m+i]>h2[(t-1)*m+i]) {swap(b[(j-1)*m+i],b[(t-1)*m+i]); swap(h2[(j-1)*m+i],h2[(t-1)*m+i]);}
    k=0;
    i=1;
    while (i<=m)
    {
        j=1;
        k=0;
        while (j<=n)
        {
            k++;
            y[b[(j-1)*m+i]]=n-k;
            while (h2[(j-1)*m+i]==h2[(j-1)*m+i+1] && j+1<=n) {y[b[(j-1)*m+i]]=n-k; j++;}
            j++;
        }
        i++;
    }


    mn=600;
    for (i=1;i<=n*m;i++)
        if (x[i]+y[i]<mn) mn= x[i]+y[i];
    cout <<mn;

    return 0;
}
