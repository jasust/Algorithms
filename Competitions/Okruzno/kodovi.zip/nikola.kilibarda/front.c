#include<stdio.h>

int main(){
int x[100000], y[100000], N, F=0, i, j, P=1;

scanf("%d", &N);
for(i=0; i<N; i++)
scanf("%d %d", &x[i], &y[i]);


for(i=0; i<N; i++){
    P=1;
for(j=0; j<N; j++){
if(j==i) ;
else if(x[j]>=x[i] && y[j]>=y[i])
P=0;

}
F+=P;
}
printf("%d", F);
return 0;

}
