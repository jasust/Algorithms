#include<stdio.h>

int main(){

int N, M, K, A[100000], B[100000], i, L, j;

scanf("%d %d %d", &N, &M, &K);
for(i=0; i<N; i++)
scanf("%d", &A[i]);
K--;

for(i=M-1; i>=0; i--){
for(j=0, L=1; j<i; L*=N, j++) ;
B[i]=0;
while(K>=L){
K=K-L;
B[i]++;}
B[i]=A[B[i]];
}

for(i=M-1; i>=0; i--)
printf("%d ", B[i]);


return 0;
}
