#include<stdio.h>

int main(){
int n, m, x, y, k, i, j, p=3;
char L[505][505];

scanf("%d %d", &n, &m);
scanf("%d %d", &y, &x);
scanf("%d", &k);

for(i=1; i<=n; i++)
for(j=1; j<=m; j++) scanf("\n%c", &L[j][i]);


while(k>0)
switch(p){
case 1:
if(L[x][y-1]!='.'){
k--;
p++;
}
else y--;
break;
case 2:
if(L[x-1][y]!='.'){
k--;
p++;
}
else x--;
break;
case 3:
if(L[x][y+1]!='.'){
k--;
p++;
}
else y++;
break;
case 4:
if(L[x+1][y]!='.'){
k--;
p=1;
}
else x++;
break;
}


printf("%d %d\n", y, x);
return 0;


}
