#include <iostream>

using namespace std;

int main()
{
    int m,n,x,y,k;
    cin >> n;
    cin >> m;
    cin >> y;
    cin >> x;
    cin >> k;
    int smer = 270;
    string mat[n+1][m+1];
    for(int i = 1; i < n+1; i++){
        for(int j = 1; j < m+1; j++){
            cin >> mat[i][j];
        }
    }
    int i = 0;
    while(i<k){
        if(smer == 270){
        if (y < n && mat[y+1][x] == "."){
            y++;
            continue;
        }else{
            smer=0;
            i++;
            continue;
        }
        }
        else
        if(smer == 0){
        if (x < m && mat[y][x+1] == "."){
            x++;
            continue;
        }else{
            smer=90;
            i++;
            continue;
        }
        }
        else
        if(smer == 90){
        if (y > 1 && mat[y-1][x] == "."){
            y--;
            continue;
        }else{
            smer=180;
            i++;
            continue;
        }
        }
        else
        if(smer == 180){
        if (x > 1 && mat[y][x-1] == "."){
            x--;
            continue;
        }else{
            smer=270;
            i++;
            continue;
        }
        }

    }
    cout << y << " ";
    cout << x;
    return 0;
}
