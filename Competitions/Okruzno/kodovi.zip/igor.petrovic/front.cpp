#include <iostream>

using namespace std;

int main()
{
    int N;
    int F = 0;
    cin >> N;
    int x[N],y[N];
    for (int i = 0; i < N; i++){
    cin >> x[i];
    cin >> y[i];
    }
    int xa;
    int ya;
    for(int i = N; i > 0 ; i--){
    xa = x[i];
    ya = y[i];
     for(int j = 0; j < N; j++){
        if(xa-1 < x[j] && ya-1 < y[j]){
                if(i == j)
                continue;
            F++;
            break;
        }
        }
     }
     F = N-F-1;
    cout << F << endl;
    return 0;
}
