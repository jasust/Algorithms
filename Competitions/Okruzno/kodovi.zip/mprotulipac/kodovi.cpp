#include <cstdio>

int main()
{
    int n,x,p[100],h[100],l=0,d=0,sek=0,k=0,s=0,g=0;


    scanf("%d %d",&n , &x);
    for (int i=1 ; i<=n; i++)
    {
        scanf("%d %d",&p[i], &h[i]);
        if (p[i]>x) {d+=h[i]; }  else {l+=h[i]; }
    }


    if (d>l) { k=2*l+1; s=1; }  else { k=2*d; s=2; }

    if (s==1)
    for (int i=1 ; i<=n; i++)
    {
        g+=h[i];

        if ((g<k) and (p[i]<x)) sek+=(h[i]*(x-p[i]))*2;
        if ((g<k) and (p[i]>x)) sek+=(h[i]*(p[i]-x))*2;

        if (g>=k) (sek+=(h[i]-(g-k)+1)*(p[i]-x)); printf("%d 1 \n",sek);

    }



    if (s==2)
    for (int i=n ; i>=1; i--)
    {
        g+=h[i];

        if ((g<k) and (p[i]<x)) sek+=(h[i]*(x-p[i]))*2;
        if ((g<k) and (p[i]>x)) sek+=(h[i]*(p[i]-x))*2;

        if (g>=k) (sek+=(h[i]-(g-k)+1)*(x-p[i])); printf("%d 2 \n",sek);

    }


    printf("%d \n",k);
    printf("%d \n",sek);

    return 0;

}
