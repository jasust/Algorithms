#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<ctype.h>
// N koliko broja ima u mnizu, tj ulazu
// M velicina niza matorke :p
// K broj od kojeg se uzima sifra
int main()
{
      int niz[1000],n,m,k,i;
      scanf("%d%d%d",&n,&m,&k);
      for(i=0;i<n;i++)scanf("%d",&niz[i]);
      printf("%d",niz[k-1]);
      return 0;
}
