#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<ctype.h>
//n,m  m- broj redova u vertikali, n- broj redova u horizontali
//y,x koordinate drejka
//k broj sudara, m,broj redova u vertikali = broju zidova
// kolone su [][x], nizovi[x][]
int main()
{
    int m=3,n=3,y,x,k,g,i;
    char mat[501][501];
   scanf("%d%d",&m,&n);
   scanf("%d%d",&y,&x);
   scanf("%d",&k);
      for(g=0;g<m;g++) //g=broj redova na dole;
      {
      for(i=0;i<=n;i++)scanf("%c",&mat[i][g]);
      }
      putchar('\n');
      //for(g=0;g<m;g++) //g=broj redova na dole;
      //{
      //
      //for(i=0;i<=n;i++)printf("%c",mat[i][g]);
      //}
      //
x--;
y--;
//g=k;
   while(k!=0)
   {
if(mat[x][y+1]=='.')
while(mat[x][y+1]=='.'){
{y++;}}
else if(mat[x+1][y]=='.'){k--;
while(mat[x+1][y]=='.')
{x++;}}

else if(mat[x][y-1]=='.') {k--;
while(mat[x][y-1]=='.')
{y--;}}
else if(mat[x-1][y]=='.'){k--; 
while(mat[x-1][y]=='.')
{x--;}}

  } 
 // if(g%2!=0){x=x+2;y=y+2;} 
  printf("%d %d",x,y);
  return 0;
}
