#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<ctype.h>
int main()
{
    int g,i=0,n,br=0,niz[1000],niz1[1000];
    scanf("%d",&n);
    for(i=0;i<n;i++){scanf("%d%d",&niz1[i],&niz[i]);}
    g=i;
 //   printf("I=%d",i);
    while(i>0)
    {
    if(niz[i-1]<=niz[i]) {br++;i--;}
    else i--;
    }
    if(niz[0]<=niz[1]) br++;
    //if(niz[0]<=niz[2]) br++;
    //for(i=0;i<g;i++)printf(" %d",niz[i]);
    printf("%d",br);
    return 0;
}
