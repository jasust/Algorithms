#include <iostream>
#include <vector>

using namespace std;

vector <long> p;
vector <long> k;

int main()
{
    long n,x;
    cin>>n>>x;
    long pp;
    long long sec=0;
    long long levo=0;
    long long desno=0;
    p.resize(n);
    k.resize(n);
    long i=0;
    while (i<n)
    {
        long a,b;
        cin>>a>>b;
        if (a<x) levo+=b;
        else desno+=b;
        p[i]=a;
        k[i]=b;
        if ((i>0) && (p[i-1]<x) && (a>x)) pp=i;
        else {if ((i==0) && (a>x)) sec=a-x;}
        i++;
    }
    if (sec==0) {
    if (levo<desno) desno=levo+1;
    else levo=desno;
    long long l=levo;
    long long d=desno;
    long h,g;
    i=pp;
    while (d>0)
    {
        if (d>k[i])
        {
            sec+=(p[i]-x)*k[i]*2;
            d-=k[i];
        }
        else
        {
            sec+=(p[i]-x)*d*2;
            h=p[i]-x;
            d=0;
        }
        i++;
    }
    i=pp-1;
    while (l>0)
    {
        if (l>k[i])
        {
            sec+=(x-p[i])*k[i]*2;
            l-=k[i];
        }
        else
        {
            sec+=(x-p[i])*l*2;
            l=0;
            g=x-p[i];
        }
        i--;
    }
    if (levo<desno) sec-=h;
    else sec-=g;}
    cout<<desno+levo<<endl;
    cout<<sec<<endl;
    return 0;
}
