#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct peri{
    int br;
    int per;
};

bool uporedi(peri a,peri b)
{
    return(a.br<b.br);
}

int main()
{
    int n,k;
    cin>>n>>k;
    int s=0;
    vector <peri> g(n);
    for(int i=0;i<n;i++)
    {
        int a;
        cin>>a;
        g[i].br=a;
        g[i].per=i;
        s+=a;
    }
    int q=s/k;
    int h=0;
    int y=n;
    vector <int> z(k,0);
    vector <int> p(n,0);
    sort(g.begin(),g.end(),uporedi);
    for(int i=n-1;i>=0;i--)
    {
        if (g[i].br>q) {z[h]=g[i].br;
        p[g[i].per]=h+1;
        h++;
        y--;}
    }
    for (int i=h;i<k;i++)
    {
        z[i]=g[i-h].br;
        p[g[i-h].per]=i+1;
    }
    while (y>=(k-h)*2)
    {
        for(int i=0;i+h<k;i++)
        {
            z[i+h]+=g[y-1-i].br;
            p[g[y-1-i].per]=i+h+1;
        }
        y-=(k-h);
    }
    int mn=z[0];
    int mx=z[0];
    for(int i=1;i<k;i++)
    {
        if (mn>z[i]) mn=z[i];
        if (mx<z[i]) mx=z[i];
    }
    cout<<mx-mn<<endl;
    for (int i=0;i<n;i++)
        cout<<p[i]<<' ';
    return 0;
}
