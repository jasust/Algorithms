#include <stdio.h>
#include <iostream>

using namespace std;

int main(){
    int n,x,y,f=0,i=1,a=0,b=0,m;
    scanf("%d", &n);
    
    for(i;i<=n;i++){
                    scanf("%d%d", &x,&y);
                    if(x==a && y<b){
                          m=y;
                          y=b;
                          b=m;}
                           
                    if((y<b && x>a) || (y<b && x==a))
                            f++;
                            else f=0;        
                    a=x;
                    b=y;}
    printf("%d", f+1);
    return 0;
}
                    
