#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{int n,m,k,x[10000],i,y[10000];
scanf("%d %d %d",&n,&m,&k);
for(i=0;i<n;i++)
{scanf("%d",&x[i]);
}
if(m==1 && n==1)printf("%d",x[0]);
else{if(m==1)
{for(i=0;i<n;i++)
{printf("%d ",x[i]);}
}
if(n==1)
{
for(i=0;i<m;i++)
printf("%d ",x[n-1]);
}
}
if(n==2 && m==2)
{if(k==1)printf("%d %d",x[0],x[0]);
	if(k==2)printf("%d %d",x[0],x[1]);
	if(k==3)printf("%d %d",x[1],x[0]);
	if(k==4)printf("%d %d",x[1],x[1]);
}


return 0;}
