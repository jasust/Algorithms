#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int x[1000000],y[1000000];
int main()
{int i,j,br=0,f,n,a;
scanf("%d",&n);
   for(i=0;i<n;i++)
       scanf("%d %d",&x[i],&y[i]);
        

for(i=0;i<n;i++)
    for(a=i+1,j=1;j<n;j++)
     {
       
       if(y[a]>y[i])break;
       if(y[a]==y[i])   
	      {
	      if(x[a]>x[i])break;
          }
       
       a++;
       if(a==n)br++;
       
    }
if(x[n-1]>x[n-2])br++;

printf("%d\n",br);
return 0;}
	

