#include <stdio.h>
#include <stdlib.h>

int Gore(char MATRICA[][500],int M, int N , int Yt, int Xt) //vraca Y pre sudara
{
    int i;
    for(i=Yt;i>-1;i--)
        if(MATRICA[i][Xt]=='#') return i+1;
    return 0;
}
int Levo(char MATRICA[][500],int M, int N , int Yt, int Xt) //vraca X pre sudara
{
    int i;
    for(i=Xt;i>0;i--)
        if(MATRICA[Yt][i]=='#') return i+1;
    return 0;
}
int Dole(char MATRICA[][500],int M, int N , int Yt, int Xt) //vraca Y pre sudara
{
    int i;
    for(i=Yt;i<M;i++)
        if(MATRICA[i][Xt]=='#') return i-1;
    return M-1;
}
int Desno(char MATRICA[][500],int M, int N , int Yt, int Xt) //vraca X pre sudara
{
    int i;
    for(i=Xt;i<N;i++)
        if(MATRICA[Yt][i]=='#') return i-1;
    return M-1;
}
int main()
{
    char MATRICA[500][500];
    int M,N,smer=4,X,Y,i,j;
    unsigned long long BR;
    scanf("%d %d",&M,&N);
    scanf("%d %d",&Y,&X);
    scanf("%llu",&BR);
    X--;
    Y--;
    for(i=0;i<M;i++)
            scanf("%s",MATRICA[i]);

    Y=Dole(MATRICA,M,N,Y,X);
    BR--;
    while(BR)
    {
        smer--;
        if(smer==0) smer=4;
        if(smer==4)
            Y=Dole(MATRICA,M,N,Y,X);
        if(smer==2)
            Y=Gore(MATRICA,M,N,Y,X);
        if(smer==3)
            X=Desno(MATRICA,M,N,Y,X);
        if(smer==1)
            X=Levo(MATRICA,M,N,Y,X);
        BR--;
    }
    printf("%d %d",Y+1,X+1);
    return 0;
}
