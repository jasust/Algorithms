#include <stdio.h>
#include <stdlib.h>
typedef struct{unsigned int x; unsigned int y;} TTacka;
int main()
{
    int n, i, k, j, l, max;
    TTacka *p, *front;
    scanf("%d", &n);
    p=malloc(sizeof(TTacka)*n);
    front=malloc(sizeof(TTacka)*n);
    for(i=0;i<n;i++)
    {
        scanf("%d %d", &p[i].x, &p[i].y);
        if(i==0)
        {
            max=i;
            continue;
        }
        if(p[i].y>=p[max].y)    max=i;
    }
    front[0].x=p[max].x;
    front[0].y=p[max].y;
    for(i=max+1,j=1;i<n;i++)
    {
        if(j>=2 && p[i].x>=front[j-1].x && p[i].y==front[j-1].y)
        {
            front[j-1].x=p[i].x;
            front[j-1].y=p[i].y;
            continue;
        }
        if(j>=2 && p[i].x==front[j-1].x && p[i].y>front[j-1].y)
        {
            front[j-1].x=p[i].x;
            front[j-1].y=p[i].y;
            continue;
        }
        if(i==n-1 && p[i].x==front[j-1].x && p[i].y>front[j-1].y) j--;
        if(i==n-1 && p[i].x==front[j-1].x && p[i].y<front[j-1].y) j--;
        for(k=j-1;k>0;k--)
        {
            if(p[i].y>=front[j-1].y)
            {
                front[k].y=p[i].y;
                front[k].x=p[i].x;
                j=k+1;
            }
        }
        if(p[i].y<front[j-1].y)
        {
            front[j].y=p[i].y;
            front[j].x=p[i].x;
            j++;
        }
    }
    printf("%d", j);
    free(p);
    free(front);
    return 0;
}
