#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int N,M,M1,i=0,j,*PokazivacN,*PokazivacM;
    unsigned long long k,kor,cif;
    scanf("%d %d %llu", &N,&M,&k);
    PokazivacN=malloc(N*sizeof(int));
    while(i<N)
    {
        scanf("%d",&PokazivacN[i]);
        i++;
    }
    PokazivacM=malloc(M*sizeof(int));
    i=0;
    M1=M;
    while(M)
    {
        kor=pow(N,M-1);
        cif=k/kor;
        PokazivacM[i]=cif;
        if(kor>k)
        {
            PokazivacM[i+1]=k-1;
            break;
        }
        k=k-kor;
        i++;
        M--;
    }
    i=0;
    while(i<M1)
    {
        printf("%d ",PokazivacN[PokazivacM[i]]);
        i++;
    }
    free(PokazivacM);
    free(PokazivacN);
    return 0;
}
