#include <cstdlib>
#include <iostream>

using namespace std;

int pokret(int gomile[][2],int n, int  *i, bool desno)
{
    if(desno)
    {
             for(int j=*i+1;j<n+1;j++)
                     {
                                   if(gomile[j][1]!=0)
                                                      {gomile[j][1]--;int k=*i;*i=j;
                                                      return gomile[j][0]-gomile[k][0];}
                     }
                     
             return -1;        
    }
    else
    {
        for(int j=*i-1; j>=0;j--)
        {
                 if(gomile[j][1]!=0)
                 {gomile[j][1]--;int k=*i;*i=j; return gomile[k][0]-gomile[j][0];}
        }    
        return -1;
    }
}


int main()
{
    int n, x, a, b, poz;
    scanf("%d%d", &n, &x);
    int gomile[n+1][2];
    
    for(int i=0; i<n; i++)
    {
        scanf("%d%d", &a, &b);
             gomile[i][0]=a;
             gomile[i][1]=b;
    }   

    for(int i=n-1;i>=0;i--)
{
    if(gomile[i][0]<x)
{   
    gomile[i+1][0]=x; gomile[i+1][1]=0; poz=i+1; break;
}
    else 
{
    gomile[i+1][0]=gomile[i][0]; gomile[i+1][1]=gomile[i][1];
}
}
    
    long long int brKodova=0, vreme=0;
    bool desno=true;
    int m=pokret(gomile, n, &poz, desno);
    //desno=!desno;
    while(m!=-1)
    {
         desno=!desno; 
         vreme+=m;
         m=pokret(gomile,n,&poz, desno);
         brKodova++;            
    } 
    
    printf("%lld%c%lld",brKodova,'\n',vreme);
    
    return 0;
}
