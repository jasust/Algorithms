#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;


int main(int argc, char *argv[])
{
    int n, k;
    scanf("%d%d", &n, &k);
    int poglavlja[n]; 
scanf("%d", &poglavlja[0]);
int max, min, zbir=0;
max=min=poglavlja[0];

    if(n==k)
    {
        printf("%d%c", max-min, '\n');
        for(int i=0; i<n;i++) printf("%d%c", i+1, ' ');
    }
    else if (n<k)
    {
        printf("%d%c", max, '\n');
        for(int i=0; i<k;i++) printf("%d%c", i+1, ' ');
    }
        else
{
zbir+=max;
    for(int i=1; i<n; i++)
    {
        scanf("%d", &poglavlja[i]);
zbir+=poglavlja[i];
        if(max<poglavlja[i]) max=poglavlja[i];
        if(min>poglavlja[i]) min=poglavlja[i];
    }

    int pod;
    if (zbir%k==0) pod=zbir/k;
    else pod=zbir/k+1;
    int pacijenti[k];
    int pomocni[n]; int zb1;
    
for(int j=0; j<k; j++)
{zb1=0;    for(int i=0; i<n; i++)
        {
if(poglavlja[i]!=0){
               if(zb1==0){if(j==0)pomocni[i]=1;else pomocni[i]=pomocni[i-1]+1; zb1+=poglavlja[i];poglavlja[i]=0;}
               else if (std::abs(zb1-pod)>std::abs(zb1+poglavlja[i]-pod))
                    { zb1+=poglavlja[i]; pomocni[i]=pomocni[i-1];poglavlja[i]=0;}
                else {pacijenti[j]=zb1;break;}}
        }
}
int max1, min1;
max1=min1=pacijenti[0];
for(int j=0; j<k; j++)
{
    if (min1>pacijenti[j]) min1=pacijenti[j];
    if(max1<pacijenti[j]) max1=pacijenti[j];
}
printf("%d$c", max1-min1, '\n');
for(int j=0; j<k; j++)
    printf("%d%c", pacijenti[j], ' ');


}
    return 0;
}
