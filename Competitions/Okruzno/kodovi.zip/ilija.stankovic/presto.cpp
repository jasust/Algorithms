#include <cstdlib>
#include <iostream>

using namespace std;

bool imaPresto(int basta[][], int n, int m)
{
    for(int i=0; i<n; i++)
        for(int j=0; j<m; j++)
            {
                
            }
}


int main(int argc, char *argv[])
{
     int n, m;
    scanf("%d%d", &n, &m);
    int basta[n][m];
    for(int i=0; i<n; i++)
        for (int j=0; j<m; j++)
            scanf("%d%d", &basta[i][j]);
    
    system("PAUSE");
}
