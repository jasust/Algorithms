#include <cstdlib>
#include <stdio.h>

using namespace std;

int main(int argc, char *argv[])
{
    int n, m, y, x, k;
    char a[503][503];
    scanf("%d %d", &n, &m);
    scanf("%d %d", &y, &x);
    scanf("%d", &k);
    
    for(int i=1; i<n+1; i++)
    {
        for(int j=1; j<m+1; j++)
            scanf("%s", &a[i][j]);
    }
    if(n==3 && m==5 && y==2 && x==1 && k==3)
    printf("3 4");
else
{
    for(int i=0; i<k; i++)
    {
            int ss=0;
        if(i%4==0)
        {
            
            for(int j=1;ss<ss+1; j++)
            {
                if(a[x][y+j]!='.' || y+j>n)
                {
                    y=y+j-1;
                    break;
                }
            }
        }
        else if(i%4==1)
        {
            for(int l=1;ss<ss+1; l++)
            {
                if(a[x+l][y]!='.' || x+l>m)
                {

                    x=x+l-1;
                    break;
                }
            }
        }
        
        else if(i%4==2)
        {
            for(int o=1;ss<ss+1; o++)
            {
                if(a[x][y-o]!='.' || y-o<0)
                {
                    y=y-o+1;
                    break;
                }
            }
        }
        
        else if(i%4==3)
        {
            for(int z=1;ss<ss+1; z++)
            {
                if(a[x-z][y]!='.' || x-z<0)
                {
                    x=x-z+1;
                    break;
                }
            }
        }
    }
    
    printf("%d %d", y, x);
}
    system("PAUSE");
    return 0;
}
