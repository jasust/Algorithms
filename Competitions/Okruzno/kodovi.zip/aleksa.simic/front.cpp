#include <cstdlib>
#include <stdio.h>

using namespace std;

int main(int argc, char *argv[])
{
    int n, x[1002], y[1002], br=0, a=1;
    scanf("%d", &n);
    for(int i=0; i<n; i++)
    {
        scanf("%d", &x[i]);
        scanf("%d", &y[i]);
    }
    
    
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
             if(i!=j)
                 if(x[j]>=x[i] && y[j]>=y[i])
                     a=0;
        }
        if(a==1)
            br++;
        else
            a=1;
    }
    
    printf("%d", br);
    system("PAUSE");
    return 0;
}
