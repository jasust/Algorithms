#include<cstdio>
#include<algorithm>
using namespace std;
long long pow(int s,int i)
{
    long long x=1;
    if(i!=0)
    {for(int t=1;t<=i;t++) x=x*s;}
    return x;
}
int main()
{
    int N,M;
    long long K;
    scanf("%d %d %lld",&N,&M,&K);
    long long x[M+1];
    long long a[N+5];
    a[0]=0;
    for(int n=1;n<=N;n++) scanf("%lld",&a[n]);
    for(int m=1;m<=M;m++)
    {
        if(((K%pow(N,m))%pow(N,m-1)==0)) x[M+1-m]=(K%pow(N,m))/pow(N,m-1);
        else x[M+1-m]=(K%pow(N,m))/pow(N,m-1)+1;
    }
    for(int t=1;t<=M;t++)
    {
        if(x[t]==0) printf("%lld ",a[N]);
        else printf("%lld ",a[x[t]]);
    }
    return 0;
}
