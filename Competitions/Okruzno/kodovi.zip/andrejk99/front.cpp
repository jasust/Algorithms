#include<cstdio>
int main()
{
    int N,p=-1,b=0;
    scanf("%d",&N);
    long long x[N+10],y[N+10];
    for(int n=1;n<=N;n++) scanf("%lld %lld",&x[n],&y[n]);
    for(int a=N;a>0;a--)
    {
        if(y[a]>p)
        {
            b++;
            p=y[a];
        }
    }
    printf("%d",b);
    return 0;
}
