#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int el[100000];
int mt[100000];

int main()
{int i,j,l,n,m,k,x,a,b;
    scanf("%d %d %d",&n,&m,&k);
    
    for(i=0;i<n;i++) scanf("%d",&el[i]);
    for(i=0;i<m;i++) mt[i]=el[0];
    a=1;
    
       for(i=0,j=0;i<k;i++)
       {  if( int( pow(n,(m-a))) == (i-1) ) {a++;
                                             mt[j]=el[n-a];}
       for(i=0,j=0,l=0;i<k;i++,j++)
        { if(j==n) {l++;
                  if(l==n) l=0;
                  mt[m-a-1]=el[l];
                  j=0;}
        mt[m-a]=el[j];}}
     
  for(x=0;x<m;x++) printf("%d ",mt[x]);        
    
                    
                    
        
//system("pause");
return 0;
}
