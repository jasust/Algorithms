#include<stdio.h>
#include<stdlib.h>
int x[1000000][2];

int main()
{int i=0,j=0,n,f=0,y=0;
    scanf("%d",&n);
    
    for(i=0;i<n;i++) 
    scanf("%d %d",&x[i][0],&x[i][1]);
    
    while(y<n)
    { for(j=n-1;j==0;j=j-1)
     { for(i=y;i<n;i++) 
      { if( ( x[j][0]>x[i][0] && x[j][1]>=x[i][1] ) || ( x[j][0]>=x[i][0]&& x[j][1]>x[i][1] ) ) f++;}
     y++;}
    }
 
printf("%d\n",f);

return 0;
}
