#include <iostream>
#include <vector>
#include <cstdio>
#include <cmath>
using namespace std;

struct T{
    int x;
    int K;
};

int main()
{
    int N, X;
    scanf("%d %d", &N, &X);
    vector<T> a(N);
    for (int i=0; i<N; i++)
        scanf("%d %d", &a[i].x, &a[i].K);
    int i=0;
    while ((i<N) && (a[i].x< X))
        i++;
    int k=i; int pre= X; long long t=0; long long s=0;
    int z=-1;
    bool q=true;
    while (q)
    {
        t+=abs(a[k].x-pre); pre = a[k].x;
        s++; a[k].K--;
        i=1;
        do
        {
            k+=z*i;
        } while ((a[k].x>=0) && (a[k].x<=a[N-1].x) && (k>=0) && (k<N) && (a[k].K==0));
        if ((k<0) || (k>=N) ||(a[k].x<0) ||(a[k].x>a[N-1].x)) q=false;
        z*=-1;
    }
    printf("%lld\n", s);
    printf("%lld", t);
    return 0;
}
