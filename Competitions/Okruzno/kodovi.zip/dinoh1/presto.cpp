#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

typedef vector<vector<int> > mat;

int minR(const mat &a, int n, int m, int i)
{
    int M=0;
    int mi=a[i][0];
    for (int j=1; j<m; j++)
        if (a[i][j] < mi) { M=j; mi=a[i][j];}
    return M;
}
int brojK(const mat &a, int n, int m, int i, int B)
{
    int K=0;
    for (int j=0; j<n; j++)
        if (a[j][i] > B) K++;
    return K;
}
int maxK(const mat &a, int n, int m, int i)
{
    int M=0;
    int ma=a[0][i];
    for (int j=1; j<n; j++)
        if (a[j][i] > ma) { M=j; ma=a[j][i];}
    return M;
}
int brojR(const mat &a, int n, int m, int i, int B)
{
    int K=0;
    for (int j=0; j<m; j++)
        if (a[i][j] < B) K++;
    return K;
}

int main()
{
    int N,M;
    cin >> N >> M;
    mat a(N, vector<int> (M));
    for (int i=0; i< N; i++)
        for (int j=0; j< M; j++)
            scanf("%lld", &a[i][j]);
    int m=1000000001;
    int k,K,k2,K2;
    for (int i=0; i<N; i++)
    {
        k = minR(a,N,M,i);
        k2 = brojK(a,N,M,k,a[i][k]);
        K = maxK(a,N,M,i);
        K2 = brojR(a,N,M,K,a[K][i]);
        if (k2<m) m = k2;
        if (K2<m) m = K2;
    }
    printf("%d", m);
    return 0;
}
