#include <stdio.h>

int main() {
	long long int k, i1, i2;
	char ar[600][600];
	int check[300000][4];
	int n, m, y, x, j;
	int helpX, helpY;
	int done = 0;
	int counter = 0;
	int aaa = 0;
	scanf("%d %d", &n, &m);
	scanf("%d %d", &y, &x);
	scanf("%lld\n", &k);
	for(i1=0; i1<=n+1; i1++){
		for(i2=0; i2<=m+1; i2++){
			ar[i1][i2] = '#';
		}
	}
	for(i1=1; i1<=n; i1++){
		for(i2=1; i2<=m; i2++){
			scanf("%c", &ar[i1][i2]);
		}
		scanf("\n");
	}
	
	helpX = 0;
	helpY = 1;
	while(done==0){
		if(ar[y+helpY][x+helpX]=='.'){
			x+=helpX;
			y+=helpY;
		}
		else{
			k--;
			check[counter][0] = y;
			check[counter][1] = x;
			check[counter][2] = helpY;
			check[counter][3] = helpX;
			counter++;
			if(counter!=1){
				for(j=0; j<counter-1; j++){
					if(y==check[j][0] && x==check[j][1] && helpY==check[j][2] && helpX==check[j][3] && aaa==0){
						k=k%4;
						aaa = 1;
					}
				}
			}
			
			if(k==0){
				printf("%d %d", y, x);
				done = 1;
			}
			if(helpX==0 && helpY==1){
				helpX = 1;
				helpY = 0;
			}
			else if(helpX==0 && helpY==-1){
				helpX = -1;
				helpY = 0;
			}
			else if(helpX==1){
				helpX = 0;
				helpY = -1;
			}
			else if(helpX==-1){
				helpX = 0;
				helpY = 1;
			}
		}
	}
	
	return 0;
}