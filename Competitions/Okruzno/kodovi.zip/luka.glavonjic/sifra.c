#include <stdio.h>

int main() {
	long long int n, m, k, i1 ,i2;
	long long int ar[100000];
	long long int ar2[100000];
	long long int counter;
	
	scanf("%lld %lld %lld", &n, &m, &k);
	for(i1=0; i1<n; i1++){
		scanf("%lld", &ar[i1]);
	}
	for(i1=0; i1<m; i1++){
		ar2[i1] = 0;
	}
	if(m==1){
		printf("%lld", ar[k-1]);
	}
	else{
		for(i1=0; i1<k-1; i1++){
			counter = 0;
			for(i2=m-1; i2>=0; i2--){
				if(ar2[i2]!=n-1){
					ar2[i2] ++; 
					break;
				}
				else{
					ar2[i2] = 0;
				}
			}
		}
		for(i1=0; i1<m; i1++){
			printf("%lld ", ar[ar2[i1]]);
		}
	}
	return 0;
}