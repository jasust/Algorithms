#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

struct gomila{
long long p;
long long n;
};
int main()
{
    int n = 0;
    long long x = 0, levo = 0, desno = 0, broj_kodova = 0, levo_uzeti = 0, desno_uzeti = 0;

    scanf("%d%lld", &n, &x);


    long long pi, ni;
    vector<gomila> levo_vektor;
    vector<gomila> desno_vektor;
    for(int i = 0; i < n; i++)
    {
        scanf("%lld%lld", &pi, &ni);
        if(pi < x)
        {
            levo += ni;
            levo_vektor.push_back(gomila());
            levo_vektor[levo_vektor.size() - 1].p = pi;
            levo_vektor[levo_vektor.size() - 1].n = ni;
        }
        else
        {
            desno += ni;
            desno_vektor.push_back(gomila());
            desno_vektor[desno_vektor.size() - 1].p = pi;
            desno_vektor[desno_vektor.size() - 1].n = ni;
        }
    }

    if(levo < desno)
    {
        broj_kodova = levo * 2 + 1;
        levo_uzeti = levo;
        desno_uzeti = levo + 1;
    }
    else
    {
        broj_kodova = desno * 2;
        levo_uzeti = desno;
        desno_uzeti = desno;
    }


    bool radi = true;

    long long vreme = 0;

    long long brojac_za_levo = 1;
    long long brojac_za_desno = 0;

    vreme += desno_vektor[0].p - x;
    desno_vektor[0].n--;
    desno_uzeti--;
    long long pozicija = desno_vektor[0].p;

    if(desno_vektor[0].n == 0)
        desno_vektor.erase(desno_vektor.begin());


    while(radi)
    {
        if(levo_vektor.size() == 0)
            break;

        vreme += pozicija - levo_vektor[levo_vektor.size() - 1].p;
        pozicija = levo_vektor[levo_vektor.size() - 1].p;
        vreme += desno_vektor[0].p - pozicija;
        pozicija = desno_vektor[0].p;

        desno_uzeti--;
        levo_uzeti--;
        levo_vektor[levo_vektor.size() - 1].n--;
        desno_vektor[0].n--;
        if(desno_vektor[0].n == 0)
            desno_vektor.erase(desno_vektor.begin());
        if(levo_vektor[levo_vektor.size() - 1].p == 0)
            levo_vektor.erase(levo_vektor.end() - 1);
        if(desno_uzeti == 0 || levo_uzeti == 0)
            radi = false;
    }

    printf("%lld\n%lld\n", broj_kodova, vreme);

    return 0;
}
