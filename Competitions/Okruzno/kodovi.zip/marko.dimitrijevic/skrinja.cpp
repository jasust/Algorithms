#include <iostream>
#include <cstdio>
using namespace std;
void zameni(long a, long b)
{
    long t=a;
    a=b;
    b=t;
}
long minik(long*p, long n)
{
    long q=p[0];
    long k=0;
    for(long i=0; i<n; i++)
        if(p[i]<q)
        {
            q=p[i];
            k=i;
        }
    return k;
}
long razlika(long*s,long k)
{
    long mi=s[0];
    long ma=s[0];
    for(long i=0; i<k; i++)
        if(s[i]>ma) ma=s[i];
           else if(s[i]<mi) mi=s[i];
    return (ma-mi);
}
int main()
{
    long n; long k;
    scanf("%ld",&n);
    scanf("%ld",&k);
    long *p=new long[n];
    for(long i=0; i<n; i++)
        scanf("%ld",&p[i]);
    long *p1=new long[n];
    for(long i=0; i<n; i++)
        p1[i]=p[i];
    for(long i=0; i<n; i++)
        printf("%ld\n",&p[i]);
    for(long i=0; i<n-1; i++)
        for(long j=i+1;j<n;j++)
          if(p1[i]<p1[j]) zameni(p1[i],p1[j]);
    for(long i=0; i<n; i++)
        printf("%ld\n",&p[i]);
    long *s=new long[k];
    for(long i=0; i<k; i++)
        s[i]=0;
    long *r=new long[n];
    for(long i=0; i<n; i++)
        r[i]=0;
    for(long i=0; i<n; i++)
        {
            long g=minik(s,k);
            s[g]=s[g]+p1[i];
            r[i]=g;
        }
    long raz=razlika(s,k);
    printf("%ld\n",raz);
    for(long i=0; i<n;i++)
        cout<<r[i]+1<<" ";
    return 0;
}
