#include <iostream>
#include <cstdio>
using namespace std;
long desno(long x,long *p, long *k,long d)
{
   long g=p[d]-x;
   k[d]=k[d]-1;
   x=p[d];
   return g;
}
long levo(long x,long *p, long *k,long l)
{
   long g=x-p[l];
   k[l]=k[l]-1;
   x=p[l];
   return g;
}
int main()
{
    long n; long x;
    scanf("%ld",&n);
    scanf("%ld",&x);
    long *p=new long[n];
    long *k=new long[n];
    for(long i=0; i<n; i++)
    {
        scanf("%ld",&p[i]);
        scanf("%ld",&k[i]);
    }
    long l=-1; long d;
    long i=0;
    long long s=0;
    long b=0;
    while(l==-1)
         {
             if(p[i]<x) i++;
             else {
                    l=i-1;
                    d=i;
                  }
         }
    long z=1;
    while((d<n)&&(l>-1))
    {
        if(z==1)
        {
            s=s+desno(x,p,k,d);
            b++;
            z=-1;
            if(k[d]==0)d=d+1;
        }
        else
        {
            s=s+levo(x,p,k,l);
            b++;
            z=1;
            if(k[l]==0)l=l-1;
        }
    }
    long long s1=s;
    if(z==1)
    {
        b++;
        s=s+(p[d]-x);
    }
    else
    {
        b++;
        s=s+(x-p[l]);
    }
    s1=s1+s;
    printf("%ld\n",b);
    printf("%lld",s1);
    return 0;
}
