#include <iostream>
#include <cstdio>
using namespace std;
long mini(long**r,long i,long m)
{
    long k=r[i][0];
    for(long j=0;j<m; j++)
        if(r[i][j]<k) k=r[i][j];
    return k;
}
long maxi(long**r,long j,long n)
{
    long k=r[0][j];
    for(long i=0;i<n; i++)
        if(r[i][j]>k) k=r[i][j];
    return k;
}
long kolmax(long**r,long j, long n,long br)
{
    long k=0;
    for(long i=0;i<n;i++)
    {
        if(r[i][j]>br) k=k+1;
    }
    return k;
}
long kolmin(long**r,long i, long m,long br)
{
    long k=0;
    for(long j=0;j<m;j++)
    {
        if(r[i][j]<br) k=k+1;
    }
    return k;
}
int main()
{
    long n;
    long m;
    scanf("%ld",&n);
    scanf("%ld",&m);
    long **r=new long*[n];
    for(long i=0; i<n; i++)
        r[i]=new long[m];
    for(long i=0; i<n; i++)
        for(long j=0;j<m; j++)
         scanf("%ld",&r[i][j]);
    long k=m+n;
    for(long i=0;i<n;i++)
    {
        long br= mini(r,i,m);
        for(long j=0;j<m; j++)
        {
            if(r[i][j]==br)
            {
                long p=kolmax(r,j,n,br);
                if(p<k) k=p;
            }
        }
    }
    long q=m+n;
    for(long j=0;j<m;j++)
    {
        long br= maxi(r,j,n);
        for(long i=0;i<n; i++)
        {
            if(r[i][j]==br)
            {
                long p=kolmin(r,i,m,br);
                if(p<q) q=p;
            }
        }
    }
    if(q<k  )printf("%ld",q);
        else printf("%ld",k);
    return 0;
}
