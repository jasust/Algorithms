#include <stdio.h>

 /*
  2
  |
3-X-1
  |
  0
  */

int main()
{
    long int M[501][501]={{0}},n,m,x,y,dir=0;
    char c;
    long int k;

    scanf("%i%i",&n,&m);
    scanf("%i%i",&y,&x);
    scanf("%i",&k);

    for (long int i=1;i<=n;++i)
    {
        scanf("\n");
        for (long int j=1;j<=m;++j)
        {
            scanf("%c",&c);
            if (c!='.')
                M[j][i]=1;
        }
    }
    while (k>0)
    {
        if (dir==0)
            while ((y<n)&&(M[x][y+1]==0))
                ++y;
        if (dir==1)
            while ((x<m)&&(M[x+1][y]==0))
                ++x;
        if (dir==2)
            while ((y>1)&&(M[x][y-1]==0))
                --y;
        if (dir==3)
            while ((x>1)&&(M[x-1][y]==0))
                --x;
        --k;
        dir=(dir+1)%4;
    }
    printf("%i %i",y,x);
    return 0;
}
