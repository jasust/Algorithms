#include <stdio.h>

long long stepen(long int a,long int i)
{
    long long k=1;
    for (int r=1;r<=i;++r)
        k*=a;
    return k;
}

int main()
{
    long long k;
    long int m,n,A[100000];
    scanf("%i%i%i",&n,&m,&k);
    --k;
    for (long int i=0;i<n;++i)
        scanf("%i",&A[i]);
    for (long int i=m-1;i>=0;--i)
    {
        long int c;
        c=(long int)k/stepen(n,i);
        k=(long int)k%stepen(n,i);
        printf("%i",A[c]);
        if (i>0)
            printf(" ");
    }
    return 0;
}
