#include <stdio.h>
#include <stdlib.h>

int main()
{
    long int *X,*Y,*K;
    X=(long int*)malloc(sizeof(long int)*1000000);
    Y=(long int*)malloc(sizeof(long int)*1000000);
    K=(long int*)malloc(sizeof(long int)*1000000);

    long int n,x=0;

    scanf("%i",&n);

    for (int i=0;i<n;++i)
    {
        scanf("%i%i",&X[i],&Y[i]);
        K[i]=1;
    }

    x=1;

    for (int i=0;i<n;++i)
    {
        int j=i-1,mx=Y[i],mxi=i,mxk=1;
        while ((j>0)&&(X[j]==X[i]))
        {
            K[j]=0;
            if (mx==Y[j])
            {
                ++mxk;
                X[j]=-1;
                Y[j]=-1;
            }
            else if (mx<Y[j])
            {
                mx=X[j];
                mxi=j;
                mxk=1;
            }
            --j;
        }
        j=i+1;
        while ((j<n)&&(X[j]==X[i]))
        {
            K[j]=0;
            if (mx==Y[j])
            {
                ++mxk;
                X[j]=-1;
                Y[j]=-1;
            }
            else if (mx<Y[j])
            {
                mx=X[j];
                mxi=j;
                mxk=1;
            }
            ++j;
        }
        K[i]=0;
        K[mxi]=mxk;
    }

    for (int i=0;i<n;++i)
    {
        int t=0;
        if (K[i]>0)
        {
            int j=i+1;
            while ((j<n)&&(Y[j]<Y[i]))
                ++j;
            if (j==n)
                t=1;
        }
        x+=K[i]*t;
    }

    printf("%i",x-K[n-1]);

    free(X);
    free(Y);
    free(K);
    return 0;
}
