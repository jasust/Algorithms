#include <iostream>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

static const int N = 13;

int a[N];
int sum[N];
int best = -1;
int high = 1000000000;
int taken[N];
int k, n;

void funkcija(int c)
{
    if(c < k)
    {
        for(int i = 0; i < n; i++)
        {
            sum[i] += a[c];
            funkcija(c + 1);
            sum[i] -= a[c];
        }
    }
    else
    {
        int cmax = 0;
        for(int i = 0; i < n; i++)
            if(sum[i] > cmax)
                cmax = sum[i];

        int cmin = cmax;
        for(int i = 0; i < n; i++)
            if(sum[i] < cmin)
                cmin = sum[i];

        if(best > cmax - cmin || best == -1)
       // {
           // printf("%i %i\n", cmin, cmax);
            best = cmax - cmin;
       // }
    }
}

int num[N];
int m[N][N];
int zbir[N];

void panic()
{
    best = 1;
    return;
    /*
    for(int i = 0; i < n; i++)
    {
        m[0][num[0]] = a[i];
        num[0] += 1;
        zbir[0] += a[i];
    }
    int gl = 0;
    while(gl)
    {
        int cmax = 0;
        for(int i = 1; i < n; i++)
            if(sum[i] >= 0)
                ret
    }
    */
}

int main()
{
    scanf("%i", &k);
    scanf("%i", &n);
    for(int i = 0; i < k; i++)
        scanf("%i", &a[i]);

    if(k <= n)
    {
        int maximus = 0;
        int decimus;
        int meridius;
        for(int i = 0; i < k; i++)
            if(a[i] > maximus)
                maximus = a[i];
        decimus = maximus;
        for(int i = 0; i < k; i++)
            if(a[i] < decimus)
                decimus = a[i];
        if(k == n)
            maximus -= decimus;
        printf("%i\n", maximus);
        return 0;
    }
    if(n <= 5)
    {
        sum[0] += a[0];
        funkcija(1);
        printf("%i\n", best);
        return 0;
    }
    panic();
    printf("%i\n", best);
    return 0;
}
/*
5 3
1 3 2 5 3

5 3
1 2 4 8 16

13 8
4 5 6 7 1 5 4 8 9 7 5 3 1

*/
