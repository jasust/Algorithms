#include <iostream>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

static const int N = 100000;

long long p[N];
long long h[N];
int n;
long long num;
long long len;

void funk(long long pos, int l, int d, int s)
{
    if(l < 0 && d >=n)
        return;
    if(l < 0)
    {
        if(s)
        {
            num += 1;
            len += p[d] - pos;
        }
        return;
    }
    if(d >= n)
    {
        if(!s)
        {
            num += 1;
            len += pos - p[l];
        }
        return;
    }
    if(s)
    {
        len -= pos - p[l];
        if(h[d] > h[l])
        {
            len += (p[d] - p[l]) * (h[l] * 2 + 1);
            num += (h[l] * 2 + 1);

            h[d] -= (h[l] + 1);
            h[l] = 0;

            pos = p[d];
            s = 0;
        }
        else
        {
            len += (p[d] - p[l]) * (h[d] * 2);
            num += (h[d] * 2);

            h[l] -= h[d];
            h[d] = 0;

            pos = p[l];
            s = 1;
        }
        if(!h[l])
            l--;
        if(!h[d])
            d++;
        funk(pos, l, d, s);
    }
    else
    {
        len -= p[d] - pos;
        if(h[d] < h[l])
        {
            len += (p[d] - p[l]) * (h[d] * 2 + 1);
            num += (h[d] * 2 + 1);

            h[l] -= (h[d] + 1);
            h[d] = 0;

            pos = p[l];
            s = 1;
        }
        else
        {
            len += (p[d] - p[l]) * (h[l] * 2);
            num += (h[l] * 2);

            h[d] -= h[l];
            h[l] = 0;

            pos = p[d];
            s = 0;
        }
        if(!h[l])
            l--;
        if(!h[d])
            d++;
        funk(pos, l, d, s);
    }
}

int main()
{
    long long x;
    scanf("%i", &n);
    cin >> x;
    for(int i = 0; i < n; i++)
    {
        cin >> p[i];
        cin >> h[i];
    }
    for(int i = 0; i < n; i++)
        if(p[i] > x)
        {
            funk(x, i - 1, i, 1);
            break;
        }

    cout << num << endl;
    cout << len << endl;
    return 0;
}
/*
4 7
1 1
5 2
10 1
12 4

*/
