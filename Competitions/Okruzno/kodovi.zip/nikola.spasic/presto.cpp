#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <algorithm>

using namespace std;

static const int N = 300;

int t[3][N][N];
int niz[2 * N];
int n, m;
int glob;

int fix(int pos, int k, int c)
{
    int b = (-k + 1) / 2;
    int e = !b * n + b * m;
    int raz = 1;
    while(raz * 2 < e)
        raz *= 2;
    while(raz)
    {
        if(pos + raz * k >= 0 && pos + raz *k < e && t[2 - b][c][pos + raz * k] == t[2 - b][c][pos])
            pos += raz * k;
        raz /= 2;
    }
    return pos;
}

int pozicija(int c, int b, int k)
{
    int l = 0;
    int d = !b * n + b * m;
    int mid;
    if(glob)
    {
        /*
        printf("%i %i\n", c, b);
        for(int i = l; i < d; i++)
            printf("%i ", t[2 - b][k][i]);
        printf("\n");
        */
    }
    while(l < d - 1)
    {
        mid = (l + d) / 2;
        if(t[2 - b][k][mid] <= c)
            l = mid;
        else
            d = mid;
    //    if(glob)
     //       printf("%i %i %i, %i\n", l, mid, d, t[2 - b][k][mid]);
    }
   // if(glob)
     //   printf(" %i\n", l + 1);
   // system("pause");
    if(b)
        l = fix(l, -1, k);
    else
        l = fix(l, 1, k);
    return l;
}

int dummyBest(int i, int j)
{
    int res = 0;
    for(int k = 0; k < m; k++)
        if(t[0][i][k] < t[0][i][j])
            res++;
    for(int k = 0; k < n; k++)
        if(t[0][k][j] > t[0][i][j])
            res++;
    return res;
}

int orig[N * 2];

void solve()
{
    int best = -1;
    int cur;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
        {
            int num = 0;
            for(int k = 0; k < n; k++)
                if(k != i)
                {
                    niz[num] = t[0][k][j];
                    orig[num] = 0;
                    num++;
                }
            for(int k = 0; k < m; k++)
                if(k != j)
                {
                    niz[num] = t[0][i][k];
                    orig[num] = 1;
                    num++;
                }
            niz[num] = t[0][i][j];
            num++;

            for(int k = 0; k < n + m - 1; k++)
                if(niz[k] == t[0][i][j])
                    orig[k] = 2;

           // for(int i = 0; i < n + m - 1; i++)
            //    printf("%i %i\n", niz[i], orig[i]);
            //printf("\n");

            for(int i = 0; i < n + m - 1; i++)
                for(int j = i + 1; j < n + m - 1; j++)
                    if(niz[i] > niz[j])
                    {
                        int tmp = niz[j];
                        niz[j] = niz[i];
                        niz[i] = tmp;
                        tmp = orig[j];
                        orig[j] = orig[i];
                        orig[i] = tmp;
                    }

           // for(int i = 0; i < n + m - 1; i++)
            //    printf("%i %i\n", niz[i], orig[i]);
           // system("PAUSe");
            int broj[3];
            for(int i = 0; i < n + m - 1; i++)
                broj[orig[i]]++;

            int k = 0;
            while(orig[k] == 0)
                k++;
            int e = n + m - 2;
            while(orig[e] == 1)
                e--;
            int g[3];
            for(int k; k <= e; k++)
            {
                if(orig[k] == 1 && g[0])
                {

                }
                g[orig[k]]++;
            }
            if(cur < best)
                best = cur;
        }
}

int main()
{
    /*
    scanf("%i", &n);
    m = n;
    int pos;
    scanf("%i", &pos);
    int a[20];
    for(int i = 0; i < n; i++)
        scanf("%i", &t[2][0][i]);
    printf("%i\n", fix(pos, 1, 0));
    return 0;
    */
    scanf("%i", &n);
    scanf("%i", &m);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
        {
            scanf("%i", &t[0][i][j]);
            t[1][i][j] = t[0][i][j];
            t[2][j][i] = t[0][i][j];
        }
    int gotov = 0;
    if(gotov)
    {
        solve();
        return 0;
    }
    for(int i = 0; i < n; i++)
        sort(t[1][i], t[1][i] + m);

    for(int i = 0; i < m; i++)
        sort(t[2][i], t[2][i] + n);
    /*
    printf("\n");
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < m; j++)
            printf("%i", t[1][i][j]);
        printf("\n");
    }
    printf("\n");
    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
            printf("%i", t[2][i][j]);
        printf("\n");
    }
    */
    int best = -1, cur;
   // int dbest = -1;
    if(!(n * m))
        best = 0;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
        {
           // if(dummyBest(i, j) < dbest || dbest == -1)
            //    dbest = dummyBest(i, j);
            if(i == 1 && j == 3)
                glob = 1;
            else
                glob = 0;
            cur = 0;
          //  printf("%i %i\n", i, j);
            cur += pozicija(t[0][i][j], 1, i);
            cur += n - pozicija(t[0][i][j], 0, j) - 1;
          //  printf("\n");
            if(cur < best || best == -1)
            {
                //printf("%i %i\n", i + 1, j + 1);
                //printf("%i\n", cur);
                best = cur;
            }
        }
    printf("%i\n", best);
    //printf("%i\n", dbest);
    return 0;
}
/*
3 4
1 9 3 0
6 2 7 5
8 4 6 3

5 5
6 1 6 1 1
1 6 1 6 1
1 1 6 1 6
6 1 1 6 1
1 6 1 1 6

5 6
1 2 3 4 5 6
2 3 4 5 6 7
3 4 5 6 7 8
4 5 6 7 8 9
5 6 7 8 9 10

*/
