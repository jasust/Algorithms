#include <iostream>
#include <cmath>

using namespace std;

int main()
{

    // zahtevam 50 posto od osvojene kopijeve nagrade
    int n, m, k;

    cin>>n;
    cin>>m;
    cin>>k;
    int brojevi[n];

    for (int i=0; i<n; i++)
    {
        cin>> brojevi[i];
    }


    int resenje[static_cast<int>(pow(static_cast<double>(n), static_cast<double>(m)))] [m];

    for (int i=n; i<k; i*=n)
    {

        if (m==1)
        {
            for(int i=0; i<n; i++)
            {
                cout << brojevi[i] << " ";
                break;
            }
        }
        else if ((k/i)<=i)
        {
            if (k%n==1)
            {
                resenje[i][k-n]=1;
            }
            else if (k%n==2)
            {
                resenje[i][k-n]=2;
            }
            else if (k%n==0)
            {
                resenje[i][k-n]=0;
            }
        }

        else if (k/i <=n)
        {
            if (k%n==1)
            {
                resenje[i][k-n]=1;
            }
            else if (k%n==2)
            {
                resenje[i][k-n]=2;
            }
            else if (k%n==0)
            {
                resenje[i][k-n]=0;
            }
        }
    }



    return 0;
}
