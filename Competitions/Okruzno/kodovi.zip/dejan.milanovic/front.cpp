#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    int n;

    scanf("%d", &n);

    int vojnik[n][2];

    for (int i=0; i<n; i++)
    {
        cin >> vojnik[i][0];
        cin >> vojnik[i][1];
    }

    int naFrontu=0;

    bool dane;
    for (int i=(n-1); i>=0; i--)
    {
        for (int j=0; j<n-1; j++)
        {
            if (!( vojnik[i][0]==vojnik[j][0] && vojnik[i][1]==vojnik[j][1]))
                {
                    if (vojnik[i][0]<=vojnik[j][0] && vojnik[i][1]<=vojnik[j][1])
                    dane=true;
                }
            else dane=false;

        }

        if (!dane)
        {
            naFrontu++;
            dane=false;
        }
    }

    cout << naFrontu;

    return 0;
}
