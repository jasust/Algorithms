#include <cstdio>
#define MAXN		100001

typedef long long llong;

struct pile {
	llong pos, count;
} P[MAXN];
llong N, X;

#define abs(x)			((x)<0?-(x):(x))

llong Rtime, Rcount;
enum direction {
	dleft,
	dright
} dir;

int main()
{
	scanf("%lld%lld", &N, &X);

	int first = -1;
	llong total = 0;
	for (int i = 0; i < N; ++i) {
		scanf("%lld%lld", &P[i].pos, &P[i].count);
		total += P[i].count;
		if (first == -1 && P[i].pos > X)
			first = i;
	}

	Rtime += P[first].pos - X;
	//P[first].count--;
	dir = dleft;
	
	int left = first - 1 /* TODO */, right = first;
	while (true) {
		int mini, maxi;
		if (P[left].count < P[right].count) 
			mini = left, maxi = right;
		else
			mini = right, maxi = left;

		Rcount += P[mini].count * 2 + (mini == right ? 0 : 1);
		P[maxi].count -= P[mini].count;
		//printf("mini is %d, left.c %lld, right.c %lld,right %d\n", mini,P[left].count,P[right].count,right);
		//printf("Rtime before is %lld\n", Rtime);
		Rtime += abs(P[mini].pos - P[maxi].pos) * (mini == left ? 2 * P[mini].count : 2 * P[mini].count - 1);
		P[mini].count = 0;
		//printf("Rtime after is %lld\n", Rtime);
		if (mini == left) {
          	if (left < 1) {
				break;
			}
                
			Rtime += abs(P[left - 1].pos - P[right].pos);
			--left;
		} else if (mini == right) {
			if (right >= N - 1) {
				break;
			}
			Rtime += abs(P[right + 1].pos - P[left].pos);
			
			++right;

		}
	}

    llong totalleft = 0;
    for (int i = 0; i < N; ++i) {
        totalleft += P[i].count;
    }
    
	printf("%lld\n%lld\n", Rcount, Rtime);
	//char s[64];
	//scanf("%s",s);

	return 0;
}
