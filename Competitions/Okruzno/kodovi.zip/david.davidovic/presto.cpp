#include <cstdio>
#include <vector>
#include <algorithm>

#define MAXN                300
#define MAXM                300

using namespace std;

struct elem {
       int idx, height;
       const bool operator< (const elem& other) const {
            return (height == other.height ? idx < other.idx : height < other.height);
       }
};

struct height_comp {
       const bool operator() (const elem& a, const elem& b) const {
             return a.height < b.height;      
       }
             };
             
struct index_comp {
       const bool operator() (const elem& a, const elem& b) const {
             return a.idx < b.idx;      
       }
             };
             
elem rows[MAXN][MAXM], cols[MAXM][MAXN];

int N, M;

int manjih_od(int V, elem* ptr, int L)
{
    elem dummy;
    dummy.height = V;
    elem* lb = lower_bound(ptr, ptr + L, dummy, height_comp());
    return lb - ptr;
}

int vecih_od(int V, elem* ptr, int L)
{
    elem dummy;
    dummy.height = V;
    elem* ub = upper_bound(ptr, ptr + L, dummy, height_comp());
    return L - (ub - ptr);
}

elem* nadji(elem &e, elem* ptr, int L)
{
      int l = 0, r = L - 1;
      while (l <= r) {
            int mid = (l + r) / 2;
            elem &emt = ptr[mid];
            if (e.idx == emt.idx && e.height == emt.height) {
                      return ptr+mid;
                      }else if (e<emt){
                   r = mid - 1;       
            } else {
                                       l = mid + 1;
                   }
            
      }
      return 0;
}
      

int main()
{
    scanf("%d%d", &N, &M);
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < M; ++j) {
            
            int h;
            scanf("%d", &h);
            
            elem e;
            e.idx = j;
            e.height = h;
            rows[i][j] = e;
            
            e.idx = i;
            cols[j][i] = e;    
        }
    }    
    
    for (int i = 0; i < N; ++i) {
        sort(rows[i], rows[i] + M);
    }
    
    for (int j = 0; j < M; ++j) {
        sort(cols[j], cols[j] + N);
    }
    
    /*for (int i = 0; i < N; ++i) {
        printf("(%d %d) ", cols[3][i].idx, cols[3][i].height);
    }printf("\n");*/
        
    int minmoves = -1, besti, bestj;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < M; ++j) {
            int manjih = manjih_od(rows[i][j].height, rows[i], M),
                vecih =  vecih_od(rows[i][j].height, cols[rows[i][j].idx], N),
                moves = manjih + vecih;
                
            if (minmoves == -1 || moves < minmoves) {
               minmoves = moves;
               besti = i;
               bestj = rows[i][j].idx;
            }
            //printf("(%d,%d):%d in %d moves (%d row %d col)\n", i, rows[i][j].idx, rows[i][j].height, moves, manjih, vecih);
        }
  //      printf("\n");
    }
    
    printf("%d\n", minmoves);
    //char s[65];
//scanf("%s",s);
    return 0;
        
}

