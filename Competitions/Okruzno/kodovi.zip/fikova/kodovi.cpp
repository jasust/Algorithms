#include <iostream>

using namespace std;

int main()
{
    int n,x;
    cin>>n>>x;
    long long int p[n],h[n],s=0,s1=0,br=0,k1,br1=0;
    bool g=true;
    for(int i=0;i<n;i++)
    {
        cin>>p[i]>>h[i];
        if(p[i]>=x&&g==true)
        {
            g=false;
            k1=i;
        }
        if(p[i]>=x)
        {
            s1+=h[i];
        }
        else
        {
            s+=h[i];
        }
    }
    if(g==true)
    {
        cout<<0<<"\n"<<0;
        return 0;
    }
    if(s1>=s+1)
    {
        for(int i=0;i<k1;i++)
        {
            br+=((x-p[i])*2)*h[i];
        }
        for(int i=k1;i<n;i++)
        {
            if(br1+h[i]<s+1)
            {
                br+=((p[i]-x)*2)*h[i];
                br1+=h[i];
            }
            else
            {
                br+=((p[i]-x)*2)*(s+1-br1)-p[i]+x;
                break;
            }
        }
        cout<<2*s+1<<"\n"<<br;
        return 0;
    }
    else
    {
        for(int i=k1;i<n;i++)
        {
            br+=((p[i]-x)*2)*h[i];
        }
        for(int i=k1-1;i>=0;i--)
        {
            if(br1+h[i]<s1)
            {
                br+=((p[i]-x)*2)*h[i];
                br1+=h[i];
            }
            else
            {
                br+=((x-p[i])*2)*(s1-br1)-x+p[i];
                break;
            }
        }
        cout<<2*s1<<"\n"<<br;
    }
    return 0;
}
