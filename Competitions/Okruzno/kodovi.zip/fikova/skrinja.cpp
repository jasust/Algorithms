#include <iostream>

using namespace std;
void kaka(int min,int max,int n,int k)
{

}
int main()
{
    int n,k;
    cin>>n>>k;
    int a[n],a1[n],b[k],q[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    if(k>n)
    {
        for(int i=0;i<n;i++)
        {
        a1[i]=i;
        b[i]=a[i];
        }
        for(int i=n;i<k;i++)
        {
        b[i]=0;
        }
    }
    else
    {
        for(int i=0;i<k;i++)
        {
            a1[i]=i;
            b[i]=a[i];
        }
        for(int i=k;i<n;i++)
        {
            a1[i]=k-1;
            b[k-1]+=a[i];
        }
    }
    for(int i=0;i<n;i++)
    {
        q[i]=a1[i];
    }
    bool g=true,t1=true,k2=true,t=true;
    long long int min, max,minmin;
    int kmax,kmin,amin,j;
    int w;
    while(g)
    {
        min=b[0];
        max=b[0];
        kmax=0;
        kmin=0;
        for(int i=1;i<k;i++)
        {
            if(b[i]<min)
            {
                min=b[i];
                kmin=i;
            }
            else if(b[i]>max)
            {
                max=b[i];
                kmax=i;
            }
        }
        if(t1==true)
        {
            minmin=max-min;
            t1=false;
        }
        else
        {
            if(minmin>max-min)
            {
                minmin=max-min;

                for(int i=0;i<n;i++)
                {
                    q[i]=a1[i];
                }
            }
            else if(minmin==max-min)
            {

                k2=true;
                for(int i=0;i<n;i++)
                {
                    if(q[i]!=a1[i])
                    {
                        k2=false;
                    }
                }
                if(k2==true)
                {
                    break;
                }
            }
        }
        t=true;
        for(int i=0;i<n;i++)
        {
            if(a1[i]==kmax&&t==true)
            {
                amin=a[i];
                j=i;
                t=false;
            }
            else if(a1[i]==kmax&&a[i]<amin)
            {
                amin=a[i];
                j=i;
            }
        }
        a1[j]=kmin;
        b[kmax]-=a[j];
        b[kmin]+=a[j];
    }
    cout<<minmin<<"\n";
    for(int i=0;i<n;i++)
    {
        cout<<a1[i]+1<<" ";
    }
    return 0;
}
