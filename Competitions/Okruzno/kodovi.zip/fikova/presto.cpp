#include <iostream>

using namespace std;

int main()
{
    int n,m;
    cin>>n>>m;
    int a[n][m],b[n][m];
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
    {
        cin>>a[i][j];
    }
    bool g=true;
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
    {
        g=true;
        for(int l=0;l<m;l++)
        {

            for(int k=0;k<n;k++)
            {
                if(a[i][l]<a[k][j])
                {
                    g=false;
                }
            }
        }
        if(g==true)
        {
            cout<<0;
            return 0;
        }
    }
    cout<<1;
    return 0;
}
