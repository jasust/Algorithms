#include<stdio.h>
#include<math.h>
void razmeni(int *a, int *b)
{
    int c;
    c=*a;
    *a=*b;
    *b=c;
}
int main()
{
    int n,s=0,k,i,pv,pm,r,j,l,perica,min,max,k1;
    scanf("%d%d",&n,&k);
    int niz[n],uci[n],p[n],niz1[n],per[k];
    k1=k;
    for(i=0;i<n;i++)
    {  scanf("%d",&niz[i]);
       s+=niz[i];
       p[i]=niz[i];
       niz1[i]=niz[i];
    }
    min=s; max=0;
    float x=float(s)/float(k);
    pv=ceil(x);
    pm=floor(x);
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
          if(p[i]<p[j]) razmeni(&p[i],&p[j]);
    i=0;
    while (p[i]>=pv)
    {
        for(j=0;niz[j]!=p[i];j++);
        uci[j]=i+1;
        s-=niz[j];
        niz[j]=0;
        p[i]=0;
        k--;
        i++;
        x=float(s)/float(k);
        pv=ceil(x);
        pm=floor(x);
    }
    l=0; perica=i+1;
    while(p[l]==0) l++;
    j=l+1;
    while(p[l]+p[j]>pv) j++;
    if (p[l]+p[j]==pv || p[l]+p[j]==pm)
    {
      for(i=0;niz[i]!=p[l];i++);
        uci[i]=perica;
        s-=niz[i];
        niz[i]=0;
        p[l]=0;
        for(i=0;niz[i]!=p[j];i++);
        uci[i]=perica;
        s-=niz[i];
        niz[i]=0;
        p[j]=0;
        k--;
        x=float(s)/float(k);
        pv=ceil(x);
        pm=floor(x);
        perica++;

    }
    if (k==1)
    {
        i++;
        for(j=0;j<n;j++)
            if(niz[j]!=0) uci[j]=perica;

    }
    for(i=0;i<k1;i++) per[i]=0;
    for(i=0;i<n;i++)
       per[uci[i]-1]+=niz1[i];
    for(i=0;i<k1;i++)
    {
        if(per[i]>max) max=per[i];
        if(per[i]<min) min=per[i];
    }
    l=max-min;
    printf("%d\n",l);
    for (i=0;i<n;i++) printf("%d ",uci[i]);

    return 0;
}
