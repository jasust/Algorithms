#include<stdio.h>
struct pom
{
    int r;
    int k;
};
void razmeni(int *a, int *b)
{
    int c;
    c=*a;
    *a=*b;
    *b=c;
}
int main()
{
    int n,m,i,j;
    scanf("%d%d",&n,&m);
    int a[n][m],b[n][m];
    struct pom c[n][m];
    for (i=0;i<n;i++)
        for(j=0;j<m;j++)
          {scanf("%d",&a[i][j]);
          b[i][j]=a[i][j];
          }
     for(i=0;i<n;i++)
        for(j=0;j<m-1;j++)
        for(l=j+1;l<m;l++)
        if (b[i][j]>b[i][l]) razmeni(&b[i][j],&b[i][l]);



    return 0;
}
