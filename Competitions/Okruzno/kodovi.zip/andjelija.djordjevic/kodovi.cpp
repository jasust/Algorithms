#include<stdio.h>
struct gomila
{
    long long p;
    long long h;
};
int main()
{
    long long n,x,i,t=0,k=0;
    bool p=true;
    scanf("%lld%lld",&n,&x);
    struct gomila niz[n];
    for(i=0;i<n;i++) scanf("%lld%lld",&niz[i].p,&niz[i].h);
    i=0;
    while(x>niz[i].p && i<n) i++;
    if (i==n)
    {
        t=0; k=0;
    }
    else

        while (p)
        {
            while(niz[i].h==0 && i<n) i++;
            if (i==n) p=false;
            else
            {
                t+=niz[i].p-x;
                k++;
                niz[i].h--;
                x=niz[i].p;
                i--;
                while(niz[i].h==0 && i>=0) i--;
                if (i<0) p=false;
                else
                {
                    t+=x-niz[i].p;
                    k++;
                    niz[i].h--;
                    x=niz[i].p;
                    i++;
                }
            }

        }
        printf("%lld\n%lld",k,t);



    return 0;
}
