#include <cstdio>

using namespace std;

int main()
{
    int n,x,i,j,k=0,kod,smer=-1,pom,maxx,minn,levi=0,desni=0;
    long long vreme=0;
    int p[100005], h[100005];

    scanf("%d%d",&n,&x);
    for(i=1;i<=n;i++){
        scanf("%d%d",p+i,h+i);
        if (p[i]<x)k=i;
    }
    if (k==0) printf("1\n%d",p[1]-x); else{
    for(i=1;i<=k;i++){
        levi+=h[i];
    }
    for(i=k+1;i<=n;i++){
        desni+=h[i];
    }
    if(levi<desni) kod=2*levi+1; else kod=2*desni;

    i=k; j=k+1; vreme+=p[j]-x; h[j]--;
    while(i>=1 && j<=n){
        if (h[i]>h[j]) {maxx=i; minn=j;} else {maxx=j; minn=i;}
        if (h[i]==h[j] && smer==1){maxx=i; minn=j;}else if (h[i]==h[j] && smer==-1){maxx=j; minn=i;}
        if ((smer==1 && maxx==j)||(smer==-1 && maxx==i)){
                vreme+=(2*h[minn]+1)*(p[j]-p[i]);
                smer=-smer;
                pom=1;
        }
        else vreme+=h[minn]*2*(p[j]-p[i]);
        if (h[i]==h[j]){
            h[i]=0;
            h[j]=0;
            i--; j++;
            pom=0;
        }
        else{
            h[maxx]=h[maxx]-h[minn]-1;
            h[minn]=0;
            if (minn==i)i--;else j++;
        }
    }
printf("%d%c%lld",kod,'\n',vreme); }
return 0;
}
