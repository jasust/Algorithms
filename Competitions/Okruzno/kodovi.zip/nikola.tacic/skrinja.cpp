#include <cstdio>

using namespace std;

int main()
{
   int i,n,maxx,minn,k,a[15];
   scanf("%d%d",&n,&k);
   for(i=1;i<=n;i++)
        scanf("%d",a+i);

    maxx=a[1]; minn=a[1];
    for (i=1;i<=n;i++){
        if(a[i]>maxx)maxx=a[i];
        if(a[i]<minn)minn=a[i];

    }
    printf("%d\n",maxx-minn);
    if (n==k)for(i=1;i<=n;i++)printf("%d%c",i,i==n?'\n':' ');


    return 0;
}
