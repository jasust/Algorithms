#include <cstdio>

using namespace std;

int main()
{
    int n,m,i,j,k,l,manji,veci,minn,a[305][305],b[305][305];
    scanf("%d%d",&n,&m);
    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
            scanf("%d",&a[i][j]);


    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++){
            manji=0; veci=0;
            for(k=1;k<=n;k++)
                    if (a[i][j]<a[k][j]) manji++;
            for(k=1;k<=m;k++)
                    if (a[i][j]>a[i][k]) veci++;
            b[i][j]=manji+veci;
    }
    minn=b[1][1];
    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
            if(b[i][j]<minn)minn=b[i][j];
    printf("%d",minn);
    return 0;
}
