#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    unsigned long long K,KORAK,CIFRA;
    int a,b,c,Br,*q,*p;

    scanf("%d %d %llu", &a,&b,&K);
    q=malloc(b* sizeof(int));
    p=malloc(a* sizeof(int));
    for(Br=0; Br<a; Br++)
        scanf("%d",&p[Br]);

    Br=0;
    c=b;
    while(b)
    {
        KORAK=pow(a,b-1);
        CIFRA = K / KORAK;
        q[Br]=CIFRA;
        if(KORAK > K)
        {
            q[Br+1] = K-1;
            break;
        }

        K=K-KORAK;
        Br++;
        b--;

    }

    for(Br=0; Br<c; Br++)
    printf("%d ",p[q[Br]]);
    free(p);
    free(q);
    return 0;
}
