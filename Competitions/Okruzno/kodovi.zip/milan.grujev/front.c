#include <stdio.h>
#include <stdlib.h>

typedef struct {int x; int y;} tacke;
int main()
{
    int n, f=0, br, i, j=0, c=1, b;
    tacke *m, *d;
    scanf("%d", &n);
    m=malloc(sizeof(tacke)*n);
    d=malloc(sizeof(tacke)*n);
    for(br=0;br<n;br++)
        scanf("%d %d", &m[br].x, &m[br].y);
    d[0].x=m[0].x;
    d[0].y=m[0].y;
    for(i=1;i<n;i++)
            if(m[i].y>d[0].y)
            {
                d[0].x=m[i].x;
                d[0].y=m[i].y;
                j=i+1;
            }
    while(j<n)
        {
            if(m[j].y>=d[0].y && m[j].x>d[0].x)
            {
                d[0].x=m[j].x;
                d[0].y=m[j].y;
                i=j+1;
            }
            else
                i=1;
        j++;
        }
    while(i<n)
    {
        if(m[i].x>d[0].x)
        {
            d[c].x=m[i].x;
            d[c].y=m[i].y;
            c++;
        }
    i++;
    }
    for(i=1;i<c;i++)
        for(j=2;j<c;j++)
            if(d[j].y>=d[i].y)
            {
                d[i].x=d[j].x;
                d[i].y=d[j].y;
                d[j].x=-1;
                d[j].y=-1;
                continue;
            }
    if(d[c].x==d[c-1].x && d[c].y<d[c-1].y)
        {
            d[c].x=-1;
            d[c].y=-1;
        }
    for(i=0;i<=c;i++)
    {
        if(d[i].x>=0 && d[i].y>=0)
            f++;
    }
    for(j=0;j<c;j++)
    {
        if(d[j].x>0)
            b=j;

    }
    if(d[b].x==m[n-1].x && d[b].y>m[n-1].y)
        f--;

    printf("%d",f);
    free(d);
    free(m);
    return 0;
}
