#include <stdio.h>
#include <stdlib.h>
int DoleDo(char a[][500],int n, int m , int yt, int xt)
{
    int i;
    for(i=yt;i<n;i++)
        if(a[i][xt]=='#') return i-1;
    return n-1;
}
int GoreDo(char a[][500],int n, int m , int yt, int xt)
{
    int i;
    for(i=yt;i>-1;i--)
        if(a[i][xt]=='#') return i+1;
    return 0;
}
int DesnoDo(char a[][500],int n, int m , int yt, int xt)
{
    int i;
    for(i=xt;i<m;i++)
        if(a[yt][i]=='#') return i-1;
    return n-1;
}
int LevoDo(char a[][500],int n, int m , int yt, int xt)
{
    int i;
    for(i=xt;i>0;i--)
        if(a[yt][i]=='#') return i+1;
    return 0;
}



int main()
{
    char a[500][500];
    int n,m,sm=4,x,y,i,j;
    unsigned long long k;

    scanf("%d %d",&n,&m);
    scanf("%d %d",&y,&x);
    scanf("%llu",&k);
    x--;
    y--;
    for(i=0;i<n;i++)
            scanf("%s",a[i]);

    y=DoleDo(a,n,m,y,x);
    k--;
    while(k)
    {
        sm--;
        if(sm==0) sm=4;
        switch( sm )
        {
        case 1:
            x=LevoDo(a,n,m,y,x);
            break;
        case 2:
            y=GoreDo(a,n,m,y,x);
            break;
        case 3:
            x=DesnoDo(a,n,m,y,x);
            break;
        case 4:
            y=DoleDo(a,n,m,y,x);
            break;
        }
        k--;
    }


    printf("%d %d",y+1,x+1);
    return 0;
}
