#include <cstdio>
#include <iostream>
#include <algorithm>


using namespace std;
int main()
{
    int n,x;
    int pos[100001];
    int num[100001];
    int dir=1; int*p,*pp; bool flag=false;
    long long s=0;
    long long t=0,pt;
    scanf("%d%d",&n,&x);
    int curx=x;
    for(int i=0;i<n;i++)scanf("%d%d",&pos[i],&num[i]);
    while (1)
    {
          pt=0; 
          if(flag)break;
          if(dir>0)
          { 
          
            p = lower_bound(pos,pos+n,curx+1);
            pt += *p-curx;
            if(p<pos || (p==pos && num[p-pos]<=-1) || (p==pos+n-1 && num[p-pos]<=-1) || (p>=pos+n)) {flag=true;break;}
          
            while( num[p-pos]<=0 )
            {
                   pp = p;
                   p = lower_bound(pos,pos+n,*p+1);
                   if(p<pos || (p==pos && num[p-pos]<=-1)|| (p==pos+n-1 && num[p-pos]<=-1) || (p>=pos+n)) {flag=true;break;}
                   pt += *p - *pp;
                   
            }  
          
            if(!flag)  { t+=pt; curx = *p; num[p-pos]--; dir=-1; s++;}
            else {break; } 
        
          }
         
          else
          {   
             
              p = lower_bound(pos,pos+n,curx-1)-1;
              
              if(p<pos || (p==pos && num[p-pos]<=-1)|| (p==pos+n-1 && num[p-pos]<=-1) || (p>=pos+n)) {flag=true;break;}
              pt += curx-*p;
            
            
            
              while( num[p-pos]<=0 )
              {
                     
                     if(p<pos || (p==pos && num[p-pos]<=-1)|| (p==pos+n-1 && num[p-pos]<=-1) || (p>=pos+n)) {flag=true;break;}
                     pp=p;
                     p = lower_bound(pos,pos+n,*p-1)-1;
                     pt += *pp - *p; 
                    
                    
                     
              }
              
              if( !flag) { t+=pt; curx = *p; num[p-pos]--; dir=1; s++;}
              else {  break; } 
             
          }
    }
    printf("%lld\n%lld\n",s,t);

    
    return 0;   
}
