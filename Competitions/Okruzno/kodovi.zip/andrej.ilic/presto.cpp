#include <cstdio>
#include <iostream>
#include <algorithm>
#include <climits>
#define MAX 301
using namespace std;
int main()
{
    int m , n ,p;
    scanf("%d%d",&n,&m);
    int a [MAX][MAX];
    int ainv [MAX][MAX];
    int orig[MAX][MAX];
    int s=0;
    
    for ( int i=0;i<n; i++)
         for(int j=0;j<m;j++)
         {
            scanf("%d",&orig[i][j]);     
            a[i][j]=orig[i][j];
            ainv[j][i]=orig[i][j];     
         }
    for(int i = 0 ;i<n ; i++) 
    {
         sort(a[i],a[i]+m);
    }
    for(int i = 0 ;i<m ; i++) 
    {
         sort(ainv[i],ainv[i]+n);  
    }
    //////
    /*
    for ( int i=0;i<n; i++){
         for(int j=0;j<m;j++)
         {
            printf("%d ",ainv[i][j]);     
             
         }printf("\n");
         }
       */  
         ////////////
    int minn = INT_MAX,x,y;
    for ( int i=0;i<n; i++)
    {
         for(int j=0;j<m;j++)
         {
         x= ( lower_bound(a[i],a[i]+m,orig[i][j])-a[i] )  + 1 - binary_search(a[i],a[i]+m,orig[i][j])   ;
         y=n-( upper_bound(ainv[j],ainv[j]+n,orig[i][j])-ainv[j]);
         //printf("%d .. %d ",x,y);
             p=  x    +  y;
             
             if(p<minn && p>=0) minn =p;
         }
         
    }
                    
    printf("%d\n",minn);

 return 0;   
}
