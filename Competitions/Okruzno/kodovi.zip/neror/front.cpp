#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<iostream>
#include<algorithm>
using namespace std;

int n,bry,brx,raz1,raz2;
int x[1005],y[1005];

int main () {
 scanf("%d",&n);
 bry=0;
 brx=0;
 for(int i=1;i<=n;i++){
  scanf("%d %d",&x[i],&y[i]);
 raz1=abs(x[i-1]-y[i+1]);
 raz2=abs(y[i+1]-x[i-1]);

 if(raz1>y[i]) bry++;
 if(raz2>x[i]) brx++;
 }

 printf("%d\n",bry+brx+1);
return 0;
}
