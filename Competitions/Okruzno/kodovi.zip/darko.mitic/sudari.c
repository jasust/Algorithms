#include <stdio.h>
#include <stdlib.h>

typedef struct tacka
{
    int y;
    int x;
}Tacka;

char lavirint[500][500];

Tacka pomeriTacku(Tacka D,int x)
{
    switch(x)
    {
        case 1:
            case1:
            if(lavirint[D.y+1][D.x] == '.')
            {
                D.y++;
                goto case1;
            }
            break;
        case 2:
            case2:
            if(lavirint[D.y][D.x+1] == '.')
            {
                D.x++;
                goto case2;
            }
            break;
        case 3:
            case3:
            if(lavirint[D.y-1][D.x] == '.')
            {
                D.y--;
                goto case3;
            }
            break;
        case 4:
            case4:
            if(lavirint[D.y][D.x-1] == '.')
            {
                D.x--;
                goto case4;
            }
            break;
    }

    return D;

}

int main()
{
    //n=y
    //m=x

/*
4 5
2 1
4
...#.
.#...
....#
#....
*/

    int n,m,i,x=1;
    long long k,j;
    Tacka D;
    Tacka temp;

    scanf("%d %d",&n,&m);
    scanf("%d %d",&D.y,&D.x);
    scanf("%lld",&k);

    D.x--;
    D.y--;
    temp.y = D.y;
    temp.x = D.x;

    for(i = 0;i<n;i++)
    {
        scanf("%s",&lavirint[i]);
    }


    while(k>0)
    {
        temp = pomeriTacku(D,x);
        if(D.x == temp.x && D.y == temp.y)
        {
            k--;
            x++;
            if(x == 5)
            {
                x = 1;
            }
        }
        else
        {
            D.x = temp.x;
            D.y = temp.y;
        }

    }
    printf("%d %d", D.y+1,D.x+1);

    return 0;
}
