#include <stdio.h>
#include <stdlib.h>

typedef struct tacka
{
    long x;
    long y;
}Tacka;

int main()
{
    Tacka *Vojnici;
    int n,i,j,brojac=0,ind=0;

    scanf("%d",&n);

    Vojnici = calloc(n,sizeof(Tacka));

    for(i = 0; i<n;i++)
    {
        scanf("%ld",&Vojnici[i].x);
        scanf("%ld",&Vojnici[i].y);
    }

    for(i = 0; i<n;i++)
    {
        ind = 0;
        for(j=i+1;j<n;j++)
        {
            if(Vojnici[i].x == Vojnici[j].x)
            {
                if(Vojnici[i].y < Vojnici[j].y)
                {
                    ind = 1;
                    break;
                }
            }
            else
            {
                if(Vojnici[i].y <= Vojnici[j].y)
                {
                    ind = 1;
                    break;
                }
            }
        }

        if(ind == 0)
        {
            brojac++;
            ind = 0;
        }
    }
    printf("%d",brojac);

    return 0;
}
