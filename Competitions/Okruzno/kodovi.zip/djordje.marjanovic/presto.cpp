#include<iostream>
#define N 294
using namespace std;

struct polje
{
    int x,v;
};

bool cmp(const polje & lhs, const polje & rhs)
{
    return lhs.x < rhs.x;
}

int main()
{
    int n,m,max[N],min[N];
    polje a[N][N],b[N][N],c[N][N];
    polje B[N];
    int res=500;
    cin>>n>>m;
    for(int i=0; i<n; i++)min[i]=1e9;
    for(int j=0; j<m; j++)max[j]=0;
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            cin>>a[i][j].x;
            if(a[i][j].x>max[j])max[j]=a[i][j].x;
            if(a[i][j].x<min[i])min[i]=a[i][j].x;
        }
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            if(a[i][j].x==max[j])a[i][j].v=+1;
            else if(a[i][j].x==min[i])a[i][j].v=-1;
            else a[i][j].v=0;
        }
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            B[j]=a[i][j];
        }
        sort(B, B+m, cmp);
        for(int j=0; j<m; j++)
        {
            b[i][j]=B[j];
        }
    }
    for(int j=0; j<m; j++)
    {
        for(int i=0; i<n; i++)
        {
            B[i]=a[i][j];
        }
        sort(B, B+n,cmp);
        for(int i=0; i<n; i++)
        {
            c[i][j]=B[i];
        }
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            if(b[i][j].v==+1)
            {
                if(j<res)res=j;
            }
        }
    }
    for(int j=0; j<m; j++)
    {
        for(int i=n-1; i>=0; i--)
        {
            if(c[i][j].v==-1)
            {
                if(n-1-i<res)res=n-i;
            }
        }
    }
    cout<<res;
    return 0;
}
