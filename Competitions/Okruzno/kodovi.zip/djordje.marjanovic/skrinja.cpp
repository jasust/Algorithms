#include<iostream>
#define N 13

using namespace std;

struct per
{
    int x,i,p;
};

bool cmp(const per & lhs, const per & rhs)
{
    return lhs.x > rhs.x;
}

bool cmpi(const per & lhs, const per & rhs)
{
    return lhs.i < rhs.i;
}

int main()
{
    int n,k,s[N],res[N];
    per a[N];
    cin>>n>>k;
    for(int i=0; i<n; i++)
    {
        cin>>a[i].x;
        a[i].i=i;
    }
    sort(a, a+n, cmp);
    for(int i=0; i<k; i++)
    {
        s[i]=a[i].x;
        a[i].p=i;
    }
    for(int i=k; i<n; i++)
    {
        int min=1e8+1;
        int minj=13;
        for(int j=0; j<k; j++)
        {
            if(s[j]<min)
            {
                min=s[j];
                minj=j;
            }
        }
        s[minj]+=a[i].x;
        a[i].p=minj;
    }
    int min(13e8+1),max(0);
    for(int i=0; i<k; i++)
    {
        if(s[i]>max)max=s[i];
        if(s[i]<min)min=s[i];
    }
    sort(a,a+n,cmpi);
    cout<<max-min<<endl;
    for(int i=0; i<n; i++)cout<<a[i].p+1<<" ";
    return 0;
}
	