#include<iostream>
#include<vector>
#define N 100000

using namespace std;

struct pair
{
    int p,h;
}

int main()
{
    int n, x, xi(0), s, t, dir(+1);
    vector<pair> k[N];
    cin>>n>>x;
    for(int i=0; i<n; i++)
    {
        pair tmp;
        tmp.p=0;tmp.h=0;
        k.push_back(null);
        cin>>k[i].p>>k[i].h;
        if(k[i].p>x && xi==0)xi=i;
    }
    x=k[xi].p;
    k[xi].p--;
    s++;
    while(1/*uslov...*/)
    {
        if(dir==+1)
        {
            if(k[xi].h==0)
            {
                xi++;
                x=k[xi].p;
                s++;
                k[xi].h--;
            }
            else
            {
                if(k[xi].h>=k[xi+1].h)
                {
                    s+=k[xi+1].h*2;
                    k[xi].h-=k[xi+1].h;
                    k[xi+1].h=0;
                }
                else
                {
                    s+=h[xi]*2;
                    x=p[xi+1];
                    h[xi+1]-=h[xi];
                    h[xi]=0;
                }
            }
        }
        else
        {
        }
    }
	return 0;
}
