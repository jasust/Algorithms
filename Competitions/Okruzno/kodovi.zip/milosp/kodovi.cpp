#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

long long   p[100005];
long long   h[100005];
long long   n,
            x,
            posL = 0,
            posR = 0,    // p[pos-1] < x < p[pos]
            t = 0,
            src = 0,
            minSrc;
bool    dir = 1;    // 1 - right, 0 - left

int main() {
    scanf("%lld %lld", &n, &x);

    for (long long i=0; i<n ; i++){
        scanf("%lld %lld", p+i, h+i);
        if (x > p[i]) {
            posR = i+1;
        }
    }
    posL = posR-1;


    t += p[posR] - x;
    src++;
    h[posR]--;
    dir = !dir;

    while ((posL >= 0) && (posR < n)) {
        if (dir && (h[posL] == 0)) {
            t += p[posR] - p[posL];
            src++;
            h[posR]--;
            posL--;
            dir = !dir;
        }
        else if ((dir == 0) && (h[posR] == 0)) {
            t += p[posR] - p[posL];
            src++;
            h[posL]--;
            posR++;
            dir = !dir;
        }
        else {
            minSrc = min(h[posL], h[posR]);
            src += 2*minSrc;
            h[posL] -= minSrc;
            h[posR] -= minSrc;

            t += 2*minSrc*(p[posR]-p[posL]);

            if (dir) {
                if (h[posL]) {
                    posR++;
                }
            }
            else {
                if (h[posR]) {
                    posL--;
                }
            }
        }
    }

    printf("%lld\n%lld", src, t);
    return 0;

}
