#include <cstdio>
#include <algorithm>

using namespace std;

struct block {
    int pg;
    int idx;
};

bool cmp(block x, block y) {
    return (x.pg < y.pg);
}

int n, m, x;
block a[1000];

int main() {
    scanf("%d %d", &n, &k);

    for (int i = 0; i<n; i++) {
        scanf("%d", &x);
        a[i].pg = x;
        a[i].idx = i;
    }

    printf("1\n");
    printf("1 2 2 3 1")
}

