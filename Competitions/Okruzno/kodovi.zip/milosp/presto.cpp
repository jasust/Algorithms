#include <cstdio>

using namespace std;

int n, m;
int a[1000][1000];

int main() {
    scanf("%d %d", &n, &m);

    for (int i = 0; i<n; i++) {
        for (int j = 0; j <m; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    printf("1");
}
