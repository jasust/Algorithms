#include <cstdio>

using namespace std;

int main()
{
    unsigned long long n;
    scanf("%llu", &n);

    unsigned long long * Xi = new unsigned long long[n];
    unsigned long long * Yi = new unsigned long long[n];

    for (unsigned long long i = 0; i < n; i++)
        scanf("%llu %llu", &Xi[i], &Yi[i]);

    unsigned long long f = 0;

    for (unsigned long long i = 0; i < n; i++)
    {
        for (unsigned long long x = 0; x < n; x++)
        {
            if (Xi[i] <= Xi[x] && Yi[i] <= Yi[x] && i != x)
                break;
            if (x == (n - 1))
                f++;
        }
    }

    printf("%llu", f);

    return 0;
}
