#include <cstdio>

using namespace std;

int main()
{
    unsigned int n, m, x, y;
    scanf("%d %d", &n, &m);
    scanf("%d %d", &y, &x);

    unsigned long long k;
    scanf("%llu", &k);

    char matrica[n][m];

    long long _index1, _index2;

    for (_index1 = 0; _index1 < n; _index1++)
        for (_index2 = 0; _index2 < m; _index2++)
            scanf("\n%c", &matrica[_index2][_index1]);

    x--;
    y--;

    int smer = 0;

    for (_index1 = 0; _index1 < k; _index1++)
    {
        switch(smer)
        {
            case 0:
            {
                for (_index2 = y; _index2 <= n; _index2++)
                {
                    if (matrica[x][_index2] == '#')
                    {
                        y = _index2-1;
                        smer = 1;
                        break;
                    }
                    if (_index2 == n)
                    {
                        y = _index2-1;
                        smer = 1;
                    }
                }
                break;
            }
            case 1:
            {
                for (_index2 = x; _index2 <= m; _index2++)
                {
                    if (matrica[_index2][y] == '#')
                    {
                        x = _index2-1;
                        smer = 2;
                        break;
                    }
                    if (_index2 == m)
                    {
                        x = _index2-1;
                        smer = 2;
                    }
                }
                break;
            }
            case 2:
            {
                for (_index2 = y; _index2 >= -1; _index2--)
                {
                    if (matrica[x][_index2] == '#')
                    {
                        y = _index2+1;
                        smer = 3;
                        break;
                    }
                    if (_index2 == -1)
                    {
                        y = 0;
                        smer = 3;
                    }
                }
                break;
            }
            case 3:
            {
                for (_index2 = x; _index2 >= -1; _index2--)
                {
                    if (matrica[_index2][y] == '#')
                    {
                        x = _index2+1;
                        smer = 0;
                        break;
                    }
                    if (_index2 == -1)
                    {
                        x = 0;
                        smer = 0;
                    }
                }
                break;
            }
        }
    }

    y++; x++;

    printf("%d %d", y, x);

    return 0;
}
