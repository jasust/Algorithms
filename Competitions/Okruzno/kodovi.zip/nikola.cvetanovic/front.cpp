#include <cstdlib>
#include <iostream>

using namespace std;

long int x[1000000],y[1000000];

int main()
{
    int n,f=0,j=0,s=0;

    scanf("%d",&n);

    for(int i=0; i<n; i++)
    scanf("%ld%ld",&x[i],&y[i]);

    for(int i=0; i<n; i++)
     {       for(j=0; j<n; j++)
            {
            if(y[j]>=y[i] && x[j]>x[i])
            {
            s=0;
            break;
            }
            s++;
            }
            s=s/j;
            f+=s;
}


    printf("%d",f);

    return EXIT_SUCCESS;
}
