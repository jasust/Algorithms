#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;
int n,x,poz[100010],vis[100010];
int main(){
    scanf("%d %d",&n,&x);
    int pozicija=0;
    long long sol=0;
    long long sek=0;
    for(int i=1;i<=n;i++){
        scanf("%d %d",&poz[i],&vis[i]);
        if((x<poz[i])&&(pozicija==0))pozicija=i;
    }
        if(x<poz[1]){
            printf("1\n");
            printf("%d\n",poz[1]-x);
            return 0;
        }
    int left=pozicija-1;
    int right=pozicija;
    sol++;
    sek+=poz[right]-x;
    vis[right]--;
    while((vis[1]!=0)&&(vis[n]!=0)){
        int tmp=min(vis[left],vis[right]);
        //jednako
        if(vis[left]==vis[right]){
            sol+=2*tmp;
            if(pozicija==left){
                sek+=2*tmp*(poz[right]-poz[left]);
                vis[left]=0;
                vis[right]=0;
                left--;
                if(left>=1){sek+=poz[left+1]-poz[left]; sol++; vis[left]--;}
                pozicija=left;
                right++;
            }else
            if(pozicija==right){
                sek+=2*tmp*(poz[right]-poz[left]);
                vis[left]=0;
                vis[right]=0;
                right++;
                if(right<=n){sek+=poz[right]-poz[right-1]; sol++; vis[right]--;}
                pozicija=right;
                left--;
            }
        }
        //u minimumu
        if(vis[pozicija]==tmp){
            sol+=tmp*2+1;
            if(pozicija==left){
                sek+=(tmp*2+1)*(poz[right]-poz[left]);
                vis[left]-=tmp;
                vis[right]-=tmp;
                vis[right]--;
                left--;
                pozicija=right;
            }else
            if(pozicija==right){
                sek+=(tmp*2+1)*(poz[right]-poz[left]);
                vis[left]-=tmp;
                vis[left]--;
                vis[right]-=tmp;
                right++;
                pozicija=left;
            }
        }
        //u maximumu
        else{
            sol+=tmp*2;
            if(pozicija==left){
                sek+=(tmp*2)*(poz[right]-poz[left]);
                vis[left]-=tmp;
                vis[right]-=tmp;
                right++;
            }else
            if(pozicija==right){
                sek+=(tmp*2)*(poz[right]-poz[left]);
                vis[left]-=tmp;
                vis[right]-=tmp;
                left--;
            }
        }
    }
    printf("%lld\n",sol);
    printf("%lld\n",sek);
    return 0;
}

