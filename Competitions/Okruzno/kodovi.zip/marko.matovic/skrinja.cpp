#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;
int i,j,n,k,b[20],a[20],sol[20],per[20],minn,indmin;
int main(){
    scanf("%d %d",&n,&k);
    for(i=1;i<=n;i++){
        scanf("%d",&a[i]);
        sol[i]=0;
        b[i]=a[i];
    }
    sort(a+1,a+n+1);
    //specijalni slucajevi
    if(k>n){
        printf("%d\n",a[n]);
        for(i=1;i<=n;i++)printf("%d ",i);
        return 0;
    }
    if(k==n){
        printf("%d\n",a[n]-a[1]);
        for(i=1;i<=n;i++)printf("%d ",i);
        return 0;
    }
    //specijalni slucajevi
    for(i=1;i<=k;i++){
        per[i]=a[n-i+1];
        int tmp=a[n-i+1];
        for(j=1;j<=n;j++)if(b[j]==tmp){
            b[j]=0;
            sol[j]=i;
            break;
        }
    }
    int cnt=n-k;
    while(cnt>0){
        minn=per[1];
        indmin=1;
        for(i=2;i<=k;i++)if(per[i]<minn){
            minn=per[i];
            indmin=i;
        }
        per[indmin]+=a[cnt];
        for(i=1;i<=n;i++)if(b[i]==a[cnt]){
            b[i]=0;
            sol[i]=indmin;
        }
        cnt--;
    }
    sort(per+1,per+k+1);
    printf("%d\n",per[k]-per[1]);
    for(i=1;i<=n;i++)printf("%d ",sol[i]);
    return 0;
}

