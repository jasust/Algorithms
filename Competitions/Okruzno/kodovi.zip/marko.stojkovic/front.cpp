#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    long x;
    cin >> x;

    long a;
    long b;
    int arr[x];
    int arr2[x];
    for (long i =0;i<x;i++){
       cin  >> arr[i];
      cin  >> arr2[i];
    }


    long r=0;
    for (long i =0;i<x;i++){
      if ((arr[i]<=arr2[i+2])&&(arr[i+1]<=arr2[i+3])){
        r++;
      }
    }
    cout << r;

    return 0;
}
