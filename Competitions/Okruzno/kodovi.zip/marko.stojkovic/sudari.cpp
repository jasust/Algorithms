#include <iostream>
#include <string>
using namespace std;
int z;
int dplus(string test){

   while (test[z]!='#'){

    z++;
    }
    return z;
}

int main()
{
    int a;
    int b;
    int c;
    int d;
    int e;

    cin >> a;
    cin >> b;
    cin >> c;
    cin >> d;
    cin >> e;
    string test;
    string arr[a];

    for (long i=0;i<a;i++){
        cin >> arr[i];
    }

    d -=1;
    while (e!=0){
       test = arr[c];
       if (test[d]!='#'){
         c++;
       }else{
         e-=1;
         c-=1;
         z=d;
         dplus(test);
         d=z;
       }
    }

    cout << c;
    cout << " ";
    cout << d;
    return 0;
}

