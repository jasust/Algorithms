#include <cstdio>

int main()
{
    int n,x[100000],y[100000],i,j,s=0,t;
    bool p;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d%d",&x[i],&y[i]);
    }
    for(i=0;i<n;i++)
    {
        t=0;
        p=1;
        if(i>0)
        {
        j=i-1;
        while(x[j]==x[i])
        {
            j-=1;
            t++;
        }
        }
        for(j=i-t;j<n;j++)
        {
            if(y[j]>=y[i]&&i!=j)
            {
              p=0;
              break;
            }
        }
        if(p)
        {
            s+=1;
        }
    }
    printf("%d",s);
    return 0;
}
