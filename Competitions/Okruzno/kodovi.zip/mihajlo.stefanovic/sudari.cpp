#include <cstdio>

int main()
{
    char c[500][500],d='j',p;
    int n,m,pn,pm;
    long long k;
    scanf("%d%d%d%d%lld",&n,&m,&pn,&pm,&k);
    pn-=1;
    pm-=1;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
            scanf("\n%c",&c[i][j]);
    }
    while(k--)
    {
        p=1;
        if(d=='j')
        {
            while(c[pn][pm]!='#')
            {
                if(pn==n-1)
                {
                    p=0;
                    break;
                }
                else pn++;
            }
            d='i';
            if(p) pn-=1;
        }
        else if(d=='i')
        {
            while(c[pn][pm]!='#')
            {
                if(pm==m-1)
                {
                    p=0;
                    break;
                }
                else pm++;
            }
             d='s';
            if(p) pm-=1;
        }
        else if(d=='s')
        {
            while(c[pn][pm]!='#')
            {
                if(pn==0)
                {
                    p=0;
                    break;
                }
                else pn--;
            }
             d='z';
            if(p) pn+=1;
        }
        else if(d=='z')
        {
            while(c[pn][pm]!='#')
            {
                if(pm==0)
                {
                    p=0;
                    break;
                }
                else pm--;
            }
            d='j';
            if(p) pm+=1;
        }
    }
    printf("%d %d",pn+1,pm+1);
    return 0;
}
