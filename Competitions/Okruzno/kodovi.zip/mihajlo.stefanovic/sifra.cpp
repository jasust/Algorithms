#include <cstdio>

int main()
{
    int n,m,a[100000],b[100000],t=1,n1,s;
    long long k;
    scanf("%d%d%lld",&n,&m,&k);
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(int i=0;i<m;i++)
        b[i]=a[0];
    k-=1;
    while(k)
    {
        s=0;
        t=1;
        while(t<=k)
        {
            t*=n;
            s+=1;
        }
        t/=n;
        n1=n;
        while(n1--!=1)
            if(t*n1<=k)
        {
            t*=n1;
            break;
        }
        k-=t;
        b[m-s]=a[n1];
    }
    for(int i=0;i<m;i++)
        printf("%d ",b[i]);
    return 0;
}
