#include<stdio.h>
int main()
{
    long long n,i,p[100001],h[100001],x,r,pre,d,t,b;
    scanf("%lld%lld",&n,&x);
    for (i=1;i<=n;i++)
    scanf("%lld%lld",&p[i],&h[i]);
    i=0;
    t=1;
    b=0;
    r=0;
    if (x<p[1]) {b=1;t=p[1]-x;}
    else
    {
    while (t)
    {
     i=i+1;
     if ((x>p[i]) && (x<p[i+1])) t=0;
    }
    r=i;
    }
    pre=x;
    d=1;
    while ((r<=n) && (r>=1))
    {
    if (d==1)
    {
    r=r+1;
    while ((h[r]==0) && (r<=n) && (r>=1))
     {
      r=r+1;
     }
    }
    if (d==0)
    {
    r=r-1;
    while ((h[r]==0) && (r<=n) && (r>=1))
    {
    r=r-1;
    }
    }
    if ((r!=0) && (r!=n+1))
    {
    h[r]=h[r]-1;
    b=b+1;
    if (d==1) t=t+(p[r]-pre); else t=t+(pre-p[r]);
    if (d==1) d=0; else d=1;
    pre=p[r];
    }
    }
    printf("%lld\n",b);
    printf("%lld",t);
    return(0);
}
