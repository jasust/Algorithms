#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <stdlib.h>
#include <cstring>


using namespace std;

int n;
int uk=0;
long long maxy=0,maxx=0,maxi;
long long xp[1000000];
long long yp[1000000];




int main()
{
    scanf("%d",&n);




    for(int i=0;i<n;i++)
    {
      scanf("%lld%lld",&xp[i],&yp[i]);
      if(maxy<=yp[i])
        {
            if(maxx<=xp[i])
            {maxy=yp[i];
            maxx=xp[i];
            maxi=i;}
        }

    }
    if(n==1)
    {
        printf("1");
    }

 else
    {
    int up=maxi+1;
     while(true)
    {

        if(xp[maxi]==xp[up])
        {
            xp[up]=xp[maxi];
            yp[up]=yp[maxi];
            maxi=up;
            up++;
        }
        else
        {
            break;
        }
    }

    uk++;

    while(maxi!=n-1)
    {


        maxy=0;
        maxx=0;
        for(int i=maxi+1;i<n;i++)
            {
                if(maxy<=yp[i])
                {
                    if(maxx<=xp[i])
                    {
                        maxy=yp[i];
                        maxx=xp[i];
                        maxi=i;
                    }
                }
            }
        int up=maxi+1;
     while(true)
    {


        if(xp[maxi]==xp[up])
        {
            xp[up]=xp[maxi];
            yp[up]=yp[maxi];
            maxi=up;
            up++;
        }
        else
        {
            break;
        }
    }

    uk++;

    }
    printf("%d \n",uk);
    }



    return 0;
}
