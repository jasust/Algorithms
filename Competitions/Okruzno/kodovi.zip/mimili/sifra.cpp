#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <cstring>
#include <stdlib.h>
using namespace std;
long long k,k1=0,k2=0,coef=1;
int n,m;
long long niz[1000000];
int main()
{
    scanf("%d%d%lld",&n,&m,&k);
    long long res[m];
    for(int i=0;i<n;i++)
    {
        scanf("%lld",&niz[i]);
    }
    for(int i=0;i<m;i++)
    {
        k1=k/coef;
        if(k1*coef<k)
        {
            k1++;
        }
        k2=k1%n;
        if(k2==0)
        {
            k2=n;
        }
        res[i]=niz[k2-1];
        coef=coef*n;
    }

    for(int i=m-1;i>=0;i--)
    {
        printf("%lld \n",res[i]);
    }

    return 0;
}
