#include <iostream>

using namespace std;

int main()
{
    int n,x[60002],y[60002],f,i,xt,yt,maxy;
    cin >> n;
    x[0]=-1;
    y[0]=-1;
    for (i=1;i<=n;i++)
    {
        cin >> xt >> yt;
        if (xt>x[i-1])
        {
            x[i]=xt;
            y[i]=yt;
        } else
        {
            i--;
            n--;
            if (yt>y[i]) y[i]=yt;
        }
    }
    f=0;
    maxy=-1;
    for (i=n;i>0;i--)
    {
        if (y[i]>maxy)
        {
            f++;
            maxy=y[i];
        }
    }
    cout << f;
    return 0;
}
