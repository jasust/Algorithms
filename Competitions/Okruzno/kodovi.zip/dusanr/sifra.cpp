#include <iostream>

using namespace std;

int main()
{
    int n,m,a[100002],kom[100002],j;
    long long k,i;
    cin >> n >> m >> k;
    for (j=1;j<=n;j++)
    {
        cin >> a[j];
    }
    for (j=1;j<=m;j++)
    {
        kom[j]=1;
    }
    j=m;
    while (k>1)
    {
        kom[j]=k%n;
        if (kom[j]==0)
        {
            kom[j]=n;
            k=k/n;
        } else
        {
            k=k/n+1;
        }
        j--;
    }
    for (j=1;j<=m;j++)
    {
        cout << a[kom[j]];
        if (j<m) cout << ' ';
    }
    return 0;
}
