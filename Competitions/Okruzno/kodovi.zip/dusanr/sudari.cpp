#include <iostream>

using namespace std;

int main()
{
    int i,j,x,y,n,m,p;
    long long k;
    char lav[502][502];
    cin >> n >> m;
    cin >> y >> x;
    cin >> k;
    for (i=1;i<=n;i++)
    {
        lav[i][0]='#';
        lav[i][m+1]='#';
    }
    for (i=1;i<=m;i++)
    {
        lav[0][i]='#';
        lav[n+1][i]='#';
    }
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m;j++)
        {
            cin >> lav[i][j];
        }
    }
    p=1;
    while (k>0)
    {
        if (p==1)
        {
            while (lav[y+1][x]=='.') y++;
        }
        if (p==2)
        {
            while (lav[y][x+1]=='.') x++;
        }
        if (p==3)
        {
            while (lav[y-1][x]=='.') y--;
        }
        if (p==4)
        {
            while (lav[y][x-1]=='.') x--;
        }
        k--;
        p++;
        if (p==5) p=1;
    }
    cout << y << ' ' << x;
    return 0;
}
