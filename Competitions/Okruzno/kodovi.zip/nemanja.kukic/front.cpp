#include <cstdio>

using namespace std;

int main()
{
    int N, brojac = 0;
    scanf("%d", &N);
    int x[N], y[N];
    for (int i = 0; i < N; ++i) {
        scanf("%d %d", &x[i], &y[i]);
    }

    for (int i = 0; i < N; ++i) {
        int trenutni_x = x[i];
        int x_prolazi = 1;
        int trenutni_y = y[i];
        int y_prolazi = 1;

        int k = i+1;
        while (k < N) {
            if (trenutni_x <= x[k]) {
                    if (trenutni_y < y[k]) x_prolazi = 0;
                    break;
            }
            ++k;
        }
        k = i+1;
        while (k < N) {
            if (trenutni_y <= y[k]) {
                    y_prolazi = 0;
                    break;
            }
            ++k;
        }

        if ((x_prolazi == 1) && (y_prolazi == 1))
                ++brojac;

    }

    printf("%d", brojac);
    return 0;
}

