#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

int main()
{
    int N, M;
    long long int K, brojac = 0;
    scanf("%d %d %lld", &N, &M, &K);
    int A[N];
    std::vector<int> tmp;
    for (int i = 0; i < N; ++i) {
        scanf("%d", &A[i]);
    }

    uint64_t prethodna_N_vrednost = N;

    for (int i = (M-1); i > -1; --i ) {
        uint64_t vrednost;
        vrednost = (K % prethodna_N_vrednost)-1;
        prethodna_N_vrednost *= N;
        tmp.push_back(vrednost);
    }

    for (int k = M-1; k > -1; --k) {
                    printf("%d", A[tmp.at(k)]);
                    if (k > 0) printf(" ");
    }

    return 0;
}
