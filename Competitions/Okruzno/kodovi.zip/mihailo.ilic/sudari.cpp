#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;
int x,y;

int main(int argc, char *argv[])
{
    long long k=0,br;
    
    short n,m;
    short p=1;
    cin>>n;
    cin>>m;
    int t[n][m];
    char a;
    cin>>y>>x;
    cin>>br;
    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=m; j++)
        {
            cin>>a;
            if (a=='.') t[i][j]=0; else t[i][j]=1;
            
            
           }     }
          
     while(k<br)
     {
      switch(p)
      {
               case 1:{
                    if(y+1>n){k++;p=2;}
                    else
                    if(t[y+1][x]==1){k++;p=2;}
                    else y++;
                    }break;
                    case 2:{
                    if(x+1>m){k++;p=3;}
                    else
                    if(t[y][x+1]==1){k++;p=3;}
                    else x++;
                    }break;
                    case 3:{
                    if(y-1<1){k++;p=4;}
                    else
                    if(t[y-1][x]==1){k++;p=4;}
                    else y--;
                    }break;
                    case 4:{
                    if(x-1<1){k++;p=0;}
                    else
                    if(t[y][x-1]==1){k++;p=0;}
                    else x--;
                    }break;
               
               
               }       
             
             
             
             }     
    cout<<y<<" "<<x;
    
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
