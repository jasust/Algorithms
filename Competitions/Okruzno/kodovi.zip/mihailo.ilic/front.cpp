#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    
    int n;
    cin>>n;
    int x[n],y[n],br=0,ind=0,maxx=0,maxy=0;
    for (int i=0; i<n; i++)
    {
        cin>>x[i];
        cin>>y[i];
        if (y[i]>maxy)maxy=y[i];   
         if (x[i]>maxx)maxx=x[i];     
    }
    for(int i=0; i<n; i++)
    {
     for (int j=0; j<n; j++)
     {
         
     if (i!=j){
               if(x[i]==x[j]&&y[i]==maxy) ind=1;
               if(x[i]==maxx&&y[i]==maxy)ind=1;
               if (y[i]==y[j]&&x[i]==maxx)ind=1;
               }
               
         
         }if(ind==1)br++;
               ind=0;
            
            }
            cout<<br+1;
    
    
    return 0;
}
