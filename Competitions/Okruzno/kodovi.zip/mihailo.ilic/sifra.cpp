#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;



int main()
{
    int n,m,k;//3,4,37
    cin>>n;
    cin>>m;
    cin>>k;
    int a[n],br=0;
    short p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15;
    p1=p2=p3=p4=p5=p6=p7=p8=p9=p1=p11=p12=p13=p14=p15=0;
    for(int i=0; i<n; i++)
    {
            cin>>a[i];
                   
    }
   
   switch(m)
   {
            case 4:{
   for (int i=0; i<n; i++)
   {
       for(int j=0; j<n; j++)
       {
                   for(int l=0; l<n; l++)
                   {
                           for(int m=0; m<n; m++)
                           {
                                   br++;
                                   if(br==k){printf("%d %d %d %d",a[p1],a[p2],a[p3],a[p4]);return 0;}
                                   p4++;
                                   if(p4>n) p4=0;
                                   
                                   
                                   }
                                   
                                   p3++;
                                   if(p3>n) p3=0;
                           } 
                           
                           p2++;
                           if(p2>n) p2=0;
               }  
               
               p1++;
               if(p1>n) p1=0;  
       
   }}
   case 1:{
        cout<<a[k-1];
        
        
        }
   case 2:{
        for(int i=0; i<n;i++)
        {
                for(int j=0; j<n; j++)
                
                {
                        br++;
                        if(br==k){printf("%d %d",a[p1],a[p2]);return 0;}
                        p2++;
                        if(p2==n) p2=0;
                        }
                
                p1++;
               if(p1==n) p1=0;  
                
                }
        
        case 10:
             {
                 for (int i=0; i<n; i++)
   {
       for(int j=0; j<n; j++)
       {
                   for(int l=0; l<n; l++)
                   {
                           for(int m=0; m<n; m++)
                           {
                                 for(int pet=0; pet<n; pet++)
                                 {
                                       for(int sest=0; sest<n; sest++)
                                 {
                                         for(int sedam=0; sedam<n; sedam++)
                                 {
                                         for(int osam=0; osam<n; osam++)
                                 {
                                         for(int devet=0; devet<n; devet++)
                                 {
                                         for(int deset=0; deset<n; deset++)
                                 {
                                         
                                         br++;
                                   if(br==k){
                           
                           printf("%d %d %d %d %d %d %d %d %d %d",a[p1],a[p2],a[p3],a[p4],a[p5],a[p6],a[p7],a[p8],a[p9],a[p10]);return 0;}
                                         
                                         
                                         p10++;
                                         if(p10>n) p10=0;
                                         }
                                         p9++;
                                         if(p9>n) p9=0;
                                         }
                                         p8++;
                                         if(p8>n) p8=0;
                                         }
                                         p7++;
                                         if(p7>n) p7=0;
                                         }
                                         p6++;
                                         if(p6>n) p6=0;
                                         }  
                                         p5++;
                                         if(p5>n) p5=0;
                                         }
                                   p4++;
                                   if(p4>n) p4=0;
                                   
                                   
                                   }
                                   
                                   p3++;
                                   if(p3>n) p3=0;
                           } 
                           
                           p2++;
                           if(p2>n) p2=0;
               }  
               
               p1++;
               if(p1>n) p1=0;  
       
   }
                 
                 
                 
                 }
        
        }
   
  
  
        
   
   
   
}
    system("PAUSE");
    return EXIT_SUCCESS;
}
