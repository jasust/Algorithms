#include <stdio.h>
int basta[300][300];
void citaj(int a[300][300],int n,int m)
{for(int i=0;i<n;i++)
  for(int j=0;j<m;j++)
   scanf("%d",&a[i][j]);
}
 int minred(int a[300][300],int n,int m)
{
     int min=0;
     for(int j=1;j<m;j++)
     {if(a[n][j]<a[n][min])
     min=j;
     }
     return min;
}
int promena(int a[300][300],int n,int m, int min)
   {int pomr;
    for(int i=0;i<n;i++)
    {if(a[i][m]>min)
    pomr++;
    }
    return pomr;
}
int main()
{
    int n,m,pomrmin,pomr;
    int minr;
    scanf("%d %d",&n,&m);
    pomrmin=n;
    citaj(basta,n,m);
    for(int i=0;i<n;i++)
     {minr=minred(basta,i,m);
       for(int j=0;j<m;j++)
        {if(basta[i][j]==basta[i][minr])
          pomr=promena(basta,n,j,basta[i][minr]);
         if(pomr<=pomrmin)
         pomrmin=pomr;
         }}
         printf("%d",n-pomrmin+1);
    return 0;
    }
