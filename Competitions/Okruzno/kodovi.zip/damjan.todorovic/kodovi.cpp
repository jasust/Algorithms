#include<stdio.h>
#define max 100000
int main()
{ 
 long long int n,x,a[max],b[max],sec,kod,i;
 scanf("%lld %lld",&n,&x);
 for(int j=0;j<n;j++)
 scanf("%lld %lld",&a[j],&b[j]);
 for(int k=0;k<n;k++)
 {if(a[k]>x)
 {i=k;break;}
}
 while(i>=0 && i<n)
 {
         if(a[i]>x && b[i]!=0)
         {sec=sec-x+a[i];x=a[i];kod++;b[i]--;i--;}
         else if(a[i]>x && b[i]==0)
         {i++;}
         else if(a[i]<x && b[i]!=0)
         {sec=sec+x-a[i];x=a[i];kod++;b[i]--;i++;}
         else if(a[i]<x && b[i]==0)
         {i--;}
 }
 printf("%lld\n",kod);
 printf("%lld",sec);
 return 0;
}
