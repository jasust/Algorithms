#include <stdio.h>
int main()
{
    int n,k,raz;
    long long int a[13];
    scanf("%d %d",&n,&k);
    for(int i=0;i<n;i++)
     scanf("%lld",&a[i]);
    if(k==1)
    {raz=1;
    printf("%d\n",raz);
    for(int i=0;i<n;i++)
    printf("%d ",raz);
    }
    return 0;
    }
