#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

int static const N=1<<(14);

int n,k;
int a[20];
int b[N+1];
int radi[20];
int razl=100000;

void radii()
{
    if(n == 1)
    {
        radi[1] = 1;
        razl = a[1];
        if(k ==1)
                printf("0\n");
        else
            printf("%i\n",razl);
        for(int i=1;i<=n;i++)
            printf("%i ",radi[i]);
    }
    if(n==2)
    {
        if(k == 1)
        {
            radi[1] = 1;
            radi[2] = 1;
            razl = 0;
        }
        if( k >= 2)
        {
            radi[1] = 1;
            radi[2] = 2;
            razl = abs(a[1]-a[2]);
            if(k > 2)   razl = max(a[1],a[2]);
        }
        printf("%i\n",razl);
        for(int i=1;i<=n;i++)
            printf("%i ",radi[i]);
    }
    if(k==3)
    {
        int r1,r2,r3,pk=0,minn;
        for(int i=0;i<(1<<n);i++)
            for(int j=0;j<(1<<n);j++)
            {
                if( (i & j) == 0)
                {
                    int d1,d2,d3,rr,d11,d22,d33;
                    d1=i;
                    d2=j;
                    d3=((1<<n)^(r1|r2));
                    d11=b[d1];
                    d22=b[d2];
                    d33=b[d3];
                    if(d11 > d22 && d11 > d33)     rr=d11-min(d22,d33);
                    if(d22>d11 && d22>d33)  rr=d22 - min(d11,d33);
                    if(d33>d11 && d33 > d22)    rr=d33 - min(d11,d22);
                    if(pk == 0 || rr<minn)
                    {
                        r1=d1;
                        r2=d2;
                        r3=d3;
                        minn = rr;
                        pk =1;
                    }

                }
            }
    }


}

int main()
{
    scanf("%i%i",&n,&k);
    for(int i=1;i<=n;i++)
            scanf("%i",&a[i]);
    for(int i=0;i<=(1<<n);i++)
    {
        b[i] = 0;
        for(int j=0;j<n;j++)
            if(i||(1<<j) == i)
                b[i]+=a[j];
    }
    radii();


    return 0;
}
