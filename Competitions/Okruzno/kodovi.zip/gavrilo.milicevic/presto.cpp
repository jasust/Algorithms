#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

struct vred
{
    int vr,gr;
};

int n , m;
int a[301][301];
vred niz[1000];

bool cmp(vred x , vred y)
{
    if(x.vr < y.vr) return true;
    return false;
}

int main()
{
    scanf("%i%i",&n,&m);
    int minn=1000000;
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
            scanf("%i",&a[i][j]);
    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
        {
            int br=0;
            for(int q = 0 ; q < n; q++)
            {
                if(q != i)
                {
                    niz[br].vr = a[q][j];
                    niz[br].gr = 0;
                    br++;
                }
            }
            for(int q = 0 ; q < m; q++ )
            {
                if(q !=  j)
                {
                    niz[br].vr = a[i][q];
                    niz[br].gr = 1;
                    br++;
                }
            }
            int ppp=0,l,d,k=0;
            sort(niz,niz+br,cmp);
            for(int q = br-1 ; q>=0 ; q--)
            {
                if( k == m - 1)
                {
                    l=niz[q].vr;
                    d=niz[q+1].vr;
                    break;
                }
                if(niz [q].gr == 0)
                    ppp++;
                else    k++;
            }
            if( a[i][j] < l || a[i][j] > d)
                    ppp++;
            if(ppp < minn)
                    minn = ppp;
            /*if( ppp == 1)
            {
                for(int q=0;q<br;q++)
                    printf("%i ",niz[q].vr);
                    printf("\n%i %i\n",i,j);
            }*/
            if(minn == 0)
                    break;
        }
    printf("%i\n",minn);

    return 0;
}
/*
3 4
1 9 3 0
6 2 7 5
8 4 6 3
*/
