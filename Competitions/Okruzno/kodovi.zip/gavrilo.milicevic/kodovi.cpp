#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;
int static const maxSize = 100000;

struct gomila
{
    int p,h;
};
int n,x;

gomila a[maxSize + 1];
long long int res=0,bk=0;

int main()
{
    scanf("%i%i",&n,&x);
    for(int i=0;i<n;i++)
        scanf("%i%i",&(a[i].p),&(a[i].h));
    int l=-3,d=-3;
    for(int i=0;i<n-1;i++)
    {
        if( a[i].p < x && a[i+1].p > x )
        {
            l=i;
            d=i+1;
            break;
        }
    }
    int poz = a[d].p;
    if(d != -3 && l != -3)
    {
        res += a[d].p-x;
        bk++;
    }
    a[d].h--;
    int sm = -1;
    while ( l >= 0  && d < n )
    {
        if(a[d].h == 0) d++;
        else
        {
            if(a[l].h == 0) l--;
            else
            {
                if(sm == 1)
                {
                    if(poz != a[l].p)
                    {
                        res += (long long int)(a[d].p - poz);
                        poz = a[d].p;
                        a[d].h--;
                        bk++;
                        sm = -1;
                    }
                    else
                    {
                        int q=min(a[l].h,a[d].h);
                        if(a[d].h > a[l].h)
                        {
                            res +=(long long int)((a[d].p - a[l].p)*(2*q+1) );
                            sm = -1;
                            poz = a[d].p;
                            bk += (long long int)( 2*q + 1 );
                        }
                        else
                        {
                            res += (long long int)((a[d].p - a[l].p)*2*q);
                            sm = 1;
                            bk += (long long int)(2*q);
                            poz = a[l].p;
                        }
                        a[l].h -= q;
                        a[d].h -= q;

                    }
                }
                else
                {
                    if(poz != a[d].p)
                    {
                        res += (long long int)(poz - a[l].p);
                        poz = a[l].p;
                        a[l].h--;
                        bk++;
                        sm = 1;
                    }
                    else
                    {
                        int q=min(a[l].h,a[d].h);
                        if(a[d].h > a[l].h)
                        {
                            res += (long long int)((a[d].p - a[l].p)*(2*q));
                            sm = -1;
                            poz = a[d].p;
                            bk += (long long int)(2*q);
                        }
                        else
                        {
                            res += (long long int)((a[d].p - a[l].p)*(2*q+1));
                            sm = 1;
                            poz = a[l].p;
                            bk += (long long int)(2*q+1);
                        }
                        a[l].h -= q;
                        a[d].h -= q;
                    }
                }
            }
        }
    }
    printf("%lld\n%lld\n",bk,res);
    return 0;
}
/*
3 7
5 2
10 1
12 4

7 10
2 5
4 6
7 14
8 1
9 2
13 5
17 3
*/
