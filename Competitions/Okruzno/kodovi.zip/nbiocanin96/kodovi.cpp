#include <iostream>
#include <cstdio>
int main()
{
    long long n,x,pi[10000][10000],hi[10000][10000],k,l,a,b,kor,h=0;
    scanf("%lld %lld",&n,&x);
    for(long long i=0;i<n;i++)
    {
    scanf("%lld %lld",&pi[i][i],&hi[i][i]);
    h+=hi[i][i];
    }
    for(long long i=0;i<n;i++)
    {
             if(pi[i][i]>x)
             {
             k=i;
             break;
             }
             else continue;
    }
    b=pi[k][k]-x;
    a=1;
    hi[k][k]-=1;
    l=k-1;
    kor=pi[k][k]-pi[l][l];
    b+=kor;
    a+=1;
    hi[l][l]-=1;
    for(long long i=0;i<h-2;i++)
    {
             if(hi[k][k]==0)
             {
             if(k<n)
             k++;
             else if(k==n)
             break;
             }
             b+=pi[k][k]-pi[l][l];
             a+=1;
             hi[k][k]-=1;
             if(hi[l][l]==0)
             {
             if(l>0)
             l--;
             else if(l==0)
             break;
             }
             b+=pi[k][k]-pi[l][l];
             a+=1;
             hi[l][l]-=1;
    }
    printf("%lld\n%lld",a,b);
    return 0;
}
