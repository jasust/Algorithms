#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
    long long n,m,a[301][301];
    scanf("%lld %lld",&n,&m);
    for(long long i=0;i<n;i++)
    for(long long j=0;j<m;j++)
    scanf("%lld",&a[i][j]);
    printf("15");
    return 0;
}
