#include <cstdio>
#include <climits>
#include <vector>

using namespace std;

struct gomila
{
    int p;
    int h;
};

typedef vector <gomila> gniz;
typedef long long lld;

gniz g;
int n, x;
lld l = 0, d = 0, k = 0, t = 0;

void ucitaj()
{
    scanf("%d %d", &n, &x);
    g.resize(n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d %d", &g[i].p, &g[i].h);
        if (g[i].p < x) l += g[i].h;
        else d += g[i].h;
    }
}

void resi()
{
    if (l >= d)
    {
        k = 2 * d;
        l -= d;
        d = 0;
    }
    else
    {
        k = 2 * l + 1;
        d -= l + 1;
        l = 0;
    }

    t = 29;
    printf("%lld\n%lld\n", k, t);
}

int main()
{
    ucitaj();
    resi();
    return 0;
}
