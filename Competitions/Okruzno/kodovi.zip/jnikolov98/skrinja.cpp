#include <cstdio>
#include <vector>
#include <iterator>
#include <algorithm>

using namespace std;

struct sve
{
    int bs;
    int si;
    int pi;
};

typedef long long lld;
typedef vector <lld> niz;
typedef vector <sve> sniz;

int n, k;
niz p;
sniz x;

bool pre1(sve a, sve b)
{
    return a.bs > b.bs;
}

bool pre2(sve a, sve b)
{
    return a.si < b.si;
}

void ucitaj()
{
    scanf("%d %d", &n, &k);

    x.resize(n);
    p.resize(k, -1);

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &x[i].bs);
        x[i].si = i;
        x[i].pi = -1;
    }
}

void resi()
{
    sort(x.begin(), x.end(), pre1);

    for (int i = 0; i < k; i++)
    {
        p[i] = x[i].bs;
        x[i].pi = i;
    }

    for (int i = k; i < n; i++)
    {
        niz::iterator m = min_element(p.begin(), p.end());
        *m += x[i].bs;
        x[i].pi = m - p.begin();
    }

    sort(x.begin(), x.end(), pre2);

    niz::iterator emin = min_element(p.begin(), p.end());
    niz::iterator emax = max_element(p.begin(), p.end());

    printf("%lld\n", (*emax - *emin));
    for (int i = 0; i < n; i++)
        printf("%d ", x[i].pi + 1);
}

int main()
{
    ucitaj();
    resi();
    return 0;
}
