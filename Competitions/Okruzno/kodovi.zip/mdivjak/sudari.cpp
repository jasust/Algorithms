#include <stdio.h>

int main() {
    int n, m;
    int x, y;
    char lavirint[500][500];
    int udarci;
    char pravac;

    scanf("%d %d\n", &n, &m);
    scanf("%d %d\n", &y, &x); --y; --x;
    scanf("%d", &udarci);

    pravac = 'S';
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++) {
            scanf("%c", &lavirint[i][j]);
        }

    int k = 0;
    int a = 0, b = 0;
    bool rezultat;
    while(k < udarci) {

        a = x; b = y;
        switch(pravac) {
            case 'S': ++b; break;
            case 'N': --b; break;
            case 'W': ++a; break;
            case 'E': --a;
        }

        if((a >= 0 && a < m) && (b >= 0 && b < n)) {
            if(lavirint[a][b] != '#') {
                x = a; y = b;
                rezultat = true;
            } else {
                switch(pravac) {
                    case 'S': pravac = 'E'; break;
                    case 'N': pravac = 'W'; break;
                    case 'W': pravac = 'S'; break;
                    case 'E': pravac = 'N';
                }
                rezultat = false;
            }
        } else {
            switch(pravac) {
                case 'S': pravac = 'E'; break;
                case 'N': pravac = 'W'; break;
                case 'W': pravac = 'S'; break;
                case 'E': pravac = 'N';
            }
            rezultat = false;
        }

        if(!rezultat) ++k;
    }
    ++x; ++y;
    printf("%d %d", y, x);
    return 0;
}
