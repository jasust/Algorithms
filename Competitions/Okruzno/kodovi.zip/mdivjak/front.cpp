#include <stdio.h>

int main() {
    const int max = 1000000;
    static int vojnik[max];
    int n, x;
    scanf("%d", &n);
    for(int i = 0; i < n; i++) {
        scanf("%d %d", &x, &vojnik[i]);
        //cin >> x >> vojnik[i];
    }

    int na_frontu = 1;
    int poslednji_na_frontu = vojnik[n-1];
    for(int i = n-2; i >=0; i--) {
        if(vojnik[i] > poslednji_na_frontu) {
            ++na_frontu;
            poslednji_na_frontu = vojnik[i];
        }
    }
    //cout << na_frontu;
    printf("%d", na_frontu);
    return 0;
}
