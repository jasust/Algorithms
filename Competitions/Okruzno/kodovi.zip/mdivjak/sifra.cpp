#include <stdio.h>
#include <algorithm>

void add(int a[], int i, int n) {
    bool carry;
    do {
        ++a[i];
        if(a[i] == n) {
            a[i] = 0;
            --i;
            carry = true;
        } else carry = false;
    } while(carry);
    return;
}

int main() {
    int n, m;
    long long k;
    int a[100000], b[100000] = {0};

    scanf("%d %d %I64d", &n, &m, &k);
    for(int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    std::sort(a, a+n);
    /*for(int i = 0; i < n; i++)
        printf("%d ", a[i]);
    printf("\n");*/

    if(m == 1) {
        printf("%d", a[k-1]);
    } else if(k == 1) {
        for(int i = 0; i < m; i++)
            printf("%d ", a[0]);
    } else {
        for(long long i = 0; i < k-1; i++) {
            //printf("%I64d.\t", i+1);
            add(b, m-1, n);
            //for(int j = 0; j < m; j++) printf("%d ", b[j]);
            //printf("\n");
        }
        for(int i = 0; i < m; i++) {
            printf("%d ", a[b[i]]);
        }
    }

    return 0;
}
