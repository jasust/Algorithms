#include <iostream>
using namespace std;

int main()
{   char Tab[500][500];
    int n,m;    
    int x,y,k;
    
    cin >> n >> m; 
    cin >> y >> x; 
    cin >> k;
    for(int q=1;q<=n;q++)
    {
            for(int v=1;v<=m;v++)
            {
                    cin  >> Tab[q][v];
            }
    }
    for(int g=1;g<=k;g++)
    {         if(g==1)
              {while(y!=n)               //dole
                { if(Tab[y+1][x]=='#')         
                   {break;}
                   else 
                   {y++;}                
                } 
                
              }
              
             else
              {    if(g%4==2)
                  { while(x!=m , Tab[y][x+1]!='#')                 //desno
                   {
                    
                    {x++;}                
                   } }
                   if(g%4==3)
                    {if(x==m || Tab[y][x+1]=='#')
                   {
                          while( y!=1,Tab[y-1][x]!='#')          //gore
                          {                            
                            {y--;}                
                          }}}
                          if(y==1 || Tab[y-1][x]=='#')
                           {       if(g%4==0)
                                   {  
                                   while(x!=1,Tab[y][x-1]!='#')        //levo
                                   {
                                   {x--;}                
                                   } 
                                   ;}
                                   if(g%4==1)
                                   {if(x==1 || Tab[y][x-1]=='#')
                                   {
                                   while(y!=n,Tab[y+1][x]!='#')              //dole
                                   {                                    
                                     {y++;}                
                                   }
                                   }}
                           
                          }
              
              } 
}
    
    cout << y <<" "<< x;
    
   return 0;
  
}


