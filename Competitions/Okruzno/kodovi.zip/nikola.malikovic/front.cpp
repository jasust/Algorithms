#include <iostream>
using namespace std;

int main()
{   int B,Vx[1000],Vy[1000],c,a;
    cin >> B;
    for(int z=1;z<=B;z++)
    {
            cin >> Vx[z] >>Vy[z];
    };
    for(int v=1;v<=Vx[B];v++)
    {
         for(int q=v+1;q<=Vx[B];q++)
               if(Vx[v]==Vx[q])
               {break;}
               else
               { 
                   if(Vy[v]<Vy[q])
                   {break;}
                   else
                   {c++;}
                   if (c>0)
                   a++;
                   
               } 
                  
                        
         
            
    }
    cout << c;
    return 0;
    
}
