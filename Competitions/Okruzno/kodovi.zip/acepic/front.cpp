#include<cstdio>
#include<cmath>
#include<iostream>
#include<algorithm>
using namespace std;
int x[1005],y[1005],n,m,i;
int main () {
scanf("%d",&n);
for(i=1;i<=n;i++) {
    scanf("%d %d",&x[i],&y[i]);
if((x[i]<abs(x[i+1]-(y[i-1]))) or (y[i]<abs(x[i-1])-(y[i+1]))) { m++;

  }
}
printf("%d",m);
return 0;
}
//4

