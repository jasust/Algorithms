#include <stdio.h>
#include <iostream>
using namespace std;
long int dobij_fakt(long int s,long int n,long int k)
{
     long int sum=1;
     if(k==1&&s-1==0)return -1;
     for(long int i=0;i<s-1;i++)
     {
              sum*=n;
              if(sum>k)return -1;
     }
     return sum;
}
int main()
{
    long int n,m,k;
    cin>>n>>m>>k;
    long int niz[n+1];
    long int sol[n];
    
    for(long int i=0;i<=n;i++)cin>>niz[i];
    //niz[0]=niz[1];
    long int br=0;
    for(long int i=0;i<m;i++)sol[i]=niz[0];
    for(long int i=m;i>=1;i--)
    {
             long int q=dobij_fakt(i,n,k);
             //cout << k<<" "<<q<<endl;
             //cout << q<<endl;system("PAUSE");
             if(q==-1){sol[br]=niz[0];br++;continue;}
             sol[br]=niz[k/q];
             k=k%q;
             //cout << k<< endl;
             br++;
    }
    for(long int i=0;i<br;i++)cout <<sol[i]<<" ";
    //system("PAUSE");
    return 0;
}
    
    
