#include <iostream>
#include <stdio.h>
using namespace std;
struct dot
{
       long int x,y;
};
int main()
{
    long int n;
    scanf("%ld",&n);
    struct dot arr[n];
    long int sol=1;
    for(long int i=0;i<n;i++)
    {
            scanf("%ld %ld",&arr[i].x,&arr[i].y);
    }
    long int por=n-1;
    long int stx,sty;
    stx=arr[n-1].x;
    sty=arr[n-1].y;
    long int j=0;
    for(long int i=n-2;i>=0;i--)
    {
             j=i;
          if(stx==arr[j].x)
             {while(stx==arr[j].x&&j>=0)
          {
                              sty=max(sty,arr[j].y);j--;
          }
          sol++;
          i=j;
          }
          if(arr[i].y>sty){sol++;sty=arr[i].y;}
          stx=arr[i].x;
                                         
                     
    }
    printf("%ld",sol);
    //system("PAUSE");
    return 0;
}            
    
