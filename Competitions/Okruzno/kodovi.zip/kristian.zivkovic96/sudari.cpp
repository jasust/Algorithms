#include <iostream.h>
#include <stdio.h>
using namespace std;
int matrica[501][501];
int smer[501][501];
int n,m;
long int k;
int smervrs[]={1,0,-1,0};
int smerkol[]={0,1,0,-1};
bool dobar(int x,int y)
{
     if((x>=1)&&(x<=n)&&(y>=1)&&(y<=m)&&(matrica[x][y]!=-1))return 1;
     return 0;
}
void dfs(int x,int y,int sm)
{
     //matrica[x][y]=0;
     smer[x][y]=sm;
     for(int i=0;i<4;i++)
     {
     if(dobar(x+smervrs[sm],y+smerkol[sm]))
     {
         ///if(matrica[x+smervrs[sm]][y+smerkol[sm]]==0)k%=(zv_ukup+1)
         
         dfs(x+smervrs[sm],y+smerkol[sm],sm);
     }
     else {k--;sm++;if(sm>4)sm=1;}
     if(k<=0){cout << x <<" "<<y;system("PAUSE");exit(0);}
     }
}
int main()
{
    for(int i=0;i<=500;i++)for(int f=0;f<=500;f++)smer[i][f]=-1;
    scanf("%d %d",&n,&m);
    int startx,starty;
    scanf("%d %d",&startx,&starty);
    //long int k;///OBAVEZNO LLD
    scanf("%ld",&k);
    for(int i=1;i<=n;i++)
    {
            for(int f=1;f<=m;)
            {
                    char a;
                    scanf("%c",&a);
                    if(a=='.'){matrica[i][f]=1;f++;}
                    else if(a=='#'){matrica[i][f]=-1;f++;}
            }
    }
    dfs(startx,starty,1);
    system("PAUSE");
    return 0;
}
    
