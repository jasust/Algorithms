#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;
int k,m,n,x[1000000];
int main() {

        scanf("%d %d %d", &n,&m,&k);

        for(int i=1;i<=n;i++) scanf("%d", &x[i]);


        sort(x+1, x+n+1);

        printf("%d\n", x[k]);






    return 0;
}
