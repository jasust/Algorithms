#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
using namespace std;
int n,x[1000000],y[1000000],cnt1,cnt2,cntfinal;
int main() {

        scanf("%d", &n);

        cnt1=0;
        cnt2=0;
        cntfinal=0;

        for(int i=1;i<=n;i++) scanf("%d %d", &x[i],&y[i]);

        for(int i=1;i<=n;i++) {

            if((x[i]<=x[i+1]) and (y[i]<=y[i+1])) cnt1++;
            else if(y[i]==y[i+1]) cnt2++;
        }
        cntfinal=n-cnt1-cnt2;
        printf("%d\n", cntfinal);


    return 0;
}
