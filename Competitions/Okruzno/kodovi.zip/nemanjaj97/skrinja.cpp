#include <stdio.h>
#include <stdlib.h>

int n,k,min=999999,resenje[13],pocetni[13];
void razmeni(int *a,int *b)
{
     int pom;
     pom=*a;*a=*b;*b=pom;
}
void quicksort(int a[],int levi,int desni)
{
     int i,j;
     float d;
     if(levi<desni)
     {
                   i=levi;
                   j=desni;
                   d=a[desni];
                   do
                   {
                              while(a[i]<d)i++;
                              while(a[j]>=d&&i<j)j--;
                              if(i<j)razmeni(&a[i],&a[j]);
                   }
                   while(i!=j);
                   quicksort(a,levi,i-1);
                   quicksort(a,i+1,desni);
     }
}
int nadji(int i, int niz[])
{
    int j;
    int perica[13];
    if(i==n)
    {
            for(j=0;j<n;j++)
            perica[niz[j]]+=pocetni[j];
            quicksort(perica,0,n);
            if(perica[k-1]-perica[0]<min)
            {
                                       min=perica[2]-perica[0];
                                       for(j=0;j<n;j++)
                                       {
                                                       resenje[j]=niz[j]+1;
                                       }
            }
    }
    else 
    {
          for(j=0;j<k;j++)
          {
                          niz[i]=j;
                          nadji(i+1,niz);
          }
    }
}
int main()
{
    int l,niz[13];
    scanf("%d, %d",&n, &k);
    for(l=0;l<n;l++)
    {
                    scanf("%d",&pocetni[l]);
    }
    nadji(0,niz);
    printf("%d\n",min);
    for(l=0;l<n;l++)
    {
                    printf("%d ",resenje[l]);
    }
    return 0;
}
