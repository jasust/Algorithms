#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,m;
    float h[300][300],v[][];
    scanf("%d %d",&n,&m);
    for(i=0;i<n;i++)
    for(j=0;j<m;j++)
    scanf("%f",&h[i][j]);
    printf("0");
    return 0;
}
