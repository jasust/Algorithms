#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,x,p[100000],h[100000],k=1,poz=1,i;
    long long s=0,b=0;
    scanf("%d %d",&n,&x);
    for(i=0;i<n;i++)
    {
                    scanf("%d %d",&p[i],&h[i]);
    }
    int levi=0, desni=n, sredina;
    while(levi<desni)
    {
           sredina=(levi+desni)/2;
           if(x>p[sredina])
           levi=sredina+1;
           else if(x<p[sredina])
           desni=sredina-1;
           else break;
    }
    i=sredina;
    while(k!=0)
    {
               if(poz==1)
               {
                   while(x<p[i]){x++; s=s+1;}
                   h[i]--;
                   i--;
                   b++;
                   while(h[i]==0&&i>0)
                   {
                                      i--;
                   }
                   if((i==0)&&(h[0]==0)) {k=0;}
               }
               if(poz==-1)
               {
                   while(x>p[i]){x--; s=s+1;}
                   h[i]--;
                   i++;
                   b++;
                   while(h[i]==0&&i<n-1)
                   {
                                        i++;
                   }
                   if((i==(n-1))&&(h[n-1]==0)) {k=0;}
               }
               poz=-poz;
    }
               printf("%lld \n%lld",b,s);
               return 0;
}
