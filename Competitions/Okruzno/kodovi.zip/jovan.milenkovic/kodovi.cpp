#include <cstdio>
#include <algorithm>
#include <cstdlib>
using namespace std;
long long a[100005],kod[100005];
int main()
{
    long long i,x,n,brlevo=0,brdesno=0,sol=0,vreme=0;
    scanf("%lld %lld",&n,&x);
    for(i=0;i<n;i++)
    {
        scanf("%lld %lld",a+i,kod+i);
        if(a[i]<x)
            brlevo+=kod[i];
        else
            brdesno+=kod[i];
    }



    if(brlevo==brdesno)
    {
        sol=brlevo+brdesno;
        for(i=0;i<n;i++)
            vreme+=2*abs(a[i]-x)*kod[i];
        vreme-=x-a[0];
    }
    else if(brlevo<brdesno)
    {
        sol=2*brlevo+1;
        for(i=0;i<n;i++)
        {
            if(a[i]<x)
                vreme+=2*(x-a[i])*kod[i];
            else if(brlevo>=0)
            {
                if(brlevo>=kod[i])
                {
                    vreme+=2*(a[i]-x)*kod[i];
                    brlevo-=kod[i];
                }
                else
                {
                    vreme+=(2*brlevo+1)*(a[i]-x);
                    brlevo-=kod[i];
                    break;
                }
            }
        }
    }
    else
    {
        sol=2*brdesno;
        for(i=n-1;i>=0;i--)
        {
            if(a[i]>x)
            {
                vreme+=2*(a[i]-x)*kod[i];
            }
            else if(brdesno>0)
            {
                if(brdesno>kod[i])
                {
                    vreme+=2*(x-a[i])*kod[i];
                    brdesno-=kod[i];
                }
                else
                {
                    vreme+=(x-a[i])*(2*brdesno-1);
                    brdesno-=kod[i];
                }
            }

        }
    }
    printf("%lld\n%lld",sol,vreme);
    return 0;
}
