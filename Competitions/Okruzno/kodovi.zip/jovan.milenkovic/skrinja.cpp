#include <cstdio>
#include <algorithm>
using namespace std;
int niz[15],perica[15][15],sol[15],suma,resenje,duzp[15],original[15];
bool mark[15];
int i,j,k;
int n,brp;
void f(int sapocetka)
{
    int minimum=suma,maximum=0,tmp=0;
    if(sapocetka==n)
    {
        for(i=0;i<brp;i++)
        {
            tmp=0;
            for(j=0;j<14;j++)
                tmp+=perica[i][j];
            if(tmp<minimum)
                minimum=tmp;
            if(tmp>maximum)
                maximum=tmp;
        }
        tmp=0;
        if(maximum-minimum<resenje)
        {
            resenje=maximum-minimum;
            for(i=0;i<brp;i++)
                for(j=0;j<duzp[i];j++)
                {
                    for(k=0;k<n;k++)
                        if(mark[k]==0 && perica[i][j]==original[k])
                        {
                            mark[k]=1;
                            sol[k]=i;
                            break;
                        }
                }
        }
        for(i=0;i<brp;i++)
        {
            for(j=0;j<duzp[i];j++)
                perica[i][j]=0;
            duzp[i]=0;
        }
        for(i=0;i<n;i++)
            mark[i]=0;
        perica[0][0]=niz[0];
        duzp[0]=1;
        return ;
    }
    i=0;
    while(perica[i][0]<niz[sapocetka])
        i++;

    perica[i][duzp[i]]=niz[sapocetka];
        duzp[i]++;
        f(sapocetka+1);
    i++;

    for(i;i<brp;i++)
    {
        perica[i][duzp[i]]=niz[sapocetka];
        duzp[i]++;
        duzp[i-1]--;
        perica[i-1][duzp[i-1]]=0;
        f(sapocetka+1);
    }
}
int main()
{
    scanf("%d %d",&n,&brp);
    for(i=0;i<n;i++)
    {
        scanf("%d",niz+i);
        original[i]=niz[i];
        suma+=niz[i];
    }
    resenje=suma;

    sort(niz,niz+n);
    perica[0][0]=niz[0];
    duzp[0]=1;
    f(1);
    printf("%d\n",resenje);
    for(i=0;i<n;i++)
        printf("%d ",sol[i]);




    return 0;
}
