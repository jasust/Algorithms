#include <cstdio>
#include <algorithm>
using namespace std;
int basta[304][304];
int main()
{
    int i,j,k,n,m,brmanjih,brvecih,sol;
    scanf("%d %d",&n,&m);
    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
            scanf("%d",&basta[i][j]);
    sol=m*n;

    for(i=0;i<n;i++)
        for(j=0;j<m;j++)
        {
            brmanjih=0;
            brvecih=0;
            for(k=0;k<m;k++)//setam se po redu i gledam koliko je nizih
            {
                if(basta[i][k]<basta[i][j])
                    brmanjih++;
            }
            for(k=0;k<n;k++)//setam se po koloni i trazim visa polja
            {
                if(basta[k][j]>basta[i][j])
                    brvecih++;
            }
            if(brvecih+brmanjih<sol)
                sol=brvecih+brmanjih;
        }
    printf("%d",sol);
    return 0;
}
