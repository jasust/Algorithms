#include<stdio.h>
struct gom
{
    int p;
    int h;
};
int main()
{
    int i,k,b,s,n,x,l=0,d=0,m=0;
    struct gom a[10000];
    scanf("%d %d",&n,&x);
    for(i=0;i<n;i++)
    {
        scanf("%d %d",&a[i].p,&a[i].h);
        if (a[i].p>x) d+=a[i].h;
            else l+=a[i].h;
        if (a[i].p>x && m==0) m=i;
    }
    if (l==d) k=2*l;
        else if (l>d) k=2*d;
            else k=2*l +1;


    s=0;
    b=k/2;
    i=m;
    while(b>=1)
    {
        if (a[i].h<=b)
        {
            s+=(a[i].h*2)*(a[i].p-x);
            b-=a[i].h;
            i++;
        }
        else
        {
            s+=(b*2)*(a[i].p-x);
            b=0;
            if (l<d) s+=(a[i].p-x);
        }
    }

    b=k/2;
    i=m-1;
    while(b>=1)
    {
        if (a[i].h<=b)
        {
            s+=(a[i].h*2)*(x-a[i].p);
            b-=a[i].h;
            i--;
        }
        else
        {
            s+=(b*2)*(x-a[i].p);
            b=0;
        }
    }





    printf("%d\n%d",k,s);




    return 0;
}
