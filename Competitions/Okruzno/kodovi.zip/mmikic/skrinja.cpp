#include<stdio.h>
#include<algorithm>
using namespace std;
struct pog
{
  int b;
  int r;
  int p;
};
int main()
{
    int i,n,t,j,k,b[100]={0.0};
    bool p=true;
    struct pog d[100];
    scanf("%d %d",&n,&k);
    for (i=0;i<n;i++)
    {
        scanf("%d",&d[i].b);
        d[i].r=i;

    }
    for (i=0;i<n-1;i++)
        for (j=i+1;j<n;j++)
    {
        if (d[i].b>d[j].b)
        {
            t=d[i].b;
            d[i].b=d[j].b;
            d[j].b=t;
        }
    }



    j=0;
    for(i=n-1;i>=0;i--)
    {
        if (p && j<k)
        {
            b[j]+=d[i].b;
            d[i].p=j+1;
            j++;
            if (j==k)
            {
                p=false;
                j--;
            }
        }
        else
            if (p==false && j>=0)
        {
            b[j]+=d[i].b;
            d[i].p=j+1;
            j--;
            if (j==-1)
            {
                p=true;
                j++;
            }
        }
    }

    for (i=0;i<n-1;i++)
        for (j=i+1;j<n;j++)
    {
        if (d[i].r>d[j].r)
        {
            t=d[i].r;
            d[i].r=d[j].r;
            d[j].r=t;
        }
    }
    int mi=b[0],ma=0,rez;
    for (i=0;i<k;i++)
    {
        if (mi>b[i]) mi=b[i];
        if (ma<b[i]) ma=b[i];
    }
    rez=ma-mi;
    printf("%d\n",rez);

    for (i=0;i<n;i++)
       printf("%d ",d[i].p);



    return 0;
}
