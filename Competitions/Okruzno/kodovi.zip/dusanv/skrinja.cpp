#include <cstdlib>
#include <iostream>
#include <stdio.h>

#define MAXN 20
#define MAXK 20
using namespace std;
int a[MAXN];
int b[MAXK],pr[MAXK];//imaju k "cifara", a n je osnova
int c[MAXN],minim[MAXK];
void prepisi(int k)
{
     int i;
     for (i=0;i<k;i++)
     {
         minim[i]=b[i];
     }
}
int povecaj(int n,int k)
{
    int i;
    for (i=k-1;i>=0;i--)
    {
        if (b[i]!=n-1)
        {
           b[i]++;
           break;
        }
        while (i>=0 && b[i]==n-1)
        {
              b[i]=0;
              i--;
        }
        if (i>=0 && b[i]!=n-1)
        {
           b[i]++;
           break;
        }
    }
}
bool razliciti(int a[],int b[],int k)
{
     int i;
     for (i=0;i<k;i++)
     {
         if (a[i]!=b[i])
         {
            return true;
         }
     }
     return false;
}
int izracunaj(int n,int k,int z)
{
    
    int i,min=z,j,min1=z,max1=0;
    for (i=0;i<n;i++)
    {
        c[i]=0;
    }
    for (i=0;i<k;i++)
    {
        c[b[i]]+=a[i];
    }
    for (i=0;i<n;i++)
    {
        if (c[i]>max1)
        {
           max1=c[i];
        }
        if (c[i]<min1)
        {
           min1=c[i];
        }
    }
    
    return max1-min1;
}
void test(int k)
{
     int i;
     for (i=0;i<k;i++)
     {
         cout<<b[i]<<" ";
     }cout<<"\n";
}
int main(int argc, char *argv[])
{
    int n,k,i,min=0,z=0;
    bool prvi=true;
    scanf("%d%d",&k,&n);
    for (i=0;i<k;i++)
    {
        scanf("%d",&a[i]);
        min+=a[i];
    }
    z=min;
    for (i=0;i<k;i++)
    {
        pr[i]=b[i]=0;
    }
    while (prvi || razliciti(b,pr,k))
    {
          prvi=false;
          int x=izracunaj(n,k,z);
          if (x<min)
          {
             min=x;
             prepisi(k);
          }
          povecaj(n,k);
    }
    printf("%d\n",min);
    for (i=0;i<k;i++)
    {
        printf("%d ",minim[i]+1);
    }
    //system("PAUSE");
    return 0;
}
