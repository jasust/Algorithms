#include <cstdlib>
#include <iostream>
#include <stdio.h>

#define MAXN 10005
#define MAXX 1000000005
#define MINX -1000000005
using namespace std;
struct polje
{
       int x,v;
};
polje a[MAXN];
int manji(int a,int b)
{
    if (a<b)
    return a;
    return b;
}
int main(int argc, char *argv[])
{
    int n,poz,i,levi=-1,desni,j;
    char s='d';
    long long z=0,t=0;
    bool f=true;
    //unos
    scanf("%d%d",&n,&poz);
    desni=n+1;
    for (i=0;i<n;i++)
    {
        scanf("%d%d",&a[i].x,&a[i].v);
    }
    //nalazenje pozicije
    for (i=0;i<n;i++)
    {
        if (a[i].x>poz)
        {
           j=i;
           desni=i;
           levi=i-1;
           break;
        }
    }
    //rad    
    while (f)
    {
          if (s=='d' && desni==n)
          {
             break;
          }
          if (s=='l' && levi==-1)
          {
             break;
          }
          if (s=='d' && a[desni].v<=a[levi].v)
          {
             z=z+(long long)(2*(long long)(a[desni].v));//tamo i nazad i opet je okrenut nadesno
             t=t+(long long)(a[desni].x-poz);
             t+=(long long)(2*a[desni].v-1)*(long long)(a[desni].x-a[levi].x);
             poz=a[levi].x;      
             a[levi].v-=a[desni].v;
             if (a[levi].v==0)
             {
                levi--;
             }
             desni++;
             //cout<<desni<<"\n";
             
          }
          if (s=='l' && a[levi].v<=a[desni].v)
          {
             z=z+(long long)(2*(long long)(a[levi].v));//tamo i nazad i opet je okrenut nadesno
             t=t+(long long)(poz-a[levi].x);
             t+=(long long)(2*a[levi].v-1)*(long long)(a[desni].x-a[levi].x);
             poz=a[desni].x;             
             a[desni].v-=a[levi].v;
             if (a[desni].v==0)
             {
                desni++;
             }
             levi--;
             
          }
          if (s=='d' && a[desni].v>a[levi].v)
          {
             z=z+(long long)((long long)(2*a[levi].v+1));//tamo i nazad i opet je okrenut nadesno
             t=t+(long long)(a[desni].x-poz);
             t+=(long long)(2*a[levi].v)*(long long)(a[desni].x-a[levi].x);
             poz=a[desni].x;             
             a[desni].v-=(1+a[levi].v);
             if (a[desni].v==0)
             {
                desni++;
             }
             levi--;
             s='l';
             
          }
          if (s=='l' && a[desni].v<a[levi].v)
          {
             z=z+(long long)((long long)(2*a[desni].v+1));//tamo i nazad i opet je okrenut nadesno
             t=t+(long long)(poz-a[levi].x);
             t+=(long long)(2*a[desni].v)*(long long)(a[desni].x-a[levi].x);
             poz=a[levi].x;
             a[levi].v-=(1+a[desni].v);
             if (a[levi].v==0)
             {
                levi--;
             }
             desni++;
             s='d';
             
          }
          
    }
    printf("%lld\n%lld\n",z,t);
    //system("PAUSE");
    return 0;
}
