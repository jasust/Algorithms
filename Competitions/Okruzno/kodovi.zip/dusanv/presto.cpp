#include <cstdlib>
#include <iostream>
#include <stdio.h>

#define MAXN 305
using namespace std;
struct polje
{
       int v,ind;
};

int a[MAXN][MAXN],b[MAXN][MAXN],c[MAXN][MAXN];
polje red[MAXN][MAXN],kol[MAXN][MAXN];
int zamenar(int i1,int j1,int i2,int j2)
{
    polje pom=red[i1][j1];
    red[i1][j1]=red[i2][j2];
    red[i2][j2]=pom;
}
int zamenak(int i1,int j1,int i2,int j2)
{
    polje pom=kol[i1][j1];
    kol[i1][j1]=kol[i2][j2];
    kol[i2][j2]=pom;
}
void quicksortr(int i,int l,int d)
{
     int k,id=l,s=(l+d)/2;
     if (l<=d)
     {
        for (k=l+1;k<=d;k++)
        {
            if (red[i][k].v<=red[i][l].v)
            {
               id++;
               zamenar(i,k,i,id);
            }
            
        }
        zamenar(i,l,i,id);
        quicksortr(i,l,id-1);
        quicksortr(i,id+1,d);
     }
}
void quicksortk(int j,int l,int d)
{
     int k,id=l,s=(l+d)/2;
     if (l<=d)
     {
        for (k=l+1;k<=d;k++)
        {
            if (kol[j][k].v<=kol[j][l].v)
            {
               id++;
               zamenak(j,k,j,id);
            }
            
        }
        zamenak(j,l,j,id);
        quicksortk(j,l,id-1);
        quicksortk(j,id+1,d);
     }
}
int broj(int i,int j,int n,int m)
{
    int min=red[i][0].v,br1=0,br2=0,max=kol[j][n-1].v,k,l,od=-1;
    if (b[i][j]==0)
    {
       min=red[i][1].v;
    }
    if (c[i][j]==n-1)
    {
       max=kol[j][n-2].v;
    }  
    //bacamo kolonu na pocetak
    for (k=0;k<n;k++)
    {
        if (k==c[i][j])
        {
           od=0;
        }
        if (k!=c[i][j] && kol[j][k].v>min)
        {
           //bice beskonacno mali
           br1=n-k+od;
           break;
        }
    }
    if (a[i][j]>min)
    {
       br1++;
    }
    //bacamo red na kraj
    od=-1;
    
    for (k=m-1;k>=0;k--)
    {
        //cout<<red[i][k].v<<"\n";
        if (k==b[i][j])
        {
           od=0;
        }
        if (k!=b[i][j] && red[i][k].v<max)
        {
           //bice beskonacno veliki
           br2=k+1+od;
           break;
        }
    }
    if (a[i][j]<max)
    {
       br2++;
    }
    if (br1<br2)
    {
       return br1;
    }
    return br2;
}
int main(int argc, char *argv[])
{
    int n,m,i,j;
    scanf("%d%d",&n,&m);
    int min=n*m;
    for (i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            scanf("%d",&a[i][j]);
            red[i][j].v=a[i][j];
            red[i][j].ind=j;
            kol[j][i].v=a[i][j];
            kol[j][i].ind=i;
        }
    }
    for (i=0;i<n;i++)
    {
        quicksortr(i,0,m-1);
    }
    for (j=0;j<m;j++)
    {
        quicksortk(j,0,n-1);
    }
    //nalazenje
    for (i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            b[i][red[i][j].ind]=j;
        }
    }
    for (j=0;j<m;j++)
    {
        for (i=0;i<n;i++)
        {
            c[kol[j][i].ind][j]=i;
        }
    }
    //glavnica
    for (i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            int pom=broj(i,j,n,m);
            if (pom<min)
            {
               min=pom;
            }
        }
    }
    printf("%d\n",min);
    //system("PAUSE");
    return 0;
}
