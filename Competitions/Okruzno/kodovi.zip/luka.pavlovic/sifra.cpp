#include <iostream>

using namespace std;

int main()
{
    long n,m,i;
    long long k,uk,p;

    cin >> n >> m >> k;
    long long a[n];
    for (i = 0; i < n; i++){
        cin >> a[i];
    }

    uk = n;
    for (i = 1; i < m; i++){
        uk = uk * n;
    }

    for (i = 0; i < m; i++){
        p = (int)(uk / k);
        if ((n - p) < 0)
            p = n;
        cout << a[n-p];
        uk = k - (p-1)*(uk/n);
    }

    return 0;
}
