#include <iostream>

using namespace std;

int main()
{
    long n,i,u,b;

    cin >> n;
    long long x[n];
    long long y[n];
    bool front[n];
    for (i = 0; i < n; i++){
        cin >> x[i] >> y[i];
        front[i] = true;
    }

    //sort
    /*long long z1,z2;
    bool menjase = true;
    while (menjase) {
         for (u = 0; u < n; u++){
            for (i = u + 1; i < n; i++){
                if (x[i] == x[u] && y[i] < y [u]){
                    menjase = true;
                    z1 = x[i];
                    z2 = y[i];
                    x[i] = x[u];
                    y[i] = y[u];
                    x[u] = z1;
                    y[u] = z2;
                }else{
                    menjase = false;
                }
           }
        }
    }

    for (i = 0; i < n; i++){
        cout << x[i] << " " << y[i] << "\n";
    }
   */

    b = 0;
    for (i = n-1; i > 0 ; i--){
        for (u = i-1; u > -1 ; u--){
            if (x[i] >= x[u] && y[i] >= y[u]){
                front[u] = false;
            }
        }
    }

    for (i = 0; i < n; i++){
        if (front[i] == true)
            b++;
        //cout << front[i] << "\n";
    }

    cout << b;

    return 0;
}
