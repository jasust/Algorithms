#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    int n,m,x,y;
    long long k;
    cin >> n >> m;
    cin >> x >> y;
    cin >> k;
    char l[n][m];

    int i,u;
    for (i = 0; i < n; i++){
        for (u = 0; u < m; u++){
            cin >> l[i][u];
        }
    }

    x--;
    y--;
    int x1,y1;
    bool nemaPrepreka = true;
    int smer = 3;
    while (k!= 0){
        while(nemaPrepreka){
            x1 = x; y1 = y;
           if (smer == 1){
                x = x - 1;
           } else if(smer == 2){
               y = y + 1;
           } else if(smer == 3){
               x = x + 1;
           } else if(smer == 4){
               y = y - 1;
           }
           if (l[x][y]=='#' || x == n || y == m){
                nemaPrepreka = false;
                x = x1;
                y = y1;
                //cout << x << " " << y << "\n";
           }
        }
        nemaPrepreka = true;
        k--;
        //cout << k << "\n";
        smer--;
        if (smer==0)
            smer = 4;
    }

    x++;
    y++;
    cout << x << " " << y;

    return 0;
}
