#include <stdio.h>
#include <stdlib.h>

int x[1000001],y[1000001];

int main()
{
    int n;
    int sol=0,i,j;
    int lb=0;

    scanf ("%d",&n);
    for (i=0;i<n;i++){
        scanf ("%d%d",&x[i],&y[i]);
    }

    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            if (j!=i){ /* da ne proveravasamog sebe*/
                if (x[i]<=x[j] && y[i]<=y[j]){ /*provera zadatog uslova*/
                    lb++; /*povecava se broj losihtacaka*/
                    j=n; /*break*/
                }
            }
        }
    }

        sol=n-lb;
    /*od ukupnog broja tacaka oduzmemo one lose*/
    printf ("%d",sol);
    return 0;
}












