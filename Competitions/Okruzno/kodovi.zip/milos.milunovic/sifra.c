#include <stdio.h>
#include <stdlib.h>

long long k;
int main()
{
int n,m;
int a[100];

scanf ("%d%d%lld",&n,&m,&k);
int i;

for (i=0;i<n;i++){
    scanf ("%d",&a[i]);
}

    printf ("%d",a[k-1]); /*kada je m==1, 10 poena*/

    return 0;
}
