#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

struct Polje
{
    int v;
    int p;
    int sol;
};

bool cmp(Polje a, Polje b)
{
    if (a.v<b.v) return true;
    return false;
}
Polje a[300*300],b[300*300];

int main()
{

    int n,m;
    scanf("%d %d",&n,&m);
    for (int i=0;i<n;i++)
        for (int j=0;j<m;j++)
    {
        scanf("%d",&a[i*m+j].v);
        a[i*m+j].p=i*m+j;
        a[i*m+j].sol=0;
        b[j*n+m].v=a[i*m+j].v;
        b[j*n+m].p=i*m+j;
        b[j*n+m].sol=0;
    }
    for (int i=0;i<n;i++)
        sort(a+i*m,a+(i+1)*m-1,cmp);
        int cnt=0;
    for (int i=0;i<n;i++)
    {
        cnt=0;
        for (int j=0;j<m;j++)
        {
            if (a[i*m+j].v<a[i*m+j+1].v) cnt++;
            a[a[i*m+j].p].sol+=cnt;
        }
    }
    for (int j=0;j<m;j++)
        sort(b+j*n,b+(j+1)*n-1,cmp);
        cnt=0;
        for (int i=0;i<n;i++)
    {
        cnt=0;
        for (int j=0;j<m;j++)
        {
            if (b[j*n+i].v<b[j*n+i+1].v) cnt++;
            a[b[j*n+i].p].sol+=cnt;
        }
    }
    int ans=a[0].sol;
        for (int i=0;i<n*m;i++)
            if (a[i].sol<ans) ans=a[i].sol;
        printf("%d\n",ans);


    return 0;
}
