#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    long long h[100000],p[100000];
    long long n,x,pl=0,pd=0;
    long long t=0,cnt=0;
    scanf("%lld %lld",&n,&x);
    long long k; bool ok=false;
    for (long long i=0;i<n;i++)
        {
            scanf("%lld %lld",&p[i],&h[i]);
            if (p[i]>x)
            if (!ok) {ok=true; k=i;}
        }
        if (n==1)
            {
                printf("1\n");
                if (p[0]-x>0) printf("%lld\n",p[0]-x);
                else printf("%lld\n",x-p[0]);
                return 0;
        }
        long long m;
        long long last;
    while (k+pd<n && k-1-pl >=0)
    {
        ok=false;
        if (h[k+pd] == h[k-1-pl]) ok=true;
        if (h[k+pd] > h[k-1-pl]) {m=h[k-1-pl];h[k+pd]-=m;h[k-1-pl]=0;}
        else {m=h[k+pd];h[k-1-pl]-=m;h[k+pd]=0;}
        cnt+=2*m;
        t+=(p[k+pd]-x)+(p[k+pd]-p[k-1-pl])+(m-1)*2*(p[k+pd]-p[k-1-pl]);
        x=p[k-1-pl];
        last=(p[k+pd]-p[k-1-pl]);
        if (ok) {pl++;pd++;continue;}
        if (h[k+pd] > h[k-1-pl]) pl++;
        else pd++;
    }
    if (k-1-pl<0)
        if (k+pd<n) {t+=last;cnt++;}
    printf("%lld\n",cnt);
    printf("%lld\n",t);



    return 0;
}
