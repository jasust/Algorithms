#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

int main()
{
    int a[15],n,k;
    a[0]=-1;
    scanf("%d %d",&n,&k);
    for (int i=1;i<=n;i++)
        scanf("%d",&a[i]);
        if (n==1)
        {
            printf("0\n");
            printf("1\n");
            return 0;
            }
     if (n==2)
     {
         if (k==1)
        {
            printf("0\n");
            printf("1 1\n");
            return 0;
            }
         printf("%d\n",abs(a[1]-a[2]));
         printf("1 2\n");
         return 0;
     }
    if (n==3)
    {
        if (k==1)
        {
            printf("0\n");
            printf("1 1 1\n");
            return 0;
            }
            if (k==2)
            {
                int m1,m2,m3;
                m1=abs(a[1]+a[2]-a[3]);
                m2=abs(a[1]+a[3]-a[2]);
                m3=abs(a[2]+a[3]-a[1]);
                int minimum;
                if (m1<m2) minimum=m1;
                else minimum=m2;
                if (m3<minimum) minimum=m3;
                printf("%d\n",minimum);
                if (minimum==m1) printf("1 1 2\n");
                else if (minimum==m2) printf("1 2 1\n");
                else if (minimum==m3) printf("2 1 1\n");
            }
            if (k==3)
            {
                sort (a,a+4);
                printf("%d\n",abs(a[3]-a[1]));
                printf("1 2 3\n");
            }
            return 0;
    }

    if (k==1)
    {
        printf("0\n");
        for (int i=0;i<n;i++)
            printf("1 ");
        printf("\n");
        return 0;
    }

    if (n==k)
    {
        sort(a,a+n+1);
        printf("%d\n",abs(a[n]-a[1]));
        for (int i=1;i<=n;i++)
            printf("%d ",i);
        printf("\n");
    }

    return 0;
}
