#include <cstdio>

int main()
{
    int n, m, min=99999, o=0;
    long long a[300][300];
    scanf("%d %d", &n, &m);

    for (int i=1; i<=n; i++)
    for (int j=1; j<=m; j++) scanf("%lld", &a[i][j]);

    for (int i=1; i<=n; i++)
    for (int j=1; j<=m; j++)
    {
        for (int k=1; k<=m; k++) if ((a[i][j]>a[i][k]) and (j!=k)) o++;
        for (int k=1; k<=n; k++) if ((a[i][j]<a[k][j]) and (j!=k)) o++;

        if (o<min) min=o;
        o=0;
    }

    printf("%d", min);

	return 0;
}
