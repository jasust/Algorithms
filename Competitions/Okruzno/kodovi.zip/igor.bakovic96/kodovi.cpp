#include <cstdio>

int main()
{
    long long n;
    long long x[100000], k[100000], l, r, x1, s=0, minn, ss=0, o=2;
    scanf("%lld %lld", &n, &x1);

    for (int i=1; i<=n; i++) scanf("%d %lld", &x[i], &k[i]);

    if (x1<x[1]) { printf("%lld %d", x[1]-x1, 1); o=8;}
    if (x1>x[n]) { printf("%d %d", 0, 0); o=9;}

    if (o<5)
    {
    for (int i=1; i<=n; i++) if ((x[i-1]<=x1) and (x[i]>x1)) { l=i-1; r=i; }

    s=s+x[r]-x1;
    ss=ss+1;
    k[r]=k[r]-1;

    while (o<5)
    {
        if (k[r]<k[l]) minn=k[r]; else minn=k[l];

        ss=ss + 2*minn;
        s=s + 2*minn*(x[r]-x[l]);
        k[r]=k[r] - minn;
        k[l]=k[l] - minn;
        x1=x[r];

        if (k[l]==0) l--;
        if (k[r]==0)
        {
            if(l!=0)
            {
            r++;
            k[l]--;
            ss++;
            s=s+x1-x[l];
            x1=x[l];
            if (r!=n+1) { k[r]--; ss++; s=s+x[r]-x1; }
            } else o=15;
        }

        if (l==0) o=12;
        if (r==n+1) { if (l!=0) s=s+x1-x[l]; o=13;}
    }

    printf("%lld\n%lld", ss, s);
    }

    return 0;
}
