#include <cstdio>

int main()
{
    int n, k, bit[14], rez[14], c[14], o=2, ;
    long long x[14], r, l;
    scanf("%d %d", &n, &k);
    r=-1;
    l=100000000;

    for (int i=1; i<=n; i++)
    {
        scanf("%lld", &x[i]);
        bit[i]=1;
        rez[i]=0;
        if (x[i]>r) r=x[i];
        if (x[i]<l) l=x[i];
    }

    if (k>n) { printf("%d\n", r);  for (int i=1; i<=n; i++) printf("%d ", i); o=12;}
    if (k==n) { printf("%d\n", r-l);  for (int i=1; i<=n; i++) printf("%d ", i); o=12;}

    if (o<5)
    {
    bit[n+1]=0;
    long long sum=100000000;

    while (bit[n+1]==0)
    {
        bit[1]++;
        long long minn=100000000;
        long long maxx=-1;

        for (int i=1; i<=n; i++) if (bit[i]==k+1) {bit[i]=1; bit[i+1]++;}

        for (int i=1; i<=n; i++) rez[bit[i]]=rez[bit[i]]+x[i];

        for (int i=1; i<=k; i++)
        {
                if (rez[i]<minn) minn=rez[i];
                if (rez[i]>maxx) maxx=rez[i];
        }
        if ((maxx-minn)<sum) {sum=(maxx-minn); for (int i=1; i<=n; i++) c[i]=bit[i];}

        for (int i=1; i<=k; i++) rez[i]=0;
    }

    printf("%d\n", sum);
    for (int i=1; i<=n; i++) printf("%d ", c[i]);
    }

    return 0;
}
