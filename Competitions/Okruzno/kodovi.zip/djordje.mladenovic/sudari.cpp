#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{int n,m;
cin>>m;
cin>>n;
int lav[n][m];
long long int k;
int x,y;
cin>>x;
cin>>y;
cin>>k;

char ch;
for(int i=0;i<m;i++)
for(int j=0;j<n;j++)
{cin>>ch;
if(ch=='.')
lav[i][j]=1;
if(ch=='#')
lav[i][j]=2;
} 
int smer=1;

while(k!=0)
{
if(smer>4){smer=1;}

if(smer==1)
{if((lav[y+1][x]==1)&&((y+1)<=m-1))
y++;
else
{k--;
smer++;}}
if(smer==2)
{if((lav[y][x+1]==1)&&((x+1)<=n-1))
x++;
else
{k--;
smer++;}}
if(smer==3)
{if((lav[y-1][x]==1)&&((y-1)>=0))
y--;
else
{k--;
smer++;}}
if(smer==4)
{if((lav[y][x-1]==1)&&((x-1)>=0))
x--;
else
{k--;
smer++;}}
}
cout<<x+1<<" ";
cout<<y+1;

getchar();getchar(); 
 return 0;   }
