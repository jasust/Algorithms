#include<iostream>
#include<stdio.h>
using namespace std;
int front[1000][1000];
class vojnik
{private:
      int x,y,nf;
public:
void unos(){cin>>x;cin>>y;
front[1000-y][x]=1;
}
void proveri()
{int brr=0;
     for(int i=0;i<1000-y+1;i++)
for(int j=x;j<1000;j++)
if(front[i][j]==1)
{brr++;}
if(brr>1)
{nf=2;}}
void set_nf(){nf=1;}
int get_nf(){int nnf=nf;
return nnf;}


};
int main()
{for(int i=0;i<1000;i++)
for(int j=0;j<1000;j++)
{front[i][j]=0;}

int n,br=0;
cin>>n;
    vojnik v[n];
    for(int i=0;i<n;i++)
 {v[i].set_nf();
         }
 for(int i=0;i<n;i++)
 {v[i].unos();
         }
 for(int i=0;i<n;i++)
 {v[i].proveri();
 }
 for(int i=0;i<n;i++)
 {if(v[i].get_nf()==1){br++;}}
 cout<<br;

    return 0;}
    
    
    
    
    
