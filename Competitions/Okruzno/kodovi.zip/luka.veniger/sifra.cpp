#include <cstdio>
#include <cstdlib>
#include<algorithm>

using namespace std;
int n,m,a[100001],k;


int main() {
    scanf("%d %d %d", &n,&m,&k);
    for (int i=1;i<=n;i++)
        scanf("%d", &a[i]);
        sort(a+1,a+n+1);

    printf("%d\n", a[k]);







    return 0;
}
