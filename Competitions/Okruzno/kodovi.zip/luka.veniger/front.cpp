#include <cstdio>
#include <algorithm>
#include <cstdlib>

using namespace std;

int n,x[1000005],y[1000005],br,br2,solucija;

int main() {
    scanf("%d", &n);
    for (int i=1;i<=n;i++)
        scanf("%d %d", &x[i],&y[i]);

    for(int c=1;c<=n;c++){
        if( x[c]<=x[c+1]  and y[c]<=y[c+1]) br++;
         else if(y[c]==y[c+1]) br2++;

    }

    solucija=n-br-br2;


    printf("%d\n", solucija);









    return 0;
}
/*
6
0 1
1 5
3 2
3 5
4 4
5 4 */
