#include <cstdio>
#include <algorithm>
using namespace std;

struct chapter {
    int index;
    int num;
    int per;
};

struct niz {
    int per;
    int sum;
};

int n, k, i, j, optimalNum, sol, sum, visak, x;
chapter a[15];
niz perica[15], temp;

bool cmpChapter(chapter a, chapter b) {
    return a.num < b.num;
}

bool cmpChapterOrgnl(chapter a, chapter b) {
    return a.index < b.index;
}

int main() {
    scanf("%d%d", &n, &k);
    for (i = 1; i <= n; ++i) {
        scanf("%d", &(a[i].num));
        a[i].index = i;
        sum += a[i].num;
    }
    sort(a + 1, a + 1 + n, cmpChapter);
    if (k > n) {
        printf("%d\n", a[n].num);
        for (i = 1; i <= n; ++i) {
            printf("%d ", i);
        }
        return 0;
    }
    if (k == n) {
        printf("%d\n", a[n].num - a[1].num);
        for (i = 1; i <= n; ++i) {
            printf("%d ", i);
        }
        return 0;
    }
    visak = n - k;
    for (i = n; i > visak; --i) {
        a[i].per = n - i + 1;
        perica[n - i + 1].sum = a[i].num;
        perica[n - i + 1].per = n - i + 1;
    }
    for (i = 1; i <= visak; ++i) {
        //for (j = 1; j <= k; ++j) {
        //    a[i].per = n - i + 1;
        a[i].per = perica[k].per;
        perica[k].sum += a[i].num;
        x = k;
        while (x > 1 && perica[x].sum > perica[x - 1].sum) {
            temp = perica[x - 1];
            perica[x - 1] = perica[x];
            perica[x] = temp;
            --x;
        }
    }
    sol = perica[1].sum - perica[k].sum;
    printf("%d\n", sol);
    sort(a + 1, a + 1 + n, cmpChapterOrgnl);
    for (i = 1; i <= n; ++i) {
        printf("%d ", a[i].per);
    }
    return 0;
}
