#include <cstdio>
#include <algorithm>
using namespace std;

int n, x, i, p[100005], h[100005], lastLeft, cLeft, cRight, lessH;
long long l, d, sol1, sol2;
bool left;

int main() {
    scanf("%d%d", &n, &x);
    for (i = 1; i <= n; ++i) {
        scanf("%d%d", p + i, h + i);
        left = p[i] < x;
        ((left) ? l : d) += h[i];
        if (left) {
            lastLeft = i;
        }
    }
    if (l == 0) {
        printf("1\n%lld\n", p[1] - x);
        return 0;
    }
    sol1 = 2 * min(l, d) + (d > l);
    cLeft = lastLeft;
    cRight = lastLeft + 1;
    sol2 = p[cLeft] - x;
    while (cLeft > 0 && cRight <= n) {
        lessH = min(h[cLeft], h[cRight]);
        sol2 += abs(p[cLeft] - p[cRight]) * 2LL * lessH;
        if (h[cLeft] == h[cRight]) {
            --cLeft;
            ++cRight;
        } else if (lessH == h[cLeft]) {
            --cLeft;
            h[cRight] -= lessH;
        } else if (lessH == h[cRight]) {
            ++cRight;
            h[cLeft] -= lessH;
        }
    }
    if (cLeft == 0 && cRight <= n) {
        sol2 += abs(p[1] - p[cRight]);
    } else if (cRight > n && cLeft > 0) {
        sol2 += abs(p[cLeft] - p[n]);
    }
    printf("%lld\n%lld\n", sol1, sol2);
    return 0;
}
