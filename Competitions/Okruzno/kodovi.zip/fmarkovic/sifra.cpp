#include <iostream>
#include <stdio.h>
#include <algorithm>
using namespace std;

bool sorter(int a, int b) {
return a < b;
}


int main () {
    int m,n;
    long long k;
    scanf("%d %d %lld",&n,&m,&k);
    long niz [n];

    for (int i = 0; i < n; i++ ){
        cin>>niz[i];
    }
    sort(niz, niz+n, sorter);
    printf("%d",niz[k-1]);


return 0;
}
