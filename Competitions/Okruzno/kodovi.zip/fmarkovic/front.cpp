#include <iostream>
#include <stdio.h>

using namespace std;

int main () {

    long  n, xv, yv;
    long brojac1 = 0;
    long brojac2 = 0;
     // brojac1 broji borce na frontu gore desno, brojac dva vojnike van fronta
    //broj VOJNIKA, x koordinata tekuceg, y koordinata tekuceg

    scanf("%ld", &n);

    int matrica [n][2]; // MATRICA IMA N MESTA

    for (long i = 0; i < n; i++){ // RADI :)
        scanf("%ld %ld", &xv, &yv);
        matrica [i][0] = xv;
        matrica [i][1] = yv;
    }
        for (long i = 0; i < n; i++){

            for (long j = i + 1; j < n; j++){ // i + 1 jer x koordinata ne moze biti MANJA

                if (matrica [j][1] >= matrica [i][1]){
                    brojac1+=1;
                }
                if (j == n-1){ //do kraja
                    if(brojac1 == 0){ //ako nema boraca gore desno
                        brojac2+=1;    //ovo je za PRINTOVANJE
                    }
                    else {            //vrati na nulu za sledece brojanje
                        brojac1 = 0;
                    }
                }
            }
    }

    printf("%ld", brojac2);
    //NALAZI 2 umesto 3


return 0;
}
