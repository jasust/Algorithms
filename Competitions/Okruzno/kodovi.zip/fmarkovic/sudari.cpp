#include <iostream>
#include <stdio.h>

using namespace std;


int main () {


    int n,m,y,x,k;
    scanf("%d %d", &n, &m);
    char matrica [m+5][n+5];
    char temp [m+5];
    scanf("%d %d", &y, &x);
    scanf("%d", &k);
    for (int i = 1; i < n; i++){
        scanf("%s",temp);

    }


return 0;
}
