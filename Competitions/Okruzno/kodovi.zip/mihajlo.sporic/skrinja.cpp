#include <stdio.h>
int abs(int x)
{if(x<0) return -x;
 return x;
    }
    
int max(int a,int b,int c)
{if(a>b)
   {if(a>c) return a;
    return c;
   }
if(b>c) return b;
    return c;
   
}
int min(int a,int b,int c)
{if(a<b)
   {if(a<c) return a;
    return c;
   }
if(b<c) return b;
    return c;
   
}

int main()
{int n,k,i,a[20];
 scanf("%d %d", &n,&k);
 for(i=0;i<n;i++)
  scanf("%d",&a[i]);
 if(n==1){if(k>1)printf("%d",a[0]);
         else printf("0");                          
          }
 if(n==2){if(k>2)printf("%d",max(a[0],a[1],0));
          else if(k==2)printf("%d",abs(a[1]-a[0]));
          else printf("0"); 
          }
 if(n==3){if(k>3)printf("%d",max(a[0],a[1],a[2]));
          else if(k==3) printf("%d",max(a[0],a[1],a[2])-min(a[0],a[1],a[2]));
          else if(k==2) printf("%d",abs(2*max(a[0],a[1],a[2])-(a[0]+a[1]+a[2])));     
          else printf("0");                 
          }
 return 0;}
