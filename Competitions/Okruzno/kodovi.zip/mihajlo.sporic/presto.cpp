#include <stdio.h>
int main()
{int ok=0,m,n,i,j,max=0,min=2000000000;
 int h[300][300],a[300],b[300];
 scanf("%d %d", &m,&n);
 for(i=0;i<n;i++)
  for(j=0;j<m;j++)
   scanf("%d", &h[i][j]);
 
for(i=0;i<n;i++)
  {for(j=0;j<m;j++)
   if(h[i][j]<min) min=h[i][j];
   a[i]=min; min=2000000000;
   }
for(j=0;j<m;j++)
  {for(i=0;i<n;i++)
   if(h[i][j]>max) max=h[i][j];
   b[j]=max; max=0;
   }
for(i=0;i<n;i++)
  for(j=0;j<m;j++)
   if(a[i]<=b[j]) ok=1;
if(ok)printf("0");
else printf("1");
 return 0;
}
