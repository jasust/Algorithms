#include <stdio.h>
long long int p[10000],h[10000],t=0,br=0;
short s=1;
int n;
void f(int l,int d,int x,int s)
{
 if(s)
  {   
      if(h[l]+1<h[d])
      {
         t+=p[d]-x+(h[l]*2+1)*(p[d]-p[l]);
         br+=h[l]*2+1;
         h[d]-=h[l]+1;
         if(l-1==-1) {t-= p[d]-p[l];   return;}
         f(l-1,d,p[l],0);            
      }
      else if(h[l]+1==h[d])
           {t+=p[d]-x+(h[l]*2+1)*(p[d]-p[l]);
            br+=h[l]*2+1;
            if(l-1==-1) {t-= p[d]-p[l];   return;}
            else if(d+1==n){t+=p[l]-p[l-1]; br++; return;}
            f(l-1,d+1,p[l],0);
           }
      else if(h[l]==h[d])
           {t+=p[d]-x+h[l]*2*(p[d]-p[l]);
            br+=h[l]*2;
            if(d+1==n) {t-= p[d]-p[l];   return;}
            else if(l-1==-1){t+=p[d+1]-p[d]; br++; return;}
            f(l-1,d+1,p[d],1);
           }
      else
      {
         t+=p[d]-x+h[d]*2*(p[d]-p[l]);
         br+=h[d]*2;
         h[l]-=h[d];
         if(d+1==n) {t-= p[d]-p[l];   return;}
         f(l,d+1,p[d],1);            
      }
  }
 else
  {
      if(h[l]<h[d])
      {
         t+=x-p[l]+h[l]*2*(p[d]-p[l]);
         br+=h[l]*2;
         h[d]-=h[l];
         if(l-1==-1) {t-= p[d]-p[l];   return;}
         f(l-1,d,p[l],0);            
      }
      else if(h[l]==h[d])
           {t+=x-p[l]+h[l]*2*(p[d]-p[l]);
            br+=h[l]*2;
            if(l-1==-1) {t-= p[d]-p[l];   return;}
            else if(d+1==n){t+=p[l]-p[l-1]; br++; return;}
            f(l-1,d+1,p[l],0);
           }
      else if(h[l]==h[d]+1)
           {t+=x-p[l]+(h[d]*2+1)*(p[d]-p[l]);
            br+=h[d]*2+1;
            if(d+1==n) {t-= p[d]-p[l];   return;}
            else if(l-1==-1){t+=p[d+1]-p[d]; br++; return;}
            f(l-1,d+1,p[d],1);
           }
      else
      {
         t+=x-p[l]+(h[d]*2+1)*(p[d]-p[l]);
         br+=h[d]*2+1;
         h[l]-=h[d]+1;
         if(d+1==n) {t-= p[d]-p[l];   return;}
         f(l,d+1,p[d],1);            
      }
  }
     }
int main()
{int i,l,d;
 long long int x;
 scanf("%d %lld", &n,&x);
 for(i=0;i<n;i++)
  scanf("%lld %lld",&p[i],&h[i]);
 if(x<p[0]) printf("1\n%lld",p[0]-x);
 else{i=0;
      while(!(x>p[i]&&x<p[i+1]))
      {i++;}
      l=i; d=i+1;
      f(l,d,x,s);
      printf("%lld\n%lld",br,t);
 }
 return 0;}
