#include<stdio.h>
#include<algorithm>
long long a[50];

using namespace std;
main()
{
	int n,x;
	scanf("%i%i", &n, &x);
	int s=0;
	for(int i=0;i<n;i++)
	scanf("%lld", &a[i]);
	sort(a, a+n);
	if(n<=3)
	{
		if(x>n)
		{
			int min=a[0];
			for(int i=0;i<n-1;i++)
			if(a[i+1]-a[i]<min)min=a[i+1]-a[i];
		}
		else
		{
			if(n==1)printf("0");
			if(n==2)printf("%lld", a[1]-a[0]);
			if(n==3 && a[1]+a[2]>a[3])
			printf("%lld", a[1]+a[2]-a[3]); 
			else printf("%lld", -a[1]-a[2]+a[3]);
		}
		
		
	}
	
	
	
}
