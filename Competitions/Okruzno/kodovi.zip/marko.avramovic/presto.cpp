#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
    int a[300][300];
    int n, m;
    int min=1000, k;
    scanf("%i%i", &n, &m);
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
    scanf("%i", &a[i][j]);
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
    {
        k=0;
        for(int x=0;x<n;x++)
            if(a[x][j]<a[i][j])k++;
        for(int y=0;y<n;y++)
            if(a[i][y]>a[i][j])k++;
        if(k<min)min=k;
    }
    printf("%i", min);


    return 0;
}

