#include <iostream>
#include <cstdio>
using namespace std;
long long p[100000];
long long h[100000];
int main()
{
    long long x, n, t=0, d=1,q=0;
    long long a, b;
    scanf("%lld%lld", &n, &x);

    for(int i=0;i<n;i++)
    {
        scanf("%lld%lld", &p[i], &h[i]);
        if(x>p[i]){a=i;b=i+1;}
    }
    t=p[a]-x;
        while(a>=0 && b<n)
        {
            if(d==1)
            {
                if(h[a]>=h[b])
                {
                    t+=h[b]*(p[b]-p[a])*2;
                    q+=2*h[b];
                    b++;
                }
                else
                {
                    t+=h[a]*(p[b]-p[a])*2;
                    q+=2*h[a];
                    a--;
                    d=-1;
                }
            }
            else
            {
                if(h[a]>h[b])
                {
                    t+=h[b]*(p[b]-p[a])*2;
                    q+=2*h[b];
                    b++;
                    d=1;
                }
                else
                {
                    t+=h[a]*(p[b]-p[a])*2;
                    q+=2*h[a];
                    a--;
                }
            }
        }
        if(a==-1)t-=(p[b]-p[0]);
            else t-=(p[n-1]-p[a]);
        cout<<q-1<<endl<<t;
    return 0;
}
