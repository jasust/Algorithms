#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

struct polje{
    int p;
    int h;
};

int main()
{
    int N, X;
    scanf("%d %d", &N, &X);
    vector<polje> levi(N);
    vector<polje> desni(N);
    int t1, t2;
    int n = 0;
    int m = 0;
    for(int i = 0; i < N; i++){
        scanf("%d %d", &t1, &t2);
        if(t1 < X){
            levi[n].p = t1;
            levi[n].h = t2;
            n++;
        }else{
            desni[m].p = t1;
            desni[m].h = t2;
            m++;
        }
    }
    int smer = 1;
    int poc = 0;
    long long t = 0;
    long long br = 0;
    n--;
    bool k = true;
    while(k){
        if(smer == 1){
            t += desni[poc].p - X;
            desni[poc].h--;
            X = desni[poc].p;
            if(desni[poc].h == 0)
                poc++;
        }else{
            t += X - levi[n].p;
            levi[n].h--;
            X = levi[n].p;
            if(levi[n].h == 0)
                n--;
        }
        smer = 1 - smer;
        if((smer == 1) && (poc == m))
            k = false;
        else if((smer == 0) && (n < 0))
            k = false;
        br++;
    }

    printf("%lld\n%lld", br, t);

    return 0;
}
