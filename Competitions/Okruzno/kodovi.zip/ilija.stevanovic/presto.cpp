#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

int brkol(vector<vector<int> >& a, int N, int j, int br){
    int b = 0;
    for(int i = 0; i < N; i++){
        if(a[i][j] > br)
            b++;
    }
    return b;
}

int brred(vector<vector<int> >& a, int M, int i, int br){
    int b = 0;
    for(int j = 0; j < M; j++){
        if(a[i][j] < br)
            b++;
    }
    return b;
}

int main()
{
    int N, M;
    scanf("%d %d", &N, &M);
    vector<vector<int> > a(N, vector<int>(M, 0));

    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++)
            scanf("%d", &a[i][j]);
    }

    int br = 0;
    int minbr = N+M;
    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++)
           br = brred(a, M, i, a[i][j]) + brkol(a, N, j, a[i][j]);
           if(br < minbr)
                minbr = br;
    }

    printf("%d", minbr);
    return 0;
}
