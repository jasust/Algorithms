#include <cstdlib>
#include <iostream>

using namespace std;
int sifra[100005], a[100005];

int main(int argc, char *argv[])
{
    int m, n;
    long long k;
    scanf("%d%d%lld", &n, &m, &k);
    --k;
    for(int i=0; i<n; ++i)
    {
            scanf("%d", &a[i]);
    }
    for(int i=m-1; i>=0; --i)
    {
            sifra[i]=k%n;
            k/=n;
    }
    for(int i=0; i<m; ++i)
    {
            printf("%d ", a[sifra[i]]);
    }
    return EXIT_SUCCESS;
}
