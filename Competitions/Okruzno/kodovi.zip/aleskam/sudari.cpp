#include <cstdlib>
#include <iostream>
#include <cstring>

using namespace std;

bool lavirint[500][500];
long long bio[500][500][4];
int n, m,  xt, yt, s=0, tren=0, duzina_periode;
char g[500];
long long k;

void sudar()
{
     
     ++s;
     s%=4;
     ++tren;
}



void pomeri_se()
{
     if(s==0)
     {
             if(yt==n-1)
             {
                        sudar();
                        return;
             }
             else if(lavirint[xt][yt+1])
             {
                       sudar();
                       return;
             }
             else
             {
                        ++yt;
                        return;
             }
     }
     if(s==1)
     {
             if(xt==m-1)
             {
                        sudar();
                        return;
             }
             else if(lavirint[xt+1][yt])
             {
                        sudar();
                        return;
             }
             else
             {
                        ++xt;
                        return;
             }
     }
     if(s==2)
     {
             if(yt==0)
             {
                        sudar();
                        return;
             }
             else if(lavirint[xt][yt-1])
             {
                        sudar();
                        return;
             }
             else
             {
                        --yt;
                        return;
             }
     }
     if(s==3)
     {
             if(xt==0)
             {
                        sudar();
                        return;
             }
             else if(lavirint[xt-1][yt])
             {
                        sudar();
                        return;
             }
             else
             {
                        --xt;
                        return;
             }
     }
}


int main(int argc, char *argv[])
{
    
    scanf("%d%d%d%d%lld", &n, &m, &yt, &xt, &k);
    --xt;
    --yt;
    for(int i=0; i<n; ++i)
    {
            
            scanf("%s", &g);
            for(int j=0; j<m; ++j)
            {
                    
                    
                    
                    if(g[j]==46)
                    {
                             lavirint[j][i]=false;
                             bio[j][i][0]=-1;
                             bio[j][i][1]=-1;
                             bio[j][i][2]=-1;
                             bio[j][i][3]=-1;
                    }
                    else
                    {
                             lavirint[j][i]=true;
                             bio[j][i][0]=-2;
                             bio[j][i][1]=-2;
                             bio[j][i][2]=-2;
                             bio[j][i][3]=-2;
                    }
            }
    }
    
    bool radi=true;
    while(radi)
    {
               
               pomeri_se();
               if(tren == k)
               {
                       break;
               }
               if(bio[xt][yt][s]>=0)
               {
                       duzina_periode=tren-bio[xt][yt][s];
                       radi=false;
               }
               else
               {
                   bio[xt][yt][s]=tren;
               }
    }
    
    if(radi)
    {
            ++xt;
            ++yt;
            printf("%d %d", yt, xt);
    }
    else
    {
            int r=(k-tren)%duzina_periode;
            tren=0;
            while(tren<r)
            {
                         pomeri_se();
            }
            ++xt;
            ++yt;
            printf("%d %d", yt, xt);
    }
    
    return EXIT_SUCCESS;
}
