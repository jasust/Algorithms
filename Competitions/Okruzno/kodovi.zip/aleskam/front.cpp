#include <cstdlib>
#include <iostream>

using namespace std;

struct tacka
{
       int x;
       int y;
};
tacka v[1000000];



int main(int argc, char *argv[])
{
    int n, xt, max=0;
    scanf("%d", &n);
    for(int i=0; i<n; ++i)
    {
            
            scanf("%d%d", &v[i].x, &v[i].y);
            if(v[i].x==xt)
            {
                          if(v[i].y<max)
                          {
                                        v[i].x=-1;
                                        v[i].y=-1;
                          }
            }
            else
            {
                          xt=v[i].x;
                          max=v[i].y;
            }
    }
    int f=0, visina=0;
    for(int i=n-1; i>=0; --i)
    {
            if(v[i].y>visina)
            {
                             ++f;
                             visina=v[i].y;
                             if(i)
                             {
                                           if(v[i].y<v[i-1].y&&v[i].x==v[i-1].x)
                                           {
                                                                               --f;
                                           }
                             }
            }
            

    }
    printf("%d", f);
    
    return EXIT_SUCCESS;
}
