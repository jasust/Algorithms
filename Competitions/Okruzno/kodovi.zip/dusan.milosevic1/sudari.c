#include <stdio.h>
#include <stdlib.h>

int main()
{
	int m, n, y, x, k, i, j, mode = 0;
	char M[501][501];
	
	
	if(scanf("%d %d", &n, &m) == 2);
	if(scanf("%d %d", &y, &x) == 2);	
	if(scanf("%d", &k) == 1);
	
	for(i = 0; i < n; i++)
	{
		for(j = 1; j <= m; j++)
		{
			if(scanf("%c", &M[i][j]) == 1);
		}	
	}
	
	while (k > 0)
	{
		if(mode == 0)
		{
			if((y + 1 > n) || M[x][y + 1] == '#')
			{
				k--;
				mode++;						
			}
			else
			{
				y++;
			}
		}
		else if(mode == 1)
		{
			if((x + 1 > m) || M[x + 1][y] == '#')
			{
				k--;
				mode++;				
			}
			else
			{
				x++;
			}
		}
		else if(mode == 2)
		{
			if((y - 1 < 1) || M[x][y - 1] == '#')
			{
				k--;
				mode++;			
			}
			else
			{
				y--;
			}
		}
		else if(mode == 3)
		{
			if((x - 1 < 1) || M[x - 1][y] == '#')
			{
				k--;
				mode++;				
			}
			else
			{
				x--;
			}
		}
		else if (mode == 4)
		{
			mode = 0;
			if((y + 1 > n) || M[x][y + 1] == '#')
			{
				k--;
				mode++;				
			}
			else
			{
				y++;
			}			
		}	
	}	
	
	printf("%d %d\n", y, x);
	

	return 0;
}
