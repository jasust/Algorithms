#include <stdio.h>
#include <stdlib.h>

int main()
{
	int N;
	int M;
	int K;
	int A[100000];
	int i;
	
	if(scanf("%d %d %d", &N, &M, &K) == 3);
	
	for (i = 0; i < N; i++)
	{
		if(scanf("%d", &A[i]) == 1);
		
	}
	
	printf("%d", A[K - 1]);
	
	return 0;
}
