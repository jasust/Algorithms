#include <stdio.h>
#include <stdlib.h>

int main()
{
	int N;
	int i;
	int j;
	int x[100000];
	int y[100000];
	int num = 0;
	int arr[100000];
	
	if(scanf("%d", &N) == 1);
	
	for (i = 0; i < N; i++)
	{
		arr[i] = 0;
	}
	
	for (i = 0; i < N; i++)
	{
		if(scanf("%d %d", &x[i], &y[i]) == 2);
	}
	
	for (i = 0; i < N - 1; i++)
	{
		for (j = i + 1; j < N; j++)
		{
			if (y[i] <= y[j])
			{
				arr[i]++;	
			}

		}
	}
	
	for (i = 0; i < N; i++)
	{
		if (arr[i] == 0)
		{
			num++;
		} 
	}
	
	printf("%d\n", num);
		
	return 0;	
}
