#include<cstdio>
#include<cstdlib>
#include<string>

using namespace std;

int n, m, x, y, pointerx, pointery, smer;
long long int k;
char mat[500][500];
string t, unos;
bool kret;


int main (){

    scanf("%d %d", &n, &m);
    scanf("%d %d", &y, &x);
    scanf("%lld", &k);

    for(int q=1; q<=n; q++){
        scanf("%s", &unos);
        for(int w=1; w<=m; w++){
            mat[q][w] = unos[w];
        }
    }

    pointery = y;
    pointerx = x;

    smer = 1;

    for(int q=1; q<=k; q++){
        kret = true;
        while(kret = true){
            if(smer == 1){
                pointery++;
                t = mat[pointery+1][pointerx];
                if(t == "#"){
                    smer = 2;
                    kret = false;
                }

                if((t != "#") and (t != ".")){
                    smer = 2;
                }
            }

            if(smer == 2){
                pointerx++;
                t = mat[pointery][pointerx+1];
                if(t == "#"){
                    smer = 3;
                    kret = false;
                }
                if((t != "#") and (t != ".")){
                    smer = 3;
                }
            }

            if(smer == 3){
                pointery--;
                t = mat[pointery-1][pointerx];
                if(t == "#"){
                    smer = 4;
                    kret = false;
                }
                if((t != "#") and (t != ".")){
                    smer = 4;
                }
            }

            if(smer == 4){
                pointerx--;
                t = mat[pointery][pointerx-1];
                if(t == "#"){
                    smer = 1;
                    kret = false;
                }
                if((t != "#") and (t != ".")){
                    smer = 1;
                }
            }

        }
    }

    printf("%d %d", pointery, pointerx);
    return 0;

}
