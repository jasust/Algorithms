#include<cstdio>
#include<cstdlib>

using namespace std;

int N, x[1000005], y[1000005], x1, y1, brp, br;

int main(){

    scanf("%d", &N);

    for(int q=1; q<=N; q++){
        scanf("%d %d", &x[q], &y[q]);
    }

    for(int q=0; q<=N-1; q++){
        brp=0;
        for(int w=1; w<=N-q-1; w++){
            if((x[N-q]>=x[w])and(y[N-q]>=y[w])){
                brp++;
            }
        }

        if(brp == 1){
            br++;
        }

    }

    printf("%d\n", br);
    return 0;
}
