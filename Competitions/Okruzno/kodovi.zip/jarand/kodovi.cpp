#include <stdio.h>
#include <stdlib.h>
int main()
{
    int p[100000],h[100000],l,x,n,d,poz=0;
    long long lb=0,db=0,br=0,s=0;
    scanf("%d %d",&n,&x);
    for(int i=0;i<n;i++){
        scanf("%d %d",p+i,h+i);
    }
    while (p[poz]<x) poz++;
    l=poz;
    d=poz-1;
    while (1)
    if (db>lb){
        l--;
        if(l==-1){
            s+=(1-2*(db-lb))*(p[d]-x);
            br=2*lb+1;
            break;
            }
        lb+=h[l];
	s+=2*h[l]*(x-p[l]);
    }
    else {
        d++;
        if(d==n){
            s+=(1-2*(lb-db))*(x-p[l]);
            br=2*db;
            break;
            }
        db+=h[d];
	s+=2*h[d]*(p[d]-x);
    }
    printf("%lld\n%lld\n",br,s,s);
    return 0;
}
