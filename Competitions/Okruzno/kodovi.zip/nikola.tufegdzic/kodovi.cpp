#include <iostream>
#include <vector>

using namespace std;

struct listica
{
    listica* l;
    listica* d;
    long poz;
    long br;
};
struct pok
{
    listica* p;
    listica* k;
};
void pp(listica*& t)
{
    listica* z;
    z=t->l;
    t->l->d=t->d;
    t->d->l=z;
}

int main()
{
    long t=0;
    long uk=0;
    long n;
    long x;
    listica* sad;
    cin>>n>>x;
    pok ls;
    ls.p=0;
    ls.k=0;
    for(int i=0;i<n;i++)
    {
        if(ls.p==0)
        {
            ls.p= new listica;
            ls.k=ls.p;
            cin>>ls.p->poz>>ls.p->br;
            ls.p->l=0;
            ls.p->d=0;
            sad=ls.p;
        }
        else
        {
            listica* z= new listica;
            cin>>z->poz>>z->br;
            z->l=ls.k;
            z->d=0;
            ls.k->d=z;
            ls.k=z;
            z=0;
        }
        if((x>sad->poz)&&(x<ls.k->poz))
        {
            sad=ls.k;
        }
    }
    t=sad->poz-x;
    while(sad!=0)
    {
        if(sad->l==0)
        {
           sad=0;
           uk++;
        }
        else
        {
            if(sad->br<=sad->l->br)
            {
                t=t+(sad->poz-sad->l->poz)*sad->br*2;
                uk=uk+sad->br*2;
                if(sad->d==0)
                {
                    t=t-(sad->poz-sad->l->poz);
                    sad=0;
                }
                else
                {
                    t=t+sad->d->poz-sad->poz;
                    listica* sled=sad->d;
                    sad->l->br=sad->l->br-sad->br;
                    if(sad->br==0)
                    {
                        pp(sad->l);
                    }
                    pp(sad);
                    sad=sled;
                }
            }
            else
            {
               t=t+(sad->poz-sad->l->poz)*(sad->l->br*2+1);
               uk=uk+sad->l->br*2+1;
               if(sad->l->l==0)
                {
                    t=t-(sad->poz-sad->l->poz);
                    sad=0;
                }
                else
                {
                    t=t+sad->l->poz-sad->l->l->poz;
                    listica* sled=sad->l->l;
                    sad->br=sad->br-sad->l->br;
                    pp(sad->l);
                    sad=sled;
                }
            }
        }
    }
   cout<<uk<<" "<<t;
    return 0;
}
