#include<cstdlib>
#include<cstdio>
using namespace std;
int n,m,k,niz[100005],a[12],koef,koef2;
int main () {
    scanf("%d %d %d", &n,&m,&k);
    for(int i=0;i<n;i++){
        scanf("%d", &niz[i]);
    }
    k=k-1;
    koef=10;
    koef2=1;
    for(int i=m-1;i>=0;i--){
        a[i]=(k%koef)/koef2;
        koef=koef*10;
        koef2=koef2*10;
    }
    for(int i=0;i<m;i++){
        printf("%d ", a[i]);
    }
    return 0;


}
