#include<cstdlib>
#include<cstdio>
using namespace std;
int n,x[1005],y[1005],br,bru;
int main () {
    scanf("%d", &n);
    for(int i=0;i<n;i++){
        scanf("%d %d", &x[i],&y[i]);
    }
    bru=n;
    for(int i=0;i<n;i++){
        br=1;
        for(int c=i+1;c<n;c++){
            if((x[i]<=x[c]) and (y[i]<=y[c])) {bru--;break;}
        }
    }
    printf("%d", bru);
    return 0;
}
