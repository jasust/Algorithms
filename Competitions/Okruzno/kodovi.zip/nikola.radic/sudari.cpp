#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
#include<cstdlib>
using namespace std;
int lenn,lenm,y,x,k;
string n[505],m;
int main () {
    scanf("%d %d", &lenn,&lenm);
    scanf("%d %d", &y,&x);
    scanf("%d", &k);
    for(int i=0;i<lenn;i++){
        scanf("%s",&m);
        n[i]=m;
    }

    return 0;


}
