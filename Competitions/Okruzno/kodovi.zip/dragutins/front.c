#include <stdio.h>
#include <stdlib.h>

typedef struct{
    unsigned long int x;
    unsigned long int y;
} Point;


int main()
{
    unsigned long int N, i,k=0, count=0;

    scanf("%d", &N);
    Point points[N];

    i=0;
    for(; i<N; i++){
        scanf("%d %d", &points[i].x, &points[i].y);
    }

    i=0;
    for(; i<N; i++){
        k=i+1;
        for(; k<N; k++){
            if(points[i].x<=points[k].x && points[i].y<=points[k].y){
                i++;
                k=i+1;
            }
            if(k+1==N){
                count++;
            }
        }
    }

    printf("%d", count);
    return 0;

}
