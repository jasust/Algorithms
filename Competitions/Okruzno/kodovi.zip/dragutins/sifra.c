#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned long int N,M;
    unsigned long int K, i;

    scanf("%d %d %d", &N, &M, &K);

    unsigned long int A[N];
    unsigned long int test[M];

    i=0;
    while(i<N && scanf("%d", &A[i])){
        i++;
    }

    int temp;
    int b = K/N;
    float a = (float)((float)K/(float)N)-b;

    int na = a*100;

    test[M-1] = A[retNum(na,N)-1];






    i=2;
    for(;i<M+1;i++){
        temp = b;
        b = b/N; //Ceo broj
        a = (float)((float)temp/(float)N)-b; //Ostatak
        int na = a*100;

        test[M-i] = A[retNum(na,N)];
    }

    i=0;
    for(;i<M;i++){
        printf("%d", test[i]);
    }


    return 0;
}

int retNum(int num, int k){
    int e =100.0/(float)k;
    int te = e;
    int c=0;

    while(1){
        if(num<e){
            break;
        }
        else{
            e+=te;
            c++;
        }
    }

    return c;
}
