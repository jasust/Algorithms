#include <stdio.h>
#include <algorithm>
using namespace std;
long long a[100000000];
int main()
{
    int n,k,i,j=0,prosek;
    scanf("%d%d",&n,&k);
    for(i=0;i<n;i++)
    {
     scanf("%lld",&a[i]);
     j+=a[i];
    }
printf("1\n1 2 2 3 1");
}
