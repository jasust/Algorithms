#include <stdio.h>
#include <algorithm>
using namespace std;
 
 long long n,x,r,vr,p,k;//p i k su koordinate prvog(levog) i krajnjeg(desnog) skupa,vr je vreme, r je resenje
 long long pi[100000],hi[100000];//pi je niz koordinata,a hi niz broja kodova na datim koordinatama
int main()
{
   int i,j,poc;
   short s=1;//1-desno;0-levo
   r=0;
   vr=0;
   j=0;
   poc=-1;
   scanf("%lld%lld",&n,&x);
   for(i=0;i<n;i++)
   {
                   scanf("%lld%lld",&pi[i],&hi[i]);
                   if(pi[i]>x)   
                   if(poc==-1) poc=i;
                   else continue;              
                   
   }
   while(1)
   {
          if(s==1){                                
                         if(hi[n-1]==0)break;
                         x++;
                         vr++;
                         if(pi[poc]==x && hi[poc]==0)
                         {
                                       poc++;
                                       continue;
                                       }  
                         if(pi[poc]==x && hi[poc]>0){
                                      hi[poc]=hi[poc]-1;
                                      r++;
                                      s=0;
                                      poc--;
                                      }
                                     
                   }            
        if(s==0){
                 
                 if(hi[0]==0)break;
                 x--;
                 if(x<pi[0]) break;
                 vr++;
                 if(pi[poc]==x && hi[poc]==0)
                         {
                                       poc--;
                                       continue;
                                       }  
                 if(pi[poc]==x && hi[poc]>0){
                                      hi[poc]=hi[poc]-1;
                                      r++;
                                      s=1;
                                      poc++;
                                      }
                 }  
   }
   printf("%lld\n%lld",r,vr);
   return 0;
}
