#include <cstdlib>
#include <iostream>
#include<stdio.h>
#include <stdlib.h>
using namespace std;

int main(int argc, char *argv[])
{   int n,x,y,F,p,q;
    int i,j,k;
    F=0;
    p=0;
    q=0;
    scanf("%d",&n);
   for(k=0;k<n;k++){ 
    scanf("%d%d",&x,&y);
    if(x >= p && y>=q){
             p=x;
             q=y;
             F=F+1;               
             }
             }
             
                
        
                  
    printf("%d\n",F);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
