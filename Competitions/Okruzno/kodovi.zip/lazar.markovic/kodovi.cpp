#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

long long int sSec=0;
long long int sKod=0;
long int pre=-1, posle=-1;
long long int x, on;
const int MaxA=100024;
long long int n;
long long int pos[MaxA], value[MaxA];
int smer=1;

bool doSledeceg(){
    if (!smer && value[on]==0){
        bool over=true;
        for (int i=on+1; i<n; i++){
            if (value[i]>0){
                posle=i;
                on=posle;
                sSec+=pos[posle]-x;
                value[posle]--;
                smer=1;
                over=false;
            }
        }
        if (over){
            cout<<sKod<<endl;
            cout<<sSec;
            return false;
        }
    }else if (smer && value[on]==0){
        bool over=true;
        for (int i=on-1; i>=0; i++){
            if (value[i]>0){
                pre=i;
                sSec+=x-pos[pre];
                value[pre]--;
                smer=0;
                over=false;
            }
        }
        if (over){
            cout<<sKod<<endl;
            cout<<sSec;
            return false;
        }
    }
    return true;
}

int main(){
    cin>>n>>x;
    for (int i=0; i<n; i++){
        cin>>pos[i]>>value[i];
    }
    for (int i=0; i<n; i++){
        if (pos[i]<x){
            pre=i;
        }else if (pos[i]>x){
            posle=i;
            break;
        }
    }
    if (pre==-1 && posle>-1){
        smer=1;
        on=posle;
        doSledeceg();
        return 0;
    }else if (pre>-1 && posle==-1){
        cout<<0<<"\n";
        cout<<0;
        return 0;
    }else {
        //Inicijalizacija
        /////////////////////////
        for (int i=posle; i<n; i++){
            if (value[i]>0){
                sSec+=pos[posle]-x;
                sKod=1;
                value[posle]--;
                on=posle;
                smer=0;
                break;
            }
        }

        while (doSledeceg()){
            if (value[pre]>value[posle]){
                if (smer && value[posle]%2){
                    sSec+=(pos[posle]-pos[pre])+(pos[posle]-pos[pre])*value[posle]*2;
                    sKod+=value[posle];
                    value[pre]-=value[posle]*2+1;

                }
            }
        }
    }
    return 0;
}
