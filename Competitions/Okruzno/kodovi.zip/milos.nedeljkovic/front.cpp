#include<cstdio>

int main()
{
    int n, br = 0;

    int x[100000], y[100000];

    bool pro = true;

    scanf("%d", &n);

    for (int i = 1;i < n * 2;i = i + 2)
    {
        scanf("%d %d", &x[i - 1], &y[i]);
    }

    for (int i = 1;i < n * 2;i =i + 2)
    {
        for (int i2 = 1;i2 < i;i2 = i2 + 2)
        {
            if (x[i - 1] <= x[i2 - 1] && y[i] <= y[i2])
            {
                pro = false;
            }
        }

        for (int i2 = 2 + i;i2 < n * 2;i2 += 2)
        {
            if (x[i - 1] <= x[i2 - 1] && y[i] <= y[i2])
            {
                pro = false;
            }
        }

        if (pro == true)
        {
            br++;
        }

        pro = true;
    }

    printf("%d", br);

    return 0;
}
