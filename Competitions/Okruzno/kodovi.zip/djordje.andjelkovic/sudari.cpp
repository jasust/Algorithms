#include<cstdio>
using namespace std;
long long n,m;
int bio[4][500][500];
char map[500][501];
long long px,py,pravac=1;
long long k;
int ux[2000000];
int uy[2000000];
int main()
{
	scanf("%lld%lld",&n,&m);
	scanf("%lld%lld",&py,&px);
	scanf("%lld",&k);
	for(int i=0;i<n;i++)
	{
		scanf("%s",map[i]);
	}
	py--;px--;
	int sudar=0;
	while(true)
	{
		if(bio[pravac][py][px]==true)
		{
			break;
		}
		bio[pravac][py][px]=true;
		if(pravac==0)
		{
			if(py==0||map[py-1][px]=='#')
			{
				sudar++;
				pravac=2;
				ux[sudar-1]=px;
				uy[sudar-1]=py;
			}
			else
				py--;
		}
		else if(pravac==1)
		{
			if(py==n-1||map[py+1][px]=='#')
			{
				sudar++;
				pravac=3;
				ux[sudar-1]=px;
				uy[sudar-1]=py;
			}
			else
				py++;
		}
		else if(pravac==2)
		{
			if(px==0||map[py][px-1]=='#')
			{
				sudar++;
				pravac=1;
				ux[sudar-1]=px;
				uy[sudar-1]=py;
			}
			else
				px--;
		}
		else if(pravac==3)
		{
			if(px==m-1||map[py][px+1]=='#')
			{
				sudar++;
				pravac=0;
				ux[sudar-1]=px;
				uy[sudar-1]=py;
			}
			else
				px++;
		}
		
	}
	printf("%d %d\n",uy[(k%sudar)-1]+1,ux[(k%sudar)-1]+1);
	return 0;
}