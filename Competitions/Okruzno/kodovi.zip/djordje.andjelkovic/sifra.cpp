#include<cstdio>
#include<stack>
using namespace std;
long long n,m,k;
int niz[100000];
int main()
{
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&niz[i]);
	}
	stack<int> res;
	k--;
	for(int i=0;i<m;i++)
	{
		res.push(niz[k%n]);
		k/=n;
	}
	for(int i=0;i<m;i++)
	{
		printf("%d ",res.top());
		res.pop();
	}
	printf("\n");
	return 0;
}