#include<cstdio>
#include<map>
#include<algorithm>
using namespace std;
struct vojnik
{
	int x,y;
};
vojnik nik[1000000];
int main()
{
	int n,res=0;
	map<int,int> xosa;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d%d",&nik[i].x,&nik[i].y);
		if(xosa.count(nik[i].x))
		{
			if(nik[i].y>xosa[nik[i].x])
				xosa[nik[i].x]=nik[i].y;
		}
		else
			xosa[nik[i].x]=nik[i].y;
	}
	int tren=-1;
	for(map<int,int>::iterator it=--xosa.end();it!=--xosa.begin();it--)
	{
		if((it->second)>tren)
		{
			res++;
			tren=it->second;
		}
	}
	printf("%d\n",res);
	return 0;
}