#include <stdio.h>
#include <stdlib.h>
//#include <time.h>
int eq[100000];
int code[100000];
int main()
{

    //clock_t t1,t2;
    int n,m;//4
    scanf ("%d%d",&n,&m);//5
    long long int k;//1
    scanf ("%lld",&k);//3
    for (int i=0;i<n;i++)//10*100000
    {
        scanf ("%d",&eq[i]);
        //eq[i]=i;
    }
    //for (int i=0;i<n;i++)
    //    printf ("eq[%d]=%d\n",i,eq[i]);

    //t1=clock();
    int i=m-1;//2
    long long int start=k-1;//2
    while (i>=0)//100000*6
    {

        code[i]=start%n;
        //printf ("code[%d]=%d\n",i,code[i]);
        start=start/n;
        i--;
    }
    for (int i=0;i<m;i++)//11*100000
    {
      //code[i]=eq[code[i]];
      printf ("%d",eq[code[i]]);
      if (i!=m-1)
        printf (" ");
    }
    //t2=clock();
    //printf ("\nOk, done %.3f",float(t2-t1)/CLOCKS_PER_SEC);
    //printf ("\nSize: %d",sizeof(n)+sizeof(m)+sizeof(k)+sizeof(eq)+sizeof(code)+sizeof(t1)+sizeof(t2));
    return 0;
}
