#include <stdio.h>
#include <stdlib.h>
bool lavirint[500][500];
int main()
{
    int n,m;
    char c;
    long long int k;
    int y,x;
    int sigx,sigy;
    scanf("%d%d",&n,&m);
    scanf ("%d%d",&y,&x);
    y--;
    x--;
    scanf("%lld",&k);
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<m;j++)
        {
            scanf ("%c",&c);
            if (c=='.')
                lavirint[j][i]=true;
            else
                lavirint[j][i]=false;
        }
        scanf ("\n");
    }
    /*
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<m;j++)
        {
            if (lavirint[j][i]==true)
                printf ("O");
            else
                printf ("X");
        }
        printf("\n");
    }
    */
    long long int hits=0;
    int dir=2;
    while (hits<k)
    {
        switch (dir)
        {
            case 0:
            y--;
            if (y<0 || lavirint[x][y]==false)
            {
                hits++;
                dir=3;
                y++;
                sigx=-1;
                sigy=y-1;
            }
            break;

            case 1:
            x++;
            if (x>m-1||lavirint[x][y]==false)
            {
                hits++;
                dir=0;
                x--;
                sigy=-1;
                sigx=x+1;
            }
            break;
            case 2:
            y++;
            if (y>n-1 || lavirint[x][y]==false)
            {
                hits++;
                dir=1;
                y--;
                sigx=-1;
                sigy=y+1;
            }
            break;

            default:
            x--;
            if (x<0 || lavirint[x][y]==false)
            {
                hits++;
                dir=0;
                x++;
                sigx=x-1;
                sigy=-1;
            }



        }
    }
    if (sigy==-1)
        x=sigx;
    else
        y=sigy;

    printf ("%d %d",y+1,x+1);

    return 0;
}
