#include <stdio.h>

int main(){
    long long n, x, i, s=0, kod=0, poz;
    scanf("%lld%lld",&n,&x);
    long long p[n],h[n];
    scanf("%lld%lld",&p[i],&h[i]);
    for(i=1;i<n;i++){
                     scanf("%lld%lld",&p[i],&h[i]);
                     if(x>p[i-1]&&x<p[i]) poz=i;
    }
    while(h[0]==0||h[n-1]==0){
                              if(h[poz]!=0&&h[poz-1]!=0){
                                                         if(h[poz]>h[poz-1]){
                                                                             kod+=h[poz-1];
                                                                             h[poz-1]=0;
                                                                             h[poz]=h[poz]-h[poz-1];
                                                                             x=p[poz-1];
                                                                             s=(p[poz]-p[poz-1])*h[poz-1];
                                                         }
                                                         else{
                                                              kod+=h[poz];
                                                              h[poz]=0;
                                                              h[poz-1]=h[poz-1]-h[poz];
                                                              x=p[poz];
                                                              s=(p[poz]-p[poz-1])*h[poz];
                                                         }
                              }
    }
    printf("%lld\n%lld",kod,s);
    getchar();
    return 0;
}
