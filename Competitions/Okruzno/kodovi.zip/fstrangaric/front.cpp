#include  <cstdlib>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

int a,b,j,k,i,n,m,f;
struct {int x,y;}kord[1000009];
 int res,br;

int main ()
{

    scanf("%d",&n);

 for(int i=1;i<=n;i++)
 {
     scanf("%d %d",&kord[i].x,&kord[i].y);

 }
 if (n==1) {printf("%d\n",1);return 0;}

 for( int i=1;i<=n;i++)
 {
     for(int j=1;j<=n;j++)
     {
      if (((kord[i].x==kord[j].x) and (kord[i].y==kord[j].y)) or ( (kord[i].x<=kord[j].x) and (kord[i].y<=kord[j].y) ) ) {}
      else{br++; if (br==n-1){res++;} }

     }
     br=0;
 }
 printf("%d\n",res);
 return 0;
}

