#include  <cstdlib>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstring>
using namespace std;
int  a,i,j,l,n,m;
long long k;
struct {int x,y;}kor[2];
char str[1000];

int main ()
{
    scanf("%d %d",&n,&m);
    scanf("%d %d",&kor[1].x,&kor[2].y);
    scanf("%lld",&k);
    for(int i=0;i<=n-1;i++)
    {
        for(int j=0;j<=m-1;j++)
        {
            scanf("%c",&str[i][j]);
        }
    }

    return 0;
}
