#include<stdio.h>
#include<stdlib.h>
long long int x[1000000],y[1000000];
main()
{int i,n,j,F=1;
char c;
scanf("%d",&n);
for(i=0;i<n;i++)
{scanf("%lli",&x[i]);
scanf("%lli",&y[i]);
}
i=0;
j=n-1;
while(j!=i)
{if(y[i]>y[j])
{j--;
if (j==i) {F++;
j=n-1;i++;}
}
else {i++;j=n-1;}
}
printf("%d\n",F);
return 0;
}
