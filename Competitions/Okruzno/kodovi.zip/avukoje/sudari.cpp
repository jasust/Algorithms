#include<stdio.h>
#include<stdlib.h>
char mat[500][500];
main()
{
int n,m,y,x,k,i,j,x1,y1,gd=0,ld=0,brsud=0;
scanf("%d%d",&n,&m);
scanf("%d%d",&y,&x);
scanf("%d",&k);
y1=y-1;
x1=x-1;
for(j=0;j<n;j++)
for(i=0;i<m;i++)
scanf("%c",&mat[i][j]);

while(brsud!=k)
{if(gd==0){y1++;
if((mat[x1][y1]=='#')||(y1==n))
{brsud++;ld=0;y1--;}}   


if(gd==1){y1--;
if((mat[x1][y1]=='#')||(y1<0))
{brsud++;ld=1;y1++;}}
  
if(ld==0){x1++;
if((mat[x1][y1]=='#')||(x1==m))
{brsud++;gd=1;x1--;}}  

if(ld==1){x1--;
if((mat[x1][y1]=='#')||(x1<0))
{brsud++;gd=0;x1++;}}  
}
y1--;
x1--;
printf("%d %d\n",y1,x1);
system("pause");
}
