#include<cstdio>
#include<algorithm>
using namespace std;
int niz[100005],q,m,n,res[100005];
long long k,br;
int main(){
    scanf("%d %d %lld",&n,&m,&k);
    for(int i=1;i<=n;i++)scanf("%d",&niz[i]);
    br=1;
    for(int i=1;i<=m;i++)
        br=br*n;
    for(int i=1;i<=m;i++){
        br=br/n;
        q=0;
        while(br*q<k)q++;
        res[i]=niz[q];
        k=k-br*(q-1);
        }
    for(int i=1;i<=m;i++)printf("%d ",res[i]);
    printf("\n");

return 0;
}
