#include<algorithm>
#include<cstdio>
#include<cstdlib>
using namespace std;
int br,maxy,n;
struct slog{
int x,y;
bool operator  < (const slog &q)const{
  return((x<q.x) or ((x==q.x)and(y<q.y)));}

}niz[1000006];
int main(){
    scanf("%d",&n);
    br=1;
    for(int i=1;i<=n;i++) scanf("%d %d",&niz[i].x,&niz[i].y);
    sort(niz+1,niz+n+1);
    maxy=niz[n].y;
    for(int i=n-1;i>0;i--){
        if(niz[i].y>maxy){br++; maxy=niz[i].y;}
    }
    printf("%d\n",br);


return 0;
}
