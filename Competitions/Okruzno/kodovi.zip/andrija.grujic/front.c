#include <stdio.h>
#include <stdlib.h>

struct vojnik{
    int x;
    int y;
};
int main()
{
    int n,i;
    int f=0;
    struct vojnik vojnici[30];
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d %d",&vojnici[i].x,&vojnici[i].y);
    }
    for(i=0;i<n;i++){
            if(vojnici[i].y>=vojnici[i+1].y || vojnici[i].x>=vojnici[i+1].x){
                f++;
        }
    }
    printf("%d",f);
    return 0;
}
