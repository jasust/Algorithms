#include<stdio.h>

char a[500][500];
int main(){

int n,m,x,y,k,d=0;

scanf("%d%d",&n,&m);

scanf("%d%d",&x,&y);
scanf("%d",&k);
int i,j;

for(i=0;i<n;i++)
    for(j=0;j<n;j++)
    scanf("%c",&a[i][j]);


do{
if(d<k)
//dole
for(y;y>0;y--){
if(a[x][y]=='#'){
    d++;
    printf("dafsdffd");
}
break;
}



if(d<k)
//levo
for(x;x<=m;x++){
if(a[x][y]=='#'){
    d++;
}
break;
}

if(d<k)
//gore
for(y;y<=n;y++){
if(a[x][y]=='#'){
    d++;
}
break;
}

if(d<k)
//dwsno
for(x;x>0;x--){
if(a[x][y]=='#'){
    d++;
}
break;
}


}
while(d<k);
printf("%d %d",x,y);
return 0;
}
