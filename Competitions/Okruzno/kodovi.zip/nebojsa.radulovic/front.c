#include<stdio.h>

int x[10000000],y[10000000];
int main(){

int n,i,F=0,j,k=0;

scanf("%d",&n);
for(i=0;i<n;i++){
scanf("%d %d",&x[i],&y[i]);
}

for(i=0;i<n;i++)
    for(j=0;j<n;j++)
{
if(x[i]<=x[j] && y[i]<=y[j] && i!=j){
    k++;
break;
}
}

F=n-k;

printf("%d",F);
return 0;
}
