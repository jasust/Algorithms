#include <math.h>
#include <algorithm>
#include <stdio.h>

using namespace std;

int main()
{
	int n=0;
	long x=0;
	scanf("%d %ld", &n, &x);

	long p;
	long h;

	int i=0;
	long long zbir=0;
	long long vreme=0;

	long long zbl=0;
	long long zbd=0;
	int zap=0;
	if(n>1000)
	{
		for(i=0;i<n;i++)
		{
			scanf("%ld%ld",&p,&h);
			if(x>p)
			{

				zbl+=h;

			}
			else
			{
				zbd+=h;

			}

		}
		if(zbl>=zbd)
			zbir=2*zbd;
		else zbir=zbl*2+1;
		printf("%lld\n%lld\n",zbir,vreme);
	}
	else
	{
        bool pre=true;
		long pp[1001];
		long hh[1001];
		int po=0;
		int kr=0;
		for(i=0;i<n;i++)
		{
			scanf("%ld %ld",&pp[i],&hh[i]);
			if(pre==true)
			{
				if(x>pp[i])
				{
					zbl+=hh[i];
                }
				else
				{
					pre=false;
					zap=i;
					zbd+=hh[i];
				}
			}
			else
			{
				zbd+=hh[i];
            }
		}

		if(zbl>=zbd)
		{
			zbir=2*zbd;
        }
		else
        { 
            zbir=zbl*2+1;
        }
		int zbir1=0;
		kr=zap;
		po=zap-1;
		int poz1=x;
		int poz2=pp[kr];
		i=0;
		vreme=0;
		while((kr<n) && (po>=0))
		{
			vreme+=abs(poz2-poz1);
			zbir1++;
			hh[kr]--;

			poz1=pp[kr];
			poz2=pp[po];

			if(hh[kr]==0)
				kr++;
			
			vreme+=abs(poz1-poz2);
			zbir1++;

			poz1=pp[po];
			poz2=pp[kr];

			hh[po]--;
			if(hh[po]==0)
				po--;
			


		}

		if(kr<n)
		{
			vreme+=abs(poz1-poz2);
			zbir1++;
			hh[kr]--;
		}

		printf("%lld\n%lld",zbir,vreme);
        
	}
	scanf("%d",&n);
    return 0;
}
