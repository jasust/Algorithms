#include <math.h>
#include <stdio.h>
#include <algorithm>

using namespace std;


int main()
{
  int n;
  int k;
  scanf("%d%d",&n,&k);
  long a[14];
  long b[14];
  int res[14];
  int premes[14];

  int zbir=0;
  for(int i=0;i<n;i++)
  {
   scanf("%ld", &a[i]);
   b[i]=a[i];
      zbir+=a[i];
      premes[i]=i;
  }

  for(int i=0;i<n-1;i++)
  {
    for(int j=0;j<i;j++)
    {
        if(b[i]>b[j])
        {
            b[j]=b[i];
            premes[j]=i;
            premes[i]=j;
        }
    }
  }


  double pribl=zbir/n;
  int kr=n-1;
  int poc=0;

int i=1;
if(k==n)
{
   printf("%ld\n",(b[n-1]-b[0]));
   for(int ii=1;ii<=k;ii++)
   {
       printf("%d ", ii);
    }

}
else
{


if(k>n)
{
   printf("%ld\n",b[n-1]);
   for(int ii=1;ii<=n;ii++)
   {
       printf("%d ", ii);
    }

}
    else
    {
        long mini=10000000;
        long maks=0;
        if(k==1)
        {
            printf("0");
            for(int ii=1;ii<=k;ii++)
            {
                printf("%d ", ii);
            }
        }


    }
}
return 0;
}
