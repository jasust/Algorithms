#include <cstdlib>
#include <iostream>
#include <cstdio>
using namespace std;
bool poc=true;
int n,m,x,y,i,j;
short sm=3;
long long k,u,l;
char pom[500][500];
int main()
{
    
    cin>>n>>m;
    cin>>y>>x;
    cin>>k;
    for(i=0;i<n;i++) cin>>pom[i];
    i=y-1;
    j=x-1;
    while(k>0)
    {
              if(sm==3)
              {
                       if(i==n-1 || pom[i+1][j]=='#')
                       {
                                 sm=2;
                                 k--;
                       }
                       else
                       {
                           i++;
                       }
              }
              else
              {
                  if(sm==2)
                  {
                           if(j==m-1 || pom[i][j+1]=='#')
                           {
                                     sm=1;
                                     k--;
                           }
                           else
                           {
                               j++;
                           }
                  }
                  else
                  {
                      if(sm==1)
                      {
                           if(i==0 || pom[i-1][j]=='#')
                           {
                                     sm=4;
                                     k--;
                           }
                           else
                           {
                               i--;
                           }
                      }
                      else
                      {
                           if(j==0 || pom[i][j-1]=='#')
                           {
                                     sm=3;
                                     k--;
                           }
                           else
                           {
                               j--;
                           }
                      }
                  }
              }
    }
    printf("%d %d\n",i+1,j+1);
    return 0;
}
