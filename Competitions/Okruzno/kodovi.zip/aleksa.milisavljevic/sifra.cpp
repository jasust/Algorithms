#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
int n,m,a[100000],i;
long long k,l=1,l0;
void ispisuj(int q)
{
    if(q>=1)
    {
    //printf("%d ",k);
    if(q==1) 
    {
             if(k>0)printf("%d\n",a[k-1]);
             else printf("%d\n",a[n-1]);
    }
    else
    {
    for(i=1;i<q;i++)
    {
        l0=l;
        l=l*n;
        if(l/l0!=n) break;
    }
    if(i<q-1) printf("%d ",a[i]);
    else 
    {
         if(k%l!=0)
         {
         printf("%d ",a[k/l]);
         k=k%l;
         }
         else
         {
             if(k>0)printf("%d ",a[k/l-1]);
             else printf("%d ",a[n-1]);
             if(k>=l) k=k%n;
         }
    }
    l=1;
    ispisuj(q-1);
    }
    }
}
int main()
{
    scanf("%d %d %lld",&n,&m,&k);
    for(i=0;i<n;i++) scanf("%d",&a[i]);
    ispisuj(m);
    return 0;
}
