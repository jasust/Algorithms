#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <iostream>
struct vojnik
{
       int x;
       int y;
};
bool by_size_of_y (vojnik c,vojnik d)
{
     return c.y>=d.y; 
}
using namespace std;
vojnik a[1000000];
int n,f=1,k=0;
int main()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++) scanf("%d %d",&a[i].x,&a[i].y);
    for(int i=1;i<n;i++)
    {
            if(a[i].x==a[i-1].x) k++;
            else
            {
                if(k>0) sort(a+i-k-1,a+i,by_size_of_y);
                k=0;
            }
    }
    if(k>0) sort(a+n-k-1,a+n,by_size_of_y);
    for(int i=1;i<n;i++)
    {
            f++;
            if((a[i].y>=a[i-1].y && (i<2 ||(i>=2 && a[i-1].x!=a[i-2].x))) || a[i].x==a[i-1].x) f--;
    }
    printf("%d\n",f);
    return 0;
}
