#include <cstdlib>
#include <iostream>
#include <stdio.h>

/*
using namespace std;
int argc, char *argv[]
*/

int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    
    
    int x,y;
    scanf("%d%d",&x,&y);
    
    
    int k;
    scanf("%d",&k);
    
    
    char lavirint[n][m];
    for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                    
                    scanf("%c",&lavirint[i][j]);
                    
                    
                    }
            }
            
    printf("0 0");
    
    return 0;
}
