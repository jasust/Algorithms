#include <cstdlib>
#include <iostream>
#include <stdio.h>

/*
using namespace std;
int argc, char *argv[]
*/

int main()
{
    int n;
    scanf("%d",&n);
    
    
    int x,y;
    int xx;
    int yy[n];
    
    for(int i=0; i<n; i++){
            scanf("%d%d",&x,&y);
            
            if(i>0 && x==xx){
                   if(y>=yy[i-1]){
                                 
                                 i--;
                                 n--;
                                 
                                 }
                   }
            for(int j=0;j<i;j++){
                    if(y>=yy[j]){
                                
                                n-=i-j;
                                i=j;
                                }
                    }
                    
            yy[i]=y;
            
            xx=x;
            }
    printf("%d",n);
    
    return 0;
}
