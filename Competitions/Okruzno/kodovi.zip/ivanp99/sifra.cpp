#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <math.h>

/*
using namespace std;
int argc, char *argv[]
*/

int main()
{
    int n,m;
    long long int k;
    
    
    
    scanf("%d%d%lld",&n,&m,&k);
    
    
    int a[n];
    
    
    for(int i= 0; i < n; i++){
            scanf("%d",&a[i]);
            
            }
    
    
    
    int poz;
    long long int stepen;
    
    
    
    
    for(int i = 1; i<=m; i++){
            stepen=pow(n,m-i);//1
            
            poz=k/stepen;
            
            k=k%stepen;
            if(k==0){
                     k=stepen;
                     poz--;
                     }
            
            printf("%d ",a[poz]);
            
            }
    
    
    
    
    
    return 0;
}
