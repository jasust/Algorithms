#include <stdio.h>
#include <iostream>
#include <math.h>
#include <algorithm>
 
int h[1001];
int p[1001];

 
int main ()
{
    int n;
    int x;
    scanf("%d %d",&n,&x);
    for( int i=0; i<n; i++)
    {
         scanf("%d %d",&p[i],&h[i]);
        
    }
    int k=1;
    int b=0;
    int a=0,t=0;
    int g=0;
    while(p[g]<x)
    g++;
    t+=p[g]-x;
    a++;
    h[g]-=1;
    k=-k;
    int pre=p[g];
           
    
    if (g==0)
    {
             printf("%d %d",a,t);
    }
    else
   {
      while(h[0]>0&&h[n-1]>0)
      {
        g+=k;
         while ( h[g]==0) 
        {
        b++;
        g+=k;
        }
      
      
        if(k==-1)
        t+=pre-p[g];
        
        else
        t+=p[g]-pre;
        
        pre=p[g];
        
        a++;
        h[g]-=1;
        k*=-1;
        
        
          
      }
      if(h[0]==0&&h[n-1]>0)
      {
             
             g+=k;
         while ( h[g]==0) 
        {
        b++;
        g+=k;
        }
        t+=pre-p[g];
             a++; 
                      
      }
      if(h[0]>0&&h[n-1]==0)
      {
                      g+=k;
         while ( h[g]==0) 
        {
        b++;
        g+=k;
        }
        t+=p[g]-pre;
             a++;  
                    
      }

       

   
     printf("%d %d",a,t); system( "pause");
     return 0; 
        
}
}

