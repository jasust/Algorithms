#include <stdio.h>
#include <iostream>
#include <math.h>
#include <algorithm>

int t [300][300];
int main()
{
    int n,m;
    scanf("%d %d",&n,&m);
    
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
    scanf("%d",&t[i][j]);
    
    int a=1;
    printf("%d",a);
    
 return 0;
}
