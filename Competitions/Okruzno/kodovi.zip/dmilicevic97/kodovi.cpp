#include <cstdio>
#include <vector>
#include <set>
#include <queue>
#include <stack>
#include <utility>
#include <algorithm>
#include <climits>
#include <cmath>
#include <cstdlib>
using namespace std;

typedef long long lld;
typedef vector<int> vi;
typedef vector<bool> vb;
typedef vector< vector<int> > vvi;
typedef pair<int, int> ii;
typedef vector< ii > vii;
typedef vector< vii > vvii;

#define sz(c) (c).size()
#define pb push_back
#define mp make_pair
#define all(c) (c).begin(), (c).end()
#define tr(c, i) for(typeof((c).begin()) i = (c).begin(); i != (c).end(); i++)
#define present(c,x) (c).find() != (c).end()
#define vpresent(c, x) find(all(c), x) != (c).end()

struct Gomila {
    int x, h;

    Gomila() {}
    Gomila(int _x, int _h) {
        x = _x;
        h = _h;
    }
};

int n, x;
vector<Gomila> g;
lld solCnt = 0LL, solTime = 0LL;


void input() {
    scanf("%d %d", &n, &x);

    int p, h;
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &p, &h);
        g.pb( Gomila(p, h) );
    }
}

void solve() {
    if (x < g[0].x) {
        solTime += g[0].x - x;
        solCnt = 1;
        return;
    }

    int left = 0, right = 1;
    for (; right < n-1; left++, right++)
        if (g[left].x < x && x < g[right].x)
            break;

   // printf("%d %d\n", left, right);

    bool dir = true; /// true - desno
    while (left > -1 && right < n) {
        solCnt++;
        solTime += (dir) ? (g[right].x - x) : (x - g[left].x);

        if (dir) {
            x = g[right].x;
            g[right].h--;
            dir = false;
            if (g[right].h == 0) {
                right++;
                continue;
            }
        }
        else {
            x = g[left].x;
            g[left].h--;
            dir = true;
            if (g[left].h == 0) {
                left--;
                continue;
            }
        }

        if (dir) {
            if (g[left].h > g[right].h) {
                g[left].h -= g[right].h;
                solCnt += 2 * g[right].h;
                solTime += (lld)g[right].h * 2 * (g[right].x - g[left].x);
                right++;
                dir = true;

            } else if (g[left].h < g[right].h) {
                g[right].h -= (g[left].h + 1);
                solCnt += 2 * g[left].h + 1;
                solTime += (lld)g[left].h * 2 * (g[right].x - g[left].x) + (g[right].x - g[left].x);
                left--;
                x = g[right].x;
                if (g[right].h == 0) right++;
                dir = false;

            } else {
                solCnt += 2 * g[left].h;
                solTime += (lld)g[right].h * 2 * (g[right].x - g[left].x);
                left--, right++;
                dir = true;
            }
        }
        else {
            if (g[right].h > g[left].h) {
                g[right].h -= g[left].h;
                solCnt += 2 * g[left].h;
                solTime += (lld)g[left].h * 2 * (g[right].x - g[left].x);
                left--;
                dir = false;

            } else if (g[right].h < g[left].h) {
                g[left].h -= (g[right].h + 1);
                solCnt += 2 * g[right].h + 1;
                solTime += (lld)g[right].h * 2 * (g[right].x - g[left].x) + (g[right].x - g[left].x);
                right++;
                x = g[left].x;
                if (g[left].h == 0) left--;
                dir = true;

            } else {
                solCnt += 2 * g[left].h;
                solTime += (lld)g[right].h * 2 * (g[right].x - g[left].x);
                left--, right++;
                dir = false;
            }
        }
    }
}

void output() {
    printf("%lld\n%lld\n", solCnt, solTime);
}

int main() {
    input();
    solve();
    output();
    return 0;
}
