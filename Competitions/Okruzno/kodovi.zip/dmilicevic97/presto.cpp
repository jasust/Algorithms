#include <cstdio>
#include <algorithm>
#include <climits>
using namespace std;

const int MAX_N = 300;

int n, m;
int mat[MAX_N][MAX_N];
int rows[MAX_N][MAX_N], cols[MAX_N][MAX_N];

void input() {
    scanf("%d %d", &n, &m);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) {
            scanf("%d", mat[i] + j);
            rows[i][j] = cols[j][i] = mat[i][j];
        }
}

int upper(int x, int col) {
    int l = 0, r = n-1;
    int mid;

    while (l < r-1) {
        mid = (l + r) / 2;

        if (cols[col][mid] <= x)
            l = mid;
        else r = mid;
    }

    if (cols[col][r] <= x) return r;
    return l;

}

void solve() {
    for (int i = 0; i < n; i++)
        sort(rows[i], rows[i] + m);
    for (int i = 0; i < m; i++)
        sort(cols[i], cols[i] + n);

    int sol = INT_MAX;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) {
            for (int k = 0; k < m; k++) {
                int idxInCol = upper(rows[i][k], j);

                int smallerInRow = k;
                if (mat[i][j] < rows[i][k])
                    smallerInRow--;

                int largerInCol = n-1 - idxInCol;
                if (mat[i][j] > cols[j][idxInCol])
                    largerInCol--;

                int currSol = smallerInRow + largerInCol;
                if (mat[i][j] != rows[i][k])
                    currSol++;

                sol = min(sol, currSol);

                while (k < m-1 && rows[i][k] == rows[i][k+1])
                    k++;
            }
        }

    printf("%d\n", sol);

   /* for (int i = 0; i < n; i++, printf("\n"))
        for (int j = 0; j < m; j++)
            printf("%d ", rows[i][j]);
    for (int j = 0; j < m; j++, printf("\n"))
        for (int i = 0; i < n; i++)
            printf("%d ", cols[j][i]);
    */
}

int main() {
    /*scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", cols[0] + i);
    }
    int idx = upper(2, 0);
    printf("%d", idx);
    */

    input();
    solve();
    return 0;
}
