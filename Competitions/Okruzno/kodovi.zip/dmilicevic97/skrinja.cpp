#include <cstdio>
#include <algorithm>
#include <climits>
using namespace std;

const int MAX_N = 13;

int poglavljaBr, perice;
int a[MAX_N];

void input() {
    scanf("%d %d", &poglavljaBr, &perice);
    for (int i = 0; i < poglavljaBr; i++)
        scanf("%d", a+i);
}

void solve() {
    if (perice >= poglavljaBr) {
        int najvece = 0, najmanje = INT_MAX;
        for (int i = 0; i < poglavljaBr; i++) {
            najvece = max(najvece, a[i]);
            najmanje = min(najmanje, a[i]);
        }

        if (perice == poglavljaBr)
            printf("%d\n", najvece - najmanje);
        else printf("%d\n", najvece);

        for (int i = 1; i < poglavljaBr; i++)
            printf("%d ", i);
        printf("%d\n", poglavljaBr);
        return;
    }


}

int main() {
    input();
    solve();
    return 0;
}
