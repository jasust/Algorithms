#include <algorithm>
#include <iostream>
#include <map>
using namespace std;
enum { MAXN = 330, MAXM = 330, INF=1<<30 };
int n, m, r[MAXN][MAXM], c[MAXM][MAXN], h[MAXN][MAXM];
int numOfBigger(int s, int f, int* r, int v){
    while(s<f){
        int mid=(s+f)/2;
        if(r[mid]<=v){
            s=mid+1;
        }
        else f=mid;
    }
    if(r[s]==v) return s+1;
    return s;
}
int numOfSmaller(int s, int f, int* r, int v){
    while(s<f){
        int mid=(s+f+1)/2;
        if(r[mid]>=v){
            f=mid-1;
        }
        else s=mid;
    }
    if(r[s]==v) return 0;
    return s+1;
}
int main() {
    ios_base::sync_with_stdio(false);
    cin>>n>>m;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            cin>>h[i][j];
            r[i][j]=h[i][j];
            c[j][i]=r[i][j];
        }
    }
    for(int i=0; i<n; i++) sort(r[i], r[i]+m);
    for(int i=0; i<m; i++) sort(c[i], c[i]+n);
    int minc=INF;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            int chg=m-numOfBigger(0, m-1, r[i], h[i][j])+numOfSmaller(0, n-1, c[j], h[i][j]);
            if(minc>chg) minc=chg;
        }
    }
    cout<<minc;
    return 0;
}
