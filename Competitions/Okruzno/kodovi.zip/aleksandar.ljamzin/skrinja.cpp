#include <algorithm>
#include <iostream>
#include <map>
//#define map<raspored, int>::iterator mrit
using namespace std;
enum { MAXK = 15, MAXN = 13, INF=1<<30 };
int n, k;
struct raspored {
    int k;
    int r[MAXN];
    int u[MAXK];
    raspored(){}
    raspored(int k0, int *r0, int *u0){
        k=k0;
        for(int i=0; i<n; i++){
            r[i]=r0[i];
        }
        for(int i=0; i<k; i++){
            u[i]=u0[i];
        }
    }
    bool operator<(const raspored &rp)const {
        if(k!=rp.k) return k<rp.k;
        for(int i=0; i<n; i++) {
            if(r[i]!=rp.r[i]) {
                return r[i]<rp.r[i];
            }
        }
        return false;
    }
    bool operator==(const raspored &rp)const {
        if(k!=rp.k) return false;
        for(int i=0; i<n; i++) {
            if(r[i]!=rp.r[i]) {
                return false;
            }
        }
        return true;
    }
    int minDif(){
        int mx=r[0];
        int mn=r[0];
        for(int i=0; i<n; i++){
            if(r[i]<mn) mn=r[i];
            if(r[i]>mx) mx=r[i];
        }
        return mx-mn;
    }
};
map<raspored, int> mp;
int val[MAXK];
raspored r0;
map<raspored, int>::iterator calc(raspored r){ ///INVALID BREAK
    map<raspored, int>::iterator it=mp.find(r);
    if(it!=mp.end()) return it;
    if(r.k==k) return mp.insert(pair<raspored, int>(r, r.minDif())).first;
    int* t=r.r;
    int* v=r.u;
    int p=r.k+1;
    int mn=INF;
    int rv=0;
    for(int i=0; i<n; i++){
        t[i]+=val[p];
        v[p]=i+1;
        map<raspored, int>::iterator nw=calc(raspored(p, t, v));
        if(nw->second<mn) { mn=nw->second; rv=i+1; }
        t[i]-=val[p];
    }
    return mp.insert(pair<raspored, int>(r, mn)).first;

}
int main() {
    ios_base::sync_with_stdio(false);
    cin>>k>>n;
    for(int i=0; i<k; i++) {
        cin>>val[i];
    }
    if(n==1) {
        cout<<0<<endl;
        for(int i=0; i<k; i++) {
            cout<<1<<" ";
        }
        return 0;
    }
    sort(val, val+k);
    if(k<n) {
        cout<<val[k-1]<<endl;
        for(int i=1; i<=k; i++) {
            cout<<i<<" ";
        }
        return 0;
    }
    if(k==n) {
        cout<<val[k-1]-val[0]<<endl;
        for(int i=1; i<=k; i++) {
            cout<<i<<" ";
        }
        return 0;
    }
    for(int i=0; i<n; i++) {
        r0.r[i]=val[i];
        r0.u[i]=i+1;
    }
    map<raspored, int>::iterator it=calc(r0);
    const int* u=it->first.u;
    cout<<it->first.k<<endl;
    for(int i=0; i<k; i++){
        cout<<u[i]<<" ";
    }
    return 0;
}
