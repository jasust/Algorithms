#include <algorithm>
#include <iostream>
using namespace std;
enum { MAXN = 100100 };
int n, l, r;
long long x, p[MAXN], val[MAXN], t, cnt;
int main() {
    ios_base::sync_with_stdio(false);
    cin>>n>>x;
    l=-1;
    r=-1;
    bool none=true;
    bool foundpos=false;
    for(int i=0; i<n; i++) {
        cin>>p[i]>>val[i];
        if(val[i]>0) none=false;
        else{
            n--;
            i--;
        }
        if(p[i]>=x&&!foundpos) {l=i-1; r=i; foundpos=true;}
    }
    if(l<0||r>=n||r<0||none) {
        cout<<0<<endl<<0;
        return 0;
    }
    if(r==0) {
        cout<<1<<endl<<abs(x-p[0]);
        return 0;
    }
    t+=p[r]-x;
    cnt++;
    val[r]--;
    t+=p[r]-p[l];
    val[l]--;
    cnt++;
    while(1) {
        long long dis=p[r]-p[l];
        long long lt=dis*val[l]*2;
        long long rt=dis*(val[r]*2-1);
        if(rt<=0){
            if(r==n-1) break;
            r++;
            continue;
        }
        if(lt<rt) {
            t+=lt;
            cnt+=val[l]*2;
            if(l==0){
                t+=dis;
                cnt++;
                break;
            }
            ///align to new left
            t+=dis-p[l-1]+p[r];
            val[r]-=val[l]+1;
            val[l-1]--;
            cnt+=2;
            l--;
        } else {
            t+=rt;
            cnt+=val[r]*2-1;
            if(r==n-1){
                t+=dis;
                cnt++;
                break;
            }
            ///align to new left
            t+=dis;
            cnt+=1;
            val[l]-=val[r];
            r++;
        }
    }
    cout<<cnt<<endl<<t;
    return 0;
}
