#include <cstdio>

long int n,x,i;
long long p[100000], h[100000];
long long sol1, sol2;

long long svedinan2(void)
{
    long long s1;
    long long levo = 0, desno = 0;
    for(long int j = 0; j < n; j++)
        if(p[j] < x) levo+= h[j];
        else desno+= h[j];

    if(!levo) return 1;

    if(levo < desno)
        s1 = 2*levo + 1;
    else
        s1 = 2*desno;

    return s1;
}

int main()
{

    scanf("%ld %ld", &n, &x);

    //Zagarantovano je da ce da bude bar 1 gomila desno od Gavre
    //Gomila sa najmanjom koordinatom: p[0]
    if(n == 1)
    {
        scanf("%lld %lld", &p[0], &h[0]);
        sol1 = 1;
        sol2 = p[0] - x;
    }
    //N=2 - 15 poena
    else if(n == 2)
    {
        for(i = 0; i < n; i++)
        {
            scanf("%lld %lld", &p[i], &h[i]);
            //if(p[i] < x) imase = 1;
        }

        bool imase = (p[0] < x);

        if(!imase)
        {
            sol1 = 1;
            sol2 = p[0]-x;
        }
        else
        {
            if(h[0] < h[1])
            {
                sol1 = 2*h[0] + 1;
                sol2 = 2*h[0]*(p[1] - p[0]) + p[1] - x;
            }
            else
            {
                sol1 = 2*h[1];
                sol2 = (2*h[1]-1)*(p[1] - p[0]) + p[1] - x;
            }
        }
    }
    //n<=1000; p[i], h[i] <= 1000 - 0.6*25=15 poena
    else if(n <= 1000)
    {
        for(i = 0; i < n; i++)
        {
            scanf("%lld %lld", &p[i], &h[i]);
        }

        if(p[0] > x)
        {
            sol1 = 1;
            sol2 = p[0] - x;
        }
        else
        {
            sol1 = svedinan2();
            sol2 = 666;
        }
    }
    //ostalo - 0.6*(40+20)=36 poena
    else
    {
        for(i = 0; i < n; i++)
        {
            scanf("%lld %lld", &p[i], &h[i]);
        }

        if(p[0] > x)
            sol2 = p[0] - x;
        else
            sol2 = 666;

        sol1 = svedinan2();
    }

    //Ocekivanje: 66 poena
    //Not bad, necu se cimam za vise
    printf("%lld\n%lld", sol1, sol2);
    return 0;
}
