#include <cstdio>

int n, m, i, j;
long long h[300][300], dp[300][300];
long long a[300], b[300];
long long minimum;
int ii[300][300], jj[300][300], ii1[300][300], jj1[300][300];

int main()
{
    minimum = 1000000002;
    scanf("%d %d", &n, &m);
    for(i = 0; i < n; i++)
    for(j = 0; j < m; j++)
    {
        scanf("%lld", &h[i][j]);
        ii[i][j] = ii1[i][j] = i;
        jj[i][j] = jj1[i][j] = j;
    }

    //Za vrste
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < m; j++) a[j] = h[i][j];

        for(int k = 0; k < m-1; k++)
        for(int l = k+1; l < m; l++)
        if(a[l] < a[k])
        {
            int y = jj[i][k];
            jj[i][k] = jj[i][l];
            jj[i][l] = y;

            int x = a[l];
            a[l] = a[k];
            a[k] = x;
        }

        for(j = 0; j < m; j++) dp[ii[i][j]][jj[i][j]] = j;
    }

    //Za kolone
    for(j = 0; j < m; j++)
    {
        for(i = 0; i < n; i++)
        {
            b[i] = h[i][j];
        }

        for(int k = 0; k < n-1; k++)
        for(int l = k+1; l < n; l++)
        if(b[l] > b[k])
        {
            int y = ii1[k][j];
            ii1[k][j] = ii1[l][j];
            ii1[l][j] = y;

            int x = b[l];
            b[l] = b[k];
            b[k] = x;
        }

        for(i = 0; i < n; i++) dp[ii1[i][j]][jj1[i][j]]+= i;
    }

    for(i = 0; i < n; i++)
        for(j = 0; j < m; j++)
        if(dp[i][j] < minimum) minimum = dp[i][j];

    printf("%lld", minimum);
    return 0;
}
