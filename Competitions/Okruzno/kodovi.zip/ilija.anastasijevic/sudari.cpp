#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    int n, m, x, y, vx, vy;
    vx = 0;
    vy = 1;
    long long k;

    scanf("%d%d" &n, &m);
    scanf("%d%d", &y, &x);
    scanf("%lld", &k);

    char lavirint[n][m];

    for (int i = 0; i < n; i++)
    {
        int j = 0;
        for (j; j < m; j++)
        {
            scanf("%c", &lavirint[i][j]);
        }
    }

    for (long long i; i < k; i++)
    {
        if (lavirint[y + vy][x + vx] == "#" || x + vx => m || x + vx < 0 || y + vy => n || y + vy < 0)
        {
            if(vx)
            {
                vy = -vx;
                vx = 0;
            }
            else if(vy)
            {
                vx = vy;
                vy = 0;
            }
        }

        x += vx;
        y += vy;
    }

    x -= vx;
    y -= vy;

    cout << y << endl << x << endl;


    return 0;
}
