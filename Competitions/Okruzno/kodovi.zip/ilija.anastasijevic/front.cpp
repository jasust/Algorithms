#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    long long n, f, nf;
    f = 0;
    nf = 0;

    scanf("%lld", &n);

    long long vojnicix[n];
    long long vojniciy[n];

    for (long long i = 0; i < n; i++)
    {
        scanf("%lld%lld", &vojnicix[i], &vojniciy[i]);
    }

    for (long long i = 0; i < n; i++)
    {
        long long j = 0;

        for(j; j < n; j++)
        {
            if (i != j && (vojnicix[i] <= vojnicix[j] && vojniciy[i] <= vojniciy[j]))
            {
                f++;
                goto izlaz;
            }
            j++;
        }

        izlaz:

        if(true);
    }

    cout << n - f << endl;

    return 0;
}
