#include <cstdlib>
#include <iostream>
#include <stdio.h>
void razmeni(long long *a,long long *b)
{
     long long pom;
     pom=*a;
     *a=*b;
     *b=pom;
}
void quicks(long long a[],long long b[],int levi,int desni)
{
     int i,j;
     long long d;
     if (levi<desni)
        {
        i=levi;
        j=desni;
        d=a[desni];
        do
          {
          while (a[i]<d) i++;
          while (a[j]>=d && i<j) j--;
          if (i<j) { razmeni (&a[i],&a[j]); razmeni(&b[i],&b[j]); }
          }
        while (i!=j);
        razmeni(&a[i],&a[desni]);
        razmeni(&b[i],&b[desni]);
        quicks(a,b,levi,i-1);
        quicks(a,b,i+1,desni);
        }
}
using namespace std;

int main(int argc, char *argv[])
{
    long long a[15],b[15],c[15],min,max,razl;    
    int ispis[15],pom,indx_min,indx_max,r,n,k,i;
    
    //ucitavanje
    scanf("%d",&n);
    scanf("%d",&k);
    for (i=0;i<n;i++) scanf("%lld",&a[i]);
    for (i=0;i<n;i++) b[i]=i;
    
    quicks(a,b,0,n-1);

    for (i=1;i<=k;i++) c[i]=0; //c-koliko ko ima strana
    
    pom=n-1;
    max=c[1];
    indx_max=1;
    min=c[k];
    indx_min=k;
    //podela
    while (pom>=0)
          {
          //nova dodela
          c[indx_min]+=a[pom];
          min+=a[pom];
          r=b[pom];
          ispis[r]=indx_min;
          pom--;
          //nov min i max
          if (min>max) { max=min; indx_max=indx_min; }
          for (i=1;i<=k;i++) 
              if (c[i]<min) { min=c[i]; indx_min=i; }
          } 
    razl=max-min; 
    printf("%d\n",razl);
    for (i=0;i<n;i++) printf("%d ",ispis[i]);
    printf("\n");
    return 0;
}
