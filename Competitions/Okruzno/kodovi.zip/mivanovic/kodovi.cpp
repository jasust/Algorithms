#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

int main(int argc, char *argv[])
{
    long long n,x,p[100000],h[100000],i,sec,kod,m,sacuv,donja,gornja,sredina;
    int ok,z;
    
    //ucitavanje
    scanf("%lld",&n);
    scanf("%lld",&x);
    for (i=0;i<n;i++)
        scanf("%lld%lld",&p[i],&h[i]); 
      
   //postavljanje na pocetak
   z=1; //okrenut je udesno
   sec=0; //broj sekundi
   kod=0; //broj uzetih kodova
   
   //odredjivanje prvog najblizeg m
   ok=1;
   donja=0;
   gornja=n-1;
   if (x<p[0]) m=0; //ako je x levo od prvo
   else
       while (ok) //ako je x negde u nizu
         {
         if (p[gornja-1]<x)
            {
            m=gornja;
            ok=0;
            }
         else
             {
             sredina=(gornja+donja)/2;
             if (x>p[sredina]) donja=sredina;
             else gornja=sredina;
             }
         }
  
   //odredjivanjeostalih
   ok=1; //dok nije otisao u beskonacnost
   while (ok)
         {
          //pomeranje Sime, dodavanje vremena i broja kodova
          sec+=z*(p[m]-x);
          x=p[m];
          kod++;
          h[m]--;
          z*=-1;
          sacuv=m;
          //odredjivanje sledece pozicije prvog koda ili oznacavanje da je otisao u beskonacnost ok=0
          if (z==1)
             if (m<n) m++;
             else ok=0;
          else
              if (m>0) m--;
              else ok=0;
          //pomeranje niza ako je h=0
          if (h[sacuv]==0)
             if (ok)
                {
                for (i=sacuv+1;i<n;i++)
                    {
                    p[i-1]=p[i];
                    h[i-1]=h[i];
                    }
                n--;
                if (z==1) m--;
                }
         }
         
   printf("%lld\n%lld\n",kod,sec);
    return 0;
}
