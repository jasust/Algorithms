#include<stdio.h>
int main(){
    int i,x[1000],y[1000],N,j,F=0,pom;
    scanf("%d",&N);
    for(i=0;i<N;i++)
    scanf("%d %d",&x[i],&y[i]);

    for(i=1;i<N;i++)
    for(j=i-1;j<i;j++)
    if(x[i]<x[j])
    {
        pom=x[i];
        x[i]=x[j];
        x[j]=pom;
    }
    for(i=1;i<N;i++)
    for(j=i-1;j<i;j++)
    {
        if(x[i]*y[i]>x[j]*y[j])
            F++;
    }
    printf("%d",F);
    return 0;
}
