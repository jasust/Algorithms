#include <iostream>
#include <cstdio>
using namespace std;

int Stepen(int N, int M)
{
	int i,a=1;
	for (i=0;i<M;i++)
		a*=N;
	return a;
}
int main() 
{
	unsigned int N, M; 
    unsigned long long K, i;
	scanf("%u %u %llu", &N, &M, &K);
	unsigned long Niz[N];
	for (i=0;i<N;i++)
		scanf("%lu", &Niz[i]);
	int a=Stepen(N,M);
	int idx;
	for(i=0;i<M;i++)
	{
		idx=((K-1)%a)/(a/N);
		printf("%lu ",Niz[idx]);
		a/=N;
	}
	return 0;
}
