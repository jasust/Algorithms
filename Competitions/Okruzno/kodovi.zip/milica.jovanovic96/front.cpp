#include <iostream>
#include <cstdio>
using namespace std;

int main() 
{
	int n, br=0, i,j,postoji;
	scanf("%d", &n);
	long x[n], y[n];
	for (i=0;i<n;i++)
		scanf("%ld %ld", &x[i], &y[i]);
	for(i=0;i<n-1;i++)
		{
			for (j=i+1;j<n;j++)
			{
				postoji=0;
				if ((x[i]<=x[j])&&(y[i]<=y[j]))
					{
						postoji=1;
						break;
					}
			}
			if(!postoji) br++;
		}
	postoji=0;
	for(i=0;i<n-1;i++)
		if((x[n-1]<=x[i])&&(y[n-1]<=y[i])) postoji=1;
	if(!postoji) br++; 
	printf("%d", br);	
	return 0;
}
