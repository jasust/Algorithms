#include <stdio.h>
#include <conio.h>
int main()
{
    int i, j, n, m, x, y, k;
    char mat[500][500], g;
    scanf("%d%d", &n, &m);
    scanf("%d%d", &y, &x);
    scanf("%d%", &k);

    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%c", &mat[i][j]);
        }
    }
    i=x;
    j=y;
    do{
        while(i!=n && mat[i+1][j]!='#'){i++; if(k==0){break;};k--;}//dole
        while(y!=m && mat[i][j+1]!='#'){j++;if(k==0){break;}k--;}//desno
        while(x!=0 && mat[i-1][j]!='#'){i--;if(k==0){break;}k--;}//gore
        while(j!=0 && mat[i][j-1]!='#'){j--;if(k==0){break;}k--;}//levo
    }
    while(k!=0);
    printf("%d %d", i, j);


    return 0;
}

