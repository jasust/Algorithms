#include <stdio.h>
typedef struct{ int x, y; } Vojnik;
int main()
{

	int n, i, z=0, g;
	int p=0;
	Vojnik sold[1000];

	scanf("%d", &n);

	for (i = 0; i < n; i++)
	{
		scanf("%d%d", &sold[i].x, &sold[i].y);
	}

	for(i=0;i<n;i++)
	{
	    z=0;
                for(g=i;g<n;g++)
                {

                    if(sold[i].x<=sold[g].x || sold[i].y<=sold[g].y)
                    {
                        z++;
                    }

                }
                if (z==0)
                    {
                        p++;
                    }
        }


printf("%d", p);
		return 0;
}




