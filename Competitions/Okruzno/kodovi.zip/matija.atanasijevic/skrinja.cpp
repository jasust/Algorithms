#include <cstdio>
#include <vector>
#include <algorithm>
#include <iterator>

using namespace std;

long int i,j,n,k;
long long int min1,min1Pos,max1,max1Pos,max2,max2Pos,currmin1,currmin1Pos,diff,tmp;
vector<long int> p (15,0);
vector<long long int> a (15,0);
vector<long int> res (15,0);

void minimum(void)
{
  min1 = a.at(0);
  min1Pos = 0;

  long int o;
  for (o=1;o<k;o++)
  {
    if (a.at(o)<min1)
    {
      min1 = a.at(o);
      min1Pos = o;
    }
  }
}

void maximum(void)
{
  max1 = a.at(0);
  max1Pos = 0;
  long int o;
  for (o=1;o<k;o++)
  {
    if (a.at(o)>max1)
    {
      max1 = a.at(o);
      max1Pos = o;
    }
  }
}

int main(void)
{
  scanf("%d %d",&n,&k);
  for (i=0;i<n;i++)
  {
    scanf("%d",&tmp);
    p[i]=tmp;
  }

  //sort(p.begin(),p.begin()+n);

  max2Pos = 0;
  max2 = p.at(0);
  for (i=1;i<n;i++)
  {
    if (p.at(i)>max2)
    {
      max2 = p.at(i);
      max2Pos = i;
    }
  }

  a.at(0) = p.at(max2Pos);
  res.at(max2Pos)=1;
  //p.erase(p.begin()+n-1);
  p.at(max2Pos)=0;

  for (i=1;i<n;i++)
  {
    minimum();
    maximum();

    tmp = max1-min1;

    currmin1 = (int) abs(p.at(0)-tmp);
    currmin1Pos = 0;
    for (j=1;j<n;j++)
    {
      diff = (int) abs(p.at(j)-tmp);
      if (diff<currmin1)
      {
        currmin1 = diff;
        currmin1Pos = j;
      }
    }

    //printf("%d %d\n",currmin1,currmin1Pos);

    a.at(min1Pos)+=p.at(currmin1Pos);
    res.at(currmin1Pos)=min1Pos+1;
    p.at(currmin1Pos) = 0;
    //p.erase(p.begin()+currmin1Pos);
  }
/*
  for (i=0;i<k;i++)
  {
    printf("%d ",a.at(i));
  }
  printf("\n");*/

  minimum();
  maximum();
  printf("%lld\n",max1-min1);

  for (i=0;i<n;i++)
  {
    printf("%d ",res.at(i));
  }

  return 0;
}
