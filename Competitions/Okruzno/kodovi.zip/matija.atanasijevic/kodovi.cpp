#include <cstdio>

long int n,x,i,posX,poslednji;
long int p[100005];
long int h[100005];
long long int levi, desni, last, kodovi, vreme;

int main(void)
{
  scanf("%d %d",&n,&x);

  levi = 0;
  desni = 0;
  posX = 0;

  for (i=0;i<n;i++)
  {
    scanf("%d %d",&p[i],&h[i]);
    if (p[i]<x)
    {
      levi += h[i];
    }
    else
    {
      if (!posX)
      {
        posX = i;
      }
      desni += h[i];
    }
  }

  if (levi<desni)
  {
    desni = levi+1;
    poslednji = 1;
  }
  else
  {
    levi = desni;
    poslednji = 0;
  }
  kodovi = levi+desni;

  //for (i=posX;desni>0 && i<n;i++)
  for (i=posX;desni>0;i++)
  {
    if (h[i]<desni)
    {
      vreme += h[i]*(p[i]-x);
      desni -= h[i];
    }
    else
    {
      vreme += desni*(p[i]-x);
      if (poslednji) {last = p[i]-x;}
      desni = 0;
    }
  }

  for (i=posX-1;levi>0;i--)
  {
    if (h[i]<=levi)
    {
      vreme += h[i]*(x-p[i]);
      levi -= h[i];
    }
    else
    {
      vreme += levi*(x-p[i]);
      if (!poslednji) {last = x-p[i];}
      levi = 0;
    }
  }
  //printf("%lld\n",last);

  vreme *= 2;
  vreme -= last;

  printf("%lld\n",kodovi);
  printf("%lld",vreme);

  return 0;
}
