#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <algorithm>

using namespace std;

long int red[305][305];
long int kol[305][305];
long int maxred,minkol;
long int n,m,i,j,cnt,result;

bool manji(int x,int y)
{
  return x<=y;
}

bool veci(int x,int y)
{
  return x>=y;
}

int main(void)
{
  memset(red,0,90000);
  memset(kol,0,90000);

  scanf("%d %d",&n,&m);

  result = n;
  if (n>m) {result = m;}

  for (i=0;i<n;i++)
  {
    for (j=0;j<m;j++)
    {
      scanf("%d",&red[i][j]);
      kol[j][i] = red[i][j];
    }
  }

  for (i=0;i<n;i++)
  {
    sort(&red[i][0],&red[i][m],manji);
  }
  for (i=0;i<m;i++)
  {
    sort(&kol[i][0],&kol[i][n],veci);
  }

/*
  for (i=0;i<n;i++)
  {
    for (j=0;j<m;j++)
    {
      printf("%d ",red[i][j]);
    }
    printf("\n");
  }

  for (i=0;i<m;i++)
  {
    for (j=0;j<n;j++)
    {
      printf("%d ",kol[i][j]);
    }
    printf("\n");
  }*/

  maxred = red[0][0];
  for (i=1;i<n;i++)
  {
    if (maxred<red[i][0])
    {
      maxred = red[i][0];
    }
  }

  minkol = kol[0][0];
  for (i=1;i<m;i++)
  {
    if (minkol>kol[i][0])
    {
      minkol = kol[i][0];
    }
  }

  //printf("%d %d\n",minkol,maxred);

  for (i=0;i<n;i++)
  {
    cnt = 0;
    for (j=0;j<m;j++)
    {
      if (minkol>red[i][j])
      {
        cnt++;
      }
      else {break;}
    }
    //printf("MinKol %d %d %d\n",i,j,cnt);
    if (cnt<result)
    {
      //printf("RES\n");
      result=cnt;
    }
  }

  for (i=0;i<m;i++)
  {
    cnt = 0;
    for (j=0;j<n;j++)
    {
      if (maxred<kol[i][j])
      {
        cnt++;
      }
      else {break;}
    }
    //printf("MaxRed %d %d %d\n",i,j,cnt);
    if (cnt<result)
    {
      //printf("RES\n");
      result=cnt;
    }
  }

  printf("%d",result);
  return 0;
}
