#include<stdio.h>
int Max(int a[100],int n)
   {
     int i,j,max;
     for(i=0;i<n;i++)
      {
        if(a[i]>max)
        max = a[i];               
      }         
     return max;
   }
int main()
{
  int a[100],n,k,i,max,s=0;
  
  scanf("%d%d",&n,&k);
  for(i=0;i<n;i++)      
   scanf("%d",&a[i]);

  max = Max(a,n);
  for(i=0;i<k;i++)
     {
                 
     }
  return 0;
}
