#include<stdio.h>
#include<math.h>
int main()
{
 long long p[100],h[100];
 int i,n,x,max=0,min=100;
 scanf("%d%d",&n,&x);
 for(i=0;i<n;i++)
   scanf("%lld%lld",&p[i],&h[i]);             
   
    
    for(i=n-1;i>=0;i--)
      {
       if(p[i]>x)
       max = p[i];               
      }
    for(i=0;i<n;i++)
      {
        if(p[i]<x)
        min = p[i];              
      }
      

   //return 0;    
  printf("%d\n%d\n",max,min);
  for(;;);
}
