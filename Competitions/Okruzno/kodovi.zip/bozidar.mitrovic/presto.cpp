#include<stdio.h>
/*int Min(int a[][10],int n,int m)
    {
      int min;
      for(int i=0;i<n;i++)
        for(int j = 0;j<m;j++)
          {
            if(a[i][j]>min)
            min = a[i][j];      
          }        
      return min;
    }*/
int main()
{
long long a[100][100];
int x = 0,n,m,i,j,min;
scanf("%d%d",&n,&m);
for(i=0;i<n;i++)
  for(j=0;j<m;j++)
    scanf("%lld",&a[i][j]);
    
      for( i=0;i<n;i++)
        for(j = 0;j<m;j++)
          {
            if(a[i][j]<min)
            min = a[i][j];      
          }   
  printf("10"); 
  
 return 0;    
}
