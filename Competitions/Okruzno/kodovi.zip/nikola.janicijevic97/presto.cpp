#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n,m, a[300][300], i, j, k, s[300][300], min;
    int tmp,tmp2;
    cin >> n >> m;
    for(i=0;i<n;i++)
    {
            for(j=0;j<m;j++)
            {
                   cin >> a[i][j];
                   s[i][j]=0;
            }
    }
    for(i=0;i<n;i++)
    {
           for(j=0;j<m;j++)
           {
                  for(k=0;k<m;k++)
                  {
                         if(a[i][j]>a[i][k])
                         s[i][j]++;
                  }
                  for(k=0;k<n;k++)
                  {
                         if(a[i][j]<a[k][j])
                         s[i][j]++;                   
                  }
                  
           }
    }
    min=a[0][0];
    for(i=0;i<n;i++)
    {
            for(j=0;j<m;j++)
            {
                   if(s[i][j]<min)
                   min=s[i][j];
            }
    }
    cout << min << endl;
    //system("PAUSE");
    return 0;
}
/*
3 4
1 9 3 0
6 2 7 5
8 4 6 3

*/
