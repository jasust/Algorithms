#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{ 
    int n, x, h[100000], p[100000], l=0, d=0, vreme=0;
    cin >> n >> x;
    for(int i=0;i<n;i++)
    {
            cin >> p[i] >> h[i];       
    }
    for(int i=0;i<n;i++)
    {
            if(p[i]<x)
            l+=h[i];
            else
            d+=h[i];
    }
    if(l<d)
    cout << 2*l+1 << endl;
    else
    cout << 2*d;
    l=d=0;
    while(p[d]<x)
    {
          d++;                   
    }
    l=d-1;
    vreme+=(p[d]-p[x]);
    while((h[0]>0)&&(h[n-1]>0))
    {                               
          vreme+=(p[d]-p[l]);
          h[d]--;
          h[l]--;
          while((h[d]==0)&&(d<n))
          {
             d++;           
          }
          while((h[l]==0)&&(l>0))
          {
             l--;           
          }
    }
    vreme+=(p[d]-p[l]);
    cout << vreme << endl;
    //system("PAUSE");
    return 0;
}
/*
3 7
5 2
10 1
12 4
*/
