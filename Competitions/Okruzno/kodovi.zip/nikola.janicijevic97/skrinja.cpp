#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int n, k, a[13], i, p[13], min, tmp, per[13],j, max ,tmp2, o;
    cin >> n >> k;
    for(i=0;i<n;i++)
    {
          cin >> a[i];
    }
    for(i=0;i<k;i++)
    {
         per[i]=0;                
    }
    max=a[0];
    for(i=0;i<n;i++)
    {
                    for(o=0;o<n;o++)
                    {
                              if(a[o]>max)
                              {
                                   max=a[o];
                                   tmp2=o;                
                              }
                    }
    
                    for(j=0;j<k;j++)
                    {       
                            if(per[j]<min)
                            {        
                                     min=per[j];
                                     tmp=j;
                            }                       
                    }
                    min=per[tmp]+=max;
                    p[tmp2]=tmp+1;
                    max=a[tmp2]=-1;
                    
    }
    min=max=per[0];
    for(i=1;i<k;i++)
    {
             if(per[i]<min)
             min=per[i];
             if(per[i]>max)
             max=per[i];
    }
    cout << max-min << endl;
   for(i=0;i<n;i++)
    {
        cout << p[i] << " ";                           
    }
    cout << endl;
    
   //system("PAUSE");
    return 0;
}
