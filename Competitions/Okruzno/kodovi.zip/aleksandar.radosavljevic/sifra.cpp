#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float N, M;
	int br1, red, pom, pom1=1, K, i, j, kol, br=1;
	cin>>N>>M>>K;
	kol=pow(N,M);
	pom=N*pow(M-1,2);
	red=M;
	br1=N;
	int Mat[kol][red], C[br1];
	for(i=1; i<=br1; i++)
		cin>>C[i];
	for(i=1; i<=red; i++)
		for(j=1; j<=kol; j++)
		{
			if(pom1<=pom)
			{
				Mat[j][i]=C[br];
				pom1++;
			}
			else
			{
				br++;
				pom1=1;
				Mat[j][i]=C[br];
			}
			pom=pom/br1;
		}
	for(i=1; i<=red; i++)
			cout<<Mat[K][i]<<endl;
	
	
	return 0;
}
