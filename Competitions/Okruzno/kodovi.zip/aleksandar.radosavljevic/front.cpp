#include<iostream>
using namespace std;
class Vojnik
{
	public:
		int x;
		int y;
		void Unos(int a, int b)
		{
			x=a;
			y=b;			
		}
};

int main()
{
	int N, a, b, pom=0, pom1, pom3=0, br=0, br1=0, i, j;
	cin>>N;
	Vojnik V[N], B[N], M[N];
	for(int i=0; i<N; i++)
	{
		cin>>a>>b;
		V[i].Unos(a,b);
	}
	for(i=0; i<N-1; i++)
	{
		for(j=i+1; j<N; j++)
		{
			if(V[i].y==V[j].y)						
			{
				pom=1;
				break;
			}
			if(V[i].y!=V[j].y)
					continue;
		}
		if(pom==0)	
		{
			B[br].x=V[i].x; B[br].y=V[i].y;
			br++;
		}
		pom=0;		
	}
	for(i=0; i<br-1; i++)
	{
		for(j=0; j<br-i-1; j++)
			if(B[j].y>B[j+1].y)
			{
				pom1=B[j].y;
				B[j].y=B[j+1].y;
				B[j+1].y=pom1;
			}

	for(i=0; i<br-1; i++)
	{
		for(j=i+1; j<br; j++)
		{
			if(B[i].y==B[j].y)						
			{
				pom=1;
				break;
			}
			if(B[i].y!=B[j].y)
				continue;
		}
		if(pom==0)	
		{
			M[br1].x=B[i].x; M[br1].y=B[i].y;
			br1++;
		}
		pom=0;		
	}
	cout<<endl<<br1+1<<endl<<endl;
	}
	return 0;
}
