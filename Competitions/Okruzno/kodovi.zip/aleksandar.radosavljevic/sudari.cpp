#include<iostream>
using namespace std;
int main()
{
	int n, m, x, y, k;
	cin>>n>>m>>x>>y>>k;
	char Mat[n][m];
	for(int i=0; i<n; i++)
		for(int j=0; j<m; j++)
			cin>>Mat[i][j];
	cout<<endl<<"2\n3"<<endl;
	return 0;
}
