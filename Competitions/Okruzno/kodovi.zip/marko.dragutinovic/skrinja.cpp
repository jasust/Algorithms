#include <cstdio>

using namespace std;

int a[14];
bool a1[14];
int per[14];
int perbr[14];

int main()
{
    int n,k;
    long long opt=0;
    long long sum=0;
    scanf("%d %d", &n,&k);
    for(int i=0;i<n;i++)
    {
            scanf("%d",&a[i]);
            sum+=a[i];
    }
    for(int i=0;i<n;i++)
    {
            a1[i]=true;
            perbr[i]=0;       
    }
    opt=sum/k;
    int del=sum%k;
    int max=0;
    int pos=0;
    int count=k;
    for(int i=0;i<n;i++)
    {
            pos=0;max=0;
           for(int j=0;j<n;j++)
           {
                   if(max<a[j] && a1[j])
                   {
                               max=a[j];                  
                               pos=j;
                    }
           } 
           a1[pos]=false;
           if(perbr[count]<opt+del)
           {
                               per[pos]=count;
                               perbr[count]+=max; 
                               count--;
           }
           if(count==0)count=k;
    }
    for(int i=0;i<n;i++)
            printf("%d",per[i]);
    return 0;   
}
