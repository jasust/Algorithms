#include <cstdio>

using namespace std;

long long p[10010];
long long h[10010];

int main()
{
    long long n,x;
    int k=0;
    int dir=1;
    long long buk=0;
    long long sec=0;
    scanf("%lld", &n);
    scanf("%lld", &x);
    for(int i=0;i<n;i++)
    {
            scanf("%lld %lld", &p[i],&h[i]);
            if(x>=p[i])k++;       
    }
    if(k==0)
    {
            printf("%lld\n %lld",1,p[0]-x);
            return 0;       
    }
    int des=k;
    int lev=k-1;
    sec+=p[des]-x;
    bool change=true;
    bool ima=true;
    while(ima)
    {
              change=true;
             
              if(dir==1)
              {
                       h[des]--;buk++; 
                       
                       if(h[des]==0)
                       {
                                    change=false;
                            sec+=p[des]-p[lev];
                            des++;
                       }
                       dir=-1;
              }
              else if(dir==-1)
              {
                         h[lev]--;buk++; 
                         if(h[lev]==0)
                         {
                                      change=false;
                            sec+=p[des]-p[lev];         
                            lev--;
                         }
                         dir=1;
              }
              if(des>n-1 || lev<0)
              {
                         ima=false;
                         break;
              }
              if(change)
              {
                 if(h[lev]>h[des])
                 {
                        buk+=2*h[des];
                        h[lev]-=h[des];
                        if(dir==-1)
                        sec+=(p[des]-p[lev])*(h[des]+2);
                        else
                        sec+=(p[des]-p[lev])*(h[des]+1);
                        h[des]=0;
                        des++;
                        dir=-1;
                 }   
                 else if(h[lev]<h[des])
                 {
                      buk+=2*h[lev];
                      h[des]-=h[lev];
                      if(dir==-1)
                        sec+=(p[des]-p[lev])*(h[lev]+1);
                      else
                        sec+=(p[des]-p[lev])*(h[lev]+2);
                      h[lev]=0;
                      lev--;
                      dir=1;    
                 }
                 else 
                 {
                     if(dir==1)
                     {
                               buk+=2*h[lev];
                               sec+=(p[des]-p[lev])*h[des]*h[lev];
                               if(des+1>n-1)
                               {
                                            ima =false;                        
                               }
                               else
                               {
                                   sec+=p[des+1]-p[lev];
                               }
                               h[lev]=0;
                               h[des]=0;
                               des++;
                               lev--;
                     } 
                     else 
                     {
                            buk+=2*h[lev];
                               sec+=(p[des]-p[lev])*h[des]*h[lev];
                               if(lev-1<0)
                               {
                                            ima =false;                        
                               }
                               else
                               {
                                   sec+=p[des]-p[lev-1];
                               }
                               h[lev]=0;
                               h[des]=0;
                               des++;
                               lev--;  
                     }
                      
                 }
              }
    }
    printf("%lld %lld",buk,sec );
    return 0;   
}
