#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

long long pre[100000][2];
long long posle[100000][2];
long long i,x,n,temp,pren,poslen,t1,t2,distanca,brojkodova,l,d;
bool done, idedesno;

int main()
{
    scanf("%lld %lld", &n, &x);
    for (i=0; i<n; i++)
    {
        scanf("%lld",&temp);
        if(temp < x)
        {
            pre[i][0]=temp;
            scanf("%lld",&t1);
            pre[i][1]=t1;
        }
        else
        {
            pren=i;
            posle[0][0]=temp;
            scanf("%lld",&t1);
            posle[0][1]=t1;
            break;
        }
    }
    if (i < n-1)
    {
        temp=1;
        i++;
        for(i=i; i<n; i++)
        {
            scanf(" %lld",&t1);
            scanf(" %lld",&t2);
            posle[temp][0]=t1;
            posle[temp][1]=t2;
            temp++;

        }
        poslen=temp;
    }
    else poslen=1;

    l=0;
    d=0;
    distanca=posle[0][0]-x;
    brojkodova=1;
    posle[0][1]--;
    idedesno=false;



    while((d < poslen) && (l < pren))
    {
        if(idedesno)
        {
            if (pre[l][1] < posle[d][1])
            {
                distanca+=(posle[d][0] - pre[l][0]) * (2*pre[l][1]+1);
                brojkodova+=2*pre[l][1] + 1;
                if(pre[l][1] == 0)
                    posle[d][1]--;
                else
                    posle[d][1]=posle[d][1] - pre[l][1] - 1;
                idedesno=false;
                l++;
            }
            else
            {
                distanca+=(posle[d][0] - pre[l][0]) * (2*posle[d][1]);
                brojkodova+=2*posle[d][1];
                pre[l][1]=pre[l][1] - posle[d][1];
                idedesno=true;
                d++;
            }
        }
        else
        {
            if (posle[d][1] < pre [l][1])
            {
                distanca+=(posle[d][0] - pre[l][0]) * (2*posle[d][1]+1);
                brojkodova+=2*posle[d][1] + 1;
                if (posle[d][1] == 0)
                    pre[l][1]--;
                else
                    pre[l][1]=pre[l][1] - posle[d][1] - 1;
                idedesno=true;
                d++;
            }
            else
            {
                distanca+=(posle[d][0] - pre[l][0]) * (2*pre[l][1]);
                brojkodova+=2*pre[l][1];
                posle[d][1]=posle[d][1]-pre[l][1];
                idedesno=false;
                l++;
            }
        }
    }
     printf("%lld\n",brojkodova);
     printf("%lld\n",distanca);
    return 0;
}
