#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

long long int N, K, A[15], so[15], pe[15], is[15];

int pronadji(long long int D[], long long int Ci)
{
    int i;
    {
        for(i=0; i<N; i++)
        {
            if(D[i]==Ci)
            {
                D[i]=-1;
                return i;
            }
        }
        return 15;
    }
}

int najmanje(long long int P[])
{
    int i, j, nm;
    nm=P[0];
    j=0;
    for(i=0; i<K; i++)
    {
        if(nm>P[i])
        {
            nm=P[i];
            j=i;
        }
    }
    return j;
}

int najvise(long long int P[])
{
    int i, j, nm;
    nm=1;
    for(i=0; i<K; i++)
    {
        if(nm<P[i])
        {
            nm=P[i];
            j=i;
        }
    }
    return j;
}
bool tmp(long long int a, long long int b)
{
    a>b;
}
int main()
{
    scanf("%lld %lld", &N, &K);
    int i, mi, br;
    long long int kako, br1;
    for(i=0; i<N; i++)
    {
        scanf("%lld", &A[i]);
        so[i]=A[i];
        is[i]=0;
    }
    for(i=0; i<K; i++)
        pe[i]=0;
    sort(A, A+N);
    for(i=N-1; i>-1; i--)
    {
        mi=najmanje(pe);
        pe[mi]=pe[mi]+A[i];
        kako=A[i];
        br=pronadji(so, kako);
        is[br]=mi+1;
    }
    br=najvise(pe);
    mi=najmanje(pe);
    br1=pe[br]-pe[mi];
    printf("%lld\n", br1);
    for(i=0; i<N; i++)
        printf("%lld ", is[i]);

    return 0;
}
