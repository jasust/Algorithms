#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

long long int N, X, P[100005], H[100005], C, T;
int flag, gleda;

int main()
{
    scanf("%lld %lld", &N, &X);
    long long int i, le, de;
    le=-1;
    for(i=0;i<N;i++)
    {
        scanf("%lld %lld", &P[i], &H[i]);
        if(X>P[i])
            le++;
    }
    if(le==-1)
    {
        printf("%lld\n", le+2);
        printf("%lld", P[0]-X);
    }
    else
    {
        de=le+1;
        T=P[de]-X;
        C=1;
        H[de]--;
        gleda=1;
        flag=1;
        while(flag)
        {
            if(gleda)
            {
                if(H[le]>H[de])
                {
                    C=C+2*H[de];
                    T=T+((H[de]+1)*(P[de]-P[le]));
                    H[le]=H[le]-H[de];
                    de++;
                    gleda=0;
                }
                else // if(H[le]<=H[de])
                {
                    C=C+2*H[le];
                    T=T+(H[le]*(P[de]-P[le]));
                    H[de]=H[de]-H[le];
                    le--;
                    gleda=1;
                }
            }
            else
            {
                if(H[le]>=H[de])
                {
                    C=C+2*H[de];
                    T=T+(H[de]*(P[de]-P[le]));
                    H[le]=H[le]-H[de];
                    de++;
                    gleda=0;
                }
                else // if(H[le]<H[de])
                {
                    C=C+2*H[le];
                    T=T+((H[le]+1)*(P[de]-P[le]));
                    H[de]=H[de]-H[le];
                    le--;
                    gleda=1;
                }
            }
            if(le<0)
                flag=0;
            if(de>(N-1))
                flag=0;
        }
        printf("%lld\n", C);
        printf("%lld", T);
    }

    return 0;
}
