#include <iostream>
#define MAXN 500
char lavirint[MAXN][MAXN];
using namespace std;

int main(){
    int brojac=0,provera=0;
    int n,m;
    scanf("%d %d",&n,&m);
    int y,x;scanf("%d %d",&y,&x);
    int k;scanf("%d",&k);
    int rezultatx,rezultaty;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++)cin>>lavirint[m][n];
        }
    while(provera<k){
    bool dole=true,gore=false,levo=false,desno=false;
    if(dole==true){
        if(y-1>=0 && lavirint[y-1][x]=='.'){lavirint[y-1][x]='P';brojac++;y--;}
        else {desno=true;provera++;dole=false;

    }
    if(desno==true){
        if(x+1<=n && lavirint[y][x+1]=='.'){lavirint[y][x+1]='P';brojac++;x++;}
        else{gore=true;provera++;desno=false;}

    }
    if(gore==true){

        if( y+1>=m&&lavirint[y+1][x]=='.'){lavirint[y+1][x]='P';brojac++;y++;}
        else{levo=true;provera++;gore=false;}

    }
    if( levo==true){
        if(x-1 >=0 &&lavirint[y][x-1]=='.'){lavirint[y][x-1]='P';brojac++;x--;}
        else{dole=true;provera++;levo=false;}

    }
    if(provera==k){
        rezultatx=x+1;rezultaty=y+1;
    }

        }
    printf("%d %d %d",rezultatx,rezultaty,brojac);
    return 0;
    }

}
