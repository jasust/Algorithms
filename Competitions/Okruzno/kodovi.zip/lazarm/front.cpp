#include <iostream>
#define MAXN 1000001
using namespace std;

long long int x[MAXN];
long long int y[MAXN];

int main()
{
    int brojac=0;
    int n;scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d %d",&x[i],&y[i]);
    }
    for(int i=0;i<n ;i++){
        bool dali=true;
        for(int j=0;j<n;j++){if(y[j]>=y[i] && x[j]>x[i])dali=false;}
        if(dali==true)brojac++;
    }
    printf("%d",brojac);
    return 0;
}
