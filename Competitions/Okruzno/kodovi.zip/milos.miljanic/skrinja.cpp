#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

bool cmp (int a, int b) {return a<b;}

int n,k;
long long skripte[13];
long long skr[13];
long long perice[13];
int i;
long long asd[13];
long long tr;
int c,b;
long long mini, maxi;  ///perica koliko ima
int minR, maxR; ///redni broj
long long xxx;
long long tmpMini;
int main()
{
    mini = 0;
    maxi = 0;
    minR = 0;
    maxR = 0;
    scanf(" %d %d", &n,&k);
    for(i = 0; i<n; i++)
    {
        scanf(" %lld", &skripte[i]);
        skr[i] = skripte[i];
    }
    sort(skripte, skripte+n, cmp);
    for(i = 0; i<k; i++)
    {
        perice[i] = 0;
    }



printf(" %lld %lld \n", mini, maxi);
    for(c = n-1; c>=0; c--)  ///ide kroz skripte
    {
        perice[minR] = perice[minR] + skripte[c];
        for(i = 0; i<n; i++)
        {
            if (skr[i] == skripte[c]) {asd[c] = minR;}
        }
        tmpMini = perice[0];
        for(i = 0; i<k; i++)
        {
            if(perice[i]<= tmpMini)
            {
                tmpMini = perice[i];
                minR = i;
            }
            if(perice[i]>maxi)
            {
                maxi = perice[i];
                maxR = i;
            }
            mini = tmpMini;
        }
    }
    xxx = maxi-mini;
    printf("%lld", xxx);
    for(i=0; i<n-1; i++)
    {
        printf("%d",asd[i]);
    }



    return 0;
}
