#include <stdio.h>
#include <stdlib.h>




long long x, n;
long long p[100001];
long long h[100001];
long long levo, desno, uzeo;
long long presao =0;
long long tren;
long long levokom=0;
int main()
{
    scanf("%lld %lld", &n,&x);
    long i;

    for (i = 0; i<n; i++)
        {
            scanf(" %lld %lld", &p[i], &h[i]);
            if (p[i]>x) desno+= h[i];
                else
                {
                    levo += h[i];
                    levokom++;
                }

        }
    if (levo<desno) uzeo = levo; else uzeo = desno;
    uzeo=2*uzeo;
    if ((levo%2==1 && levo!=desno)|| desno>levo) uzeo++;





    tren = x;
    for (i=levokom-1; i<n; i++)
    {
        presao = presao+desno*abs(p[i]-tren);
        desno -= 1;
        tren = p[i];
    }

    tren = x;
    for (i=levokom-1; i>=0; i--)
    {
        presao = presao + levo*abs(tren-p[i]);
        levo -= 1;
        tren = p[i];
    }
    printf("%lld \n", uzeo);
    printf("%lld", presao);
    return 0;
}
