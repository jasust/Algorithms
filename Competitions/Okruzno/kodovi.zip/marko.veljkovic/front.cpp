#include<cstdio>
int main()
{
	int N,x[1000000],y[1000000],F=0,i,j;
	scanf("%d", &N);
	for(i=0;i<N;i++)
		scanf("%d %d", &x[i], &y[i]);
	for(i=0;i<N-1;i++)
		{
		 F++;
		 for(j=i+1;j<N;j++)
		 {
				
			if((x[i]<=x[j])&&(y[i]<=y[j]))
			{  
				 F--;
				 break;
			}
			else if(x[i]==x[i-1])
				if(y[i]<y[i-1])
				{
					F--;	
		 			break;
		 		}
		 }
		}		
	if(x[N-1]!=x[N-2])
		F++;
	else
		if(y[N-1]>y[N-2])
			F++;
	printf("%d", F);
	return 0;
}
