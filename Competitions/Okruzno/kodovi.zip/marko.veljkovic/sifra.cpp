#include<cstdio>
#include<cmath>
int main()
{
	int N,M,K,A[100000],i,m,j,n;
	scanf("%d %d %d", &N, &M, &K);
	for(i=0;i<N;i++)
		scanf("%d", &A[i]);
	for(j=1;j<M;j++)
	{	
		n=pow(N,M-j);
		if((K%n)<K)
			{
			 m=K/n;
			 printf("%d ",A[m]);	
			}
		else
			{
				printf("%d ",A[0]);
			}
		K%=n;	
	}
	printf("%d",A[K/M]);
	return 0;
}
