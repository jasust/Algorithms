#include <cstdlib>
#include <iostream>
#include <vector>
#include <algorithm>
#include <iterator>
#include <list>
#include <cmath>
//lel

using namespace std;

struct pile
{
       int pos;
       int count;
       };

void subtract(list<pile>::iterator it, list<pile> lista, int x = 1)
{
     it->count-= x;
     if(it->count == 0)
     lista.erase(it);
     }
     
int dist(list<pile>::iterator it1, list<pile>::iterator it2)
{
    return abs(it2->pos - it1->pos);
}

int main()
{
    ios_base::sync_with_stdio(false);
    
    int pN, sX;
    list<pile> lista;
    pile sima;
    bool sInit = false;
    int sDist = 0;
    list<pile>::iterator sIt, pt1, pt2;
    
    cin >> pN >> sX;
    
    sima.pos = sX;
    sima.count = 0;
    
    for(int i=0; i < pN; i++)
    {
            pile buff;
            cin >> buff.pos >> buff.count;
            
            if(!sInit && buff.pos > sima.pos)
            {sIt = lista.insert(lista.end(), sima); sInit = true;}
            
            lista.push_back(buff);
            }
            
    pt1 = sIt;
    
    int dir = 1; //1 desno, -1 levo
    
    //ovaj if je suvisan
    /*if(++pt1 != lista.end())
    {
             subtract(pt1, lista);
             sIt->count++;
             sDist+= dist(sIt, pt1);
             sIt->pos = pt1->pos;
             dir = -1;
             }*/
                      
    while(true) // ovo nije dobro
    {
              
              
              pt1 = sIt;
              pt2 = sIt;
              
              //sima treba da krene ka pt1 od pt2
              if(dir == -1){pt1--; pt2++;}
              else{pt1++; pt2--;}
              
              
              if(pt1 == lista.end() || pt1 == --lista.begin())
              {
                     cout << sIt->count << "\n" << sDist;
                     return 0;
                     }
              if(pt1 == lista.end() || pt1 == --lista.begin())
              {
                     sIt->count++;
                     sDist+= dist(pt1, sIt);
                     cout << sIt->count << "\n" << sDist;
                     return 0;
                     }
              
              //if sIt.p != pt2.p; treba oduzeti razliku od sDist
              if(sIt->pos != pt2->pos)
              {
                         sDist -= dist(pt2, sIt);
                         }
              
              int c = 0;
              
              if(pt1->count <= pt2->count)
              {
                          c = pt1->count;
                          sDist += dist(pt1, pt2)*(c)*2;
                          sIt->pos = pt2->pos;
                          subtract(pt2, lista,c);
                          subtract(pt1,lista,c); 
                          sIt->count+= 2*c;
                          //dir = dir;                   ne menja se smer                           
                            }
              else
              {
                  c = pt2->count;
                  sDist += (dist(pt1,pt2)*((2)*c+1));
                  sIt->pos = pt1->pos;
                  subtract(pt1,lista,c);    
                  subtract(pt2, lista,c);                  
                  sIt->count+= 2*c+1;
                  dir *= -1;                          
                  }
              }
    return 0;  
}


