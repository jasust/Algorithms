#include <cstdlib>
#include <iostream>
#include <algorithm>

using namespace std;


int org[300][300];
int ms[300][300];
int ns[300][300];

bool compAsc(int a, int b)
{
     return a < b;
     }
bool compDesc(int b, int a)
{
      return a < b;
     }
     
int main()
{
    int N, M;
    cin >> N >> M;
    
    for(int i=0; i<N; i++)
    {
            for(int j =0; j<M; j++)
            {
                    int buff;
                    cin >> buff;
                    org[i][j]  = buff;
                    
                    ns[i][j] = buff;
                    
                    ms[j][i]= buff;
                    }
            }
            
    for(int i = 0; i < N; i++)
    {
            sort(ns[i], ns[i]+M, compAsc);
            }
    for(int i = 0; i < M; i++)
    {
            sort(ms[i], ms[i]+N, compDesc);
            }
    int sol = -1;
    for(int i=0; i<N; i++)
    {
            for(int j =0; j<M; j++) // za svaki potencijalni presto (polje)
            {
                    int cur = org[i][j];
                    int y = 0;
                    for(int x = 0; x < M;)
                    {
                            int val = ns[i][x];
                            while(val < ms[j][y])
                            {
                                      y++;
                                      }
                            int cursol = x + y;
                            if(val != cur )cursol++;
                            if(sol == -1 || cursol < sol)
                             sol = cursol;
                             
                             while(val == ns[i][x])
                             x++;                   
                    }
                    y = 0;
                    for(int x = 0; x < N;)
                    {
                            int val = ms[j][x];
                            while(val > ns[i][y])
                            {
                                      y++;
                                      }
                            int cursol = x + y;
                            if(val != cur )cursol++;
                            if(sol == -1 || cursol < sol)
                             sol = cursol;
                             
                             while(val == ms[j][x])
                             x++;                   
                    }
            }
    }
    cout << sol;
    return 0;
}
