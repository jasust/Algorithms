#include<cstdio>

int main(){
	int n, m, k, swap;

	scanf("%d%d%d", &n, &m, &k);

	int lista[n];

	for(int i = 1; i < n; i++){
		scanf("%d", &lista[i]);
	}
	scanf("%d", &lista[0]);

	int izlaz[m]; 

	for(int i = m - 1; i >= 0; i--){
		izlaz[i] = lista[k % n];

		if(k % n == 0){
			k = k / n;
		}
		else
		{
			k = k / n + 1;
		}
	}

	for(int i = 0; i < m - 1; i++){
		printf("%d ", izlaz[i]);
	}

	printf("%d\n", izlaz[m - 1]);

	return 0;
}
