#include<cstdio>

int main(){
	int n, m, y, x, k, counter = 0, smer = 0;

	scanf("%d%d%d%d%d", &n, &m, &y, &x, &k);

	char mapa[n][m];

	x--; y--;

	for(int i = 0; i < n * m; i++){
		do{
			mapa[i/m][i%m] = getchar();
		}while(mapa[i/m][i%m] == '\n' || mapa[i/m][i%m] == '\r');
	}

	do{
		if(smer % 4 == 0){
			if(mapa[y + 1][x] == '#' || y == n - 1){
				counter++;
				smer++;
			}
			else
			{
				y++;
			}
		}
		else if(smer % 4 == 1){
			if(mapa[y][x + 1] == '#' || x == m - 1){
				counter++;
				smer++;
			}
			else
			{
				x++;
			}
		}
		else if(smer % 4 == 2){
			if(mapa[y - 1][x] == '#' || y == 0){
				counter++;
				smer++;
			}
			else
			{
				y--;
			}
		}
		else if(smer % 4 == 3){
			if(mapa[y][x - 1] == '#' || x == 0){
				counter++;
				smer++;
			}
			else
			{
				x--;
			}
		}

		//printf("%d %d\n", y + 1, x + 1);
	}while(counter != k);

	printf("%d %d\n", y + 1, x + 1);

	return 0;
}
