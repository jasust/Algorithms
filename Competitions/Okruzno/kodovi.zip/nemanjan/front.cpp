#include<cstdio>
#include<map>

using namespace std;

typedef map<int, int> brojevi;

int main(){
	int n, max = 0;

	scanf("%d", &n);

	int lista[n][2];
	
	for(int i = 0; i < n; i++){
		scanf("%d%d", &lista[i][0], &lista[i][1]);
	}

	brojevi maxY;

	for(int i = n - 1;  i >= 0; i--){
		if(i < n - 1){
			if(maxY[lista[i + 1][0]] > maxY[lista[i][0]]){
				maxY[lista[i][0]] = maxY[lista[i + 1][0]];
			}
		}

		if(lista[i][1] > maxY[lista[i][0]]){
			maxY[lista[i][0]] = lista[i][1];
		}
	}

	int counter = 0;

	for(int i = n - 1;  i >= 0; i--){
		if(lista[i][1] >= maxY[lista[i][0]] && lista[i][1] > max){
			counter++;
			max = lista[i][1];
		}
	}

	printf("%d\n", counter);

	return 0;
}
