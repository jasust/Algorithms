#include <cstdio>
#include <cmath>
#include <iostream>
using namespace std;

int n, i, y[10006],x[10006],br,br1;

int main () {
scanf ("%d",&n);
    for (i=1;i<=n;i++) {
        scanf("%d %d",&x[i],&y[i]);
                if (x[i]<abs(y[i-1]-x[i-1])) {br++;}
                if (y[i]<abs(x[i-1]-y[i+1])) {br1++;}
        }
printf ("%d",br+br1);
return 0;
}
