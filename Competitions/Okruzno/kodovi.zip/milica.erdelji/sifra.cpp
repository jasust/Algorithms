#include <cstdio>
using namespace std;
int M, K, N, sifra;
using namespace std;
int main () {
scanf ("%d %d %d", &M, &K, &N);
scanf ("%d", &N);
for(N=1; N<=K; N++) printf ("%d ",M);
return 0;
}
