#include <cstdio>

using namespace std;
int n, m, y, x, k, y1, x1;

int main () {
scanf ("%d %d", &n, &m);
scanf ("%d %d", &y, &x);
scanf ("%d", k);
scanf ("%d", m );

for (k=1;k<=m;k++) printf ("%d %d",&x1,&y1);
return 0;
}
