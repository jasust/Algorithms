#include <stdio.h>

enum Dir {up = 0, right, down, left};
struct T {int x, y;};

int mat[501][501];

int main()
{
    int n, m, k, i, j, kt = 0;
    T pos;
    Dir dir = down;
    char c;

    scanf("%d %d", &n, &m);
    scanf("%d %d", &pos.y, &pos.x);
    scanf("%d", &k);

    for(i = 1; i <= n; i++)
        for(j = 1; j <= m; j++)
        {
            scanf("%c", &c);
            if(c != '\n' && c != '\r')
                mat[i][j] = c;
            else
                j--;
        }


    while(kt < k)
    {
        switch(dir)
        {
        case up:
            while(pos.y - 1 > 0 && mat[pos.y - 1][pos.x] == '.') {pos.y--;}
            kt++;
            dir = left;

            break;
        case right:
            while(pos.x + 1 <= m && mat[pos.y][pos.x + 1] == '.') {pos.x++;}
            kt++;
            dir = up;

            break;
        case down:
            while(pos.y + 1 <= n && mat[pos.y + 1][pos.x] == '.') {pos.y++;}
            kt++;
            dir = right;

            break;
        case left:
            while(pos.x - 1 > 0 && mat[pos.y][pos.x - 1] == '.') {pos.x--;}
            kt++;
            dir = down;

            break;
        }
    }

    printf("%d %d", pos.y, pos.x);
    delete[] mat;

    return 0;
}
