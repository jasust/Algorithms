#include <stdio.h>

struct T {int x, y;};


int main(void)
{
    int n;
    int frontCount = 0;
    T v, maxfront;

    maxfront.x = 0;
    maxfront.y = 0;
    scanf("%d", &n);

    for(int i = 0; i < n; i++)
    {
        scanf("%d %d", &v.x, &v.y);

        if(v.x > maxfront.x)
        {
            if(v.y > maxfront.y)
            {
                frontCount = 1;
                maxfront.y = v.y;
            }
            else if(v.y == maxfront.y)
            {
                if(!frontCount)
                    frontCount = 1;

                maxfront.y = v.y;
            }
            else if(v.y < maxfront.y)
                frontCount++;

            maxfront.x = v.x;
        }
        else if(v.x == maxfront.x && v.y > maxfront.y)
        {
            if(!frontCount)
                frontCount = 1;

            maxfront.y = v.y;
        }
    }

    printf("%d", frontCount);

    return 0;
}
