#include <stdio.h>
#include <cmath>

int nnum[100000];
int mnum[100000];

int main(void)
{
    int n, m, i;
    int k, divWith, remaining;

    scanf("%d %d %d", &n, &m, &k);
    for(i = 0; i < n; i++)
        scanf("%d", &nnum[i]);

    for(i = 0; i < m - 1; i++)
    {
        divWith = powl(n, (m - i - 1));
        if(!i)
            remaining = k;

        mnum[i] = remaining / divWith;
        remaining = k % divWith;
    }
    mnum[i] = remaining - 1;

    for(i = 0; i < m; i++)
        printf("%d ", nnum[mnum[i]]);

    return 0;
}



