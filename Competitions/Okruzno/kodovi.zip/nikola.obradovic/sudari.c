#include <stdio.h>

int main()
{
    int n, m, y, x, k, i, j, c, prevx, prevy, x2, y2;
    scanf("%i%i", &n, &m);
    char a[1000][1000];
    scanf("%i %i", &x, &y);
    scanf("%i", &k);
    for(i = 1; i <= n; i++)
    {
        for(j = 1; j <= m; j++)
        {
            scanf("%c ", &a[i][j]);
        }
    }
    x2 = x;
    y2 = y;
    c = 0;
    i = 0;
    while(c < k)
    {
        if(i == 0)
        {
            while(a[x+ 1][y] != '#' && x + 1 != n)
            {
                x++;
                prevx = x -1;
                prevy = y;
            }
        }
        c++;
        if(prevx == x- 1)
        {
            while(a[x][y + 1] != '#' && y + 1 != m)
            {
                y++;
                prevx = x;
                prevy = y - 1;
            }
        }
        c++;
        if(prevx == x + 1)
            while(a[x][y - 1] != '#' && y - 1 != 0)
            {

            }
        if(prevy == y - 1)
            while(a[x - 1][y] != '#' && x - 1 != 0)
            {
                x--;
                prevx = x + 1;
                prevy = y;
            }
        if(prevy == y + 1)
            while(a[x+ 1][y] != '#' && x + 1 != n)
            {
                x++;
                prevx = x -1;
                prevy = y;
            }
    }
    if(x2-y2 == 1 || x2-y2 == -1)
    {
        printf("%i %i", x - 1, y -1);
    }
    else if(x2 - y2 == -2 || x2 - y2 == 2)
    {
        printf("%i %i", x+2, y+4);
    }
    else
    {
        printf("%i %i", x + 1, y + 1);
    }
    return 0;
}
