#include <stdio.h>

int main()
{
    long long int n, m, k, i, j;
    scanf("%lli%lli%lli", &n, &m, &k);
    long long int a[n];
    for(i = 0; i < n; i++)
        scanf("%lli", &a[i]);
    for(i = 0; i < m; i++)
    {
        j = i % 4;
        printf("%i ", a[j]);
    }
    return 0;
}
