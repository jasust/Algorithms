#include <stdio.h>

int main()
{
    long long int n, i, j, f = 0;
    int pom;
    scanf("%lli", &n);
    int x[n], y[n];
    for(i = 0; i < n; i++)
    {
        scanf("%lli %lli", &x[i], &y[i]);
    }

    for(i = 0; i < n; i++)
    {
        pom = 1;
        for(j = 0; j < n; j++)
        {
            if(j != i )
                if(x[i] <= x[j] && y[i] <= y[j])
                {
                    pom = 0;
                    break;
                }
                }
        }
        if(pom == 1)
            f++;
    }
    printf("%lli", f);
    return 0;
}
