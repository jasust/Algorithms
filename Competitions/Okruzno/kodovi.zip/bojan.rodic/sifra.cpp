#include<cstdio>
using namespace std;
int n,m,k,a[10005];
int main() {
    scanf("%d %d %d",&n,&m,&k);
    for(int i=1;i<=n;i++){
            scanf("%d",&a[i]);
    }
    printf("%d",a[k]);
    return 0;
}
