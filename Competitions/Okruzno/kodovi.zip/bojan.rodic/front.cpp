#include<cstdio>
using namespace std;
int n,x[100005],y[100005],res,i;
int main() {
    scanf("%d",&n);
    res=1;
    for(int i=1;i<=n;i++){
            scanf("%d %d",&x[i],&y[i]);
    }
    for(int i=1;i<=n;i++){
            for(int j=i+1;j<=n;j++){
                    if(x[i]>x[j] or y[i]>y[j]) res++; break;
                    }
                    if(x[i]==x[i+1]) res=1;
    }
    printf("%d\n",res);
    return 0;
}

