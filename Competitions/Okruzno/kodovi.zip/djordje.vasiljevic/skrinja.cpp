#include<stdio.h>
#include<iostream>

using namespace std;


struct knjiga{
       int x;
       int i;
       
       };

bool uslov(const knjiga a,const knjiga b)
{
     return a.x>b.x;
}

int main()
{
    int n,k;
    knjiga a[20];
     scanf("%d%d",&n,&k);
    for(int i=0;i<n;i++)
    {
       scanf("%d",&a[i]);
    }
    if(k>=n)
     for(int i=0;i<n;i++)
     {
             printf("%d ",i+1);
     }
    else
    {
      sort(a,a+n,uslov);
      for(int i=0;i<n/k;i++)
      {
          
      }    
    }

    return 0;    
}
