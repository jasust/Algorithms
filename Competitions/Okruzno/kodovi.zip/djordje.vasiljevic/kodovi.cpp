#include<stdio.h>
#include<iostream>
#include<vector>

using namespace std;

       
       
struct polje{
       
    int x;
    int v;
    int i; 
    
    polje(int p,int q,int j)
    {
      x=p;
      v=q;
      i=j;          
    }

    polje()
    {}
      
};

struct blok{
  polje p1;
  polje p2;
  int r;
  
  blok(polje v1,polje v2)
  {
    p1=v1;
    p2=v2;
    r=p2.x-p1.x;
  }
       
};

int n,x;
vector<polje> a;
int y=0,l=0;


int nadji_levi(polje p1)
{
    if(p1.v>0)
     return p1.i;
     
    for(int i=p1.i-1;i>=0;i--)
    {
      if(a[i].i!=-1 && a[i].v>0)
        return i;        
    }  
    return -1;
}
int nadji_desni(polje p1)
{
   if(p1.v>0)
     return p1.i;
     
    for(int i=p1.i;i<n;i)
    {
      if(a[i].i!=-1 && a[i].v>0)
        return i;        
    }  
    return -1;   
    
    
}


bool resi_blok(blok &g,int &smer,int &x)
{
     
     
    polje p1=g.p1;
    polje p2=g.p2;
    int r=g.r;
    if(smer ==1)
       {  
         if(p2.i==-1)
          return 0; 
         p2=a[p2.i];  
         y+=p2.x-x; 
         l++;
         p2.v--;
         if(p1.i==-1)
          return 0;
         p1=a[p1.i];
         
         
         if(p1.v<p2.v) //izlazi levo
         {
          
           x=p1.x; l+=2*p1.v+1;
           y+=(2*p1.v+1)*r;
           x=p1.x;
           smer=-1;
           p1.v-=p1.v;
           p2.v-=p1.v+1;
           int i1=nadji_levi(p1);
           int i2=nadji_desni(p2);
           p1.i=i1;
           p2.i=i2;
           if(i1==-1)
            return 0;
           p1=a[i1];
                                            
         }
         else //izlazi desno
         {
             l+=2*p2.v;
             y+=(2*p2.v)*r;
             x=p2.x;
             smer=1;
             p1.v-=p2.v;
             p2.v-=p2.v;
             int i1=nadji_levi(p1);
             int i2=nadji_desni(p2);
              p1.i=i1;
              p2.i=i2;
               if(i2==-1)
                 return 0;
               p2=a[i2];
         }
         
       }
       else
       {
           if(p1.i==-1)
             return 0; 
         p1=a[p1.i];      
         y+=x-p1.x;
         l++;
         p1.v--;
         
          if(p2.i==-1)
          return 0;
          p2=a[p2.i];
         
         if(p1.v<=p2.v)//izasao levo
         {
           l+=2*p1.v;
           y+=(2*p1.v)*r;
           x=p1.x;
           smer=-1;
           p1.v-=p1.v;
           p2.v-=p1.v;
           int i1=nadji_levi(p1);
           int i2=nadji_desni(p2);
           p1.i=i1;
           p2.i=i2;
           
           if(i1==-1)
            return 0;
           p1=a[i1];                                    
         }
         else //izasao desno
         {
            l+=2*p2.v+1;
            y+=(2*p2.v+1)*r; 
            x=p2.x;
            smer=1;
            p1.v-=p2.v+1;
            p2.v-=p2.v;
            int i1=nadji_levi(p1);
            int i2=nadji_desni(p2);
            p1.i=i1;
            p2.i=i2;
           
             if(i1==-1)
               return 0;
             p2=a[i2];  
         }
           
       }
       return 1;  
     
}





int main()
{
  
    scanf("%d%d",&n,&x);

    
    int p,q,n1=n;
    //-----------------------
    
    for(int i=0;i<n;i++)
    {
       scanf("%d%d",&p,&q);
       if(q)
        {
            a.push_back(polje(p,q,i-(n-n1)));
        }
       else
        n1--;
    }
    //---------------------
    if(n1>2)
    {
      
      int start=-1;
      for(int i=1;i<n;i++)
       {
              if(a[i-1].x<x && x<=a[i].x)
                 {
                   start=i-1; 
                   break;          
                 }
       }
       blok g(a[start-1],a[start]);
       int smer =1;

       while(resi_blok(g,smer,x));
       printf("%d\n%d\n",l,y);

}


    return 0;    
}
