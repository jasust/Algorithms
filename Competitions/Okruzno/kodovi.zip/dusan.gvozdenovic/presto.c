#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){

    int n, m, i, j;

    scanf("%d%d", &n, &m);

    float garden[n][m];

    for(i = 0; i < n; i++)
        for(j = 0; j < m; j++)
            scanf("%f", &garden[i][j]);



    return 0;
}
