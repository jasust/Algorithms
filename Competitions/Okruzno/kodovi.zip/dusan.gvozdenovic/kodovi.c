#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LLONG long long
#define RIGHT 1
#define LEFT 0

typedef struct{
        LLONG num;
        LLONG x;
}Heap;

int main(){
    LLONG n, sima, i, start, iter, code_num = 0, secs = 0, prev, first = 1;
    int dir = RIGHT, added = 1;

    scanf("%lld%lld", &n, &sima);

    n++;

    Heap codes[n], *current = NULL;

    for(i = 0; i < n; i++){
        scanf("%lld%lld", &codes[i].x, &codes[i].num);
        if(codes[i].x > sima && added){
            start = i - 1;
            codes[i + 1].x = codes[i].x;
            codes[i + 1].num = codes[i].num;
            codes[i].x  = sima;
            codes[i].num = 1;
            i++;
            added = 0;
        }
    }

    Heap *find_next(){
        if(dir == LEFT){
            for(iter = start - 1; iter >= 0; iter--){
                if(codes[iter].num > 0){
                    dir  = RIGHT;
                    start = iter;
                    return &codes[iter];
                }
            }
        }else{
            for(iter = start + 1;iter < n; iter++){
                if(codes[iter].num > 0){
                    if(first)
                        first = 0;
                    else
                        dir = LEFT;
                    start = iter;
                    return &codes[iter];
                }
            }
        }
        return NULL;
    }

    prev = sima;

    while((current = find_next()) != NULL){
       current->num--;
        code_num++;
        secs += abs(current->x - prev);
        prev = current->x;
    }


    printf("%lld\n%lld", --code_num, secs);

    return 0;
}
