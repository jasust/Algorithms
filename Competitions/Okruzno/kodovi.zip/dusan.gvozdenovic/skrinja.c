#include <stdio.h>
#include <stdlib.h>

#define MAX(A, B) ((A) > (B) ? (A) : (B))
#define MIN(A, B) ((A) < (B) ? (A) : (B))

typedef struct{
    int length;
    long pages[13];
    long long sum;
}Perica;

void perica_insert(Perica *self, long pgs){
    //printf("Insertion : %d %lld\n", self->length, self->sum);
    self->pages[self->length] = pgs;
    self->sum += pgs;
    self->length++;
}

int perica_contains(Perica *self, long pgs){
    int i;
    for(i = 0; i < self->length; i++)\
        if(self->pages[i] == pgs)
            return 1;
    return 0;
}

int main(){
    int n, k;

    scanf("%d%d", &n, &k);

    float sum = 0;
    long pages[n], i, j;
    int pgInsert = n - 1;

    for(i = 0; i < n; i++){
        scanf("%ld", &pages[i]);
        sum += pages[i];
    }

    qsort(pages, n, sizeof(long), ({
        int compare(const void *a, const void *b){
            return *(long *)a - *(long *)b;
        }
        compare;
    }));

    Perica perice[k];

    for(i = 0; i < k; i++){
        perice[i].length = 0;
        perice[i].sum = 0;
    }

    sum /= k;

    i = 0;
    while(pgInsert > 0){
        if(i == k) i = 0;
        //printf("pages : %ld\n", pages[pgInsert]);
        perica_insert(&perice[i++], pages[pgInsert--]);
    }


    long long pmax = 0, pmin = 100000001;

    for(i = 0; i < k; i++){
        if(MAX(pmax, perice[i].sum) == perice[i].sum)
            pmax = perice[i].sum;
        if(MIN(pmin, perice[i].sum) == perice[i].sum)
            pmin = perice[i].sum;
    }

    //for(i = 0; i < k; printf("%ld ", perice[i++].sum));

    printf("%ld\n", pmax - pmin);

    for(i = 0; i < n; i++)
        for(j = 0; j < k; j++)
            if(perica_contains(&perice[j], pages[i]))
                printf("%ld ", j + 1);

    return 0;
}
