#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define N 300

int main()
{

	int n,m,i,j,p[N][N],red,kol,k,mi;
	long /*long*/ a[N][N];

	scanf_s("%d %d",&n,&m);

	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
			scanf_s("%ld",&a[i][j]); //%lld

	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
		{
			red=0;
			kol=0;
			for(k=0;k<m;k++)
				if(a[i][k]<a[i][j]) red++;
			for(k=0;k<n;k++)
				if(a[k][j]>a[i][j]) kol++;
			
			p[i][j]=red+kol;
		}
	
	mi=p[0][0];

	for(i=0;i<n;i++)
		for(j=0;j<m;j++)
			if(p[i][j]<mi) mi=p[i][j];

	printf("%d\n",mi);

	return 0;
}