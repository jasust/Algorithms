#include<stdio.h>
#include<stdlib.h>
#include<math.h>

long long manji(long long a, long long b)
{
    long long p=(a<b)?a:b;
    return p;
}

int main()
{
    long long i,n,x,*p,*h,levi,desni,br,ind;
    
    scanf_s("%lld %lld",&n,&x);

    p=(long long *)calloc(n+2,sizeof(long long));
    h=(long long *)calloc(n+2,sizeof(long long));
    
    for(i=1;i<=n;i++) scanf_s("%lld %lld",p+i,h+i);
    p[0]=0;
    p[n+1]=0;
	h[0]=0;
	h[n+1]=0;
    
    
    levi=0;
    
    while(p[levi+1]<x) levi++;
    
    for(i=levi;i<=n;i++)
        if(p[i]>x)
            {
                desni=i;
                break;
            }
    
    int s=1,sek=0,pom=1;
    
    h[desni]--;
    sek=p[desni]-x;
    x=p[desni];
	ind=desni;
    pom=-1;
    
    if(h[desni]==0) desni++;
    
    while(levi!=0 && desni!=n+1)
    {
		if(h[ind]==0)
		{
			if(pom<0)
			{
				sek+=x-p[levi];
				x=p[levi];
				ind=levi;
				pom=-pom;
			}
			else
			{
				sek+=p[desni]-x;
				x=p[desni];
				ind=desni;
				pom=-pom;
			}
		}
		if(h[levi]!=h[desni])
		{
		br=manji(h[levi],h[desni]);
        if((br==h[levi] && ind=desni && pom<0) || (br==h[desni] && ind==levi && pom>0))
        {
            sek+=(2*br-1)*(p[desni]-p[levi]);
            s+=2*br;
            if(br==h[levi])
				{
					h[levi]=0;
					h[desni]-=br;
					levi--;
			}
			else
			{
				h[desni]=0;
				h[levi]-=br;
				desni++;
			}
            pom=-pom;
        }
        else
        {
            sek+=2*br*(p[desni]-p[levi]);
            s+=2*br;

			if(br==h[levi])
				{
					h[levi]=0;
					h[desni]-=br;
					levi--;
			}
			else
			{
				h[desni]=0;
				h[levi]-=br;
				desni++;
			}

            pom=-pom;
        }
		}
		else 
		{
			if(ind==desni)
			{
				s+=2*(h[levi])-1;
				if(h[desni]!=1)
					sek+=2*h[desni]*(p[desni]-p[levi])-1;
				else sek+=p[desni]-p[levi];
				h[desni]=1;
				h[levi]=0;
				ind=levi;
				x=p[ind];
				levi--;
				
		
				pom=-pom;
			}
			else {

			if(ind==levi)
			{
				s+=2*(h[desni])-1;
				if(h[desni]!=1)
					sek+=2*h[desni]*(p[desni]-p[levi])-1;
				else sek+=p[desni]-p[levi];
				sek+=2*(h[desni])*(p[desni]-p[levi])-1;
				h[desni]=0;
				h[levi]=1;
				ind=desni;
				x=p[ind];
				desni++;
				pom=-pom;
			}
		}
		}
    }

	if(desni==n+1 && pom<0)
	{
		s++;
		sek+=x-p[levi];
	}

	if(levi==0 && pom>0)
	{
		s++;
		sek+=p[desni]-x;
	}
    
    printf("%lld\n",s);
    printf("%lld\n",sek);
    
    //system("pause");
    return 0;
}
