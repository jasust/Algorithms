#include <stdio.h>
#include <stdlib.h>
#include <iostream>

int n, s, visited[10000],best = 0,end=0;

bool check(int x)
{
     if(best > s)
     {
             if(x > best)
                       return 0;
             else
                       return 1;
     }
     if(best < s)
     {
             if(x > (s + s - best))
                       return 0;
             else
                       return 1;
     }
}

void compare(int x)
{
            int p= s - x;
            int p2= s - best;
            if(p<0)
                   p= -p;
            if(p2<0)
                    p2= -p2;
            if(p<p2)
            {
                    best = x;
            }
            else
            {
                if(p == p2)
                {
                     if(x<best)
                               best = x;
                }
            }
            if(best == s) end = 1;
}

struct node 
{
       int data;
       node *next; 
};

class graf
{
      private:
              int v[10000];
              node *a[10001];
              int size;
      public:
             graf();
             ~graf();
             void setsize(int);
             void setF(int,int);
             void insert(int, int);
             void print();
             int findRoot();
             void funkcija(int, int);
             void finish(int);
};

void graf :: finish(int x)
{
     if(a[x]->next == a[x])
     {
                   insert(x,size-1);
     }
}

void graf :: funkcija(int x, int c)
{
   if(check(c))
   {
     compare(c);
     if(!end)
     {
              // printf("%i %i %i\n",x, c,best);
               node *p;
               p= a[x]->next;
               while(p!=a[x])
               {
                             funkcija(p->data, c + v[x]);
                             funkcija(p->data, c);
                             p=p->next;
               }
     }
   }
}

int graf :: findRoot()
{
    node *p;
    for(int i=0;i<size-1;i++)
    {
            p= a[i]->next;
            while(p!=a[i])
            {
                          visited[p->data] = 1;
                          p=p->next;
            }
    }
    for(int i=0;i<size-1;i++)
    {
            if(!visited[i])
                           return i;
    }
}


void graf :: print()
{
     node *p;
     for(int i=0;i<size;i++)
     {
             p=a[i]->next;
             printf("%i (%i) : ",i,v[i]);
             while(p!=a[i])
             {
                           printf("%i ",p->data);
                           p=p->next;
             }
             printf("\n");
     }
}

void graf :: insert(int x, int d)
{
     node *p;
     p=new node;
     p->data = d;
     p->next = a[x]->next;
     a[x]->next = p;
}

graf :: graf()
{
     for(int i=0;i<10001;i++)
     {
             a[i]= new node;
             a[i]->next = a[i];
     }
}

void graf :: setF(int x, int d)
{
     v[x] = d;
}

void graf :: setsize(int x)
{
     size = x;
}

graf :: ~graf()
{
     node *p;
     for(int i=0;i<10001;i++)
     {
             while(a[i]->next != a[i])
             {
                              p = a[i]->next;
                              a[i]->next = a[i]->next->next;
                              free(p);
             }         
             free(a[i]);
     }
}

int main()
{
    scanf("%i %i",&n,&s);
    int i,j,k,d,p;
    graf g;
    g.setsize(n);
    for(i=0;i<n;i++)
    {
                    scanf("%i",&d);
                    scanf("%i",&k);
                    g.setF(i,d);
                    for(j=0;j<k;j++)
                    {
                                    scanf("%i",&p);
                                    g.insert(i,p-1);
                    }
    }
    g.setsize(n+1);
    for(i=0;i<n;i++)
    {
                    g.finish(i);
    }
    g.setF(n,0);
  //  g.print();
  //  printf("%i\n",g.findRoot());
    int root = g.findRoot();
    g.funkcija(root, 0);
    printf("%i\n",best);
   // g.print();
   // system("PAUSE");
    return 0;
}
/*
8 20
22 3 2 3 4
7 2 6 5
100 0
1 1 7
10 0
2 1 8
2 0
12 0

8 20
22 3 2 3 4
8 2 6 5
100 0
1 1 7
10 0
2 1 8
2 0
12 0

8 20
22 2 2 3
7 2 6 5
100 0
1 2 7 1
10 0
2 1 8
2 0
12 0

*/
