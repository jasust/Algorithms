#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int a[1000][1000];
int al[1000][1000];
int ag[1000][1000];
int ac1[1000][1000];
int ac2[1000][1000];
int h=0;
int niz[300000];

int main()
{
    int n,q,i,j,e,k,t1=0,t2=0,d,ft,p=5;
    char rec[1000];
    scanf("%i",&n);
    for(i=0;i<n;i++)
    {
                    scanf("%s",rec);
                    for(j=0;j<n;j++)
                    {
                                    a[i][j] = rec[j]-'0';
                    }
    }
    for(i=0;i<n;i++)
    {
                    k=0;
                    for(j=0;j<n;j++)
                    {
                                    if(a[i][j] == 1)
                                    {
                                            al[i][k] = 1;
                                            k++;
                                    }
                    }
    }
    for(j=0;j<n;j++)
    {
                    k=0;
                    for(i=0;i<n;i++)
                    {
                                    if(a[i][j] == 1)
                                    {
                                               ag[k][j] =1;
                                               k++;
                                    }
                    }
    }
    for(i=0;i<n;i++)
    {
                    k=0;
                    for(j=0;j<n;j++)
                    {
                                    if(ag[i][j] == 1)
                                    {
                                            ac1[i][k] = 1;
                                            k++;
                                    }
                    }
    }
    
    for(j=0;j<n;j++)
    {
                    k=0;
                    for(i=0;i<n;i++)
                    {
                                    if(al[i][j] == 1)
                                    {
                                               ac2[k][j] =1;
                                               k++;
                                    }
                    }
    }
    /*
    for(i=0;i<n;i++)
    {
                    for(j=0;j<n;j++)
                    {
                                    printf("%i ",al[i][j]);
                    }
                    printf("\n");
    }
    printf("\n");
    for(i=0;i<n;i++)
    {
                    for(j=0;j<n;j++)
                    {
                                    printf("%i ",ag[i][j]);
                    }
                    printf("\n");
    }
    printf("\n");
    for(i=0;i<n;i++)
    {
                    for(j=0;j<n;j++)
                    {
                                    printf("%i ",ac1[i][j]);
                    }
                    printf("\n");
    }
    printf("\n");
    for(i=0;i<n;i++)
    {
                    for(j=0;j<n;j++)
                    {
                                    printf("%i ",ac2[i][j]);
                    }
                    printf("\n");
    }
    */
    scanf("%i",&q);
    d=0;
    int l=0,g=0;
    for(e=0;e<q;e++)
    {
                    scanf("%i",&k);
                    if(k==1)
                    {
                            scanf("%i",&d);
                            if(d==1)
                            {
                                    t1= 1;
                                    g= 1;
                            }
                            if(d==3)
                            {
                                    t1= 1;
                                    g= 0; 
                            }
                            if(d==2)
                            {
                                    t2=1;
                                    l= 1;
                            }
                            if(d==4)
                            {
                                    t2=1;
                                    l=0;
                            }
                            if(p==5)
                            {
                                    p=t1;
                            }
                    }
                    else
                    {
                            scanf("%i %i",&i,&j);
                            i--;
                            j--;
                            if(d==0)
                            {
                                  //  printf("%i\n",a[i][j]);
                                    niz[h] = a[i][j];
                                    h++;
                            }
                            //*********
                            if(d==1)
                            {
                                    if(t2==0)
                                    {
                                         //    printf("%i\n",ag[i][j]);
                                             niz[h] = ag[i][j];
                                             h++;
                                    }
                                    else
                                    {
                                        if(p)
                                        {
                                            if(l)
                                            {
                                            //     printf("%i\n",ac1[i][j]);
                                                 niz[h] = ac1[i][j];
                                                 h++;
                                            }
                                            else
                                            {
                                           //      printf("%i\n",ac1[i][n-j-1]);
                                                 niz[h] = ac1[i][n-j-1];
                                                 h++;
                                            }
                                        }
                                        else
                                        {
                                            if(l)
                                            {
                                         //        printf("%i\n",ac2[i][j]);
                                                 niz[h] = ac2[i][j];
                                                 h++;
                                            }
                                            else
                                            {
                                       //          printf("%i\n",ac2[i][n-j-1]);
                                                 niz[h] = ac2[i][n-j-1];
                                                 h++;
                                            }
                                        }
                                    }
                            }
                            //*********
                            if(d==3)
                            {
                                    if(t2==0)
                                    {
                                      //       printf("%i\n",ag[n-i-1][j]);
                                             niz[h] = ag[n-i-1][j];
                                                 h++;
                                    }
                                    else
                                    {
                                        if(p)
                                        {
                                            if(l)
                                            {
                                      //           printf("%i\n",ac1[n-i-1][j]);
                                                 niz[h] = ac1[n-i-1][j];
                                                 h++;
                                            }
                                            else
                                            {
                                        //         printf("%i\n",ac1[n-i-1][n-j-1]);
                                                 niz[h] = ac1[n-i-1][n-j-1];
                                                 h++;
                                            }
                                        }
                                        else
                                        {
                                            if(l)
                                            {
                                       //          printf("%i\n",ac2[n-i-1][j]);
                                                 niz[h] = ac2[n-i-1][j];
                                                 h++;
                                            }
                                            else
                                            {
                                       //          printf("%i\n",ac2[n-i-1][n-j-1]);
                                                 niz[h] = ac2[n-i-1][n-j-1];
                                                 h++;
                                            }
                                        }
                                    }
                            }
                            //***********
                            if(d==2)
                            {
                                    if(t1==0)
                                    {
                                     //        printf("%i\n",al[i][j]);
                                             niz[h] = al[i][j];
                                                 h++;
                                    }
                                    else
                                    {
                                        if(p)
                                        {
                                            if(g)
                                            {
                                      //           printf("%i\n",ac1[i][j]);
                                                 niz[h] = ac1[i][j];
                                                 h++;
                                            }
                                            else
                                            {
                                      //           printf("%i\n",ac1[n-i-1][j]);
                                                 niz[h] = ac1[n-i-1][j];
                                                 h++;
                                            }
                                        }
                                        else
                                        {
                                            if(g)
                                            {
                                    //             printf("%i\n",ac2[i][j]);
                                                 niz[h] = ac2[i][j];
                                                 h++;
                                            }
                                            else
                                            {
                                    //             printf("%i\n",ac2[n-i-1][j]);
                                                 niz[h] = ac2[n-i-1][j];
                                                 h++;
                                            }
                                        }
                                    }
                            }
                            //*************
                            if(d==4)
                            {
                                    if(t1==0)
                                    {
                                   //          printf("%i\n",al[i][n-j-1]);
                                             niz[h] = al[i][n-j-1];
                                                 h++;
                                    }
                                    else
                                    {
                                        if(p)
                                        {
                                            if(g)
                                            {
                                     //            printf("%i\n",ac1[i][n-j-1]);
                                                 niz[h] = ac1[i][n-j-1];
                                                 h++;
                                            }
                                            else
                                            {
                                    //             printf("%i\n",ac1[n-i-1][n-j-1]);
                                                 niz[h] = ac1[n-i-1][n-j-1];
                                                 h++;
                                            }
                                        }
                                        else
                                        {
                                            if(g)
                                            {
                                    //             printf("%i\n",ac2[i][n-j-1]);
                                                 niz[h] = ac2[i][n-j-1];
                                                 h++;
                                            }
                                            else
                                            {
                                   //              printf("%i\n",ac2[n-i-1][n-j-1]);
                                                 niz[h] = ac2[n-i-1][n-j-1];
                                                 h++;
                                            }
                                        }
                                    }
                            }
                    }
    }
    for(i=0;i<h;i++)
                    printf("%i\n",niz[i]);
   // system("PAUSE");
    return 0;
}
/*
5
00000
01000
11000
01010
00000
6
2 5 2
1 3
2 5 2
2 3 2
1 4
2 5 2

*/
