#include <cstdio>
#include <cstring>

bool pel[1001][1001];
int N, Q;
int kol[1001];

void sever()
{
    for( int i = 0; i < N; i++ )
        for( int j = 0; j < N; j++ )
            if( pel[i][j] )
                pel[i][j] = 0, pel[ kol[j]++ ][j] = 1;

    return ;
}

void jug()
{
    for( int i = N - 1; i >= 0; i-- )
        for( int j = 0; j < N; j++ )
            if( pel[i][j] )
                pel[i][j] = 0, pel[ N - 1 - kol[j]++ ][j] = 1;

    return ;
}

void istok()
{
    for( int i = 0; i < N; i++ )
        for( int j = N - 1; j >= 0; j-- )
            if( pel[i][j] )
                pel[i][j] = 0, pel[i][ N - 1 - kol[i]++ ] = 1;

    return ;
}

void zapad()
{
    for( int i = 0; i < N; i++ )
        for( int j = 0; j < N; j++ )
            if( pel[i][j] )
                pel[i][j] = 0, pel[i][ kol[i]++ ] = 1;

    return ;
}

int main()
{
    scanf("%d", &N);

    for( int i = 0; i < N; i++ )
    {
        char c[1001];
        scanf("%s", &c);

        for( int j = 0; j < N; j++ )
            pel[i][j] = c[j] - '0';
    }

    int Q;

    scanf("%d", &Q);

    while( Q-- )
    {
        int op;

        scanf("%d", &op);

        if( op == 2 )
        {
            int x, y;
            scanf("%d %d", &x, &y);
            x--, y--;

            printf("%d\n", pel[x][y]);
        }
        else
        {
            int x;
            scanf("%d", &x);
            memset(kol, 0, sizeof kol);

            if( x == 1 )
                sever();
            else if( x == 2 )
                zapad();
            else if( x == 3 )
                jug();
            else
                istok();
        }
    }

    return 0;
}
