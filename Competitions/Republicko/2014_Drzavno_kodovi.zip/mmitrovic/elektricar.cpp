#include <cstdio>
#include <algorithm>

using namespace std;

int N, M, C, D, S;
int bandera[300001], kuca[300001], cena[300001];


int main()
{
    scanf("%d %d %d %d", &N, &M, &D, &C);

    for( int i = 0; i < N; i++ )
        scanf("%d", &cena[i]);

    for( int i = 0; i < N; i++ )
        scanf("%d", &bandera[i]);

    for( int i = 0; i < M; i++ )
        scanf("%d", &kuca[i]);

    int res = (C - cena[N - 1] - cena[0]) / (bandera[N - 1] - bandera[0]);

    printf("%d", res);

    return 0;
}
