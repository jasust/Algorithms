#include <cstdio>
#include <vector>
#include <stack>

using namespace std;

/*vector < int > G[10001];
int N, S, res, tmpres = 123456789;
int broj[10001];
bool vis[10001];
stack < int > stek;
vector < int > a;

inline int abs( int x )
{
    return x < 0 ? -x : x;
}

void dfs( int x, int suma )
{
    vis[x] = 1;
    //printf("DEBUG : %d\n", x);

    if( abs(suma - S) < tmpres )
        tmpres = suma - S, res = suma;

    if( G[x].size() == 0 )
        return ;

    a.push_back(x);

    for( int i = 0; i < G[x].size(); i++ )
        if( !vis[ G[x][i] ] )
        {
            dfs( G[x][i], suma + broj[ G[x][i] ] );
           // vis[ G[x][i] ] = 0;
        }
}

/*void dfs( int q, int suma )
{
    stek.push(q);
    vis[q] = 1;

    while( !stek.empty() )
    {
        int x = stek.top();
        stek.pop();
        a.push_back(x);
        vis[x] = 1;
        if( abs(suma - S) < tmpres )
            tmpres = suma - S, res = suma;

        for( int i = 0; i < G[x].size(); i++ )
            if( !vis[ G[x][i] ] )
            {
                stek.push( G[x][i] ), suma += broj[ G[x][i] ];
                //vis[ G[x][i] ] = 0;
            }
    }
}*/

int main()
{
    int N, S;
    scanf("%d %d", &N, &S);
    printf("%d", S);
    /*for( int i = 0; i < N; i++ )
    {
        int tmp;

        scanf("%d %d", &broj[i], &tmp);

        for( int j = 0; j < tmp; j++ )
        {
            int x;

            scanf("%d", &x);
            x--;
            G[i].push_back(x);
        }
    }

    for( int i = 0; i < N; i++ )
    {
        a.clear();
        dfs( i, broj[i] );
        for( int i = 0; i < a.size(); i++ )
        printf("%d  ", a[i]);
        printf("\n");
    }
    printf("%d", res);*/


    return 0;
}
