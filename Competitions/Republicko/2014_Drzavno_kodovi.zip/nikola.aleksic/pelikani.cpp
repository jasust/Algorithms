#include<stdio.h>
char a[1001][1001];
int kol[1001]={0},vrsta[1001]={0},pom[1001]={0};
int main()
{
    int n,i,j,m,ind=0,x,y,z,s,k;
    scanf("%d\n",&n);
    for(i=1;i<=n;i++)
   { for(j=1;j<=n;j++)
    { scanf("%c",&a[i][j]);
     if(a[i][j]=='1')
     {kol[j]++;
     vrsta[i]++;}
     }scanf("\n");}
     scanf("%d",&m);
     for(k=0;k<m;k++)
     { scanf("%d",&x);
       if(x==2)
       {scanf("%d%d",&y,&z);
       if(ind==0)
       printf("%d\n",a[y][z]-48);
       else if(ind==1)
            {if(kol[z]>=y)
            printf("1\n");
            else printf("0\n");}
       else if(ind==2)
            {if(vrsta[y]>=z)
            printf("1\n");
            else printf("0\n");}
       else if(ind==3)
            {if(n-kol[z]<y)
            printf("1\n");
            else printf("0\n");
            }
       else if(ind==4)
            {if(n-vrsta[y]<z)
            printf("1\n");
            else printf("0\n");
            }
            }
            if(x==1)
            {  scanf("%d",&s);
            if(s==1)
            {ind=1;for(i=0;i<n;i++)
            pom[kol[i]]++;
            for(i=n-1;i>=1;i--)
            pom[i]=pom[i]+pom[i+1];
            for(i=1;i<=n;i++)
            {vrsta[i]=pom[i];
            pom[i]=0;}
            }
            if(s==2)
            {ind=2; for(i=1;i<=n;i++)
            pom[vrsta[i]]++;
            for(i=n-1;i>=1;i--)
            pom[i]=pom[i]+pom[i+1];
            for(i=1;i<=n;i++)
            {kol[i]=pom[i];
            pom[i]=0;}
            }
            if(s==3)
            {ind=3; for(i=1;i<=n;i++)
            pom[n-kol[i]+1]++;
            for(i=2;i<=n;i++)
            pom[i]=pom[i]+pom[i-1];
            for(i=1;i<=n;i++)
            {vrsta[i]=pom[i];
            pom[i]=0;}
            }
            if(s==4)
            {ind=4; for(i=1;i<=n;i++)
            pom[n-vrsta[i]+1]++;
            for(i=2;i<=n;i++)
            pom[i]=pom[i]+pom[i-1];
            for(i=1;i<=n;i++)
            {kol[i]=pom[i];
            pom[i]=0;}
            }
            }
            }
            return 0;
            }
