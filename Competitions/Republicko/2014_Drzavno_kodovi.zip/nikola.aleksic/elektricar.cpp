#include<stdio.h>
int bandera[100],cena[100],kuca[100];
int main()
{
    int n,m,d,c,x,min=1000000,max=0,i,cm,cv;
    scanf("%d%d%d%d",&n,&m,&d,&c);
    for(i=0;i<n;i++)
    scanf("%d",&bandera[i]);
    for(i=0;i<n;i++)
    scanf("%d",&cena[i]);
    for(i=0;i<m;i++)
    scanf("%d",&kuca[i]);
    for(i=0;i<n;i++)
    if(bandera[i]<min)
    {min=bandera[i];
    cm=cena[i];}
    for(i=0;i<n;i++)
    if(bandera[i]>max)
    {max=bandera[i];
    cv=cena[i];}
    printf("%d",max-min+cm+cv);
    return 0;

}
    
    
