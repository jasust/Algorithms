#include<stdio.h>
int apso(int a)
{ if(a>=0)
return a;
return -a;
}
int lucky[501],a[501][501],min,x=0,n,s,i,j;
void trazi(int r,int b,int s)
{   int i;
     if(apso(s-b)<min)
{min=apso(s-b);x=b;}
if(apso(s-b)==min)
if(b<x)
x=b;
if(apso(s-b-lucky[r])<min)
{min=apso(s-b-lucky[r]); x=b+lucky[r];}
if(apso(s-b-lucky[r])==min)
if(b+lucky[r]<x)
x=b+lucky[r];
for(i=1;i<=a[r][0];i++)
{ trazi(a[r][i],b+lucky[r],s);
  trazi(a[r][i],b,s);
}
}
     
int main()
{
    scanf("%d%d",&n,&s);
    min=s;
    for(i=1;i<=n;i++)
    {scanf("%d%d",&lucky[i],&a[i][0]);
    for(j=1;j<=a[i][0];j++)
    scanf("%d",&a[i][j]); }
    trazi(1,0,s);
    printf("%d",x);
    return 0;
}
