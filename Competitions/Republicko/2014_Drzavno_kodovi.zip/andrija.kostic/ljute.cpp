#include <iostream>
#include <cstdio>

using namespace std;

#define MaxN 1000010
#define DEBUG (false)

long H[MaxN];

int main(){

    long i,j,k,l,pozicija,dh,dluft,luft,m,n,dlength,rk,hb;

    scanf("%ld%ld", &n,&k);

    for(i=0; i<n; i++){
        scanf("%ld", &l);
        H[i]=l-k+1;
    }

    scanf("%ld%ld",&rk,&hb);

    if(hb<k) printf("%ld %ld\n", rk,hb);
    else{
        luft = 0;
        dlength = 0;
        for(i=n-1; i>=0; i--){
            if(rk-1==i){
                /* Ako su svi zasiceni dh = k -1*/
                dluft = (hb-k+1)+luft;
                if(dluft>0){
                    if((dluft%k)<k) dlength++;
                    if(DEBUG) printf("Prvi: %ld %ld\n", dluft, dlength);
                    dlength += dluft/k;
                    if(DEBUG) printf("Drugi: %ld\n", dlength);
                    if(dluft%k==0){
                        dh = k-1;
                        dlength++;
                    }
                    else dh = dluft %k;
                }
                else{
                    if(dluft<0) dh = k+dluft-1;
                    else dh = k-1;
                }
                pozicija = n+dlength;
                if(DEBUG) printf("Upao u dluft>0: %ld %ld\n", dluft, dlength);
                break;
            }
            else{
                if(H[i]>0){
                    dluft = H[i]+luft;
                    if(dluft>0){
                        if(DEBUG) printf("dluft1: %ld %ld\n", H[i], dluft%k);
                        dlength += dluft/k;
                        if((dluft%k)<k){
                            dlength++;
                            if(DEBUG) printf("OK\n");
                        }
                        if(dluft==k) luft = 0;
                        else luft = dluft - k +1;
                        if(DEBUG) printf("dluft2: %ld %ld\n", dlength, dluft);
                    }
                    else luft += H[i];
                }
                else luft += H[i];
                if(DEBUG) printf("Racuna Luft: %ld %ld %ld\n", i, luft, dlength);
            }
         }
         printf("%ld %ld\n", pozicija, dh);
    }
    return 0;
}
