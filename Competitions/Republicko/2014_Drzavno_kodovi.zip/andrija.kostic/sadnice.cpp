#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>

using namespace std;


#define MaxN 100
#define DEBUG (false)

long long A[MaxN];

long long Stepen(long long osnova, long long stepen){

    long long i,p=1;
    for(i=1; i<=stepen; i++) p = p*osnova;
    return p;
}

int main(){

    long long stepenn,stepenp,j,i,k,l,km,m,n,dn,ukupno;
    bool p = true;

    scanf("%lld%lld",&n,&m);

if(m==Stepen(2,n)) printf("%lld\n", n);
else{
    stepenn =0;
    km=m;
    while(km>0){
        km/=2;
        stepenn++;
    }

    ukupno = 1;
    for(i=1; i<=n; i++) ukupno = ukupno*2;

    memset(A,sizeof(A), 0);
    stepenp = stepenn-1;
    if(DEBUG) printf("%lld\n", stepenp);


    i=n;
    k=1;
    dn=1;
    if(DEBUG) printf("m: %lld\n",m);
    while(m>k){
        k+= Stepen(2,i-dn);
        dn++;
        if(DEBUG){
            printf("%lld %lld\n", k, dn);
        }
    }
    dn--;
   // printf("%lld ", dn);

    for(i=dn; i<=n; i++) printf("%lld ", i);

    printf("\n");
}
    return 0;
}
