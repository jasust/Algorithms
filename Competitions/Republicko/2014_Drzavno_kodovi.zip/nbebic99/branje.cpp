#include <iostream>
/*
11
5 6 3 14 9 7 11 3 8 1 4
1 5 11 4 6 4 4 5 4 8 2

*/
using namespace std;

int z[1000000], n, s, c, rC, p, k, m;
long r[1000000], m1, m2, m3;

void idle() {}

void cistiLevo()
{
    m2 = -2000000000;

    for (int i = 0; i<p; i++)
    {
        int pz = 0;
        for (int j = i; j < p; j++)
        {
            pz += r[j];
            if (pz>m2)
            {
                m2 = pz;
            }
        }
    }
}

void cistiDesno()
{
    m3 = -2000000000;

    for (int i = k+1; i<rC; i++)
    {
        int pz = 0;
        for (int j = i; j < rC; j++)
        {
            pz += r[j];
            if (pz>m3)
            {
                m3 = pz;
            }
        }
    }
}

int main()
{
    cin>>m;

    for (int i=0; i<m; i++)
    {
        cin>>z[i];
    }

    rC = 0;
    c = 0;

    for (int i=0; i<m; i++)
    {
        cin>>s;
        z[i]=z[i]-s;

        if ((c == 0) && (z[i] < 0))
        {
            rC++;
            c = 1;
        }
        else if ((c == 1) && (z[i] > 0))
        {
            rC++;
            c = 0;
        }

        r[rC] += z[i];
    }

    rC++;
    m1 = -2000000000;
    p = 0;
    k = rC-1;

    for (int i = 0; i<rC; i++)
    {
        int pz = 0;
        for (int j = i; j < rC; j++)
        {
            pz += r[j];
            if (pz>m1)
            {
                m1 = pz;
                p = i;
                k = j;
            }
        }
    }

    if ((p==0) && (k==n-1))
        idle();
    else if (p==0)
        cistiLevo();
    else if (k==0)
        cistiDesno();
    else
    {
        cistiDesno();
        cistiLevo();
    }

    if ((p!=k) && (max(m2,m3) < 0))
        cout<<m1;
    else
        cout<<m1+max(m2,m3);

    return 0;
}
