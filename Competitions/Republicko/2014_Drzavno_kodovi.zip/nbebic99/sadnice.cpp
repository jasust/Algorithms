#include <iostream>
#include <queue>
#include <math.h>

/*
4 12

*/

using namespace std;

int x,n,sl;

queue<int>* nadji(queue<int> *q,int zb)
{
    if (zb >= x) //kraj
        return q;
    else //nije kraj
    {
        zb += 1;
        while (zb + pow(2,n-sl) < x)
        {
            zb += pow(2,n-sl);
            sl++;
        }
        q->push(sl++);
        return nadji(q,zb);
    }
}

int main()
{
    cin>>n>>x;
    x--;
    sl = 1;
    queue<int> *q = nadji(new queue<int>(),0);

    while (!q->empty())
    {
        cout<<q->front()<<" ";
        q->pop();
    }

    return 0;
}
