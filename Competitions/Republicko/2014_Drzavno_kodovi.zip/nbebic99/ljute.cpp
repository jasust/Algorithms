#include <iostream>
/*
3 4
6 7 1
1 6

*/
using namespace std;

int n,h,a[1000000],w,s,rn,rh,dH;

int main()
{
    cin>>n>>h;
    for (int i = 1; i<=n; i++)
    {
        cin>>a[i];
    }
    cin>>rn>>rh;

    a[rn] = rh;

    w = rn;
    s = rh - h + 1;
    while (true)
    {
        w++;
        if (w > n)
            dH = -h + 1;
        else
            dH = a[w] - h + 1;
        if (s < -dH)
            break;
        else
            s += dH;
    }
    cout<<w<<" "<<s+((w>n) ? 0 : a[w]);

    return 0;
}
