#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>

using namespace std;

const int N = 1 << 19;
const long long INF = 1LL << 60LL;
int n, m, gap;
int pole[N], house[N], upkeep[N];
bool house_before[N];
int reach[N];

class segtree
{
public:
    void init()
    {
        for(int i = 0; i < 2 * N; i++) tree[i] = INF;
    }

    void set(int pos, long long val)
    {
        pos += N;
        tree[pos] = val;
        for(pos >>= 1; pos; pos >>= 1)
            tree[pos] = min(tree[pos << 1], tree[(pos << 1) + 1]);
    }

    long long query(int left, int right)
    {
        if(left > right) return INF;
        left += N; right += N;
        long long res = min(tree[left], tree[right]);
        while((left >> 1) != (right >> 1))
        {
            if(!(left & 1)) res = min(res, tree[left + 1]);
            if(right & 1) res = min(res, tree[right - 1]);
            left >>= 1; right >>= 1;
        }
        return res;
    }

private:
    long long tree[2 * N];
};

long long d0[N], d1[N];
segtree tree;
long long cost_segtree(long long s)
{
    tree.init();
    d0[0] = 0; d1[0] = INF;
    tree.set(0, (long long)upkeep[0] - (long long)pole[0] * s);
    for(int i = 1; i < n; i++)
    {
        d0[i] = house_before[i] ? (1 << 30) : min(d0[i - 1], d1[i - 1]);
        tree.set(i, d0[i] + (long long)upkeep[i] - (long long)pole[i] * s);
        d1[i] = min(INF, tree.query(reach[i], i - 1) + (long long)upkeep[i] + (long long)pole[i] * s);
    }
    return min(d0[n - 1], d1[n - 1]);
}

long long cost_no_reach(long long s)
{
    d0[0] = 0; d1[0] = INF;
    long long m = (long long)upkeep[0] - (long long)pole[0] * s;
    for(int i = 1; i < n; i++)
    {
        d0[i] = house_before[i] ? (1 << 30) : min(d0[i - 1], d1[i - 1]);
        d1[i] = min(INF, m + (long long)upkeep[i] + (long long)pole[i] * s);
        m = min(m, d0[i] + (long long)upkeep[i] - (long long)pole[i] * s);
    }
    return min(d0[n - 1], d1[n - 1]);
}

long long cost_fast(long long s)
{
    return cost_segtree(s); // ovo nemamo
}

int binary(long long goal)
{
    int left = 1, right = 1 << 30;
    while(left < right)
    {
        int mid = (left + right) / 2;
        long long x = (gap == 1000000000LL) ? cost_no_reach(mid) : (n <= 50000) ? cost_segtree(mid) : cost_fast(mid);
        if(x == goal)
            return mid;
        else if(x < goal) left = mid + 1;
        else right = mid;
    }
    return 0; // ovo ne bi trebalo da se desi
}

int main()
{
    //freopen("test.in", "r", stdin);

    int goal;
    scanf("%i %i %i %i", &n, &m, &gap, &goal);
    for(int i = 0; i < n; i++) scanf("%i", &upkeep[i]);
    for(int i = 0; i < n; i++) scanf("%i", &pole[i]);
    for(int i = 0; i < m; i++) scanf("%i", &house[i]);
    house[m] = 1 << 30;

    int h = 0;
    for(int i = 0; i < n; i++)
    {
        if(house[h] < pole[i]) house_before[i] = true;
        while(h < m && house[h] < pole[i]) h++;
    }

    int r = 0;
    for(int i = 0; i < n; i++)
    {
        while(r < i && pole[i] - pole[r] > gap) r++;
        reach[i] = r;
    }

    printf("%i\n", binary(goal));

    return 0;
}
