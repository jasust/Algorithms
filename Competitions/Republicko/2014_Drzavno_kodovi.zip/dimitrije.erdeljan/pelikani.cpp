#include <iostream>
#include <cstdio>
#include <cstdlib>

using namespace std;

const int N = 1005;

struct board
{
    bool bird[N][N];
    void move_o_deprecated(int);
    void move_n(int);
} ;
int n;

const int DI[] = { -1, 0, 1, 0 } ;
const int DJ[] = { 0, -1, 0, 1 } ;

void board::move_o_deprecated(int dir)
{
    for(int i = (DI[dir] == 1 ? n - 1 : 0); i >= 0 && i < n; i += (DI[dir] == 1 ? -1 : 1))
        for(int j = (DJ[dir] == 1 ? n - 1 : 0); j >= 0 && j < n; j += (DJ[dir] == 1 ? -1 : 1))
            if(bird[i][j])
        {
            int ii = i, jj = j;
            while(ii + DI[dir] >= 0 && jj + DJ[dir] >= 0 && ii + DI[dir] < n && jj + DJ[dir] < n)
                if(bird[ii + DI[dir]][jj + DJ[dir]]) break;
                else
                {
                    bird[ii][jj] = false;
                    bird[ii += DI[dir]][jj += DJ[dir]] = true;
                }
        }
}

void board::move_n(int dir)
{
    if(dir == 1 || dir == 3)
        for(int i = 0; i < n; i++)
        {
            int cnt = 0;
            for(int j = 0; j < n; j++)
                if(bird[i][j]) cnt++;
            for(int j = 0; j < n; j++) bird[i][j] = false;
            for(int j = 0; j < cnt; j++) bird[i][dir == 1 ? j : (n - 1 - j)] = true;
        }
    else
        for(int j = 0; j < n; j++)
        {
            int cnt = 0;
            for(int i = 0; i < n; i++)
                if(bird[i][j]) cnt++;
            for(int i = 0; i < n; i++) bird[i][j] = false;
            for(int i = 0; i < cnt; i++) bird[dir == 0 ? i : (n - 1 - i)][j] = true;
        }
}

board start;

void cpy(board &a, board &b)
{
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            b.bird[i][j] = a.bird[i][j];
}

board one[5];
board seed;

board res[2][2];
bool done_gen = false;
void gen()
{
    if(done_gen) return;
    done_gen = true;
    for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
        {
            cpy(seed, res[i][j]);
            res[i][j].move_n(i ? 2 : 0);
            res[i][j].move_n(j ? 3 : 1);
        }
}

int main()
{
    //freopen("test.in", "r", stdin);

    scanf("%i", &n);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
        {
            char c;
            scanf(" %c", &c);
            start.bird[i][j] = c == '1';
        }

    cpy(start, one[0]);
    for(int i = 1; i <= 4; i++)
    {
        cpy(start, one[i]);
        one[i].move_n(i - 1);
    }

    int q;
    scanf("%i", &q);
    bool ud = false, lr = false;
    int last = 0, last_ud, last_lr;
    while(q--)
    {
        int op;
        scanf("%i", &op);
        //if(!RELEASE) printf("%s\n", op == 1 ? "MOVE" : "QUERY");
        if(op == 1)
        {
            int dir;
            scanf("%i", &dir);
          //  if(!RELEASE) printf("%i\n", dir);
            //printf("%i\n", dir);
            if(dir % 2) { ud = true; last_ud = (dir == 1 ? 0 : 1); }
            else { lr = true; last_lr = (dir == 2 ? 0 : 1); }

            if(ud && lr && !done_gen)
            {
                cpy(one[last], seed);
                seed.move_n(dir - 1);
                gen();
            }

            last = dir;
           // brute.move_o(dir - 1);
        }
        else
        {
            int i, j;
            scanf("%i %i", &i, &j);


            if(ud && lr) printf("%i\n", res[last_ud][last_lr].bird[i - 1][j - 1] ? 1 : 0);
            else printf("%i\n", one[last].bird[i - 1][j - 1] ? 1 : 0);

           // draw(brute); printf("\n");
           // draw(ud && lr ? res[last_ud][last_lr] : one[last]); printf("\n"); printf("\n");

            //printf("%i\n", res[last_ud][last_lr].bird[i - 1][j - 1]);
        }
    }
    //draw(start);

    return 0;
}
