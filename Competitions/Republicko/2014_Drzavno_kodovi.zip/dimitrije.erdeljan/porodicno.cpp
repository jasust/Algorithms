#include <iostream>
#include <cstdio>

using namespace std;

const int N = 10005;
const int S = 10005;

struct node
{
    int v;
    node *next;
    node(int vv, node *n) { v = vv; next = n; }
} ;
node *graph[N];
int val[N];
int d[S];
int res, goal;

inline int abs(int x) { return x < 0 ? -x : x; }

void dfs(int curr, int depth)
{
    for(int i = 0; i < S; i++)
        if(d[i] >= depth)
        {
            if(i == 0 || i == val[curr] || d[i] < depth || (i - val[curr] >= 0 && d[i - val[curr]] < depth))
                d[i] = depth;
            else d[i] = 1 << 30;
        }
    for(int i = 0; i < S; i++)
        if(d[i] <= depth)
            if((abs(i - goal) < abs(res - goal)) || (abs(i - goal) == abs(res - goal) && i < res))
                res = i;
    for(node *i = graph[curr]; i; i = i->next)
        dfs(i->v, depth + 1);
}

bool root[N];

int main()
{
    //freopen("test.in", "r", stdin);

    int n;
    scanf("%i %i", &n, &goal);
    for(int i = 0; i < n; i++)
    {
        int m;
        scanf("%i %i", &val[i], &m);
        for(int ii = 0; ii < m; ii++)
        {
            int v;
            scanf("%i", &v);
            graph[i] = new node(v - 1, graph[i]);
        }
    }

    for(int i = 0; i < n; i++) root[i] = true;
    for(int i = 0; i < n; i++)
        for(node *j = graph[i]; j; j = j->next)
            root[j->v] = false;

    res = 0;
    for(int i = 0; i < n; i++)
        if(abs(val[i] - goal) < abs(res - goal) || (abs(val[i] - goal) == abs(res - goal) && val[i] < res))
            res = val[i];
    for(int i = 0; i < S; i++) d[i] = 1 << 30;

    for(int i = 0; i < n; i++)
        if(root[i])
            dfs(i, 0);

    printf("%i\n", res);

    return 0;
}
