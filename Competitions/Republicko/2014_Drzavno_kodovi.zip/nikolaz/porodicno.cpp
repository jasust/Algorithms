#include <iostream>
#include <math.h>
#include <cstdio>

using namespace std;

int ulaz[10000];
int srecni[10000];
int n,simpatija;


int main()
{
    int pom = 0;
    int pom2,pom3;
    cin >> n >> simpatija;
    for(int i = 1; i <= n; i++)
    {
        cin >> srecni[i];
        pom += srecni[i];
        int potomci;
        cin >> potomci;
        for(int j = 1; j <= potomci; j++)
        {
            int potomak;
            cin >> potomak;
        }
    }
    pom2 = pom / n;
    pom3 = pom2;
    pom2 = simpatija - pom2;
    if(pom2 < 0) pom2 = pom2 * -1;
    if(pom2 < simpatija) cout<<pom3<<endl;
    else cout <<"0"<<endl;
    return 0;
}
