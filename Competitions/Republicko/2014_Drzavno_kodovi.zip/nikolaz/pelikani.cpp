#include <iostream>
#include <cstdio>

using namespace std;

int ulaz[1005][1005];
int n,q;
struct pelikani
{
    int x,y;
};
pelikani pelikan[1000005];

int broj_pelikana = 0;

string linija;

int main()
{
    cin >> n;
    for(int i = 1; i <= n; i++)
    {
        cin >> linija;
        for(int j = 0; j < n; j++)
        {
            ulaz[i][j+1] = linija[j] - '0';
            if(ulaz[i][j+1] == 1)
            {
                broj_pelikana++;
                pelikan[broj_pelikana].x = i;
                pelikan[broj_pelikana].y = j+1;
            }
        }
    }
    /*for(int i = 1; i <= n; i++)
    {
            for(int j = 1; j <= n; j++)
            {
                cout  << ulaz[i][j] ;
            }
            cout<<endl;
    }*/
    cin >> q;
    for(int i = 1; i <= q; i++)
    {
            /*cout<<endl;
            cout<<endl;
            for(int i = 1; i <= n; i++)
            {
            for(int j = 1; j <= n; j++)
            {
                cout  << ulaz[i][j] ;
            }
            cout<<endl;
            }
            cout<<endl;
            cout<<endl;*/
        int x;
        cin >> x;
        if(x == 1)
        {
            int upit;
            cin >> upit;
            int cao = 0;
            if(broj_pelikana == 0) cao = 1;
            else if(broj_pelikana == n*n) cao = 2;
            else
            {
                if(upit == 1) //gore
                {
                    for(int i = 1; i <= broj_pelikana; i++)
                    {
                        if(pelikan[i].x != 1)
                        {
                            int staro_x = pelikan[i].x;
                            int staro_y = pelikan[i].y;
                            int pom = 1;
                            while(ulaz[pom][staro_y] == 1 && pom < staro_x) pom++;
                            pelikan[i].x = pom;
                            ulaz[staro_x][staro_y] = 0;
                            ulaz[pom][staro_y] = 1;
                        }
                    }
                }
                else if(upit == 4)//desno
                {
                    for(int i = 1; i <= broj_pelikana; i++)
                    //for(int i = broj_pelikana; i >= 1; i--)
                    {
                        if(pelikan[i].y != n)
                        {
                            int staro_x = pelikan[i].x;
                            int staro_y = pelikan[i].y;
                            int pom = n;
                            while(ulaz[staro_x][pom] == 1 && pom > staro_y) pom--;
                            pelikan[i].y = pom;
                            ulaz[staro_x][staro_y] = 0;
                            ulaz[staro_x][pom] = 1;
                        }
                    }
                }
                else if(upit == 3)//dole
                {
                    for(int i = 1; i <= broj_pelikana; i++)
                    //for(int i = broj_pelikana; i >= 1; i--)
                    {
                        if(pelikan[i].x != n)
                        {
                            int staro_x = pelikan[i].x;
                            int staro_y = pelikan[i].y;
                            int pom = n;
                            while(ulaz[pom][staro_y] == 1 && pom > staro_x) pom--;
                            pelikan[i].x = pom;
                            ulaz[staro_x][staro_y] = 0;
                            ulaz[pom][staro_y] = 1;
                            //cout<<"STAVLJAM NA "<<pom<<endl;
                        }
                    }
                }
                else if(upit == 2)//levo
                {
                    for(int i = 1; i <= broj_pelikana; i++)
                    {
                        //ne menja se x
                        if(pelikan[i].y != 1)
                        {
                            int staro_x = pelikan[i].x;
                            int staro_y = pelikan[i].y;
                            int pom = 1;
                            while(ulaz[staro_x][pom] == 1 && pom < staro_y) pom++;
                            pelikan[i].y = pom;
                            ulaz[staro_x][staro_y] = 0;
                            ulaz[staro_x][pom] = 1;
                            //cout<<"STAVLJAM NA "<<pom<<endl;
                        }
                    }
                }
            }
        }
        else if(x == 2)
        {
            int i,j;
            cin >> i >> j;
            if(ulaz[i][j] == 1) cout <<"1"<<endl;
            else cout <<"0"<<endl;
        }
    }

    return 0;
}
