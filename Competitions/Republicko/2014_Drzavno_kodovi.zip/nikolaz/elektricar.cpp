#include <iostream>

using namespace std;

int n,m,d,c,s;
int bandera[300005], kuca[300005],cena_odrzavanja[300005];
bool snabdevena[300005];
int broj_snabdevenih = 0;
int x = 0;
int y = 0;

int main()
{
    cin >> n >> m >> d >> c;
    for(int i = 0; i < n; i++) cin >> cena_odrzavanja[i];
    for(int i = 0; i < n; i++) cin >> bandera[i];
    for(int i = 0; i < m; i++) cin >> kuca[i];
    if(d == 1000000000)
    {
        s = (c - cena_odrzavanja[0] - cena_odrzavanja[n-1]) / (bandera[n-1] - bandera[0]) ;
        cout <<s<<endl;
        return 0;
    }
    while(broj_snabdevenih < m)
    {
            int pom = 0;
            int old = broj_snabdevenih;
            if(old == 0) old = 0;
            else old++;
            while(bandera[pom+1]  < kuca[old]) pom++;
            int prva_bandera = pom;
            int povezujem_sa = pom+1;
            int max_udaljenost = bandera[prva_bandera] +d;
            while(bandera[povezujem_sa+1] <= max_udaljenost)
            {
                povezujem_sa++;
                if(povezujem_sa == n-1) break;
            }
            while(kuca[old] < bandera[povezujem_sa])
            {
                broj_snabdevenih++;
                old++;
            }
            x += cena_odrzavanja[prva_bandera] + cena_odrzavanja[povezujem_sa];
            y += bandera[povezujem_sa] - bandera[prva_bandera];
    }
    s = (c - x) / y;
    cout <<s<<endl;
    return 0;
}
