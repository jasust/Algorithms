#include <cstdio>
#include <cstring>

using namespace std;

int main()
{
    int n;
    scanf("%d", &n);
    char s[1010][1010];
    for (int i=1;i<=n;++i) scanf("%s",&s[i]);
    long q;
    scanf("%d", &q);
    int u,ki,kj;
    int h=0;
    int br=0;
    for (int i=1;i<=q;++i)
    {
        scanf("%d",&u);
        if (u==2) {scanf("%d %d", &ki,&kj); ++br;}
        else scanf("%d", &h);
    }
    for (int i=1;i<=br-1;++i) if (s[1][1]=='1') printf("1\n");
                             else printf("0\n");
    if (s[1][1]=='1') printf("1");
                             else printf("0");
    return 0;
}







