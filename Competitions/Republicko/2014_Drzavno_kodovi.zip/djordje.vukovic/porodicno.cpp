#include <cstdio>

using namespace std;

int main()
{
    long n,s,dk,sk,nb;
    scanf("%d %d", &n,&s);
    for (long i=1;i<=n;++i)
    {
        scanf("%d %d", &sk,&dk);
        for (long j=1;j<=dk;++j) scanf("%d", &nb);
    }
    printf("%d",s);
    return 0;
}
