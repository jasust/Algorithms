#include <cstdio>

using namespace std;

int main()
{
    long a,b,c,d,f,g,h;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    for (long i=0;i<a;++i) scanf("%d",&f);
    for (long i=0;i<a;++i) scanf("%d",&g);
    for (long i=0;i<b;++i) scanf("%d",&h);
    printf("1");
    return 0;
}
