/*
    USER: Viktor Slavkovic
    TASK: Elektricar
    COMMENT: NE VALJA RESENJE
*/

#include <cstdio>
#include <vector>

using namespace std;

typedef long long i64;
typedef long i32;

struct bandera{
    i64 pos;
    i64 price;
};

struct best {
    i64 len, price;
};

vector<bandera> bs; //bandere
vector<i64> ks; //kuce
vector<i32> kb; //broj kuca pre bandere
vector<i32> bb; //broj bandera pre u D
vector<i64> best_price; //najbolja cena
vector<i64> best_len; //ukupna duzina kabla
vector<bool> best_used;

i32 n,m,D,C;

void input() {
    scanf("%ld %ld %ld %ld",&n,&m,&D,&C);
    bs.resize(n+1);
    ks.resize(m+1);
    kb.resize(n+1,0);
    bb.resize(n+1,0);
    best_used.resize(n+1,false);
    best_price.resize(n+1,0);
    best_len.resize(n+1,0);
    for (i32 i=1; i<=n; i++) scanf("%lld",&bs[i].price);
    for (i32 i=1; i<=n; i++) scanf("%lld",&bs[i].pos);
    for (i32 i=1; i<=m; i++) scanf("%ld",&ks[i]);
}

void init() {
    i32 k=1;
    for (i32 b=1; b<=n; b++) {
        while (k<=m && ks[k]<bs[b].pos) k++;
        if (k>m) k--;
        if (ks[k]>=bs[b].pos) kb[b]=k-1;
        else kb[b]=k;
    }

    i32 l=1;
    for(i32 b=1; b<=n; b++) {
        while (bs[b].pos-bs[l].pos>D) l++;
        bb[b]=b-l;
    }
}

i64 solve() {
    for(i32 i=1; i<=n; i++) {

        best_len[i]=best_len[i-1];
        best_price[i]=best_price[i-1];

        i32 l=i-bb[i];
        i32 r=i-1;

        bool can=(kb[i]==kb[i-1]);

        bool first=true;
        i32 mp;
        i32 ml;

        while (kb[i]>kb[l] && l<=r) {
            if (first || best_price[l]+bs[l].price<mp) {
                mp=best_price[l]+bs[l].price;
                ml=best_len[l]+bs[i].pos-bs[l].pos;
                first=false;
            }
            l++;
        }

        if (!first) {
            if (!(can && mp+bs[i].price>best_price[i-1]+bs[i-1].price)) {
                best_len[i]=ml;
                best_price[i]=mp;
                best_used[i]=true;
            }
        }

    }
    if (best_used[n]) best_price[n]+=bs[n].price;
    return (C-best_price[n])/best_len[n];
}

int main()
{
    input();
    init();
    i64 S=solve();
    printf("%lld\n",S);
    return 0;
}
