/*
    USER: Viktor Slavkovic
    TASK: Porodicno stablo
    COMMENT: MOZDA VALJDA RESENJE
*/

#include <cstdio>
#include <vector>
#include <list>
#include <stack>
#include <cmath>

using namespace std;

typedef unsigned long ui32;
typedef vector<list<ui32> > graph;

graph G;
vector<ui32> val;
vector<long> num_in;

ui32 n,s,root;

ui32 ranac(vector<ui32> & v, ui32 sum) {
    vector<ui32> *cur, *prev;
    cur=new vector<ui32> (sum+1,0);
    prev=new vector<ui32> (sum+1,0);

    for (ui32 i=0; i<v.size(); i++) {
        if (v[i]==sum) {
            delete cur;
            delete prev;
            return sum;
        }
        if (v[i]>sum) {
            for (ui32 j=1; j<=sum; j++) cur->at(j)=prev->at(j);
        }
        for (ui32 j=1; j<=sum; j++) {
            if (j<v[i]) {
                cur->at(j)=prev->at(j);
                continue;
            }
            ui32 vn=prev->at(j-v[i])+v[i];
            ui32 vp=prev->at(j);
            if (vn>s || vp>vn) cur->at(j)=vp;
            else cur->at(j)=vn;
        }
        vector<ui32> * POM=cur;
        cur=prev;
        prev=POM;
    }

    ui32 res=cur->at(sum);
    delete cur;
    delete prev;
    return res;
}

ui32 better(ui32 a, ui32 b) {
    if (fabs(s-a)<fabs(s-b)) return a;
    else return b;
}

ui32 check(vector<ui32> & v) {
    ui32 total=0;
    for (vector<int>::size_type i=0; i<v.size(); i++) total+=v[i];
    if (total<=s) return ranac(v, s);
    else {
        ui32 r1=ranac(v,s);
        ui32 r2=total-ranac(v,total-s);
        return better(r1,r2);
    }
}

ui32 find_root() {
    for(vector<ui32>::size_type i=0; i<num_in.size(); i++) if (num_in[i]==-1) return i;
}

ui32 dfs() {
    ui32 best=300000;

    vector<ui32> v;

    stack<ui32> S;

    S.push(root);

    while(!S.empty()) {
        ui32 current = S.top();
        S.pop();

        if (G[current].empty()) {
            v.clear();
            long it=(long)current;
            while (it!=-1) {
                v.push_back(val[it]);
                it=num_in[it];
            }
            ui32 pom=check(v);
            best=better(pom,best);
        }
        else for(list<ui32>::iterator it=G[current].begin(); it!=G[current].end(); it++) S.push(*it);

    }

    return best;
}

void input() {
    scanf("%lu %lu",&n,&s);
    G.resize(n);
    val.resize(n);
    num_in.resize(n,-1);
    for (ui32 i=0; i<n; i++) {
        ui32 nc;
        scanf("%lu %lu",&val[i],&nc);
        for (ui32 j=0; j<nc; j++) {
            ui32 pc;
            scanf("%ld",&pc);
            pc--;
            num_in[pc]=i;
            G[i].push_back(pc);
        }
    }
    root=find_root();
}

int main()
{
    input();
    ui32 res=dfs();
    printf("%lu\n",res);
    return 0;
}
