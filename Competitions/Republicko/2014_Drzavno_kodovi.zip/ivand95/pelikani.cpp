//Ivan Dejkovic: 4 Pelikani

#include <cstdio>

using namespace std;

int n,q,t1,cmd,x,y,ob,i,j,hor[1024]={0},ver[1024]={0},t2,ob1,brojac,pom,broj[1024]={0};
bool pomereni;
char m[1024][1024];

int main() {
    scanf("%d",&n);
    for (i=1; i<=n; i++) scanf("%s",m[i]+1);
    scanf("%d",&q);
    t1=1;
    pomereni=0;
    while (t1<=q && !pomereni) {
        scanf("%d",&cmd);
        if (cmd==2) {
            scanf("%d %d",&x,&y);
            printf("%c\n",m[x][y]);
        }
        else {
            scanf("%d",&ob);
            if (ob==1 || ob==3) {
                for (i=1; i<=n; i++) {
                    for (j=1; j<=n; j++) {
                        if (m[i][j]=='1') hor[j]++;
                    }
                }
            }
            else {
                for (i=1; i<=n; i++) {
                    for (j=1; j<=n; j++) {
                        if (m[i][j]=='1') ver[i]++;
                    }
                }
            }
            pomereni=1;
        }
        t1++;
    }

    for (t2=t1; t2<=q; t2++) {
        scanf("%d",&cmd);
        if (cmd==2) {
            scanf("%d %d",&x,&y);
            if (ob==1) {
                if (hor[y]>=x) printf("1\n");
                else printf("0\n");
            }
            else if (ob==2) {
                if (ver[x]>=y) printf("1\n");
                else printf("0\n");
            }
            else if (ob==3) {
                if (hor[y]+x>n) printf("1\n");
                else printf("0\n");
            }
            else if (ob==4) {
                if (ver[x]+y>n) printf("1\n");
                else printf("0\n");
            }
        }
        else {
            scanf("%d",&ob1);
            if ((ob%2)!=(ob1%2)) { //pogledaj ovo
                for (i=1; i<=n; i++) broj[i]=0;
                if (ob==1 || ob==3) {
                    for (i=1; i<=n; i++) broj[hor[i]]++;
                    brojac=0;
                    for (i=n; i>0; i--) {
                        brojac+=broj[i];
                        ver[i]=brojac;
                    }
                    if (ob==3) {
                        for (i=1; i<=n/2; i++) {
                            pom=ver[i];
                            ver[i]=ver[n-i+1];
                            ver[n-i+1]=pom;
                        }
                    }
                }
                else {
                    for (i=1; i<=n; i++) broj[ver[i]]++;
                    brojac=0;
                    for (i=n; i>0; i--) {
                        brojac+=broj[i];
                        hor[i]=brojac;
                    }
                    if (ob==4) {
                        for (i=1; i<=n/2; i++) {
                            pom=hor[i];
                            hor[i]=hor[n-i+1];
                            hor[n-i+1]=pom;
                        }
                    }
                }
            }
            ob=ob1;
        }

    }

    return 0;
}
