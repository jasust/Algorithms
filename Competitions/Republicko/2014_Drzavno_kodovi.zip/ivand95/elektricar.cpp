//Ivan Dejkovic: 6 elektricar
//nemam pojma kako se radi

#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

int n,m,d,c,cena,b,k,sol,i;

int main() {
    srand(757);
    scanf("%d %d %d %d",&n,&m,&d,&c);
    for (i=1; i<=n; i++) scanf("%d",&cena);
    for (i=1; i<=n; i++) scanf("%d",&b);
    for (i=1; i<=m; i++) scanf("%d",&k);

    k=int(sqrt(c));
    sol=rand()%k+1;
    printf("%d\n",sol);

    return 0;
}
