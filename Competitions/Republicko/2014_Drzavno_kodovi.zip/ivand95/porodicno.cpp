//Ivan Dejkovic: 5 Porodicno stablo

#include <cstdio>
#include <vector>

using namespace std;

vector <int> E[10008];
bool dete[10008]={0},nadjen=0;
int dp[20008]={0},n,s,sol,dif,i,srecan[10008],brDece[10008],x,root,v,j;

inline void ubaci(int x) {
    for (j=2*s-x; j>=0; j--) {
        if (dp[j]) dp[j+x]++;
    }
    if (dp[s]) {
        sol=s;
        dif=0;
        nadjen=1;
    }
}

inline void izbaci(int x) {
    for (j=0; j<=2*s-x; j++) {
        if (dp[j]) dp[j+x]--;
    }
}

inline void proveri() {
    for (j=0; j<=dif; j++) {
        if (dp[s-j]) {
            sol=s-j;
            dif=j;
            break;
        }
        else if (dp[s+j]) {
            sol=s+j;
            dif=j;
            break;
        }
    }
    if (sol==s) nadjen=1;
}

void dfs(int u) {
    ubaci(srecan[u]);
    //printf("%d:\n",u);
    //for (j=0; j<=2*s; j++) printf("%d %d\n",j,dp[j]);
    if (!nadjen) {
        for (int i=0; i<brDece[u]; i++) {
            v=E[u][i];
            dfs(v);
            if (nadjen) break;
        }
        if (brDece[u]==0) {
            proveri();
        }
    }

    izbaci(srecan[u]);
}

int main() {
    scanf("%d %d",&n,&s);
    dp[0]=1;
    //for (i=1; i<=s; i++) dp[i]=0;
    sol=0;
    dif=s;
    for (i=1; i<=n; i++) {
        scanf("%d",&srecan[i]);
        scanf("%d",&brDece[i]);
        for (j=1; j<=brDece[i]; j++) {
            scanf("%d",&x);
            E[i].push_back(x);
            dete[x]=1;
        }
    }

    //nadji koren
    for (i=1; i<=n; i++) {
        if (!dete[i]) {
            root=i;
            break;
        }
    }

    dfs(root);

    printf("%d\n",sol);

    return 0;
}
