#include <iostream>
#include <stdio.h>
using namespace std;


int cif(int n, int t)
{
    int i=0;
    int p,k=t/2;;
    if (n>0)
    while (n>=p)
    {
        p=p+k;
        k=k/2;
        i++;
    }

    if (n!=0) return i;
    else return 0;
}


int main()
{
    int n,a=0,i=0,a1=0;
    int m,st=1;
    scanf("%d %d",&n,&m);
    st<<=n;
    {
    while (i<n)
    {
       m=m%st;
       m--;
       a=cif(m,st);
       st>>=a;
       if (a) printf("%d ",a+a1);
       a1=a;
       i++;
    }
    return 0;
    }
}
