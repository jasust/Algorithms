#include <iostream>
#include <stdio.h>
using namespace std;


int main()
{
    int n,i,j,maxi,maxj,k=0;
    long a,m[1000000],sum1,sum2,o[1000000];
        scanf("%d",&n);

        for (i=0;i<n;i++)
        {
            scanf("%l",&m[i]);
        }

        for (i=0;i<n;i++)
        {
            scanf("%l",&a);
            m[i]-=a;
        }

        o[0]=m[0];

        for (i=1;i<n;i++;)
        {
            if ((a[i-1]<0&&a[i]<0)||(a[i-1]>0&&a[i]>0))
                     o[k]+=a[i];
                else
                {
                    o[k]+=a[i-1];
                    k++;
                }
        }






















    return 0;
}
