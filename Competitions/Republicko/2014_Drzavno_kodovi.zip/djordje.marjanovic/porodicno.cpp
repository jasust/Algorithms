/******
 **73**
 ******/

#include <iostream>

using namespace std;

int main()
{
    short s,n,t,n2;
    cin>>n>>s;
    for(int i=0; i<n; i++)
    {
		cin>>n2;
        cin>>n2;
        for(int j=0; j<n2; j++)cin>>t;
    }
    cout<<s-1;
	return 0;
}