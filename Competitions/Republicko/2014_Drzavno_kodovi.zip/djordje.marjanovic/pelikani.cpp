/******
 **73**
 ******/

#include <iostream>

using namespace std;

void makeup(bool mat[1000][1000],int n)
{
    int a[1000];
    for(int i=0; i<n; i++)
    {
        a[i]=0;
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            if(mat[j][i])a[i]++;
            mat[i][j]=false;
        }
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            if(a[i])
            {
                a[i]--;
                mat[j][i]=true;
            }
        }
    }
}

void makeleft(bool mat[1000][1000],int n)
{
    int a[1000];
    for(int i=0; i<n; i++)
    {
        a[i]=0;
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            if(mat[i][j])a[i]++;
            mat[i][j]=false;
        }
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            if(a[i])
            {
                a[i]--;
                mat[i][j]=true;
            }
        }
    }
}
/**/
int main()
{
    int n,m(0),Q,up(0),left(0),q1,q2,side(0);
    bool mat[1000][1000],q[300000];
    char c;
    cin>>n;
    for(int i=0; i<Q; i++)q[i]=0;
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
            cin>>c;
            if(c=='1') mat[i][j]=1;
            else mat[i][j]=0;
        }
    }
    cin>>Q;
    Q++;
    while(--Q)
    {
        cin>>c;
        if(c=='1')
        {
            cin>>side;
            if((side==1)||(side==3))
            {
                if(up==0)
                {
                    makeup(mat,n);
                }
                up=2-side;
            }
            else
            {
                if(left==0)
                {
                    makeleft(mat,n);
                }
                left=3-side;
            }
        }
        else
        {
            cin>>q1>>q2;
            q1--;
            q2--;
            switch(side)
            {
            case 0:
                q[m]=mat[q1][q2];
                break;
            case 1:
                if(left==-1)q[m]=mat[q1][n-q2-1];
                else q[m]=mat[q1,q2];
                break;
            case 2:
                if(up==-1)q[m]=mat[n-q1-1][q2];
                else q[m]=mat[q1,q2];
                break;
            case 3:
                if(left==-1)q[m]=mat[n-q1-1][n-q2-1];
                else q[m]=mat[n-q1-1][q2];
                break;
            case 4:
                if(up==-1)q[m]=mat[n-q1-1][n-q2-1];
                else q[m]=mat[q1][n-q2-1];
                break;
            }
            m++;
            //cout<<"("<<q1<<","<<q2<<")->"<<q[m-1]<<endl;
        }
    }
    for(int i=0; i<m; i++)
    {
        cout<<q[i]<<endl;
    }
    return 0;
}