/******
 **73**
 ******/

#include <iostream>

using namespace std;

int main()
{
    int n,m,D,C,a;
    cin>>n>>m>>D>>C;
    for(int i=0; i<2*n+m; i++)cin>>a;
    cout<<C/D;
	return 0;
}