#include <iostream>
#include <cstdio>

using namespace std;

  int a[1000001];
int main()
{
    int n,k,rk,hb;
    scanf("%d %d",&n,&k);
    for (int i=1;i<=n;i++) scanf("%d",&a[i]);
    scanf("%d %d",&rk,&hb);
    long long mesto,pocetak,visina;
    pocetak=0;
    k--;
    for (int i=n;i>=rk+1;i--) pocetak+=a[i];
    pocetak+=hb;
    mesto=(pocetak-1)/k +rk;
    visina=pocetak%k;
    if (!visina) visina=k;
    printf("%lld ",mesto);
    printf("%lld\n",visina);
    //system ("PAUSE");
    return 0;
}
