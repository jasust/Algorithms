#include <cstdio>
#include <iostream>

using namespace std;


int main()
{
    unsigned long long m;
    int n;
    scanf("%d %llu",&n,&m);
    if (m==1) 
    {
              printf("\n");
              return 0;
              }
      printf("2\n");
             
                    
    system("PAUSE");
    return 0;
}
