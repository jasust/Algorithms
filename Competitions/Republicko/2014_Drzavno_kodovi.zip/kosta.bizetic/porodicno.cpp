#include <stdio.h>
#include <iostream>
#include <vector>
using namespace std;

short n,s,m[1001],brl = 0,p1[10001],p2[10001],kp1 = 1,kp2 = 0,ps = 0;

int minr;

struct cvor
{
    int v;
    short d;
    vector <short> p;
}stablo[1001];

short dfs(int t,int niz)
{
    if(niz == 1)
    {
        short i = 0;
        for(;i < kp1;i++)
        {
            int tmp = p1[i] + stablo[t].v;
            if(tmp >= s)
            {
                if(tmp-s < minr)
                {
                    minr = tmp - s;
                    ps = tmp;
                }
                break;
            }
            else p1[i + kp1] = tmp;
        }
        int pom = 0;
        int l = 0,d = kp1;
        while(l<kp1 && d<i+kp1)
        {
            if(p1[l]<p1[d])
            {
                p2[pom++] = p1[l++];
            }
            else if(p1[l] == p1[d])
            {
                p2[pom++] = p1[l++];
                d++;
            }
            else
            {
                p2[pom++] = p1[d++];
            }
        }
        while(l<kp1)
        {
            p2[pom++] = p1[l++];
        }
        while(d<kp1+i)
        {
            p2[pom++] = p1[d++];
        }
        kp2 = pom;
        //dalje
        if(stablo[i].d > 0)
        {
            short index = stablo[i].p[d-1];
            short tmp1 = dfs(t*(-1),index);
            if(tmp1 == 1) d--;
            if(d == 0)
            {
                return 1;
            }
            else return 0;
        }
        else
        {
            if(s-p1[kp1-1] <= minr)
            {
                minr = s-p1[kp1-1];
                ps = p1[kp1-1];
            }
            return 1;
        }
    }
    else
    {
        short i = 0;
        for(;i < kp2;i++)
        {
            int tmp = p2[i] + stablo[t].v;
            if(tmp >= s)
            {
                if(tmp-s < minr)
                {
                    minr = tmp - s;
                    ps = tmp;
                }
                break;
            }
            else p2[i + kp2] = tmp;
        }
        int pom = 0;
        int l = 0,d = kp1;
        while(l<kp2 && d<i+kp2)
        {
            if(p2[l]<p2[d])
            {
                p1[pom++] = p2[l++];
            }
            else if(p2[l] == p2[d])
            {
                p1[pom++] = p2[l++];
                d++;
            }
            else
            {
                p1[pom++] = p2[d++];
            }
        }
        while(l<kp2)
        {
            p1[pom++] = p2[l++];
        }
        while(d<kp2+i)
        {
            p1[pom++] = p2[d++];
        }
        kp1 = pom;
        //dalje
        if(stablo[i].d > 0)
        {
            short index = stablo[i].p[d-1];
            short tmp1 = dfs(t*(-1),index);
            if(tmp1 == 1) d--;
            if(d == 0)
            {
                return 1;
            }
            else return 0;
        }
        else
        {
            if(s-p2[kp2-1] <= minr)
            {
                minr = s-p2[kp2-1];
                ps = p2[kp2-1];
            }
            return 1;
        }
    }
}


int main()
{
    scanf("%d %d",&n,&s);
    minr = s + 1;
    for(int i = 0;i<n;i++)
    {
        cin >> stablo[i].v >> stablo[i].d;
        if(stablo[i].d == 0)
        {
            brl++;
        }
        else
        {
            for(short j = 0;j < stablo[i].d;j++)
            {
                short tmp;
                scanf("%d",&tmp);
                stablo[i].p.push_back(tmp);
            }
        }
    }
    for(int i = 0;i<n;i++)
    {
        dfs(0,1);
    }
    printf("%d",ps);
    return 0;
}
