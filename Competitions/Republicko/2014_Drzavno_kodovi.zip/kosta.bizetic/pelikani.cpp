#include <stdio.h>

using namespace std;

int n,m[1001][1001],h[1001],v[1001],q,psmer = 0,pr = 0,r[300001],q1 = 0,cosak = 0;

void quicksort(int a[],int left,int right)
{
    int i = left;
    int j = right;
    int pivot = a[(left + right)/2];
    int tmp;

    while(i<=j)
    {
        while(pivot < a[i]) i++;
        while(a[j] < pivot) j--;
        if(i <= j)
        {
            tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
            i++;
            j--;
        }
    }

    if(left < j) quicksort(a,left,j);
    if(i < right) quicksort(a,i,right);
}

void prvi_upit()
{
    int smer;
    scanf("%d",&smer);
    if(psmer == 0)
    {
        pr = 1;
    }
    else if(pr == 1)
    {
        int tmp = smer + psmer;
        if(tmp == 5 || tmp == 3 || tmp == 7)
        {
            if(psmer == 1 || psmer == 3)
            {
                quicksort(h,0,n-1);
                int i = 0;
                while(h[i] > 0)
                {
                    i++;
                }
                int j = 0;
                int sum = 0;
                for(;i>=0;i--)
                {
                    for(;sum < h[i];sum++)
                    {
                        v[j++] = i+1;
                    }
                }
                for(;j<n;j++)
                {
                    v[j] = 0;
                }
            }
            else
            {
                quicksort(v,0,n-1);
                int i = 0;
                while(v[i] > 0)
                {
                    i++;
                }
                int j = 0;
                int sum = 0;
                for(;i>=0;i--)
                {
                    for(;sum < v[i];sum++)
                    {
                        h[j++] = i+1;
                    }
                }
                for(;j<n;j++)
                {
                    h[j] = 0;
                }
            }
            pr = 0;
        }
    }
    cosak = psmer * smer;
    psmer = smer;
}

void drugi_upit()
{
    int x,y;
    scanf("%d %d",&x,&y);
    x--;
    y--;
    if (cosak == 2)
    {
        if(x < h[y])
        {
            r[q1++] = 1;
        }
        else r[q1++] = 0;
    }
    else if(cosak == 6)
    {
        if(n-x-1 < h[y])
        {
            r[q1++] = 1;
        }
        else r[q1++] = 0;
    }
    else if(cosak == 12)
    {
        if(n-x-1 < h[n-y-1])
        {
            r[q1++] = 1;
        }
        else r[q1++] = 0;
    }
    else if(cosak == 4)
    {
        if(x < h[n-y-1])
        {
            r[q1++] = 1;
        }
        else r[q1++] = 0;
    }
    else if(pr == 1)
    {
        if(psmer == 1)
        {
            if(x < h[y])
            {
                r[q1++] = 1;
            }
            else r[q1++] = 0;
        }
        else if(psmer == 2)
        {
            if(y < v[x])
            {
                r[q1++] = 1;
            }
            else r[q1++] = 0;
        }
        else if(psmer == 3)
        {
            if(n-x-1 < h[y])
            {
                r[q1++] = 1;
            }
            else r[q1++] = 0;
        }
        else if(psmer == 4)
        {
            if(n-y-1 < v[x])
            {
                r[q1++] = 1;
            }
            else r[q1++] = 0;
        }
    }
    else if(psmer == 0)
    {
        r[q1++] = m[x][y];
    }
}

int main()
{
    scanf("%d",&n);
    for(int i = 0;i<n;i++)
    {
        char c;
        c = getchar();
        for(int j = 0;j<n;j++)
        {
            c = getchar();
            m[i][j] = c - 48;
            v[i] += m[i][j];
            h[j] += m[i][j];
        }

    }
    scanf("%d",&q);
    for(int i = 0;i<q;i++)
    {
        int p;
        scanf("%d",&p);
        if(p == 1)
        {
            prvi_upit();
        }
        else drugi_upit();
    }
    for(int i = 0;i<q1;i++)
    {
        printf("%d\n",r[i]);
    }
    return 0;
}
