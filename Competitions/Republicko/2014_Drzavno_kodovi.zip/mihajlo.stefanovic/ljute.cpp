#include<cstdio>
#include<algorithm>
using namespace std;
int i;
int n,k,a[1000001],rk,hk,v,p=0;
bool test()
{
     int i=0;
     while(a[i]<k&&i<n+10000)
     i++;
     if(i<n+10000) return true;
     return false;
}
int main()
{
    int j,o;
    bool p;
    scanf("%d%d",&n,&k);
    for(int u=0;u<n;u++)
    scanf("%d",&a[u]);
    scanf("%d%d",&rk,&hk);
    if(k==1) 
    {
             printf("nikada nece stati sa gadjanjem");
             return 0;
}
    else if(k>hk)
    {
          printf("%d %d",rk,hk);
          return 0;
    }
    
    
    while(test())
    {
               p=false;
               v=a[i]-k+1;
               a[i]=k-1;
               if(rk==i+1)
               {
                              rk+=1;
                              hk=hk-k+1+min(k-1,a[i+1]);
                              p=true;
               }
               j=i;
               while(j++<n+10000)
               {
                        o=a[j];
                        a[j]=min(a[j],k-1)+v;
                        v=o-k+1;
                        if(v<0) break;
                        if(rk==j+1&&k<=hk&&p==false)
               {
                              rk+=1;
                              hk=hk-k+1+min(k-1,a[j+1]);
                              p=true;
               } 
               }
     }
    printf("%d %d",rk,hk);
    return 0;
}
