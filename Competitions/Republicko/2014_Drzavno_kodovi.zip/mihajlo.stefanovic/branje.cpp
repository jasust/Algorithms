#include<cstdio>
using namespace std;
int k[25000000],u1[25000000],u2[25000000];
int main()
{
    int n,a[100000],a2,i,j,max=-1000000001;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    for(i=0;i<n;i++)
    {
    scanf("%d",&a2);
    a[i]-=a2;
    }
    int o=0;
    for(i=0;i<n;i++)
    { 
    k[o++]=a[i];
    for(j=i+1;j<n;j++)
    u1[0]=i;
    u2[o]=j;
    k[o++]=k[o-1]+a[j];
    }
    for(i=0;i<o-n;i++)
    for(j=i+1;j<o;j++)
    if(k[i]+k[j]>max&&(u1[i]>u2[j]||u2[j]>u1[i])) max=k[i]+k[j];
    printf("%d",max);
    return 0;
}

