#include <cstdio>
#include <cstring>
using namespace std;
const int maxn=1010;
char s[maxn];
bool a[maxn][maxn];
int nex[maxn],ney[maxn],pom[maxn],d1[maxn];
int main(){
    int n,q,d=0,x=0,y=0;
    bool pox=0,poy=0;
    scanf("%d",&n);
    for (int i=1;i<=n;i++){
        scanf("%s",s+1);
        for (int j=1;j<=n;j++) a[i][j]=s[j]-'0';
    }
    for (int i=1;i<=n;i++)
        for (int j=1;j<=n;j++){
            nex[j]+=a[i][j];
            ney[i]+=a[i][j];
            if (a[i][j]) pom[++d1[i]]++;
        }
    scanf("%d",&q);
    while (q--){
        int g,h;
        scanf("%d",&g);
        if (g==1){
            scanf("%d",&g);
            if (g==1){
                poy=1;
                y=1;
            } else
            if (g==2){
                pox=1;
                x=-1;
            } else
            if (g==3){
                poy=1;
                y=-1;
            } else{
                pox=1;
                x=1;
            }
        } else{
            scanf("%d %d",&g,&h);
            if ((!pox)&&(!poy)) printf("%d\n",a[g][h]); else
            if ((!pox)&&poy){
                if (y==-1) g=n+1-g;
                printf("%d\n",nex[h]>=g);
            } else
            if (pox&&(!poy)){
                if (x==1) h=n+1-h;
                printf("%d\n",ney[g]>=h);
            } else{
                if (y==-1) g=n+1-g;
                if (x==1) h=n+1-h;
                printf("%d\n",pom[h]>=g);
            }
        }
    }
    return 0;
}
