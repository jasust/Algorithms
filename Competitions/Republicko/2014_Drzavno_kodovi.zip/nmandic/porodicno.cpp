/*#include <cstdio>
#include <algorithm>
#include <queue>
#include <vector>
using namespace std;
void dfs(int c,int p){
    for (int i=0;i<v[c].size();i++) if (v[c][i]!=p) dfs(v[c][i],c);
    if (a[c]>suma) minc=min(a[c],minc);
    Cvor t;
    t.cvor=c;
    while (!s.empty()&&s.top().cvor!=c){
        Cvor cr=s.top();
        int sh=a[c],j=0,j1=j;
        while (sh>=0){
            t.niz[j]=cr.niz[0]>>sh;
            sh-=64;
            j++;
        }
        sh=-sh;
        j1=j;
        while (j<maxniz){
            t.niz[j]=cr.niz[j-j1]<<sh+cr.niz[j-j1+1]>>64-sh;
            j++;
        }
        for (int j=0;j<maxniz;j++) t.niz[i]=t.niz[i]|cr.niz[i];
    }
    s.push(t);
}
int main(){
    int n;
    scanf("%d",&n1);
    n=n1;
    for (int i=1;i<=n1;i++){
        int s=2;
        scanf("%d",&a[i]);
        scanf("%d",&d[i]);
        for (int j=1;j<=d[i];j++){
            scanf("%d",&po[i]);
            f[po[j]]=1;
        }
        q.push(a[i]);
        while (s<d[i]){
            int c=q.front();
            n+=2;
            v[c].push_back(n+1);
            v[n+1].push_back(c);
            v[c].push_back(n+2);
            v[n+2].push_back(c);
            q.push(n+1);
            q.push(n+2);
            q.pop();
            s+=2;
        }
        int j=1;
        while (!q.empty()){
            int c=q.front();
            for (int k=0;k<2;k++) if (j<=d[i]){
                v[c].push_back(po[j]);
                v[po[j]].push_back(c);
                j++;
            }
            q.pop();
        }
    }
    int i;
    for (i=1;i<=n1;i++) if (!f[i]) break;
    dfs(i,0);
    for (int i=maxniz-1;i>=0;i--)
        for (int j=63;j>=0;j--) if (s.top().niz[i]>>j&&(i*64+j>min||))
    return 0;
}*/
#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;
const int maxn=1010;
int a[maxn],d[maxn],s,x,minc=1000010;
bool f[maxn];
vector <int> v[maxn];
void dfs1(int c,int p,int sumac){
    int s=0;
    for (int i=0;i<v[c].size();i++) if (v[c][i]!=p){
        s++;
        dfs1(v[c][i],c,sumac);
        dfs1(v[c][i],c,sumac+a[c]);
    }
    if (!s&&(abs(sumac-s)<minc||(abs(sumac-s)==minc&&sumac<x))){
        x=sumac;
        minc=abs(sumac-s);
    }
}
int main(){
    int n;
    scanf("%d %d",&n,&s);
    for (int i=1;i<=n;i++){
        scanf("%d %d",&a[i],&d[i]);
        for (int j=1;j<=d[i];j++){
            int x;
            scanf("%d",&x);
            f[x]=1;
            v[x].push_back(i);
            v[i].push_back(x);
        }
    }
    if (n>18){
        int x,minc=1000010;
        for (int i=1;i<=n;i++) if (abs(a[i]-s)<minc||(abs(a[i]-s)==minc&&a[i]<x)){
            x=a[i];
            minc=abs(a[i]-s);
        }
        printf("%d\n",x);
        return 0;
    }
    int i;
    for (int i=1;i<=n;i++) if (!f[i]) break;
    dfs1(i,0,0);
    printf("%d\n",x);
    return 0;
}
