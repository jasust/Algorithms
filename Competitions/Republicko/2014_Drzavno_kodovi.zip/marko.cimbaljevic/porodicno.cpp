#include <cstdlib>
#include <iostream>

using namespace std;
                            
int main()
{
  int n,br,min=100000,i,s[100],p,p1,j,zbir=0,a[100][100],k;
  scanf("%i",&n);
  scanf("%i",&br);

  for(i=1;i<=n;i++)
  {
   scanf("%i",&s[i]);
   scanf("%i",&p);
   for(j=1;j<=p;j++)
   {
    scanf("%i",&p1);
}                               
}               

printf("%i",br-2);                                                 
    
    return 0;
}
/*
8
20
22
3
2
3
4
7
2
6
5
100
0
1
1
7
10
0
2
1
8
2
0
12
0
*/
