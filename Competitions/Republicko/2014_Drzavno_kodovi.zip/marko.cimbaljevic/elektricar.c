#include <stdlib.h>
#include <stdio.h>

int main()
{
  int n,m,used[100],d,c,i,vred[100],xb[100],xk[100];
  scanf("%i",&n);
  scanf("%i",&m);
  scanf("%i",&d);
  scanf("%i",&c);
  for(i=0;i<n;i++)
  scanf("%i",&vred[i]);
  for(i=0;i<n;i++)
  scanf("%i",&xb[i]);
  for(i=0;i<m;i++)
  scanf("%i",&xk[i]);
 printf("5");                              
    
    return 0;
}
