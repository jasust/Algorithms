#include <cstdlib>
#include <iostream>
#include <string.h>
using namespace std;
void bfs(long long int i,long long int j,char a[][100],int k,long long int n)
{
     int p=0;
 if(k==3)
{    
while(i>=0)
{
if(a[i][j]=='1')
{
a[i][j]='0';
a[i+p][j]='1';
}
else
{
 p++;
}
i--;
}
}
if(k==1)
{
while(i<n)
{
 if(a[i][j]=='1')
{
 a[i][j]='0';
 a[i-p][j]='1';
}
else
{
 p++;
}
i++;
}
}
if(k==2)
{
 while(j<n)
 {
 if(a[i][j]=='1')
 {
 a[i][j]='0';
 a[i][j-p]='1';
}
else
{
 p++;
}
j++;
}
}
if(k==4)
{
while(j>=0)
{
 if(a[i][j]=='1')
 {
 a[i][j]='0';
 a[i][j+p]='1';

}
else
{
p++;
}
j--;
}
}
}                                                                                              
                
              
int main()
{
  int s=0,b[30000],br1,br;
  long long int n,q,x,y,i,j,t;
  char a[100][100];
  scanf("%I64d",&n);
  for(i=0;i<n;i++)
  scanf("%s",&a[i]);
  scanf("%I64d",&q);
  for(i=0;i<q;i++)
  {
  scanf("%i",&br);
  if(br==2)
  {
  scanf("%I64d",&x);
  scanf("%I64d",&y);
  x--;
  y--;
  if(a[x][y]=='1')
  {
   b[s]=1;
   s++;                     
}
else
{
 b[s]=0;
 s++;
}   
} 
else
{
  scanf("%i",&br1);
  if(br1==3)
  {
    for(t=0;t<n;t++)
    bfs(n-1,t,a,br1,n);
 }
  if(br1==1)
{
 for(t=0;t<n;t++)
 bfs(0,t,a,br1,n);
}
if(br1==2)
{
for(t=0;t<n;t++)
bfs(t,0,a,br1,n);
}
if(br1==4)
{
for(t=0;t<n;t++)
bfs(t,n-1,a,br1,n);
}
}
}
for(i=0;i<s;i++)
 printf("%i \n",b[i]);   
                    
  
                    
  
    return 0;
}
/*
5
00000
01000
11000
01010
00000
6
2
5
2
1
3
2
5
2
2
3
2
1
4
2
5
2
*/
