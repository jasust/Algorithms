#include <cstdio>
#include <algorithm>
#include <vector>
#include <cmath>

using namespace std;

#define MAXN 1024*32

vector<int> gen(int a)
{
    int k = 0;
    int bin[50];
    while (a>0)
    {
        bin[k] = a%2;
        a /= 2;
        k++;
    }
    vector<int> res;

    for (int i = 0; i<k; i++)
    {
        if (bin[i] == 1) res.push_back(i+1);
    }


    return res;

}

int min(int a, int b)
{
    if (a<b) return a;
    else return b;
}

bool comp(int a, int b) {
    vector<int> p,q;
    p = gen(a);
    q = gen(b);

    int i = 0;
    int n = min(p.size(), q.size());

    while (i<n && p[i] == q[i]) i++;
    if (i < n)
    {
        if (p[i] < q[i]) return true;
        else return false;
    }
    else
    {
        return n == p.size();
    }
}

void print(vector<int> a)
{
    for (int i = 0; i<a.size(); i++)
    {
        printf("%d ", a[i]);
    }
    printf("\n");
}

int main()
{
    int n,m;
    scanf(" %d %d", &n, &m);
    vector <int> all;
    for (int i = 0; i< (int) pow(2, n); i++)
    {
        all.push_back(i);
    }
    sort(all.begin(), all.end(), comp);
    print(gen(all[m-1]));
    return 0;
}
