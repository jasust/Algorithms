#include <cstdio>
using namespace std;

int a[1000000];

int main()
{
    int n,k,r,b;
    scanf(" %d %d", &n, &k);
    for (int i = 0; i<n; i++)
    {
        scanf(" %d", &a[i]);
    }
    scanf(" %d %d", &r, &b);
    if (k > b)
    {
        printf("%d %d", r, b);
        return 0;
    }
    if (n == 1)
    {
        printf("%d %d", b/k + 1, b%k);
        return 0;
    }
    return 0;
}
