#include<stdio.h>

int main()
{
    int n, k, h[1000000], rk, hb,x,y,i;
    unsigned long long br_blokova = 0;
    scanf("%d %d", &n, &k);
    for(i=0; i<n; i++)
    {
        scanf("%d",&h[i]);
        br_blokova += h[i];
        if(h[i]>=k) x = i;
    }
    scanf("%d %d",&rk, &hb);
    y = k;
    for(i = rk-1; i<n;i++)
    {
        if(i == rk-1)
        {
            br_blokova+=h[i]-rk+1;
        }else{
            if(h[i]>k)
            {
                br_blokova+=h[i]-k+1;
            }else
            {
                br_blokova-=k-h[i];
            }
        }
        if(br_blokova<0)
        {
            x=i;
            y=-br_blokova;
            break;
        }
    }
    printf("%d %d",x,y);
    return 0;
}
