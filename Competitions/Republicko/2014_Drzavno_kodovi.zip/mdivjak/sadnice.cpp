#include<stdio.h>

int dodatak = 0, uspele[51], br_uspelih = 0;

void trazenje(int n, unsigned long long m)
{
    int i, pocetak = 2, kraj, k, stepen = 1, e;
        for(i = 0; i < n - 1; i++, stepen *= 2);
        e = n - 1;
        kraj = stepen;
        for(i = 1; i <= n; i ++)
        {
            if((m >= pocetak) && (m <= kraj + 1))
            {
                k = n - e;
                uspele[br_uspelih] = k + dodatak;
                br_uspelih++;
                dodatak++;
                break;
            }
            e--;
            stepen /= 2;
            pocetak = kraj + 2;
            kraj += stepen;
        }
        /*uspele[br_uspelih] = k + dodatak;
        br_uspelih++;
        dodatak++;*/
        if((m - pocetak + 1) > 1)
            trazenje(n - k, m - pocetak + 1);
}

int main()
{
    int n;   ///n - br. sadnica, m - redni br. niza
    unsigned long long m;
    scanf("%d %I64d", &n, &m);   ///ZAMENI NA KRAJU SA %lld <-------------!!!
    if(m != 1)
    {
        trazenje(n, m);
        for(int i = 0; i < br_uspelih; i++)
        {
            if(uspele[i] <= uspele[i - 1])
            {
                uspele[i] = uspele[i - 1] + 1;
            }
            printf("%d ",uspele[i]);
        }
    }
    return 0;
}
