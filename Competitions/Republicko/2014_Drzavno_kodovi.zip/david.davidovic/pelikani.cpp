#include <stdio.h>
#include <string.h>
char state[1000][1000];
int lastRSide, lastCSide;

#define NORTH 1
#define SOUTH 3
#define EAST 4
#define WEST 2

bool flipRows, flipCols,
	 hadRows /* shifted along the rows, east-west */, hadCols /* shifted along the columns, north-south */;
int N, Q;

void compress(int side)
{
	if (side == NORTH || side == SOUTH) {
		if (hadCols) {
			if (lastCSide != side) {
				flipCols = !flipCols;
			}
		} else {s
 			for (int j = 0; j < N; ++j) {
				int count = 0;
				for (int i = 0; i < N; ++i) {
					if (state[i][j] == '1') ++count;
					state[i][j] = '0';
				}
				if (side == NORTH)
					for (int i = 0; i < count; ++i)
						state[i][j] = '1';
				else
					for (int i = N - 1; i > N - count - 1; --i)
						state[i][j] = '1';
			}
			hadCols = true;
		}
		lastCSide = side;
	} else {
		if (hadRows) {
			if (lastRSide != side) {
				flipRows = !flipRows;
			}
		} else {
			for (int i = 0; i < N; ++i) {
				int count = 0;
				for (int j = 0; j < N; ++j) {
					if (state[i][j] == '1') ++count;
					state[i][j] = '0';
				}
				if (side == WEST)
					for (int j = 0; j < count; ++j)
						state[i][j] = '1';
				else
					for (int j = N - 1; j > N - count - 1; --j)
						state[i][j] = '1';
			}
			hadRows = true;
		}
		lastRSide = side;
	}
}

int main(int argc, char** argv)
{
	scanf("%d\n", &N);
	for (int i = 0; i < N; ++i) {
		char s[1010];
		gets(s);
		memcpy(&state[i][0], s, N);
	}

	scanf("%d", &Q);
	while (Q--) {
		int type;
		scanf("%d", &type);
		if (type == 1) {
			int side;
			scanf("%d", &side);
			compress(side);
		} else {
			int i, j;
			scanf("%d %d", &i, &j);
			--i, --j;
			if (flipRows) j = N - 1 - j;
			if (flipCols) i = N - 1 - i;
			printf("%c\n", state[i][j]);
		}
	}

	return(0);
}
