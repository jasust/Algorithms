#include <stdio.h>
#include <stdint.h>
int32_t ggoal;
int N;

/* 80b (10B), maximum that can be used by an array of these structures is ~98KB */
struct node_t {
	int32_t number;
	int16_t firstChild, nextSibling, parent;
};

node_t *nodes;

#define absdiff(a, b) \
	((a) > (b) ? (a) - (b) : (b) - (a))

#define min(a, b) \
	((a) < (b) ? (a) : (b))

#define bestsol(a, b, goal) \
	(absdiff((a), (goal)) == absdiff((b), (goal)) ? \
		min((a), (b)) \
	:   (absdiff((a), (goal)) < absdiff((b), (goal)) ? \
			a \
		:	b) \
	)

int32_t optimum(int32_t, int16_t);

int32_t optimum_list(int16_t goal, int16_t start)
{
	bool foundMin = false;
	int32_t mind = -1, mini = 0;
	do {
		int32_t res = optimum(goal, start),
			    diff = absdiff(res, goal);
		if (!foundMin || diff < mind) {
			mind = diff;
			mini = res;
			foundMin = true;
		}

		start = nodes[start].nextSibling;
	} while (start != -1);
	return mini;
}

int32_t optimum(int32_t goal, int16_t node)
{
	if (nodes[node].firstChild == -1)
		return bestsol(nodes[node].number, 0, goal);

	int32_t v1 = optimum_list(goal, nodes[node].firstChild),
		    v2 = (nodes[node].number <= goal ? optimum_list(goal - nodes[node].number, nodes[node].firstChild) + nodes[node].number :
			      bestsol(nodes[node].number, 0, goal));

	return bestsol(v1, v2, goal);
}
int main(int argc, char** argv)
{
	scanf("%d", &N);
	nodes = new node_t[N]; /* dynamic, just in case */

	int iGoal;
	scanf("%d", &iGoal);
	ggoal = (uint32_t) iGoal;

	for (int i = 0; i < N; ++i) {
		nodes[i].parent = -1;
		nodes[i].nextSibling = -1;
	}

	for (int i = 0; i < N; ++i) {
		int nmb;
		scanf("%d", &nmb);
		nodes[i].number = nmb;

		int nChildren;
		scanf("%d", &nChildren);
		if (nChildren == 0) {
			nodes[i].firstChild = -1;
		} else {
			int fchild;
			scanf("%d", &fchild);
			--fchild;
			nodes[i].firstChild = fchild;
			nodes[fchild].parent = i;
			nodes[fchild].nextSibling = -1;
			while (--nChildren) {
				int ch;
				scanf("%d", &ch);
				--ch;
				nodes[ch].parent = i;
				nodes[ch].nextSibling = fchild;
				nodes[i].firstChild = ch;
				fchild = ch;
			}
		}
	}

	int root = 0;
	for (int i = 0; i < N; ++i)
		if (nodes[i].parent == -1) {
			root = i;
			break;
		}

	int res = (int) optimum(ggoal, root);
	printf("%d\n", res);

	return 0;
}
