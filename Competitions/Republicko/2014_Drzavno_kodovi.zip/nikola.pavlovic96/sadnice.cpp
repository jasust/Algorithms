#include <iostream>

using namespace std;
long long pov2[60]={1};
int main()
{
    for (long long i=1;i<=52;i++) pov2[i]=pov2[i-1]*2;
    long long n,k;
    cin >>n;
    cin >>k;
    long long cdd=k-1;
    if (cdd==0)
    {
        return 0;
    }
    for (long long i=1;i<=n && cdd>0;i++)
    {
        if (pov2[n-i]>=cdd)
        {
            cout <<i<<' ';
            cdd--;
        }
        else cdd-=pov2[n-i];
    }
	return 0;
}
