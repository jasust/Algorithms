#include <cstdio>
using namespace std;
long long n,k, ppv=0;
long long kule[1000001]={0};
long long x,y;
long long cpb=0;
int main()
{
    scanf("%lld", &n);
    scanf("%lld", &k);
    for (long long i=1;i<=n;i++)
    {
        scanf("%lld", &kule[i]);
        if (ppv==0 && kule[i]>=k)
        {
            ppv=i;
        }
    }
    scanf("%lld", &x);
    scanf("%lld", &y);
    cpb=kule[ppv]-k+1;
    long long cp=ppv+1;
    long long xpun=0;
    if (x==ppv)
    {
        xpun=y-k+1;
    }
    long long cv;
    while (cpb>0 && y>=k)
    {
        if (cp<=n)
        {
            cv=kule[cp];
            if (cv<k)
            {
                long long fali=k-cv-1;
                if (xpun!=0 && fali>=xpun)
                {
                    y=cv+xpun;
                    x=cp;
                    xpun=0;
                }
                else
                {
                    xpun-=fali;
                }
                if (fali<cpb)
                {
                    cpb-=fali;

                }
                else
                {
                    cpb=0;
                }
            }
            else
            {
                cpb+=cv-k+1;
                if (x==cp)
                {
                    xpun=y-k+1;
                }
                else
                {
                    xpun+=cv-k+1;
                }
            }
        }
        else
        {
            k--;
            x=cp+((xpun-1)/k);
            if (xpun%k==0) y=k; else y=xpun%k;
            break;
        }
        cp++;
    }
    printf("%lld ", x);//cout <<x<<' '<<y<<'\n';
    printf("%lld", y);
    return 0;
}
