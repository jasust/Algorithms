#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <algorithm>

int n,q,x,y,pom,ob=-1,px[1002],py[1002],orx=-1,ory=-1;
char s[1002][1002];


using namespace std;

int dali(int x,int y)
{
    if(ob==-1)
    {
        //printf("aaaa");
        if(s[x-1][y-1]=='1')
        return 1;
        else
        return 0;
    }

    if(orx==1)
    {
        if(ory==2)
        {
            if(px[x-1]>=y)
            return 1;
            else
            return 0;
        }

        if(ory==4)
        {
            if(px[x-1]>=1+n-y)
            return 1;
            else
            return 0;
        }

        if(ory==-1)
        {
            if(py[y-1]>=x)
            return 1;
            else
            return 0;
        }
    }

    if(orx==3)
    {
        if(ory==2)
        {
            if(px[n-x]>=y)
            return 1;
            else
            return 0;
        }

        if(ory==4)
        {
            if(px[n-x]>=1+n-y)
            return 1;
            else
            return 0;
        }

        if(ory==-1)
        {
            if(py[y-1]>=1+n-x)
            return 1;
            else
            return 0;
        }
    }

    if(orx==-1)
    {
        if(ory==2)
        {
            if(px[x-1]>=y)
            return 1;
            else
            return 0;
        }

        if(ory==4)
        {
            if(px[x-1]>=1+n-y)
            return 1;
            else
            return 0;
        }
        /*
        if(ory==-1)
        {
            if(px[x-1]>=y&&py[y-1]>=x)
            return 1;
            else
            return 0;
        }
        */
    }
}

int update(int ob2)
{
    ob=ob2;
    if(ob==1)
    {
        if(orx==-1)
        {
            for(int i=0;i<n;i++){px[i]=0;}
            for(int i=1;i<=n;i++)
            {
                for(int j=0;j<n;j++)
                {
                    if(py[j]>=i)
                    px[i-1]++;
                }
            }
        }
        orx=ob;
    }

    if(ob==2)
    {
        if(ory==-1)
        {
            for(int i=0;i<n;i++){py[i]=0;}
            for(int i=1;i<=n;i++)
            {
                for(int j=0;j<n;j++)
                {
                    if(px[j]>=i)
                    py[i-1]++;
                }
            }
        }
        ory=ob;
    }

    if(ob==3)
    {
        if(orx==-1)
        {
            for(int i=0;i<n;i++){px[i]=0;}
            for(int i=1;i<=n;i++)
            {
                for(int j=0;j<n;j++)
                {
                    if(py[j]>=i)
                    px[i-1]++;
                }
            }
        }
        orx=ob;
    }

    if(ob==4)
    {
        if(ory==-1)
        {
            for(int i=0;i<n;i++){py[i]=0;}
            for(int i=1;i<=n;i++)
            {
                for(int j=0;j<n;j++)
                {
                    if(px[j]>=i)
                    py[i-1]++;
                }
            }
        }
        ory=ob;
    }

    return 0;
}

int ispisi()
{
    printf("\nOB:%d ORX:%d ORY:%d\n",ob,orx,ory);
    for(int i=0;i<n;i++)
    {
        printf("%d ",px[i]);
    }
    printf("\n");
    for(int i=0;i<n;i++)
    {
        printf("%d ",py[i]);
    }
    printf("\n");
    printf("\n");
    printf("\n");
    return 0;
}

int ispm()
{
    printf("\n");
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        printf("%c",s[i][j]);
        printf("\n");
    }
    printf("\n");
}
int main()
{
    scanf("%d",&n);

    for(int i=0;i<n;i++)
    {
        scanf("%s",s[i]);
    }

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(s[i][j]=='1')
            {
                px[i]++;
                py[j]++;
            }
        }
    }
    //ispisi();
    scanf("%d",&q);

    for(int i=0;i<q;i++)
    {
        scanf("%d",&pom);

        if(pom==1)
        {
            scanf("%d",&ob);
            update(ob);
            //ispisi();
        }

        if(pom==2)
        {
            scanf("%d%d",&x,&y);
            //ispisi();
            printf("%d\n",dali(x,y));
        }
    }
    return 0;
}
