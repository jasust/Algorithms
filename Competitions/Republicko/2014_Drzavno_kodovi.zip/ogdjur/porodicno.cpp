#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <algorithm>

int n,s,pom,pom2;

using namespace std;

int main()
{
    scanf("%d%d",&n,&s);

    for(int i=0;i<n;i++)
    {
        scanf("%d",&pom);

        scanf("%d",&pom);

        for(int j=0;j<pom;j++)
        {
            scanf("%d",&pom2);
        }
    }
    printf("%d",s);

    return 0;
}
