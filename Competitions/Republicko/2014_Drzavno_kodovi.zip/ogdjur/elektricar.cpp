#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <algorithm>

using namespace std;

long long n,m;
long long dis,c;
long long s;
long long l=1,d=10;

struct nesto
{
    bool tip;
    bool sbolji;
    long long skuca;
    long long x;
    long long cena;
    long long fix;
};

nesto a[600010];

bool cmp(nesto q,nesto p)
{
    return q.x<p.x;
}

long long get(long long res)
{
    for(int i=0;i<n+m;i++)
    {
        a[i].sbolji=false;
        a[i].skuca=0;
        if(!a[i].tip)
        a[i].cena=0;
        a[i].fix=0;
    }

    for(int i=0;i<n+m-1;i++)
    {
        if(a[i].tip)
        {
            for(int j=i+1;j<n+m;j++)
            {
                if(a[j].tip)
                {
                    if(a[i].cena+res*(a[j].x-a[i].x)>=a[j].cena)
                    {
                        a[i].sbolji=true;
                        i=j-1;
                        break;
                    }
                    else
                    {
                        a[i].sbolji=false;
                        i=j-1;
                        break;
                    }
                }
            }
        }
    }

    for(int i=0;i<n+m;i++)
    {
        if(a[i].tip)
        {
        if(i==0||a[i-1].skuca==0)
        {
            for(int j=i+1;j<n+m;j++)
            {
                if(!a[j].tip)
                {
                    a[i].skuca=j;
                    i=j-1;
                    break;
                }
            }
        }
        else
        {
            a[i].skuca=a[i-1].skuca;
        }
        }
        else
        {
            a[i].skuca=0;
        }
    }

    long long sum=0;
    int br_kuca=0,naj=0;

    for(int i=0;i<n+m;i++)
    {
        printf("I:%d NAJ:%d\n",i,naj);

        if(br_kuca>0)
        {
            if(!a[naj].tip)
            {
                sum+=a[naj].cena;
                br_kuca--;
                naj++;
                i--;
                continue;
            }
            if(a[i].tip)
            {
                if(a[i].x-a[naj].x<=d)
                {
                    printf("A1 FIX:%d RES:%d \n",a[naj].fix,res);
                    if(a[naj].fix!=0)
                    a[naj].fix=min(a[naj].fix,res*(a[i].x-a[naj].x)+a[i].cena+a[naj].cena);
                    else
                    a[naj].fix=res*(a[i].x-a[naj].x)+a[i].cena+a[naj].cena;

                    if(a[a[naj].skuca].cena!=0)
                    a[a[naj].skuca].cena=min(a[a[naj].skuca].cena,a[naj].fix);
                    else
                    a[a[naj].skuca].cena=a[naj].fix;
                }
                else
                {
                    naj++;
                    i--;
                    continue;
                }

                if(a[naj].sbolji)
                {
                    naj++;
                    i--;
                    continue;
                }
            }
            else
            {
                br_kuca++;
                continue;
            }
        }
        else
        {
            if(!a[i].tip)
            br_kuca++;
        }
    }
    for(int i=naj;i<n+m;i++)
    {
        if(!a[i].tip)
        sum+=a[i].cena;
    }

    return sum;
}

int main()
{
    scanf("%lld%lld%lld%lld",&n,&m,&dis,&c);

    for(int i=0;i<n;i++)
    {
        scanf("%lld",&a[i].cena);
        a[i].tip=true;
        a[i].sbolji=false;
    }

    for(int i=0;i<n;i++)
    {
        scanf("%lld",&a[i].x);
    }

    for(int i=n;i<n+m;i++)
    {
        scanf("%lld",&a[i].x);
        a[i].tip=false;
        a[i].sbolji=false;
    }

    sort(a,a+n+m,cmp);

    long long poo=0;

    /*while(l<d)
    {
        poo=get((l+d)/2);
        printf(" BINAR POO:%lld\n",poo);

        if(l==d-1)
        {
            if(get(l)==c)
            {
                printf("%lld",l);
                return 0;
            }
            else
            {
                printf("%lld",d);
                return 0;
            }
        }

        if(poo>c)
        {
            d=(l+d)/2;
        }
        else if(poo<c)
        {
            l=(l+d)/2;
        }
        else if(poo==c)
        {
            printf("%lld",(l+d)/2);
            return 0;
        }
    }*/

    printf("%d",1);

    return 0;
}
