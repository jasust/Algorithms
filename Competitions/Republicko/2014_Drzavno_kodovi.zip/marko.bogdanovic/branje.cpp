#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<algorithm>
long long  n,z[100000000],s[10000000],y[10000000],x[10000][10000],max,max1,zbr;

int main()
{
    int i,k,pom,pom1=0,c,pi,pk,j=0;
    scanf("%lld",&n);
    for(i=0;i<n;i++)
    {
                    scanf("%lld",&z[i]);
                    }
    for(i=0;i<n;i++)
    {
                    scanf("%lld",&s[i]);
                    }
    for(i=0;i<n;i++)
    {
                    y[i]=z[i]-s[i];
                    }
    for(i=0;i<n;i++)
    {for(k=i;k<n;k++)
    {if(i=k)
    {x[i][k]=y[i];}
    else
    {pom=i;
        while(pom<=k)
        {pom1=pom1+y[pom];
        pom++;
        }
        x[i][k]=pom1;
        pom=0;
        pom1=0;
        }}}zbr=0;
        while(j<2)
        {max=x[0][0];
         for(i=0;i<n;i++)
         {for(k=i;k<n;k++)
         {
         if(max<x[i][k])
         {max=x[i][k];
         pi=i;
         pk=k;}}}
         x[pi][pk]=-100000000;
         zbr=zbr+max;
         j++;}
      if(n==2)
      {j=(z[0]+z[1])-(s[0]+s[1]);
      printf("%lld",j);}
      else
       {printf("%lld",zbr);}
    
    return 0;
}
