#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char *argv[])
{
    int n;
    scanf("%d",&n);
    //cin>>n;
    int i,a[n],b[n],j,k;
    long long c[n],z=0,d;
    long long max=0,maxi,min,mini=-1,mini2=-1,min2=0,d2;
    bool f=true;
    for (i=0;i<n;i++)
    {
        cin>>a[i];
        c[i]=0;
        d=0;
    }
    for (i=0;i<n;i++)
    {
        cin>>b[i];
        c[i]=z+b[i]*-1+a[i];
        z=c[i];
    }
    
    for (i=0;i<n-1;i++)
    {
        if (i==0)
        {
           d=c[0];
        }
        else
        {
        if (mini==-1)
        {
           min=0;
           mini=1;
           //mini=0;
        }
        else
        {
            if (c[i-1]<min)
            {
               min=c[i-1];
               //mini=i-1;
            }        
        }
        d=c[i]-min;
        if (d<a[i]-b[i])
        {
           d=a[i]-b[i];
           
        }
        
        }
        min2=0;
        mini2=-1;
        for (j=i+1;j<n;j++)
        {
            if (j==i+1)
            {
               d2=a[j]-b[j];
               //cout<<d2<<"\n";
            }
            else
            {
                if (mini2==-1)
                {
                   min2=c[i];mini2=1;
                }
                else
                {
                    if (c[j-1]<min2)
                    {
                       min2=c[j-1];
                    }        
                }
                d2=c[j]-min2;
                if (d2<a[j]-b[j])
                {
                   d2=a[j]-b[j];
                }
            }
            if (f)
            {
               max=d+d2;
               f=false;
            }
            else
            {
                if (d+d2>max)
                {
                   max=d+d2;
                }
            }//cout<<d<<" "<<d2;
            
        }
    }
    cout<<max<<"\n";
    //system("PAUSE");
    return 0;
}
