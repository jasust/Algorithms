#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define MAXN 50
using namespace std;
/*int a[MAXN],d,b[MAXN],d2;// a i d veci
int max(int a,int b)
{
    if (a>b)
    {
       return a;
    }return b;
}
int nzd(int a,int b)
{
    int p=a+b;
    a=max(a,b);
    b=p-a;
    while (b!=0 && b!=1)
    {
        p=a;
        a=b;
        b=p%b; 
    }
    if (b==0)
    {
       return a;
    }
    return 1;
}
void faktorijel (int n)
{
     long long p=1;
     /*if (n==0)
     {
        return 1;
     }*/
     /*for (int i=1;i<=n;i++)
     {
         b[d2++]=i;
     }

}*/
/*void faktorijel2 (int n)
{
     unsigned long long p=1;
     if (n==0)
     {
        return 1;
     }
     for (int i=1;i<=n;i++)
     {
         p*=i;
     }
     return p;
}*/
/*void delifak(int n,int k)
{
        unsigned p=n-k+1;
        for (int i=n-k+1;i<=n;i++)
        {
            //p*=i;
            a[d++]=i;
        }
}*/
/*unsigned long long delifak2()
{
    int i=0,j=0,del;
    unsigned long long p=1;
    for (i=0;i<d2;i++)
    {
        for (j=0;j<d;j++)
        {
            del=nzd(a[j],b[i]);
            //cout<<a[j]<<" "<<b[i]<<" "<<del<<"\n";
            a[j]/=del;
            b[i]/=del;
        }
    }   
    for (i=0;i<d;i++)
    {
        //cout<<a[i]<<"\n";
        p*=a[i];
    }
    return p;  
}*/
/*unsigned long long n_nad_k(int n,int k)
{
     if (n==k || nk==1)
     {
        return 1;
     }
     unsigned long long p;
     if (n-k>k)
     {
        delifak(n,n-(n-k));
     }
     else
     {
         return n_nad_k(n,n-k);
     }
     faktorijel(k);         
     p=delifak2();
     return p;
}*/
/*bool veci=false;
unsigned long long bp(int m,int n,int rb)
{
    unsigned long long p=0,p2=0;
    for (int i=n-rb;i>=1;i--)
    {
        p+=faktorijel2(k,n)*n_nad_k();
    }     
}*/
int main(int argc, char *argv[])
{
    int n;
    unsigned long long m;
    cin>>n>>m;
    if (m==1)
    {
       printf("");
    }
    else
    {
        switch (m)
        {
               
               case 2:cout<<1;break;
               case 3:cout<<1<<" "<<2;break;
               case 4:cout<<1<<" "<<2<<" "<<3;break;
               default:
               cout<<n/2<<" "<<1<<" "<<2<<" "<<3;
        }
        
    }
    //system("PAUSE");
    return 0;
}
