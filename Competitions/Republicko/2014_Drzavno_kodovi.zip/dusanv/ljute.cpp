#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <algorithm>
using namespace std;
struct mala_kolona 
{
       long long h;
       int ind;
       int nh;
};
long long min(int a,long long b)
{
     if (a<b)
     return a;
     return b;
}
int main(int argc, char *argv[])
{

    int n,rk,i,d=0;
    int h,hb;
    scanf("%d%d",&n,&h);//rk pocinje od 1
    long long a[n],dh,br=0,dh1=0;
    mala_kolona b[2*n+1];
    for (i=0;i<n;i++)
    {
        cin>>a[i];
    }
    
    scanf("%d%d",&rk,&hb);
    for (i=rk;i<n;i++)
    {
        if (a[i]>=h)
        {
           if (dh1<h)
           {
              dh1+=a[i]-h+1;
           }
        }
        if (a[i]<h)
        {
           b[d].h=a[i];
           b[d].nh=min(h-1,dh1+a[i]);
           dh1-=(h-1-a[i]);
           b[d++].ind=i;
        }
    }
    for (i=d;i<2*n+1;i++)
    {
        b[d].h=0;
        b[d].ind=n+i-d;
        d++;
    }
    dh=hb-h;
    if (hb<h)
    {
       //printf("%d%d",rk," ",hb);
       cout<<rk<<" "<<hb;
    }
    else
    {
        i=0;
        while (hb>=h && rk<n)
        {
             rk=b[i].ind;
             br+=b[i].ind-rk; 
             hb-=b[i].nh-h;
        }
        if (hb<h)
        {
           cout<<rk<<" "<<hb;
        }
        else
        {
               cout<<n+1<<" "<<dh;
        }
    }
    cout<<br<<"\n";
    //system("PAUSE");
    return 0;
}
