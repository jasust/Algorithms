#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;

  int n,q;
  int a[1000][1000];
  int l[1000] = {};
  int g[1000] = {};
  int sl[1000] = {};
  int sg[1000] = {};
  int o,x,y;
  char dir = 0;
  char c = 0;

int main(void)
{
  scanf("%d",&n);
  scanf("%c",&c);
  for (int i=0; i<n; i++)
  {
    for (int j=0; j<n; j++)
    {
      scanf("%c",&c);
      if (c=='0') { a[i][j] = 0; }
      else if (c=='1') { a[i][j] = 1; }
      else { a[i][j] = -1; }
      if (a[i][j]) { l[i]++; g[j]++; }
    }
    scanf("%c",&c);
  }

  for (int i=0; i<n; i++)
  {
    sg[ g[i] ]++;
    sl[ l[i] ]++;
  }

  for (int i=n; i>=0; i--)
  {
    sg[i]+=sg[i+1];
    sl[i]+=sl[i+1];
  }

  scanf("%d",&q);

  for (int k=0; k<q; k++)
  {
    scanf("%d",&o);
    if (o==1)
    {
      scanf("%d",&dir);
      if (dir==1)
      {
        for (int i=0; i<n; i++) { l[i] = sg[i+1]; }

        for (int i=0; i<n; i++) { sl[ l[i] ]++; }

        for (int i=n; i>=0; i--) { sl[i]+=sl[i+1]; }
      }
      else if (dir==2)
      {
        for (int i=0; i<n; i++) { g[i] = sl[i+1]; }

        for (int i=0; i<n; i++) { sg[ g[i] ]++; }

        for (int i=n; i>=0; i--) { sg[i]+=sg[i+1]; }
      }
      else if (dir==3)
      {
        for (int i=0; i<n; i++) { l[i] = sg[n-i]; }

        for (int i=0; i<n; i++) { sl[ l[i] ]++; }

        for (int i=n; i>=0; i--) { sl[i]+=sl[i+1]; }
      }

      else if (dir==4)
      {
        for (int i=0; i<n; i++) { g[i] = sl[n-i]; }

        for (int i=0; i<n; i++) { sg[ g[i] ]++; }

        for (int i=n; i>=0; i--) { sg[i]+=sg[i+1]; }
      }
    }
    else
    {
      scanf("%d %d",&x,&y);
      if (dir==1)
        {
          if ( g[y-1] >= x ) { printf("1\n"); } else { printf("0\n"); }
        }
      else if (dir==2)
        {
          if ( l[x-1] >= y ) { printf("1\n"); } else { printf("0\n"); }
        }
      else if (dir==3)
        {
          if ( g[y-1] >= (n-x+1) ) { printf("1\n"); } else { printf("0\n"); }
        }
      else if (dir==4)
        {
          if ( l[x-1] >= (n-y+1) ) { printf("1\n"); } else { printf("0\n"); }
        }
      else if (dir==0) { printf("%d\n",a[x-1][y-1]); }
    }
  }

  return 0;
}
