#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cstring>

using namespace std;

struct node
{
  int val,size;
  int* son;
};


int n,s;
int kraj=0;
int minx;
int cnt;
int m;
int l;
int a[10000];
char p[10000];
node tree[10000];

int minimum(void)
{
  for (int i=0; i<kraj; i++) printf("%d ",a[i]);
  printf("\n");

  memset(p,0,10000);

  for (int i=0; i<kraj; i++)
  {
    for (int j=0; j<10001; j++)
    {
      if ((p[j]) && (a[i]+j <= 10000)) { p[a[i]+j]=1; }
    }
    if (a[i]<=10000) p[a[i]]=1;
  }

    for (int i=0; i<100; i++) printf("%d",p[i]);
  printf("\n");

  cnt = s-1;
  while ( (cnt>s/2) && !(p[cnt]) ) { cnt--; }
  if (p[cnt]) { l=cnt; }
  cnt = s-1;
  while ( (cnt<10001) && !(p[cnt]) ) { cnt++; }
  if ((p[cnt]) && (cnt-s < s-l)) return cnt;
  return l;
}

void lkd(node& x)
{
  a[kraj]=x.val;
  kraj++;

  if (x.size)
  {
    for (int i=0; i<x.size; i++)
    {
      lkd(tree[x.son[i]-1]);
    }
  }
  else
  {
    m = minimum();
    if ( (abs(s-m)<abs(s-minx)) || ((abs(s-m)==abs(s-minx)) && (m<minx)) )  { minx=m; }
  }

  kraj--;
}

int main(void)
{
  scanf("%d %d",&n,&s);
  for (int i=0; i<n; i++)
  {
    scanf("%d %d",&tree[i].val,&tree[i].size);
    tree[i].son = (int*) calloc(tree[i].size, sizeof(int));
    for (int j=0; j<tree[i].size; j++)
    {
      scanf("%d", tree[i].son+j);
    }
  }
  minx = tree[0].val;
  lkd(tree[0]);

  printf("%d",minx);
  return 0;
}
