#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{int a[1000][2],n,br=0,m,b[1000][2],kom,b1,b2,br2=0,last;
char k[1000],resenje[300000];
bool bilo=false,;
cin>>n;
for(int i=0;i<n;i++){b[i][0]=0;b[i][1]=0;}
for(int i=0;i<n;i++){cin>>k;for(int j=0;j<n;j++){if(k[j]=='1'){a[br][0]=i;a[br][1]=j;br++;b[i][0]++;b[j][1]++;}}}
cin>>m;
while(m>0)
{cin>>kom;
          if(kom==2){
                     cin>>b1>>b2;
                     b1--;b2--;
                     resenje[br2]=false;
                     if(!bilo){
                               
                               for(int j=0;j<br;j++){if(a[j][0]==b1&&a[j][1]==b2){resenje[br2]=true;break;}}
                               bilo=true;
                               }
                               else{
                                    if(last==1){if(b[b2][1]>b1){resenje[br2]=true;}}
                               else if(last==2){if(b[b1][0]>b2){resenje[br2]=true;}}
                               else if(last==3){if(b[b2][1]>n-1-b1){resenje[br2]=true;}}
                               else if(last==4){if(b[b1][0]>n-b2-1){resenje[br2]=true;}}
                               }
                               br2++;
                     }
          else{
               cin>>b1;
               if(b1==1){for(int j=0;j<n;j++){b[j][0]=0;for(int o=0;o<n;o++){if(b[o][1]>j){b[j][0]++;}}}}
          else if(b1==2){for(int j=0;j<n;j++){b[j][1]=0;for(int o=0;o<n;o++){if(b[o][0]>j){b[j][1]++;}}}}
          else if(b1==3){for(int j=0;j<n;j++){b[n-j-1][0]=0;for(int o=0;o<n;o++){if(b[o][1]>j){b[n-j-1][0]++;}}}}
          else if(b1==4){for(int j=0;j<n;j++){b[n-j-1][1]=0;for(int o=0;o<n;o++){if(b[o][0]>j){b[n-j-1][1]++;}}}}
               last=b1;
               }
          
        m--; }
         for(int i=0;i<br2;i++){if(resenje[i])cout<<1<<endl;else cout<<0<<endl;}



   return 0;
    return EXIT_SUCCESS;
}
