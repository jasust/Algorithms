#include <cstdlib>
#include <iostream>

using namespace std;
int comb[200000][2];
void vezi(int i,int a[50000][2],int b[300000],int poc,int n,int d,int m,int ukupno,int tren)
{comb[tren][0]+=a[i][0];
int kuca=0,br2=0,lol,lol2,pom1,pom2;
lol2=ukupno;
   if(poc<m)  for(int j=poc;j<m;j++){if(b[j]>a[i][1]){kuca=b[j];poc=j+1;break;}}
     if(kuca!=0){
          for(int j=i+1;j<n;j++){if(a[j][1]>kuca){if(a[j][1]-a[i][1]<=d){br2++;}}}       
        
          
                 lol=br2;
                 
                 br2=0;
                 for(int j=i+1;j<n;j++){
                         if(a[j][1]>kuca){
                                          if(a[j][1]-a[i][1]<=d){
                                                                 if(br2==0){pom1=comb[tren][0];pom2=comb[tren][1];
                                                                            comb[tren][1]+=a[j][1]-a[i][1];
                                                                            br2++;
                                                                           
                                                                            vezi(j,a,b,poc,n,d,m,ukupno+lol,tren);
                                                                            }
                                                                 else{
                                                                      comb[lol2+tren][0]=pom1;
                                                                      comb[lol2+tren][1]=pom2;
                                                                      comb[lol2+tren][1]+=a[j][1]-a[i][1];
                                                                      
                                                                      vezi(j,a,b,poc,n,d,m,ukupno+lol,tren+lol2);
                                                                      lol2++;
                                                                      }
                                                                 }}} 
                                                                 
                      if(br2==0){
                              for(int j=i+1;a[j][1]<kuca;j++){br2++;}
                              for(int j=i+1;a[j][1]<kuca;j++){  
                                     
                                     vezi(j,a,b,poc,n,d,m,ukupno+br2,tren+j-i-1);
                                      }}
                                     else{
                                           for(int j=i+1;a[j][1]<kuca;j++){br2++;}
                                           br2--;
                                           for(int j=i+1;a[j][1]<kuca;j++){
                                                   vezi(j,a,b,poc,n,d,m,ukupno+lol,tren+lol2);
                                                   lol2++;
                                                   }
                                           }
                              
                 
                 }
     }

int main(int argc, char *argv[])
{int n,m,d,c,br=0,super=0,s=0;
cin>>n>>m>>d>>c;
int a[n][2],b[m];
for(int i=0;i<n;i++){cin>>a[i][0];}
for(int i=0;i<n;i++){cin>>a[i][1];}
for(int i=0;i<m;i++){cin>>b[i];}

for(int i=0;i<n-1;i++){comb[i][0]=0;comb[i][1]=0;}
for(int i=0;i<n;i++){if(a[i][1]<b[0]){vezi(i,a,b,0,n,d,m,1,0);
while(comb[super][0]!=0){
                         if(s==0){
                         
                                  if((c-comb[super][0])%comb[super][1]==0){s=(c-comb[super][0])/comb[super][1];}}
                         else {if(comb[super][0]+comb[super][1]*s<c){s=0;super--;}}
                         comb[super][0]=0;comb[super][1]=0;super++;}
super=0;}
}
cout<<s;
   return 0;
    return EXIT_SUCCESS;
}
