#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{int n,s,a,k,br=0;

cin>>n>>s;
for(int i=0;i<n;i++){cin>>k>>k;for(int j=0;j<k;j++){cin>>a;}}
s/=10;
s*=9;
cout<<s;

   return 0;
    return EXIT_SUCCESS;
}
