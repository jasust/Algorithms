#include <cstdio>

int n,m,d,c,price,ban,kuca;
int main()
{
    scanf("%d %d %d %d", &n, &m, &d, &c);

    for (int i=0; i<n; i++) scanf("%d", &price);
    for (int i=0; i<n; i++) scanf("%d", &ban);
    for (int i=0; i<m; i++) scanf("%d", &kuca);

    printf("1");
    return 0;
}
