#include <cstdio>

const int maxn = 1e3 + 5;

char c;
int n,q,x,y,z,a[maxn][maxn],dl[maxn],dd[maxn],y1;

void update(int p)
{
    if (p== 1)
    {
        for(int i=0; i<n; i++)
        {
            dl[0]++;
            dl[dd[i]]--;
        }
        for (int i=1; i<n; i++) dl[i] += dl[i-1];
    }
    if (p== 2)
    {
        for(int i=0; i<n; i++)
        {
            dd[0]++;
            dd[dl[i]]--;
        }
        for (int i=1; i<n; i++) dd[i] += dd[i-1];
    }
    if (p== 3)
    {
        for(int i=0; i<n; i++)
        {
            dl[0]++;
            dl[dd[i]]--;
        }
        for (int i=1; i<n; i++) dl[i] += dl[i-1];
    }
    if (p== 4)
    {
        for(int i=0; i<n; i++)
        {
            dd[0]++;
            dd[dl[i]]--;
        }
        for (int i=1; i<n; i++) dd[i] += dd[i-1];
    }
}

int main()
{

    scanf("%d", &n);
    for (int i=0; i<n; i++)
        for (int j=0; j<=n; j++)
        {
            scanf("%c", &c);
            a[i][j] = c - '0';
            dl[i] += a[i][j];
            dd[j] += a[i][j];
        }

    scanf("%d", &q);
    for (int i=0; i<q; i++)
    {
        scanf("%d", &x);
        if (x == 1)
        {
            scanf("%d", &y1);
            update(y1);
        }
        else
        {
            scanf("%d %d", &y, &z);
            if (y1 == 0) printf("%d\n", a[y][z]);
            if (y1 == 1)
            {
                if (dd[z] >= y) printf("1\n");
                else printf("0\n");
            }
            if (y1 == 2)
            {
                if (dl[z] >= y) printf("1\n");
                else printf("0\n");
            }
            if (y1 == 3)
            {
                y = n - y - 1;
                if (dd[z] >= y) printf("1\n");
                else printf("0\n");
            }
            if (y1 == 4)
            {
                y = n - y -1;
                if (dd[z] >= y) printf("1\n");
                else printf("0\n");
            }
        }
    }
    return 0;
}
