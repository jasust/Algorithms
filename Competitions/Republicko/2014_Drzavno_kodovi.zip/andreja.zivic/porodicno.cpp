#include <cstdio>

int n,s,sk,d,a;
int main()
{
    scanf("%d %d", &n, &s);
    for (int i=0; i<n;i++)
    {
        scanf("%d %d", &sk, &d);
        for (int j=0; j<d; j++) scanf("%d", &a);
    }
    printf("%d", s);
    return 0;
}
