#include<cstdio>

using namespace std;

long long zar[100000000], grupa[100000000], dru[100000];

int main(){
	long long n, i, tmp, j = 0, zn = 0, ch = 0, max, mm;

	scanf("%lld", &n);

	for(i = 0; i < n; i++){
		scanf("%lld", &zar[i]);
	}

	for(i = 0; i < n; i++){
		scanf("%lld", &tmp);
		zar[i] -= tmp;

		if(zar[i] < 0){
			if(zn == 0){
				grupa[j] += zar[i];
			}
			else
			{
				j++;
				zn = 0;
				grupa[j] += zar[i];
			}
		}
		else
		{
			if(zn == 1 || i == 0){
				zn = 1;
				grupa[j] += zar[i];
			}
			else
			{
				j++;
				zn = 1;
				grupa[j] += zar[i];
			}
		}
	}

	j++;


	for(i = 0; i < j - 2; i += 2){
		dru[i] = grupa[i];

		if(grupa[i] + grupa[i + 1] + grupa[i + 2] > grupa[i] && grupa[i] + grupa[i + 1] + grupa[i + 2] > grupa[i + 2]){
			ch = 1;
			dru[i] = grupa[i] + grupa[i + 1] + grupa[i + 2];
		}
	}

	max = dru[1];
	mm = dru[1];

	for(i = 0; i < j; i++){
		if(max > dru[i]){
			mm = max;
			max = dru[i];
		}
	}

	printf("%lld", max + mm);

	return 0;
}
