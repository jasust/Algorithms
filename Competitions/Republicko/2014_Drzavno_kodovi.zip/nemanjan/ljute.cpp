#include<cstdio>

using namespace std;

long long niz[100000000];

int main(){
	long long n, k, i, sx, sy, pom = 0;

	scanf("%lld%lld", &n, &k);

	for(i = 0; i < n; i++){
		scanf("%lld", &niz[i]);
	}

	scanf("%lld%lld", &sx, &sy);

	for(i = sx; i < n; i++){
		if(k - 1 < niz[i]){
			pom += niz[i] - (k - 1);
		}
		else if((k - 1) > niz[i]){
			if(pom >= (k - 1) - niz[i]){
				pom -= (k - 1) - niz[i];
				niz[i] = (k - 1);
			}
			else
			{
				niz[i] += pom;
				pom = 0;
			}
		}
	}

	while(pom > 0){
		if(pom >= (k - 1)){
			pom -= k - 1;
			niz[n] = k - 1;
		}
		else
		{
			niz[n] = pom;
			pom = 0;
		}

		n++;
	}

	while(sy >= k){
		if(niz[sx] < k){
			sy -= (k - 1) - niz[sx];
		}

		sx++;
	}

	printf("%lld %lld\n", sx, sy);

	return 0;
}
