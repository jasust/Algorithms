#include<cstdio>

using namespace std;

void find(long long min, long long n, long long m, long long niz[51]){
	if(m == 1){
		return;
	}

	long long n1;

	n1 = n;

	m--;

	while(m > niz[n - 1]){
		m -= niz[n - 1];
		n--;
	}

	printf("%lld ", min + n1 - n + 1);

	find(min + n1 - n + 1, n1 - n + 1, m, niz);
}

int main(){
	long long niz[51], i, m, n, n1;

	niz[0] = 1;

	for(i = 1; i <= 50; i++){
		niz[i] = niz[i - 1] * 2;
	}

	scanf("%lld%lld", &n, &m);

	if(m == 1){
		printf("\n");
		return 0;
	}

	find(0, n, m, niz);

	printf("\n");

	return 0;
}
