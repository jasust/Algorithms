#include <cstdio>
#include <iostream>

#define MaxN 1001

using namespace std;

bool lake[ MaxN ][ MaxN ], noHorizontal = 1, noVertical = 1;
int N, Q, horizontal[ MaxN ], vertical[ MaxN ], queryType, i, j, dir, oldDirH, oldDirV, invHorizontal, invVertical, index, num;
char row [ MaxN ];

int main ( )
{
    scanf ( "%d", &N );

    for ( i = 0; i < N; i++ )
    {
        scanf ( "%s", &row );

        for ( j = 0; j < N; j++ )
        if ( row[ j ] == '1' )
        {
            lake[ i ][ j ] = 1;
            horizontal[ i ] ++;
            vertical[ j ] ++;
        }
    }

    scanf ( "%d", &Q );

    while ( Q-- )
    {
        scanf ( "%d", &queryType );

        if ( queryType == 1 )
        {
            scanf ( "%d", &dir );

            if ( ( dir == 1 || dir == 3 ) && oldDirV == dir )
            continue;

            if ( ( dir == 2 || dir == 4 ) && oldDirH == dir )
            continue;

            if ( dir == 1 || dir == 3 ) //vertical
            {
                if ( noVertical )
                {
                    noVertical = 0;

                    //izracuna zbir po horizontalama
                    for ( i = 0; i < N; i++ )
                    {
                        horizontal[ i ] = 0;

                        for ( j = 0; j < N; j++ )
                        if ( vertical[ j ] > i )
                        horizontal[ i ] ++;
                    }

                    if ( dir == 3 )
                    invHorizontal = 1;
                }
                else
                invHorizontal ++;

                oldDirV = dir;
            }

            if ( dir == 2 || dir == 4 ) //horizontal
            {
                if ( noHorizontal )
                {
                    noHorizontal = 0;

                    //izracuna zbir po vertikalama
                    for ( i = 0; i < N; i++ )
                    {
                        vertical[ i ] = 0;

                        for ( j = 0; j < N; j++ )
                        if ( horizontal[ j ] > i )
                        vertical[ i ] ++;
                    }

                    if ( dir == 4 )
                    invVertical = 1;
                }
                else
                invVertical ++;

                oldDirH = dir;
            }
        }
        else
        {
            scanf ( "%d %d", &i, &j );

            if ( noHorizontal && noVertical )
            {
                printf ( "%d\n", lake[ i - 1 ][ j - 1 ] );
            }
            else
            {
                if ( dir == 1 || dir == 3 )
                {
                    if ( invHorizontal % 2 == 0 )
                    num = i - 1;
                    else
                    num = N - i;

                    if ( invVertical % 2 == 0 )
                    index = j - 1;
                    else
                    index = N - j;

                    if ( vertical[ index ] > num )
                    printf ( "1\n" );
                    else
                    printf ( "0\n" );
                }
                else
                {
                    if ( invVertical % 2 == 0 )
                    num = j - 1;
                    else
                    num = N - j;

                    if ( invHorizontal % 2 == 0 )
                    index = i - 1;
                    else
                    index = N - i;

                    if ( horizontal[ index ] > num )
                    printf ( "1\n" );
                    else
                    printf ( "0\n" );
                }
            }
        }
    }

    return 0;
}
/*
5
00000
01000
11000
01010
00000
100
2 5 2
1 3
2 5 2
2 3 2
1 4
2 5 2
*/
