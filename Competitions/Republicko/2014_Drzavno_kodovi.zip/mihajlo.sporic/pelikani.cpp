 #include <stdio.h>
 short a[1001][1001],k,zi=-1,sj=-1;
 char b[1001];
 int i,j,n,p;
 void jug()
 {for(j=1;j<=n;j++)
    {p=n;
     for(i=n;i>0;i--)
     if(a[i][j]){a[i][j]=0; a[p][j]=1; p--;}
    }
  return;
 }
 void istok()
 {for(i=1;i<=n;i++)
    {p=n;
     for(j=n;j>0;j--)
     if(a[i][j]){a[i][j]=0; a[i][p]=1; p--;}
    }
  return;
 }
 int main()
 {int q,x,y,ii;
  scanf("%d",&n);
  for(i=1;i<=n;i++)
    {scanf("%s",b);
     for(j=1;j<=n;j++)
       a[i][j]=(b[j-1]-'0');
    }
  scanf("%d",&q);
  for(ii=0;ii<q;ii++)
    {scanf("%d",&k); 
     if(k==1) {
              scanf("%d",&x); 
              if(x==1){if(sj==-1)jug(); sj=0;} 
              else if(x==2){if(zi==-1)istok(); zi=0;}
              else if(x==3){if(sj==-1)jug(); sj=1;}
              else {if(zi==-1)istok(); zi=1;}
              }
     else {
           scanf("%d%d",&x,&y); 
           if(sj==0)x=n-x+1;
           if(zi==0)y=n-y+1;
           printf("%d\n",a[x][y]);
          }
    }
  return 0;   
 }
