#include <stdio.h>
int main()
{printf("1");
 return 0;   
}
