#include <stdio.h>
int main()
{int n,s;
 scanf("%d%d",&n,&s);
 printf("%d",s);
 return 0;   
}
