#include <stdio.h>

int main()
{
    long int n, i, j, x, br, maxx=0, poz, s2, poz1, s1, poz2, maxsum1, maxsum2, zarada, iks1, iks2;

    scanf("%d", &n);

    long int z[n], s[n], suma[n];

    for(i=0; i<n; i++)
    {
        suma[i]=0;
    }

    for(i=0; i<n; i++)
    {
        scanf("%d", &z[i]);
    }
    for(i=0; i<n; i++)
    {
        scanf("%d", &s[i]);
    }
    j=0;
    for(i=0; i<n; i++)
    {
        if(z[i]-s[i]>0)
        {
            if(suma[j]>=0)
            {
                suma[j]=suma[j]+z[i]-s[i];
            }
            else
            {
                j++;
                suma[j]=suma[j]+z[i]-s[i];
            }
        }
        else
        {
            if(suma[j]<0)
            {
                suma[j]=suma[j]+z[i]-s[i];
            }
            else
            {
                j++;
                suma[j]=suma[j]+z[i]-s[i];
            }
        }
    }
    br=0;
    while(suma[br]!=0)
    {
        br++;
    }

    for(i=0; i<br; i++)
    {
        if(maxx<suma[i])
        {
            maxx=suma[i];
            poz=i;
        }
    }
    s2=1;
    poz1=poz;
    while((s2>0)&&(poz1<br))
    {
        s2=s2+suma[poz1+1]+suma[poz1+2];
        poz1=poz1+2;
    }
    s2=s2-suma[poz1-1]-suma[poz1]-1;
    s1=1;
    poz2=poz;
    while((s1>0)&&(poz2>=0))
    {
        s1=s1+suma[poz2-1]+suma[poz2-2];
        poz2=poz2-2;
    }
    s1=s1-suma[poz2+1]-suma[poz2]-1;
    maxsum1=0;
    for(i=poz2+1; i>=0; i--)
    {
        if(maxsum1<suma[i])
        {
            maxsum1=suma[i];
        }
    }
    maxsum2=0;
    for(i=poz1; i<=br; i++)
    {
        if(maxsum2<suma[i])
        {
            maxsum2=suma[i];
        }
    }
    iks1=s1-suma[poz-1];
    iks2=s2-suma[poz+1];
    if(maxsum1>maxsum2)
    {
        zarada=maxx+maxsum1;
    }
    else
    {
        zarada=maxx+maxsum2;
    }
    if(s1>s2)
    {
        zarada=maxx+s1;
    }
    else
    {
        zarada=maxx+s2;
    }
    if((iks2>s2)&&(iks2!=-suma[poz+1]))
    {
        zarada=maxx+iks2;
    }
    if((iks1>s1)&&(iks1!=-suma[poz-1]))
    {
        zarada=maxx+iks1;
    }
    printf("%d", zarada);
    return 0;
}
