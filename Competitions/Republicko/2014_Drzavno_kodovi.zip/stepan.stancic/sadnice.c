#include <stdio.h>
#include <math.h>

int main()
{
    int a, b, c, d, e;
    int n, i, y, z;
    int m, x;

    scanf("%d%d", &n, &m);

    a=1;
    b=2;
    c=3;
    d=4;
    e=5;
    z=1;

    x=1;
    for(i=0; i<n; i++)
    {
        x=x*2;
    }

    if(n==1)
    {
        switch(m)
        {
        case 1:
            {
                printf("\0");
                break;
            }
        case 2:
            {
                printf("%d", a);
                break;
            }
        }
    }
    if(n==2)
    {
        switch(m)
        {
        case 1:
            {
                printf("\0");
                break;
            }
        case 2:
            {
                printf("%d", a);
                break;
            }
        case 3:
            {
                printf("%d %d", a, b);
                break;
            }
        case 4:
            {
                printf("%d", b);
                break;
            }
        }
    }
    if(n==3)
    {
        switch(m)
        {
        case 1:
            {
                printf("\0");
                break;
            }
        case 2:
            {
                printf("%d", a);
                break;
            }
        case 3:
            {
                printf("%d %d", a, b);
                break;
            }
        case 4:
            {
                printf("%d %d %d", a, b, c);
                break;
            }
        case 5:
            {
                printf("%d %d", a, c);
                break;
            }
        case 6:
            {
                printf("%d", b);
                break;
            }
        case 7:
            {
                printf("%d %d", b, c);
                break;
            }
        case 8:
            {
                printf("%d", c);
                break;
            }
        }
    }
    if(n==4)
    {
        switch(m)
        {
        case 1:
            {
                printf("\0");
                break;
            }
        case 2:
            {
                printf("%d", a);
                break;
            }
        case 3:
            {
                printf("%d %d", a, b);
                break;
            }
        case 4:
            {
                printf("%d %d %d", a, b, c);
                break;
            }
        case 5:
            {
                printf("%d %d %d %d", a, b, c, d);
                break;
            }
        case 6:
            {
                printf("%d %d %d", a, b, d);
                break;
            }
        case 7:
            {
                printf("%d %d", a, c);
                break;
            }
        case 8:
            {
                printf("%d %d %d", a, c, d);
                break;
            }
        case 9:
            {
                printf("%d %d", a, d);
                break;
            }
        case 10:
            {
                printf("%d", b);
                break;
            }
        case 11:
            {
                printf("%d %d", b, c);
                break;
            }
        case 12:
            {
                printf("%d %d %d", b, c, d);
                break;
            }
        case 13:
            {
                printf("%d %d", b, d);
                break;
            }
        case 14:
            {
                printf("%d", c);
                break;
            }
        case 15:
            {
                printf("%d %d", c, d);
                break;
            }
        case 16:
            {
                printf("%d", d);
                break;
            }
        }
    }
    if(n==5)
    {
        switch(m)
        {
            case 1:
            {
                printf("\0");
                break;
            }
        case 2:
            {
                printf("%d", a);
                break;
            }
        case 3:
            {
                printf("%d %d", a, b);
                break;
            }
        case 4:
            {
                printf("%d %d %d", a, b, c);
                break;
            }
        case 5:
            {
                printf("%d %d %d %d", a, b, c, d);
                break;
            }
        case 6:
            {
                printf("%d %d %d %d %d", a, b, c, d, e);
                break;
            }
        case 7:
            {
                printf("%d %d %d %d", a, b, c, e);
                break;
            }
        case 8:
            {
                printf("%d %d %d", a, b, d);
                break;
            }
        case 9:
            {
                printf("%d %d %d %d", a, b, d, e);
                break;
            }
        case 10:
            {
                printf("%d %d %d", a, b, e);
                break;
            }
        case 11:
            {
                printf("%d %d", a, c);
                break;
            }
        case 12:
            {
                printf("%d %d %d", a, c, d);
                break;
            }
        case 13:
            {
                printf("%d %d %d %d", a, c, d, e);
                break;
            }
        case 14:
            {
                printf("%d %d", a, c, e);
                break;
            }
        case 15:
            {
                printf("%d %d", a, d);
                break;
            }
        case 16:
            {
                printf("%d %d %d", a, d, e);
                break;
            }
        case 17:
            {
                printf("%d %d", a, e);
                break;
            }
        case 18:
            {
                printf("%d", b);
                break;
            }
        case 19:
            {
                printf("%d %d", b, c);
                break;
            }
        case 20:
            {
                printf("%d %d %d", b, c, d);
                break;
            }
        case 21:
            {
                printf("%d %d %d %d", b, c, d, e);
                break;
            }
        case 22:
            {
                printf("%d %d %d", b, c, e);
                break;
            }
        case 23:
            {
                printf("%d %d", b, d);
                break;
            }
        case 24:
            {
                printf("%d %d %d", b, d, e);
                break;
            }
        case 25:
            {
                printf("%d %d", b, e);
                break;
            }
        case 26:
            {
                printf("%d", c);
                break;
            }
        case 27:
            {
                printf("%d %d", c, d);
                break;
            }
        case 28:
            {
                printf("%d %d %d", c, d, e);
                break;
            }
        case 29:
            {
                printf("%d %d", c, e);
                break;
            }
        case 30:
            {
                printf("%d", d);
                break;
            }
        case 31:
            {
                printf("%d %d", d, e);
                break;
            }
        case 32:
            {
                printf("%d", e);
                break;
            }
        }
    }
    if(n>5)
    {
        y=1;
        if(m==1)
        {
            printf("\0");
        }
        else if(m==2)
        {
            printf("1");
        }
        else
        {
            for(i=1; i<=n; i++)
            {
                y=y*2;
                if(m+y==x)
                {
                    printf("%d", n-i);
                    z=0;
                }
            }
            if(z==1)
            {
                for(i=0; i<n; i++)
                {
                    printf("%d ", i+1);
                }
            }
        }
    }
    return 0;
}
