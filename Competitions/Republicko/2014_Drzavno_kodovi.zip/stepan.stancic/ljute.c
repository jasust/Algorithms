#include <stdio.h>

int main()
{
    int n, k, rk, hb, i, c, d, e, s, poz, ind;
    int a=1;

    scanf("%d%d", &n, &k);

    int h[n];
    s=0;

    for(i=0; i<n; i++)
    {
        scanf("%d", &h[i]);
    }

    scanf("%d%d", &rk, &hb);

    if(n==1)
    {
        if(hb<k)
        {
            printf("%d %d", rk, hb);
        }
        else if(hb==k)
        {
            printf("%d %d", rk+1, a);
        }
        else
        {
            c=(hb/(k-1));
            d=c*(k-1);
            e=hb-d;
            printf("%d %d", c, e);
        }
    }
    else
    {
        if(hb<k)
        {
            printf("%d %d", rk, hb);
        }
        else if(hb==k)
        {
            for(i=rk; i<n; i++)
            {
                if(h[i]<k)
                {
                    ind=i;
                }
                else
                {
                    s=s+h[i]-k+1;
                }
            }
            poz=s/k+rk;
            hb=hb/k;
            printf("%d %d", poz, hb);
        }
        else
        {
            for(i=rk; i<n; i++)
            {
                if(h[i]<k)
                {
                    ind=i;
                }
                else
                {
                    s=s+h[i];
                }
            }
            poz=s/k+rk+ind+1;
            hb=hb%k;
            printf("%d %d", poz, hb);
        }
    }
    return 0;
}
