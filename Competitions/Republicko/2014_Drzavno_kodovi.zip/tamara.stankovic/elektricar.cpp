#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;


const int maxN = 300010;
const int maxC = 1000000001;

int n, m, d, c;
int odr[maxN], pb[maxN], pk[maxN];
int temp, indb, indk, br, mini, rast, mbr, mrast, uko, ukr, iz, p, s, k;

int main()
{
    scanf("%d%d%d%d", &n, &m, &d, &c);

    for (int i = 0; i < n; i++) {
        scanf("%d", &temp);
        odr[i] = temp;
    }

     for (int i = 0; i < n; i++) {
        scanf("%d", &temp);
        pb[i] = temp;
    }

     for (int i = 0; i < m; i++) {
        scanf("%d", &temp);
        pk[i] = temp;
    }

    indb = 0; indk = 0;
    mrast = 0;
    uko = 0; ukr = 0;
    int i;
    mbr = 0;
    while (indk < m) {
        if ((indb < (n-1)) && (pb[indb+1] < pk[indk])) uko = uko + odr[indb];
        while ((indb < (n-1)) && (pb[indb+1] < pk[indk])) indb++;

            mbr = 0; mini = maxC;
            i = indb + 1;
            while ((i < n) && ((pb[i] - pb[indb]) <= d)) {
                br = mbr;
                while ((indk < m) && (i < n) && (pk[indk] < pb[i]))  {indk++; br++;}
                mrast = pb[i] - pb[indb];
                if (br > mbr) {mini = mrast + odr[i]; rast = mrast; iz = i;}
                if ((mbr == br) && (mini > (mrast + odr[i]))) {mini = mrast + odr[i]; rast = mrast; iz = i;}
                i++;
                }
            uko = uko + odr[iz];
            ukr = ukr + rast;
            indb = iz ;

    }


    p = c - uko;
    s = p / ukr;

    printf("%d\n", s);

    return 0;
}
