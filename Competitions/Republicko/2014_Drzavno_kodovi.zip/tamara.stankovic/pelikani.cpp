#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <cstring>

using namespace std;

const int maxN = 1010;

int a[maxN][maxN];
int kolona[maxN] = {0};
int vrsta[maxN] = {0};
int n, Q, tip, x, y, smer, temp, p1, p2, citaj1, citaj2, t;
char s[maxN];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%s", s);
        for (int j = 0; j < n; j++) {
            a[i][j] = (int) s[j] - '0';
            vrsta[i] = vrsta[i] + a[i][j];
        }
    }

    for (int j = 0; j < n; j++) {
        for (int i = 0; i < n; i++) kolona[j] = kolona[j] + a[i][j];
    }

    scanf("%d", &Q);
    p1 = 0; p2 = 0;
    for (int q = 0; q < Q; q++) {
        scanf("%d", &tip);
        if (tip == 1) {
                scanf("%d", &smer);
                if ((smer == 1) || (smer == 3)) {
                    citaj1 = smer;
                    if (p1 == 0) {
                        if (smer == 1) {
                            p1 = 1;
                            for (int i = 0; i < n; i++) {
                                vrsta[i] = 0;
                                for (int j = 0; j < n; j++) {
                                    if (kolona[j] >= i+1) vrsta[i]++;
                                }
                            }
                        }
                        else {
                            p1 = 3;
                            for (int i = n-1; i >= 0; i--){
                                vrsta[i] = 0;
                                for (int j = 0; j < n; j++) {
                                    if (kolona[j] >= n-i) vrsta[i]++;
                                }
                            }
                        }
                    }
                    else {
                        if (smer != p1) {
                        for (int i = 0; i < (n/2 + 1); i++) {
                            t = vrsta[i];
                            vrsta[i] = vrsta[n-1 - i];
                            vrsta[n-1 - i] = t;
                        }
                        }
                    }

                }
                else {
                    citaj2 = smer;
                    if (p2 == 0) {
                        if (smer == 2) {
                            p2 = 2;
                            for (int i = 0; i < n; i++) {
                                kolona[i] = 0;
                                for (int j = 0; j < n; j++) {
                                    if (vrsta[j] >= i+1) kolona[i]++;
                                }
                            }
                        }
                        else {
                            p2 = 4;
                            for (int i = n-1; i>= 0; i--) {
                                kolona[i] = 0;
                                for (int j = 0; j < n; j++) {
                                    if (vrsta[j] >= n-i) kolona[i]++;
                                }
                            }
                        }
                    }
                    else {
                        if (smer != p2) {
                        for (int i = 0; i < (n/2 + 1); i++) {
                            t = kolona[i];
                            kolona[i] = kolona[n-1 - i];
                            kolona[n-1 - i] = t;
                        }
                        }
                    }
                }
        }
        else {
                scanf("%d%d", &x, &y);
                x = x -1; y = y -1;
                if ((p1 == 0) && (p2 == 0)) printf("%d\n", a[x][y]);
                else {
                    if (p2 == 0) {
                            if (citaj1 == 1) {
                                if (x < kolona[y]) printf("1\n");
                                else printf("0\n");
                            }
                            else if (x > n - 1 - kolona[y]) printf("1\n");
                                else printf("0\n");
                        }
                    else {
                        if (p1 == 0) {
                            if (citaj2 == 2) {
                                if (y  < vrsta[x]) printf("1\n");
                                else printf("0\n");
                            }
                            else if (y > n - 1 - vrsta[x]) printf("1\n");
                                else printf("0\n");
                        }
                        else {
                            if ((citaj1 == 1) && (citaj2 == 2)) {
                                if ((x < kolona[y]) && (y < vrsta[x])) printf("1\n");
                                    else printf("0\n");
                            }
                            else {
                                if ((citaj1 == 1) && (citaj2 != 2)) {
                                    if ((x < kolona[y]) && (y > n-1-vrsta[x])) printf("1\n");
                                        else printf("0\n");
                                }
                                else {
                                    if ((citaj1 != 1) && (citaj2 == 2)) {
                                        if ((x > n - 1 - kolona[y]) && (y < vrsta[x])) printf("1\n");
                                            else printf("0\n");
                                    }
                                    else {
                                        if ((x > n - 1 - kolona[y]) && (y > n-1-vrsta[x])) printf("1\n");
                                        else printf("0\n");
                                    }
                                }
                            }
                        }
                    }


                }
        }
    }


    return 0;
}
