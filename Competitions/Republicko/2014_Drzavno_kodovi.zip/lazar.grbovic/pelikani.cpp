#include<cstdio>
#include<cstring>
long i,n,j,pom,hor,ver,a[300100][3],x[1050],y[1050],gore[1050][1050],levo[1050][1050],gorelevo[1050][1050],b[1050][1050];
long q;
char p[1050];
int main() {
    scanf("%ld",&n);
    for (i=1;i<=n;i++) {
        x[i]=0;
        y[i]=0;
    }
    for (i=1;i<=n;i++) {
        scanf("%s",p);
        for (j=0;j<n;j++) {
            if (p[j]=='1') {
                b[i][j+1]=1;
                x[i]++;
                y[j+1]++;
            }
            else a[i][j+1]=0;
        }
    }
    scanf("%ld",&q);
    for (i=1;i<=q;i++) {
        scanf("%ld",&a[i][0]);
        scanf("%ld",&a[i][1]);
        if (a[i][0]==2) scanf("%ld",&a[i][2]);
    }
    for (i=1;i<=n;i++) for (j=1;j<=n;j++) {
        gore[i][j]=0;
        levo[i][j]=0;
        gorelevo[i][j]=0;
    }
    for (i=1;i<=n;i++) {
        for (j=1;j<=y[i];j++) gore[j][i]=1;
    }
    for (i=1;i<=n;i++) {
        for (j=1;j<=x[i];j++) levo[i][j]=1;
    }
    for (i=1;i<=n;i++) {
        pom=0;
        for (j=1;j<=n;j++) if (gore[i][j]==1) {
            pom++;
            gorelevo[i][pom]=1;
        }
    }
    hor=0;
    ver=0;
    for (i=1;i<=q;i++) {
        if (a[i][0]==1) {
            if (a[i][1]==1) ver=-1;
            else if (a[i][1]==2) hor=-1;
            else if (a[i][1]==3) ver=1;
            else hor=1;
        }
        else {
            if ((hor==-1) && (ver==-1)) {
                    if (gorelevo[a[i][1]][a[i][2]]==1) printf("1\n");
                    else printf("0\n");
            }
            if ((hor==-1) && (ver==1)) {
                    if (gorelevo[n-a[i][1]+1][a[i][2]]==1) printf("1\n");
                    else printf("0\n");
            }
            if ((hor==1) && (ver==-1)) {
                    if (gorelevo[a[i][1]][n-a[i][2]+1]==1) printf("1\n");
                    else printf("0\n");
            }
            if ((hor==1) && (ver==1)) {
                    if (gorelevo[n-a[i][1]+1][n-a[i][2]+1]==1) printf("1\n");
                    else printf("0\n");
            }
            if ((hor==0) && (ver==0)) {
                    if (b[a[i][1]][a[i][2]]==1) printf("1\n");
                    else printf("0\n");
            }
            if ((hor==-1) && (ver==0)) {
                    if (levo[a[i][1]][a[i][2]]==1) printf("1\n");
                    else printf("0\n");
            }
            if ((hor==1) && (ver==0)) {
                    if (levo[a[i][1]][n-a[i][2]+1]==1) printf("1\n");
                    else printf("0\n");
            }
            if ((hor==0) && (ver==-1)) {
                    if (gore[a[i][1]][a[i][2]]==1) printf("1\n");
                    else printf("0\n");
            }
            if ((hor==0) && (ver==1)) {
                    if (gore[n-a[i][1]+1][a[i][2]]==1) printf("1\n");
                    else printf("0\n");
            }
        }
    }
    return 0;

}
