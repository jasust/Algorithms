#include<cstdio>
#include<math.h>
long najbliza,trsuma,brojac,i,konacno,j,s,n,pom,b[10100],a[100000];
long zad(long i,long trsuma, long najbliza) {
long brojac,j,resenje1,resenje2;
brojac=a[b[i]+1];
for (j=1;j<=brojac;j++) {
    resenje1=zad(a[b[i]+1+j],trsuma,najbliza);
    if (fabs(trsuma+a[b[a[b[i]+1+j]]]-s)<fabs(s-najbliza)) najbliza=trsuma+a[b[a[b[i]+1+j]]];
    if (trsuma+a[b[a[b[i]+1+j]]]<s) resenje2=zad(a[b[i]+1+j],trsuma+a[b[a[b[i]+1+j]]],najbliza);
    if (fabs(resenje1-s)<fabs(najbliza-s)) najbliza=resenje1;
    if (fabs(resenje2-s)<fabs(najbliza-s)) najbliza=resenje2;
}
    return najbliza;
}


int main() {
scanf("%ld %ld",&n,&s);
brojac=0;
for (i=1;i<=n;i++) {
    brojac++;
    b[i]=brojac;
    scanf("%ld",&a[brojac]);
    brojac++;
    pom=brojac;
    scanf("%ld",&a[brojac]);
    for (j=1;j<=a[pom];j++) {
        brojac++;
        scanf("%ld",&a[brojac]);
    }
}
trsuma=0;
najbliza=0;
konacno=zad(1,trsuma,najbliza);
printf("%ld",konacno);
return 0;
}
