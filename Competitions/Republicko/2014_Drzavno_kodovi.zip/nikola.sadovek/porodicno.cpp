#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
using namespace std;
int **a,n,s,x,y,maximum=0;
short q=0;
vector<int> v;

void f(int index)
{
     if(q) return;
     int i;
     y=v.size();
     if(a[index][0]==0) return;
     v.push_back(a[index][0]);
     for(i=0;i<v.size();i++) 
     {
                       x=v[i]+a[index][0];
                       if(x>s) continue;
                       if(x==s){ q=1; break;}
                       if(maximum<x) maximum=x;
                       if(v[i])
                       v.push_back(x);
     }
     if(q) return;
     x=v.size();
     for(i=0;i<a[index][1];i++) {f(a[index][2+i]); if(q) return;}
     for(i=x;i>y;i--) v.pop_back();
}

int main()
{
    int i,j;
    scanf("%d%d",&n,&s);
    a=(int**)malloc(n*sizeof(int**));
    for(i=0;i<n;i++)
    {
                    scanf("%d%d",&x,&y);
                    if(x>s) x=0;
                    if(x==s) {q=1; break;}
                    a[i]=(int*)malloc((y+2)*sizeof(int*));
                    a[i][0]=x;
                    a[i][1]=y;
                    for(j=0;j<y;j++) {scanf("%d",&x); a[i][j+2]=x;}
    }
    if(q) printf("%d",s);
    else{
    v.push_back(a[0][0]);
    if(n==1) printf("%d",a[0][0]);
    else{
    for(i=0;i<a[0][1];i++)
    {
                          f(a[0][i+2]);
                          if(q) break;
    }
    if(q) printf("%d",s);
    else printf("%d",maximum);
    }
    }
    getchar();
    getchar();
}
