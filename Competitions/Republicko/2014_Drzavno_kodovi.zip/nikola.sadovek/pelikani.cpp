#include <stdio.h>
#include <algorithm>
using namespace std;
short w=0;
int n,q,vert[1000]={0},hor[1000]={0};
char lake[1000][1000];
int main()
{
    short f;
    int i,k,j,s,t;
    scanf("%d",&n);
    for(i=0;i<n;i++) scanf("%s",lake[i]);
    for(i=0;i<n;i++) for(j=0;j<n;j++) {vert[j]+=(lake[i][j]-'0'); hor[i]+=(lake[i][j]-'0');}
    scanf("%d",&q);
    for(k=0;k<q;k++)
    {
                    scanf("%d%d",&f,&s);
                    if(f==2)
                    {
                            scanf("%d",&t);
                            if(!w)
                            {
                                  printf("%c\n",lake[s-1][t-1]);
                            }
                            else
                            {
                                   if(w==1)
                                   {
                                           if(vert[t-1]>=s) printf("1\n");
                                           else printf("0\n");
                                   }
                                   if(w==2)
                                   {
                                           if(hor[s-1]>=t) printf("1\n");
                                           else printf("0\n");
                                   }
                                   if(w==3)
                                   {
                                           if(n-vert[t-1]<=s-1) printf("1\n");
                                           else printf("0\n");
                                   }
                                   if(w==4)
                                   {
                                           if(n-hor[s-1]<=t-1) printf("1\n");
                                           else printf("0\n");
                                   }
                            }
                    }
                    else
                    { 
                                   w=s;
                                   if(w==1)
                                   {
                                           for(i=0;i<n;i++) hor[i]=0;
                                           for(i=0;i<n;i++) for(j=0;j<vert[i];j++) hor[j]=hor[j]+1;
                                   }
                                   if(w==2)
                                   {
                                           for(i=0;i<n;i++) vert[i]=0;
                                           for(i=0;i<n;i++) for(j=0;j<hor[i];j++) vert[j]=vert[j]+1;
                                   }
                                   if(w==3)
                                   {
                                           for(i=0;i<n;i++) hor[i]=0;
                                           for(i=0;i<n;i++) for(j=0;j<vert[i];j++) hor[n-1-j]=hor[n-1-j]+1;
                                   }
                                   if(w==4)
                                   {
                                           for(i=0;i<n;i++) vert[i]=0;
                                           for(i=0;i<n;i++) for(j=0;j<hor[i];j++) vert[n-1-j]=vert[n-1-j]+1;
                                   }
                    }
                    
    }
    return 0;
}
