#include <stdio.h>
using namespace std;
int main()
{
    printf("7");
    return 0;
}
