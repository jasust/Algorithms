#include <cstdio>

using namespace std;

int main()
{
long long n,m;
scanf("%lld%lld",&n,&m);
long long stepen=1,t=1,nn=n;
while(m>0)
{
    if(t>n)break;
    m-=1;//Sklanjamo prazan skup
    if(m==0)break;
    stepen=(long long)1<<(nn-t);//stepen
    int id=0;
    while(m>stepen)//Prelazimo one koji sigurno nisu da bi dosli do onog koji jeste
    {
        id++;
        m-=stepen;
        stepen/=2;
    }
    printf("%d ",t+id);//t je prethodni i on mora biti veci
t=t+id+1;//postavljamo minimalni sledeci

}
printf("\n");
return 0;
}
