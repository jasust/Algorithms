#include <cstdio>
#include <fstream>
#include <algorithm>
#define MINF -999999999999999
using namespace std;
int a[1000005],size1[1000005],size2[1000005];
long long maxs1[1000005],maxs2[1000005];
int main()
{
int n,tmp;
//freopen("in.txt","r",stdin);
scanf("%d",&n);
for(int i=0;i<n;i++)scanf("%d",&a[i]);
for(int i=0;i<n;i++)
{
    scanf("%d",&tmp);
    a[i]-=tmp;
}
int s1=0,s2=0,ms1=0,ms2=0;
long long sum=0,summax=0,maxel=MINF,poz=0;
for(int i=0;i<n;i++)
{
    if(a[i]>maxel)maxel=a[i];
    if(a[i]>=0)poz++;
    sum+=a[i];
    s1++;
    if(sum<0)
    {sum=0;s1=0;}
    if(sum>summax)
    {
        ms1=s1;
        summax=sum;
    }
    size1[i]=ms1;
    if(poz==0)
    {
    maxs1[i]=maxel;
    size1[i]=0;
    }
    else
    maxs1[i]=summax;
}
sum=0;
maxel=MINF;
summax=0;
poz=0;
for(int i=n-1;i>=0;i--)
{
    if(a[i]>maxel)maxel=a[i];
    if(a[i]>=0)poz++;
    sum+=a[i];
    s2++;
    if(sum<0) {sum=0;s2=0;}
    if(sum>summax)
    {
        ms2=s2;
        summax=sum;
    }
    size2[i]=ms2;
    if(poz==0)
    {
    maxs2[i]=maxel;
    size1[i]=0;
    }
    else
    maxs2[i]=summax;
}
long long sol=MINF;
long long iz=0;
for(int i=1;i<n;i++)
{
    //printf("%I64d %I64d\n",maxs1[i-1],maxs2[i]);
    iz=maxs1[i-1]+maxs2[i];
    if(size1[i-1]>1)
    {
        if(maxs1[i-1]>iz)iz=maxs1[i-1];
    }
       if(size2[i]>1)
    {
        if(maxs2[i]>iz)iz=maxs2[i];
    }
    if(iz>sol)
    {
        sol=iz;
    }
}
    printf("%lld\n",sol);

    return 0;
}
