#include <cstdio>
using namespace std;
int a[1000005];//OK
int main()
{
int n,k;
scanf("%d%d",&n,&k);
for(int i=0;i<n;i++)
{
    scanf("%d",&a[i]);
}
long long rk,hb;
scanf("%lld%lld",&rk,&hb);
if(hb<k)//osnovni slucaj nece se pomeriti ukoliko se ispaljuje iznad.
{
    printf("%lld %lld\n",rk,hb);
    return 0;
}
//long long jer moze spici sve 10^9 a cepa u 2
long long ispod=0;
long long iznad=0;
for(int i=0;i<n;i++)
{

   if(i+1<rk)
   {
       iznad+=(a[i]-k>0?a[i]-k:0);
   }
   if(i+1==rk)
   {
       iznad+=(a[i]-hb);
       ispod+=(hb-(k-1)-1);
   }
   if(i+1>rk)
   {
       if(a[i]>=k-1)
       {
          ispod+=(a[i]-(k-1));
       }
       else
       {
           if(ispod<(k-1)-a[i])
           {

               printf("%d %d\n",i+1,a[i]+ispod+1);
               return 0;
           }
           else
           {
                          ispod-=(k-1)-a[i];
           }
       }
   }
}
hb=(ispod+1)%(k-1);
long long ispis=n;
if((ispod+1)%(k-1)!=0)
{
    ispis++;
}
else
{
    hb=k-1;
}


ispis+=(ispod+1)/(k-1);

    printf("%lld %lld\n",ispis,hb);


    return 0;
}

