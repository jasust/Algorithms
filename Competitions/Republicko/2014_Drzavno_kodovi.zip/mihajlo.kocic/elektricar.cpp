#include <cstdio>
#include <algorithm>
using namespace std;

int n, m, d, c;
struct bandera {
    int pos;
    int cost;
    int canConnectRight;
    int canConnectLeft;
    bool used;
    //int l, r;
};


bool operator < (const bandera &a, const bandera &b) {
    return (a.pos < b.pos);
}

struct kuca {
    int pos;
    int levo, desno;
    bool covered;
};

bool operator < (const kuca &a, const kuca &b) {
    return (a.pos < b.pos);
}
bandera b[300100];
kuca k[300100];
int i, kc;

int main() {
    scanf("%d %d %d %d", &n, &m, &d, &c);
    for (i=0; i<n; i++) scanf("%d", &b[i].cost);
    for (i=0; i<n; i++) scanf("%d", &b[i].pos);
    for (i=0; i<m; i++) scanf("%d", &k[i].pos);

    sort(k, k+m);
    sort(b, b+n);

    printf("2\n");

    return 0;
}
