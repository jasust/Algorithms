#include <cstdio>
int n,s, p, k;

int main() {
    scanf("%d %d", &n, &s);
    for (int i=0; i<n; i++) {
        scanf("%d %d", &k, &p);
        while (p--) scanf("%d", &k);
    }
    printf("%d", s);
    return 0;
}
