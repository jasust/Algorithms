#include <cstdio>
#include <cstring>
//#define DEBUG

char field[1010][1010];
int n, i, j, q;
int rows[1010];
int cols[1010];
int initialRows[1010];
int initialCols[1010];
int com1, com2;
bool top = false;
bool left = false;
int v;
int lastmove;
bool pelicansMoved = false;
bool pelicansMovedHor = false;
bool pelicansMovedVer = false;

int main() {
    scanf("%d\n", &n);
    for (i=0; i<n; i++)
        scanf("%s", field[i]);
    scanf("%d", &q);

    //for (i=0; i<n; i++) printf("%s\n", field[i]);
    //int t = clock();

    for (i=0; i<n; i++)
        for (j=0; j<n; j++)
            if (field[i][j] == '1') {
                rows[i]++;
                cols[j]++;
            }
    for (i=0; i<n; i++) {
        initialRows[i] = rows[i];
        initialCols[i] = cols[i];
    }

    //printf("%d\n", clock() - t);
    //t = clock();

    lastmove = 0;
    while (q--) {
        scanf("%d", &com1);
        if (com1 == 1) {
            pelicansMoved = true;
            scanf("%d", &com2);
            if (com2 == 1) {                                //SEVER - update rows
                top = true;                                 //set top to true
                //printf("TEST");
                //memset(rows, n*4, 0);
                if (pelicansMovedVer == false) {
                    for (i=0; i<n; i++) rows[i] = 0;
                    for (i=0; i<n; i++) {
                        v = cols[i];
                        if (v>0) rows[v-1] ++ ;
                    }
                    int k = 0;

                    for (i=n-1; i>=0; i--) {
                        k+= rows[i];
                        rows[i] = k;
                    }

                    #ifdef DEBUG
                        for (i=0; i<n; i++) printf("%d %d\n", rows[i], cols[i]);
                        printf("-----\n");
                    #endif

                    pelicansMovedVer = true;
                }
            }
            else if (com2 == 3) {
                top = false;                                //set top to false - bot is true

                if (pelicansMovedVer == false) {
                    for (i=0; i<n; i++) rows[i] = 0;
                    for (i=0; i<n; i++) {
                        v = cols[i];
                        if (v>0) rows[v-1] ++ ;
                    }
                    int k = 0;

                    for (i=n-1; i>=0; i--) {
                        k+= rows[i];
                        rows[i] = k;
                    }

                    #ifdef DEBUG
                        for (i=0; i<n; i++) printf("%d %d\n", rows[i], cols[i]);
                        printf("-----\n");
                    #endif

                    pelicansMovedVer = true;
                }
            }
            else if (com2 == 2) {
                left = true;                                //set left to true

                if (pelicansMovedHor == false) {
                    for (i=0; i<n; i++) cols[i] = 0;

                    for (i=0; i<n; i++) {
                        v = rows[i];
                        if (v>0) cols[v-1] ++ ;
                    }
                    int k = 0;

                    for (i=n-1; i>=0; i--) {
                        k+= cols[i];
                        cols[i] = k;
                    }

                    #ifdef DEBUG
                        for (i=0; i<n; i++) printf("%d %d\n", rows[i], cols[i]);
                        printf("-----\n");
                    #endif

                    pelicansMovedHor = true;
                }
            }
            else if (com2 == 4) {
                left = false;                                //set left to false - right is true

                if (pelicansMovedHor == false) {
                    for (i=0; i<n; i++) cols[i] = 0;
                    for (i=0; i<n; i++) {
                        v = rows[i];
                        if (v>0) cols[v-1] ++ ;
                    }
                    int k = 0;

                    for (i=n-1; i>=0; i--) {
                        k+= cols[i];
                        cols[i] = k;
                    }

                    #ifdef DEBUG
                        for (i=0; i<n; i++) printf("%d %d\n", rows[i], cols[i]);
                        printf("-----\n");
                    #endif

                    pelicansMovedHor = true;
                }
            }
        }       // if com1 == 1
        else {  //com1==2
            scanf("%d %d", &com1, &com2);
            com1--;
            com2--;
            if (!pelicansMoved) printf("%c\n", field[com1][com2]);
            else {
                //printf("%d %d\n", top, left);
                if (pelicansMovedHor && pelicansMovedVer) {
                    if (top) {
                        if (left) {
                            //topLeft
                            printf("%d\n", rows[com1] > com2 && cols[com2] > com1);
                        } else {
                            //topRight
                            printf("%d\n", rows[com1] > n-com2-1 && cols[n-com2-1] > com1);
                        }
                    } else {
                        if (left) {
                            //bottomLeft
                            printf("%d\n", rows[n-com1-1] > com2 && cols[com2] > n-com1-1);
                        }
                        else {
                            //bottomRight
                            printf("%d\n", rows[n-com1-1] > n-com2-1 && cols[n-com2-1] > n-com1-1);
                        }
                    }
                } else
                if (pelicansMovedHor) {
                    //moved horizontally but not vertically
                    if (left) {
                        printf("%d\n", initialRows[com1] > com2 && cols[com2] > 0);
                    } else {
                        printf("%d\n", initialRows[com1] > n-com2-1 && cols[n-com2-1] > 0);
                    }
                } else
                if (pelicansMovedVer) {
                    //moved only vertically
                    if (top) {
                        printf("%d\n", rows[com1] > 0 && initialCols[com2] > com1);
                    } else {
                        printf("%d\n", rows[n-com1-1] > 0 && initialCols[com2] > n-com1-1);
                    }
                }
            }

        }
    }

    #ifdef DEBUG
        for (i=0; i<n; i++) printf("%d %d\n", rows[i], cols[i]);
    #endif

    //printf("%d", clock() - t);

    return 0;
}
