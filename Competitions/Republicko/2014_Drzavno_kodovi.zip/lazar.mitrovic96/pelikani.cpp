#include <iostream>
#include <algorithm>
using namespace std;
long long px[1000001];
long long py[1000001];
long long prazan[1000001];
long long brojpelikana,q = 0;
string pom;
long long n;

bool sortpox (long long a,long long b)
{
    if (px[a]<px[b]) {swap(px[a],px[b]); swap(py[a],py[b]);}
    return false;
}
bool sortpoy (long long a,long long b)
{
    if (py[a]<py[b]) {swap(px[a],px[b]); swap(py[a],py[b]); }
    return false;
}

void dodajpelikane(long long j,string pom)
{
    for (long long i = 0; i<n; i++)
    {
        if (pom[i]=='1') {py[brojpelikana]=i+1; px[brojpelikana]=j; prazan[brojpelikana]=brojpelikana; brojpelikana++;}
    }
}

long long prebrojstarije (long long pocetniindeks, long long smer, bool red)
{
    long long brojacstarijih=1;
    long long i = pocetniindeks+smer;
    if (red) while (px[i]==px[pocetniindeks] && i>=0 && i<brojpelikana) {brojacstarijih++; i+=smer;}
    else while (py[i]==py[pocetniindeks] && i>=0 && i<brojpelikana) {brojacstarijih++; i+=smer;}
    return brojacstarijih;
}
void gravitacija (long long direkcija)
{
    /*if (direkcija==1 || direkcija==3)
    {
    sort(prazan,prazan+brojpelikana,sortpoy);
    }
    else sort(prazan,prazan+brojpelikana,sortpox);*/
    for (long long i = 0; i<brojpelikana; i++)
    {
        if (direkcija==1) {sort(prazan,prazan+brojpelikana,sortpoy); px[i] = prebrojstarije(i,-1,false);}
        if (direkcija==2) {sort(prazan,prazan+brojpelikana,sortpox); py[i] = prebrojstarije(i,-1,true); }
        if (direkcija==3) {sort(prazan,prazan+brojpelikana,sortpoy); px[i] = n+1-prebrojstarije(i,+1,false);}
        if (direkcija==4) {sort(prazan,prazan+brojpelikana,sortpox); py[i] = n+1-prebrojstarije(i,+1,true); }
    }
}
long long proveripolje (long long a,long long b)
{
    for (long long i = 0; i<brojpelikana; i++)
    {
        if(px[i]==a && py[i]==b) return 1;
    }
    return 0;
}
void pisipelikane()
{
for (long long i = 0; i<brojpelikana; i++)
    {
        cout<<prazan [i]<<". "<<px[i]<<" "<<py[i]<<endl;
    }
}
int main()
{
    cin>>n;
    for (long long i = 1; i<=n;i++) {cin>>pom; dodajpelikane(i,pom);}
    cin>>q;
    long long arg1,arg2,arg3;
    for (long long i = 0; i<q; i++) {
    /*  cout<<"/////////////////////"<<endl;
        pisipelikane();
        cout<<endl;*/
        cin>>arg1>>arg2; if (arg1==1) {gravitacija(arg2); gravitacija(arg2);} else {cin>>arg3; cout<<proveripolje(arg2,arg3)<<endl;}


         }
    return 0;
}
