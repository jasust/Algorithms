#include <iostream>

using namespace std;


int main()
{   int n,s,pom,broj;
    cin>>n>>s;
    for (int i = 0; i<n; i++)
    {
        cin>>pom;
        cin>>broj;
            for (int j=0;j<broj;j++) cin>>pom;
    }
    cout<<s;
    return 0;
}
