#include <iostream>
#include <algorithm>

using namespace std;

long long n,m,d,c;
int main()
{
    cin>>n>>m>>d>>c;
    int a[n];
    for (int i = 0; i<n; i++) cin>>a[i];
    for (int i = 0; i<n; i++) cin>>a[i];
    for (int i = 0; i<m; i++) cin>>a[i];
    cout<<c/d;
    return 0;
}
