#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

char a[1006][1006], p[4][1006][1006], pp[4][1006][1006];
int n, q, i, j, k, k2, u, x, y, trHor, trVer, matNum;
bool t[6];

int main() {
    scanf("%d", &n);
    for (i = 1; i <= n; ++i) {
        scanf("%s", a[i] + 1);
    }
    scanf("%d", &q);
    for (i = 0; i < q; ++i) {
        scanf("%d", &u);
        if (u == 1) {
            scanf("%d", &x);
            if (!t[x]) {
                if (x == 1) {
                    for (k = 2; k <= n; ++k) {
                        for (j = 1; j <= n; ++j) {
                            if (a[k][j] == '1') {
                                k2 = 1;
                                while (a[k - k2][j] == '0' && k - k2 >= 1) {
                                    a[k - k2][j] = '1';
                                    a[k - k2 + 1][j] = '0';
                                    ++k2;
                                }
                            }
                        }
                    }
                } else if (x == 3) {
                    for (k = n - 1; k >= 1; --k) {
                        for (j = 1; j <= n; ++j) {
                            if (a[k][j] == '1') {
                                k2 = 1;
                                while (a[k + k2][j] == '0' && k + k2 <= n) {
                                    a[k + k2][j] = '1';
                                    a[k + k2 - 1][j] = '0';
                                    ++k2;
                                }
                            }
                        }
                    }
                } else if (x == 2) {
                    for (j = 2; j <= n; ++j) {
                        for (k = 1; k <= n; ++k) {
                            if (a[k][j] == '1') {
                                k2 = 1;
                                while (a[k][j - k2] == '0' && j - k2 >= 1) {
                                    a[k][j - k2] = '1';
                                    a[k][j - k2 + 1] = '0';
                                    ++k2;
                                }
                            }
                        }
                    }
                } else {
                    for (j = n - 1; j >= 1; --j) {
                        for (k = 1; k <= n; ++k) {
                            if (a[k][j] == '1') {
                                k2 = 1;
                                while (a[k][j + k2] == '0' && j + k2 <= n) {
                                    a[k][j + k2] = '1';
                                    a[k][j + k2 - 1] = '0';
                                    ++k2;
                                }
                            }
                        }
                    }
                }
                t[x] = 1;
                if (x == 1 || x == 3) {
                    if (t[2] || t[4]) {
                        if (x == 1 && trHor == 2 && !p[1][1][1]) {
                            for (k = 1; k <= n; ++k) {
                                strcpy(p[1][k] + 1, a[k] + 1);
                            }
                        } else if (x == 1 && trHor == 4 && !p[2][1][1]) {
                            for (k = 1; k <= n; ++k) {
                                strcpy(p[2][k] + 1, a[k] + 1);
                            }
                        } else if (x == 3 && trHor == 2 && !p[3][1][1]) {
                            for (k = 1; k <= n; ++k) {
                                strcpy(p[3][k] + 1, a[k] + 1);
                            }
                        } else if (x == 3 && trHor == 4 && !p[4][1][1]) {
                            for (k = 1; k <= n; ++k) {
                                strcpy(p[4][k] + 1, a[k] + 1);
                            }
                        }
                    } else {
                        for (k = 1; k <= n; ++k) {
                            strcpy(pp[x][k] + 1, a[k] + 1);
                        }
                    }
                } else {
                    if (t[1] || t[3]) {
                        if (x == 2 && trVer == 1 && !p[1][1][1]) {
                            for (k = 1; k <= n; ++k) {
                                strcpy(p[1][k] + 1, a[k] + 1);
                            }
                        } else if (x == 2 && trVer == 3 && !p[3][1][1]) {
                            for (k = 1; k <= n; ++k) {
                                strcpy(p[3][k] + 1, a[k] + 1);
                            }
                        } else if (x == 4 && trVer == 1 && !p[2][1][1]) {
                            for (k = 1; k <= n; ++k) {
                                strcpy(p[2][k] + 1, a[k] + 1);
                            }
                        } else if (x == 4 && trVer == 3 && !p[4][1][1]) {
                            for (k = 1; k <= n; ++k) {
                                strcpy(p[4][k] + 1, a[k] + 1);
                            }
                        }
                    } else {
                        for (k = 1; k <= n; ++k) {
                            strcpy(pp[x][k] + 1, a[k] + 1);
                        }
                    }
                }
            } else {
                // Nista?
            }
            if (x == 1 || x == 3) {
                trVer = x;
            } else {
                trHor = x;
            }
        } else {
            scanf("%d%d", &x, &y);
            if (trVer == 1 && trHor == 2) {
                printf("%s\n", (p[1][x][y] == '1') ? "1" : "0");
            } else if (trVer == 1 && trHor == 4) {
                printf("%s\n", (p[2][x][y] == '1') ? "1" : "0");
            } else if (trVer == 3 && trHor == 2) {
                printf("%s\n", (p[3][x][y] == '1') ? "1" : "0");
            } else if (trVer == 3 && trHor == 4) {
                printf("%s\n", (p[4][x][y] == '1') ? "1" : "0");
            } else if (!trVer && trHor == 2) {
                printf("%s\n", (pp[2][x][y] == '1') ? "1" : "0");
            } else if (!trVer && trHor == 4) {
                printf("%s\n", (pp[4][x][y] == '1') ? "1" : "0");
            } else if (trVer == 1 && !trHor) {
                printf("%s\n", (pp[1][x][y] == '1') ? "1" : "0");
            } else if (trVer == 3 && !trHor) {
                printf("%s\n", (pp[3][x][y] == '1') ? "1" : "0");
            } else {
                printf("%s\n", (a[x][y] == '1') ? "1" : "0");
            }
        }
    }
    return 0;
}
