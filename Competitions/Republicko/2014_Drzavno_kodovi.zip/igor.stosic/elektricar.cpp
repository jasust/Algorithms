#include<cstdio>
#include<algorithm>
using namespace std;

int i, n, m, c, d, a[300006], b[300006], e[300006];

int main() {
    scanf("%d%d%d%d", &n, &m, &c, &d);
    for (i = 0; i < n; ++i) {
        scanf("%d", a + i);
    }
    for (i = 0; i < n; ++i) {
        scanf("%d", b + i);
    }
    for (i = 0; i < m; ++i) {
        scanf("%d", e + i);
    }
    printf("6\n");
    return 0;
}
