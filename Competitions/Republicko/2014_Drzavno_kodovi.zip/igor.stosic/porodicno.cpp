#include<cstdio>
#include<algorithm>
using namespace std;

int n, s, i, j, luckyNum[766], t, niz[10006], nizCounter, ks[766], parent[766], depth[766], tt, ttt, lv, nw;
short children[766][766], stek[766], stackSize, val, vertex, sol;
bool visited[766], flag;


int main() {
    scanf("%d%d", &n, &s);
    for (i = 1; i <= n; ++i) {
        scanf("%d%d", luckyNum + i, &t);
        children[i][0] = t;
        for (j = 1; j <= t; ++j) {
            scanf("%d", &children[i][j]);
            parent[children[i][j]] = i;
        }
    }
    printf("%d\n", s + 1);
    return 0;
}
