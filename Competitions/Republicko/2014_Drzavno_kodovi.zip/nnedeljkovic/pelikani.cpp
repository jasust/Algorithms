#include<iostream>
#include<stdio.h>


using namespace std;
//kada imam 1 4 sortiram broj jedinica po kolonama od N-te ka prvoj po redovima ostaje isti
//kada imam 1 2 sortiram broj jedinica po kolonama od prve ka N-toj po redovima ostaje isti
//kada imam 1 3 sortiram broj jedinica po redovima od N-tog ka prvom a po kolonama ostaje isti
//kada imam 1 1 sortiram broj jedinica po redovima od prvog ka N-tom a po kolonama ostaje isti
char B[1005][1005];
bool A[1005][1005];
int statehor=0,statever=0,state,Q,quest,statehorfixed,stateverfixed;
int N;
static int br1k[1005];
static int br1v[1005];
void Pisimat()
{
for (int i=0;i<N;i++)
{
for (int j=0;j<N;j++)
cout<<A[i][j];
cout<<endl;
}
}



void Movehor()
{
int i,j;
if (state==4) 
{
for (i=N-1;i>=0;i--)
for (j=N-1;j>=0;j--)
if (N-1-j<br1v[i]) A[i][j]=1;
else A[i][j]=0;
for (i=0;i<N;i++)
br1k[i]=0;
for (i=0;i<N;i++)
for (j=0;j<N;j++)
if (A[i][j]==1) br1k[j]++;
}
if (state==2)
{
for (i=0;i<N;i++)
for (j=0;j<N;j++)
if (j<br1v[i]) A[i][j]=1;
else A[i][j]=0;
for (i=0;i<N;i++)
br1k[i]=0;
for (i=0;i<N;i++)
for (j=0;j<N;j++)
if (A[i][j]==1) br1k[j]++;
}
}


void Movever()
{
int i,j;
if (state==1)
{
for(j=0;j<N;j++)
for(i=0;i<N;i++)
if (i<br1k[j]) A[i][j]=1;
else A[i][j]=0;
for (i=0;i<N;i++)
br1v[i]=0;
for (i=0;i<N;i++)
for (j=0;j<N;j++)
if (A[i][j]==1) br1v[i]++;
}
if (state==3)
{
for (j=0;j<N;j++)
for (i=N-1;i>=0;i--)
if (N-1-i<br1k[j]) A[i][j]=1;
else A[i][j]=0;
for (i=0;i<N;i++)
br1v[i]=0;
for (i=0;i<N;i++)
for (j=0;j<N;j++)
if (A[i][j]==1) br1v[i]++;
}
}



int main()
{
int i,j,x,y;
cin>>N;
for (i=0;i<N;i++)
scanf("%s",B[i]);
cin>>Q;
for (i=0;i<N;i++)
for (j=0;j<N;j++)
if (B[i][j]-'0'==1) {br1k[j]++;br1v[i]++;}
for (i=0;i<N;i++)
for (j=0;j<N;j++)
if (B[i][j]-'0'==1) A[i][j]=1;
else A[i][j]=0;

//sad radim sa matricom A


for (i=0;i<Q;i++)
{
scanf("%d",&quest);
if (quest==1)
{
scanf("%d",&state);

if ((state==2||state==4)&&statehor==0) {Movehor();statehor=state;statehorfixed=state;}
if ((state==2||state==4)&&statehor!=0) statehor=state;

if ((state==1||state==3)&&statever==0) {Movever();statever=state;stateverfixed=state;}
if ((state==1||state==3)&&statever!=0) statever=state;
}
if (quest==2)
{
scanf("%d%d",&x,&y);
x--;y--;
if (statehor==0&&statever==0) printf("%d\n",A[x][y]);
if (statever==0)
{
if (statehor!=0)
if (statehor==statehorfixed) printf("%d\n",A[x][y]); 
else
printf("%d\n",A[x][N-1-y]); 
}                  
if (statehor==0)
{
if (statever!=0)
if (statever==stateverfixed) printf("%d\n",A[x][y]);
else
printf("%d\n",A[N-1-x][y]);
}
if (statever!=0&&statehor!=0)
{
if (statever==stateverfixed&&statehor==statehorfixed)
printf("%d\n",A[x][y]); 
if (statever==stateverfixed&&statehor!=statehorfixed)
printf("%d\n",A[x][N-1-y]);
if (statever!=stateverfixed&&statehor==statehorfixed)
printf("%d\n",A[N-1-x][y]);
if (statever!=stateverfixed&&statehor!=statehorfixed)
printf("%d\n",A[N-1-x][N-1-y]);
}             
}      
      
}

return 0;
}      
