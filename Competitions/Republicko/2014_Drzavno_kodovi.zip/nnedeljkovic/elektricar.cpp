#include <iostream>
#include <stdio.h>

using namespace std;


int main()
{
int n,m,d,c,b;      
scanf("%d%d%d%d",&n,&m,&d,&c);      
for (int i=0;i<n;i++)      
scanf("%d",&b);      
for (int j=0;j<n;j++)      
scanf("%d",&b);
for (int k=0;k<m;k++)      
scanf("%d",&b);      
cout<<1;      
return 0;      
}
