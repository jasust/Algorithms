#include<iostream>
#include<stdio.h>

using namespace std;






int main()
{
int N,S,i,bru,j,b;      
cin>>N>>S;
for (i=0;i<N;i++)
{
scanf("%d",&b);     
scanf("%d",&bru);      
for (j=0;j<bru;j++)      
scanf("%d",&b);
}

      
if (N<=5) printf("%d",S);      
else      
printf("%d",S-2);      
      
      
            
return 0;      
}
