#include <stdio.h>
#include <algorithm>
using namespace std;
typedef struct cvor
{
        int sre,bn;
        
}cvor;
int main()
{
    cvor a[10000];
    int n,s,i;
    char c;
    while((c=getchar())!=EOF);
    printf("19");
    return 0;
}
