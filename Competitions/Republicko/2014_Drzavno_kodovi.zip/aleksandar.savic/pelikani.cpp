#include <stdio.h>
int kol[1000],vrs[1000];
char a[1000][1000];
void f(int str,int n)
{
         for(int i=1;i<=n;i++)
         for(int j=1;j<=n;j++)
         a[i][j]='0';
      if(str==1)
      {
                for(int j=1;j<=n;j++)
                for(int w=1;w<=kol[j];w++)
                a[w][j]='1';
                for(int i=1;i<=n;i++)
                vrs[i]=0;
                for(int i=1;i<=n;i++)
                for(int j=1;j<=n;j++)
                if(a[i][j]=='1')vrs[i]++;
                }
      else if(str==3)
      {
                for(int j=1;j<=n;j++)
                for(int w=n;w>n-kol[j];w--)
                a[w][j]='1';
                for(int i=1;i<=n;i++)
                vrs[i]=0;
                for(int i=1;i<=n;i++)
                for(int j=1;j<=n;j++)
                if(a[i][j]=='1')vrs[i]++;
                }
      else if(str==2)
      {
                for(int i=1;i<=n;i++)
                for(int w=1;w<=vrs[i];w++)
                a[i][w]='1';
                for(int i=1;i<=n;i++)
                kol[i]=0;
                for(int i=1;i<=n;i++)
                for(int j=1;j<=n;j++)
                if(a[i][j]=='1')kol[j]++;
      }
      else if(str==4)
      {
                for(int i=1;i<=n;i++)
                for(int w=n;w>n-vrs[i];w--)
                a[i][w]='1';
                for(int i=1;i<=n;i++)
                kol[i]=0;
                for(int i=1;i<=n;i++)
                for(int j=1;j<=n;j++)
                if(a[i][j]=='1')kol[j]++;
                }
}
int main()
{
    int n,i,j,q,t,pi,pj;
    char c;
    scanf("%d",&n);
    getchar();
    for(i=1;i<=n;i++)
    {
                     for(j=1;j<=n;j++)
    {
            scanf("%c",&a[i][j]);
            if(a[i][j]=='1'){kol[j]++; vrs[i]++;}
    }
    getchar();
    }
    scanf("%d",&q);
    for(int k=1;k<=q;k++)
    {
            scanf("%d",&t);
            if(t==1){
                     scanf("%d",&pi);
                     f(pi,n);
                     }
            else if(t==2){
                          scanf("%d%d",&pi,&pj);
                          printf("%c\n",a[pi][pj]);
                          }
}
return 0;
}
