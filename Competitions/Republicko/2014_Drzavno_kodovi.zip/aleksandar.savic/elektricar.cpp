#include <stdio.h>
int c[300000],kb[300000],kk[300000];
int main()
{
    int n,m,d,C;
    scanf("%d%d%d%d",&n,&m,&d,&C);
    for(int i=1;i<=n;i++)
    scanf("%d",&c[i]);
    for(int i=1;i<=n;i++)
    scanf("%d",&kb[i]);
    for(int i=1;i<=m;i++)
    scanf("%d",&kk[i]);
    printf("2");
    return 0;
}
