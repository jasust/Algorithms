#include <stdio.h>
#include <iostream>

int main()
{
    int n, s, ki, di;
    scanf("%d%d",&n,&s);
    for(int i = 0; i < n; i++)
    {
            scanf("%d%d",&ki,&di);
            for(int j = 0; j < di; j++)
            scanf("%d",&ki);
    }
    printf("%d",s);
    return 0;
}
