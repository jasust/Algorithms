#include <stdio.h>
#include <iostream>

char mat[1000][1000];

char mgo[1000][1000];
char mdo[1000][1000];
char mle[1000][1000];
char mde[1000][1000];
char mlede[1000][1000];
char mgole[1000][1000];
char mgode[1000][1000];
char mdole[1000][1000];
char mdode[1000][1000];
int c[1000];

void oterajgore(int n)
{
       //c=new int[n];
       for(int i = 0; i < n; i++)
             {
                     for(int j = 0; j < n; j++)
                     {
                             if(mat[i][j] == '1')
                             {
                             mgo[c[j]][j] = mat[i][j];
                             c[j]++;
                             }
                     }
             }
}

void oterajdole(int n)
{
       //c=new int[n];
       for(int i = n - 1; i >= 0; i--)
       {
               for(int j = 0; j < n; j++)
               {
                       if(mat[i][j] == '1')
                       {       
                               mdo[n-1-c[j]][j] = mat[i][j];
                               c[j]++;
                       }
               }
       }
}

void oterajlevo(int n)
{
       //c=new int[n];
       for(int j = 0; j < n; j++)
              {
                     for(int i = 0; i < n; i++)
                     {
                             if(mat[i][j] == '1')
                             {
                             mle[i][c[i]] = mat[i][j];
                             c[i]++;
                             }
                     }
             }
}

void oterajdesno(int n)
{
    //c=new int[n];
    for(int j = n - 1; j >= 0; j--)
                   {
                           for(int i = 0; i < n; i++)
                           {
                                   if(mat[i][j] == '1')
                                   {
                                   mde[i][n-1-c[i]] = mat[i][j];
                                   c[i]++;
                                   }
                           }
                   }
}

void oterajgoredesno(int n)
{
    //c=new int[n];
    for(int j = n - 1; j >= 0; j--)
                   {
                           for(int i = 0; i < n; i++)
                           {
                                   if(mgo[i][j] == '1')
                                   {
                                   mgode[i][n-1-c[i]] = mgo[i][j];
                                   c[i]++;
                                   }
                           }
                   }
}

void oterajdoledesno(int n)
{
     //c=new int[n];
    for(int j = n - 1; j >= 0; j--)
                   {
                           for(int i = 0; i < n; i++)
                           {
                                   if(mdo[i][j] == '1')
                                   {
                                   mdode[i][n-1-c[i]] = mdo[i][j];
                                   c[i]++;
                                   }
                           }
                   } 
}

void oterajgorelevo(int n)
{
     //c=new int[n];
     for(int j = 0; j < n; j++)
              {
                     for(int i = 0; i < n; i++)
                     {
                             if(mgo[i][j] == '1')
                             {
                             mgole[i][c[i]] = mgo[i][j];
                             c[i]++;
                             }
                     }
             }  
}

void oterajdolelevo(int n)
{
      //c=new int[n];
     for(int j = 0; j < n; j++)
              {
                     for(int i = 0; i < n; i++)
                     {
                             if(mdo[i][j] == '1')
                             {
                             mdole[i][c[i]] = mdo[i][j];
                             c[i]++;
                             }
                     }
             }
}


int main()
{
    int n, q, o, k, l, p;
    int gd = -1, ld = -1;
    scanf("%d",&n);
    for(int i = 0; i < n; i++)
    {
            scanf("%s",mat[i]);
    }
    oterajgore(n);
    for(int i = 0; i < n; i++)
               c[i] = 0;
    oterajdole(n);
    for(int i = 0; i < n; i++)
               c[i] = 0;
    oterajlevo(n);
    for(int i = 0; i < n; i++)
               c[i] = 0;
    oterajdesno(n);
    for(int i = 0; i < n; i++)
               c[i] = 0;
    oterajgorelevo(n);
    for(int i = 0; i < n; i++)
               c[i] = 0;
    oterajgoredesno(n);
    for(int i = 0; i < n; i++)
               c[i] = 0;
    oterajdolelevo(n);
    for(int i = 0; i < n; i++)
               c[i] = 0;
    oterajdoledesno(n);
    scanf("%d",&q);
    for(int i = 0; i < q; i++)
    {
            scanf("%d",&o);
            if(o == 1)
            {
                 scanf("%d",&k);
                 if(k == 1 || k == 3)
                 {
                      gd = k;
                 }
                 else
                     ld = k;
            }
            else
            {
                scanf("%d%d",&l, &p);
                if(gd == -1)
                      if(ld == -1)
                      printf("%c",mat[l-1][p-1]); //ako su oba -1
                      else
                       if(ld == 2)
                             if(mle[l-1][p-1]=='1')
                             printf("1");//ako je isao samo levo
                             else
                             printf("0");
                       else
                             if(mde[l-1][p-1]=='1')
                             printf("1");//ako je isao samo desno
                             else
                             printf("0");
                else
                if(ld == -1)
                      if(gd == 1)
                            if(mgo[l-1][p-1]=='1')
                             printf("1");//ako je isao samo gore
                             else
                             printf("0");
                      else
                          if(mdo[l-1][p-1]=='1')
                             printf("1");//ako je isao samo dole
                             else
                             printf("0");
                else
                    if(ld == 2)
                          if(gd == 1)
                          if(mgole[l-1][p-1]=='1')
                             printf("1");//ako je isao gore levo
                             else
                             printf("0");
                          else
                          if(mdole[l-1][p-1]=='1')
                             printf("1");//ako je isao dole levo
                             else
                             printf("0");
                    else
                          if(gd == 1)
                          if(mgode[l-1][p-1]=='1')
                             printf("1");//ako je isao gore desno
                             else
                             printf("0");
                          else
                          if(mdode[l-1][p-1]=='1')
                             printf("1");//ako je isao dole desno
                             else
                             printf("0");
                             
                printf("\n");
                
            }
    }
    return 0;
}
