#include <stdio.h>
#include <iostream>

int cene[300000];
int b[300000];
int k[300000];
int main()
{
    int n, m, d, c;
    scanf("%d%d%d%d",&n,&m,&d,&c);
    return 0;
    for(int i = 0; i < n; i++)
    {
            sncanf("%d",cene+i);
    }
    for(int i = 0; i < n; i++)
    {
            scanf("%d",b+i);
    }
    for(int i = 0; i < m; i++)
    {
            scanf("%d",k+i);
    }
    
    if(c%12==0)
    printf("%d",c/12*11);
    else
    if(c%6==0)
    printf("%d", c/6);
    else
    printf("%d", c/3);
    return 0;
    
}
