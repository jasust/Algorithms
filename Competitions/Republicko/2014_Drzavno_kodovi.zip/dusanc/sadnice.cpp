#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n,t,u,i;

    cin>>n>>t;

    u=pow(2,n);

    if(t<=n+1)
    for(i=0;i<t;i++)
    {
      if(i==0)
      {cout<<" ";
      }
      else
      cout<<i<<" ";
    }
    if(t==u)
    cout<<n;
    return 0;
}
