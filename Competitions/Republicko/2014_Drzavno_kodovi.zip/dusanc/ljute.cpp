#include <iostream>

using namespace std;

int main()
{
  int j,i,n,k,x,y,p,nk;

  cin>>n>>k;

  int t[10000],g[10000];

  for(i=1;i<=n;i++)
     {
     cin>>t[i];
     g[i]=t[i]-(k-1);
     }
     for(i=n+1;i<10000;i++)
    t[i]=0;
     cin>>x>>y;

     if(y<k)
       cout<<x<<" "<<y;
    else
    {
      for(i=n;i>0;i--)
      {
          p=0;
       while(g[i]>0)
           { p++;
           if(t[i+p]<k-1)
               {
                   if(g[i]>k-1-t[i+p])
                {
                 g[i]-=k-1-t[i+p];
                 if(i==x)
                      y-=k-1-t[i+p];

                 t[i+p]=k-1;
                 }
                 else
                 {
                     t[i+p]+=g[i];

                    if(i==x)
                      if(y>k-1)
                       y-=k-1;
                      g[i]=0;

                 }
               }
               if(y<k)
                        break;
            }

          if(i==x)
           x+=p;
      }
      cout<<x<<" "<<y;
    }
return 0;
}
