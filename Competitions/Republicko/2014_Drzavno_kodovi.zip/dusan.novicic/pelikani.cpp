#include <cstdio>

char c[1001][1001];

int main()
{
    int q,s,l,z,n,i,j,r[1001]={0},k[1001]={0};
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        scanf("\n");
        for (j=1;j<=n;j++)
        {
            scanf("%c",&c[i][j]);
            if (c[i][j]=='1')
            {
                r[i]++;
                k[j]++;
            }
        }
    }
    scanf("%d",&q);
    for (int t=0;t<q;t++)
    {
        scanf("%d",&z);
        if (z==2)
        {
            scanf("%d%d",&i,&j);
            printf("%c\n",c[i][j]);
        }
        else
        {
            scanf("%d",&z);
            if (z==1)
            {
                for (j=1;j<=n;j++)
                {
                    s=k[j];
                    for (i=1;i<=k[j];i++)
                    {
                        if (c[i][j]=='0')
                        {c[i][j]='1';r[i]++;}
                         else s--;
                    }
                    for (i=k[j]+1;s>0;i++)
                    {
                        if (c[i][j]=='1'){c[i][j]='0';r[i]--;s--;}
                    }
                }
            }
            else if (z==2)
            {
                for (i=1;i<=n;i++)
                {
                    s=r[i];
                    for (j=1;j<=r[i];j++)
                    {
                        if (c[i][j]=='0')
                        {c[i][j]='1';k[j]++;}
                         else s--;
                    }
                    for (j=r[i]+1;s>0;j++)
                    {
                        if (c[i][j]=='1'){c[i][j]='0';k[j]--;s--;}
                    }
                }
            }
            else if (z==3)
            {
                for (j=1;j<=n;j++)
                {
                    s=k[j];l=n-k[j];
                    for (i=n;i>l;i--)
                    {
                        if (c[i][j]=='0')
                        {c[i][j]='1';r[i]++;}
                         else s--;
                    }
                    for (i=1;s>0;i++)
                    {
                        if (c[i][j]=='1'){c[i][j]='0';r[i]--;s--;}
                    }
                }
            }
            else if (z==4)
            {

                for (i=1;i<=n;i++)
                {
                    s=r[i];l=n-r[i];
                    for (j=n;j>l;j--)
                    {
                        if (c[i][j]=='0')
                        {c[i][j]='1';k[j]++;}
                         else s--;
                    }
                    for (j=1;s>0;j++)
                    {
                        if (c[i][j]=='1'){c[i][j]='0';k[j]--;s--;}
                    }
                }
            }
        }
    }
    return 0;
}
