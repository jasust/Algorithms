#include <cstdio>

int main()
{
    int s,n,k,dk,j,i;
    scanf("%d%d",&n,&s);
    for (i=0;i<n;i++)
    {
        scanf("%d%d",&k,&dk);
        for (j=0;j<dk;j++)scanf("%d",&k);
    }
    printf("%d",s);
    return 0;
}
