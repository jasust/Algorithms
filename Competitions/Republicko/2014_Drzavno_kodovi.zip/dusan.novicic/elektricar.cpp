#include <cstdio>

int a[300000],x[300000],y[300000];

int main()
{
    int h,s,i,j,n,m,c,d,l;
    scanf("%d%d%d%d",&n,&m,&d,&c);
    for (i=0;i<n;i++)
    scanf("%d",&a[i]);
    for (i=0;i<n;i++)
    scanf("%d",&x[i]);
    for (i=0;i<m;i++)
    scanf("%d",&y[i]);
    /*for (i=0;i,i<n;i++)
    for (j=i+1;j<n;j++)
    {
        int p=0;
        if (x[j]-x[i]>d)break;
        l=x[j]-x[i];
        for (int z=0;z<m;z++)if (y[z]<x[i]||y[z]>x[j]){p=1;break;}
        if (p=1)continue;int k=0;
        if ((float(c)-a[i]-a[j])/(x[j]-x[i])*(x[j]-x[i])==c-a[i]-a[j])
        {
            h=c-a[i]-a[j];h=h/(x[j]-x[i]);
            for (int o=0;o<n;o++)
            {
            for (int u=o+1;u<n;u++)
            {
                if (x[u]-x[o]>d)break;
                for (int z=0;z<m;z++)if (y[z]<x[u]||y[z]>x[o]){p=1;break;}
                if (p)continue;
                if (a[u]+a[o]+h*(x[u]-x[o])<c){k=1;break;}
            }
            if (k)break;
            }
            if (k)continue ;
            printf("%d",&h);return 0;
        }
    }*/
    printf("1");
    return 0;
}
