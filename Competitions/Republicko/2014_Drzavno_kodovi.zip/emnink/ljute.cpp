#include <cstdlib>
#include <iostream>

using namespace std;
//emmpress

long long n, k, h[1000000], rk, hb;
int main()
{
int t, t2;
cin>>n>>k;
long long par, nepar;
bool princess;
princess=false;
t2=0;
t=0;
for (int get=1; get<=n; get++)
{
cin>>h[get];    
}
cin>>hb>>rk;
if (rk<k)
{cout<<rk<<" "<<hb;}
else
{
    
    
    while (princess==false)//smthing
 {
          par=0;
          nepar=-1;
         
   n++;
   h[n]=0;

             for (int j=1; j<=n; j++)
{            nepar=nepar+2;
par=par+2;


if (j==hb)
{

if (rk>=k)
{

hb++; 
if (h[hb]<k)
{
if (rk==k) {rk=h[hb]+1; }
if (rk>k){ rk=h[hb]+(rk-k)+1;     }
}

}

if (rk<k)
{
princess=true;
break;
}

}//i+j==hb



if (par>n||nepar>n) break;
    
if (h[nepar]<k)  {
                 
h[nepar]=h[nepar]+t; 
 t2=h[nepar]-k+1;
if (t2<0) t2=0;
}

         
             
if (h[nepar]>=k)
{    
     
t2=h[nepar]-k+1;
h[nepar]=k-1+t;

}




//this has issues



            


if (h[par]<k)
{
h[par]=h[par]+t2; t=0;
if (h[par]-k+1>0) {t=h[par]-k+1;} 


}
if (h[par]>=k)
{
              
 t=h[par]-k+1;
h[par]=t2+k-1;

}

 }//for 1



}//while
cout<<hb<<" "<<rk;

}//else

getchar(); getchar();
}
