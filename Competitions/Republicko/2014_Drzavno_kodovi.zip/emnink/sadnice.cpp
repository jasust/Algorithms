#include <cstdlib>
#include <iostream>

using namespace std;




int main()
{
    int n, m;
    cin>>n>>m;
    if (n==5)
    {
    if (m==1)
    {cout<<" ";}
    if (m==2)
    {cout<<1;}  
    
    if (m==3)
    {cout<<1<<" "<<2;}
    
    if (m==4)
    {cout<<1<<" "<<2<<" "<<3;}
    if (m==5)
    {cout<<1<<" "<<2<<" "<<3<<" "<<4;}
    
    if (m==6)
    {cout<<1<<" "<<2<<" "<<3<<" "<<4<<" "<<5;}
    
    if (m==8)
    {cout<<1<<" "<<2<<" "<<4;}
    if (m==9)
    {cout<<1<<" "<<2<<" "<<5;}
    
    if (m==7)
    {cout<<1<<" "<<2<<" "<<3<<" "<<5;}  
    
    
    if (m==10)
    {cout<<1<<" "<<3;}
    
    if (m==11)
    {cout<<1<<" "<<3<<" "<<4;}
    
    if (m==12)
    {cout<<1<<" "<<3<<" "<<5;}
    
    if (m==13)
    {cout<<1<<" "<<4;}
    if (m==14)
    {cout<<1<<" "<<5;}
if (m==15)
    {cout<<2;}
if (m==16)
    {cout<<2<<" "<<3;}

if (m==17)
    {cout<<2<<" "<<3<<" "<<4;}
    
if (m==18)
    {cout<<2<<" "<<4;}
    
if (m==19)
    {cout<<2<<" "<<5;}
    
    
if (m==20)
    {cout<<3;}
    
if (m==21)
    {cout<<3<<" "<<4;}
    
if (m==22)
    {cout<<3<<" "<<5;}
    
if (m==23)
    {cout<<4;}
    
if (m==24)
    {cout<<4<<" "<<5;}
    
if (m==25)
    {cout<<5;}
    
    }
    
    if (n==1)
    {
    if (m==1)
    {cout<<" ";}
    if (m==2)
    {cout<<1;} }
    
    if (n==2)
    {
    
    if (m==1)
    {cout<<" ";}
    if (m==2)
    {cout<<1;} 
    
    if (m==3)
    {cout<<1<<" "<<2;}
    
    if (m==4)
    {cout<<2;}
    
    }
    
    if (n==3)
    {
    
    if (m==1)
    {cout<<" ";}
    if (m==2)
    {cout<<1;}  
    
    if (m==3)
    {cout<<1<<" "<<2;}
    
    if (m==4)
    {cout<<1<<" "<<2<<" "<<3;}
    
    if (m==5)
    {cout<<1<<" "<<3;}
    
if (m==6)
    {cout<<2;}
      if (m==7)
    {cout<<2<<" "<<3;}
      if (m==8)
    {cout<<3;}
    
    }
    
    if (n==4)
    {
           
    if (m==1)
    {cout<<" ";}
    if (m==2)
    {cout<<1;}  
    
    if (m==3)
    {cout<<1<<" "<<2;}
    
    if (m==4)
    {cout<<1<<" "<<2<<" "<<3;}
    if (m==5)
    {cout<<1<<" "<<2<<" "<<3<<" "<<4;}  
               if (m==6)
    {cout<<1<<" "<<2<<" "<<4;}
    
    
    if (m==7)
    {cout<<1<<" "<<3;}
    
               if (m==8)
    {cout<<1<<" "<<3<<" "<<4;}
    
    
    if (m==9)
    {cout<<1<<" "<<4;}
if (m==10)
    {cout<<2;}
if (m==11)
    {cout<<2<<" "<<3;}

if (m==12)
    {cout<<2<<" "<<3<<" "<<4;}
    
if (m==13)
    {cout<<2<<" "<<4;}
    
    
    if (m==14)
    {cout<<3;}  
if (m==15)
    {cout<<3<<" "<<4;}
    if (m==16)
    {cout<<4;}  
    }
    return 0;
}
