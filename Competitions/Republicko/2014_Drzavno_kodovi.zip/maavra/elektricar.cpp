#include<iostream.h>





main()
{
      int n, m, d, c, a;
      cin>>n>>m>>d>>c;
      for(int i=0;i<n;i++)
      cin>>a;
      for(int i=0;i<n;i++)
      cin>>a;
      for(int i=0;i<m;i++)
      cin>>a;
      printf("3");
      return 0;
}
