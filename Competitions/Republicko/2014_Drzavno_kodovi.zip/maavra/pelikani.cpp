#include<iostream.h>
#include<stdio.h>


int a[1000][1000];
int x[1000];
int y[1000];


void pusher(int ss,int n)
{
         for(int i=0;i<n;i++)
         for(int j=0;j<n;j++)
         if((ss==1 && i<=y[j]-1) || (ss==3&&i>=n-y[j]) || (ss==2&& j<=x[i]-1) || (ss==4&&j>=n-x[i]))a[i][j]=1;
         else a[i][j]=0;
}
void push1(int ss, int n)
{
     for(int i=0;i<n;i++){x[i]=0;y[i]=0;}
     for(int i=0;i<n;i++)
     for(int j=0;j<n;j++)
     {x[i]+=a[i][j];y[j]+=a[i][j];}
     pusher(ss, n);
}
main()
{
      int n;char ch;
      int q, t;
      int save1, save2;
      int g, h;
      int k, m;
      int c=0, d=0, ss; 
      scanf("%i", &n);
      scanf("%c", &ch);
      for(int i=0;i<n;i++)
      {
              for(int j=0;j<n;j++)
              {scanf("%c", &ch);a[i][j]=ch-'0';x[i]+=ch-'0';y[j]+=ch-'0';}
              scanf("%c", &ch);
      }
      scanf("%i", &q);
      for(int i=0;i<q;i++)
      {
              scanf("%i", &t);
              if(t==1)
              {
                      scanf("%i", &ss);
                      if(ss==1)m=1;
                      if(ss==2)k=1;
                      if(ss==3)m=-1;
                      if(ss==4)k=-1;
                      
                      if(c+d==0)
                      {
                                if(ss%2==1){pusher(ss, n);d=1;}
                                if(ss%2==0){pusher(ss, n);c=1;}
                                
                                
                                
                      }
                      else if(c+d==1)
                      {
                                 if(d==0 && ss%2==0)k=ss-3;
                                 if(c==0 && ss%2==1)m=2-ss;
                                 if(d==0 && ss%2==1){push1(ss, n);d=1;save1=m;save2=k;}
                                 if(c==0 && ss%2==0){push1(ss, n);c=1;save1=m;save2=k;}
                                 
                      }
                      
                      else if(c*d==1)
                      {
                               if(ss==1)m=1;
                               if(ss==2)k=-1;
                               if(ss==3)m=-1;
                               if(ss==4)k=1;
                               
                      }
                      
              }
              else 
              {
                   scanf("%i%i", &g, &h);
                   if(m!=save1)h=n-h;
                   if(k!=save2)g=n-g;
                   printf("%i", a[g][h]);
              }
      }
      
      
      /*
      
      for(int i=0;i<n;i++)
      {
              for(int j=0;j<n;j++)
              {
                      printf("%i ", a[i][j]);
              }
              printf("\n");
      }*/
      return 0;
}             
