#include<stdio.h>
#include<iostream.h>
int mini(int a, int b){if(a*a<b*b)return a; if(a*a > b*b) return b; if(a>b) return b;}


int a[10000];//podaci
int m[10000];//indeksi
static int x[10000];

int rekurzija(int u,int s)
{
    int p, l;
    p = mini(s-a[m[u]], s);
    for(int i=m[u]+1;i<m[u+1];i++)
    {l=rekurzija(i, s);p = mini(s-l, s);}
   /* for(int i=m[u]+1;i<m[u+1];i++)
    {l=rekurzija(i, s-a[i]);p = mini(s-l, s);}*/
    return p;
}
main()
{
      int n, s;int b;
      int counter =1;
      scanf("%i%i", &n, &s);
      m[1]=1;
      for(int i=1;i<=n;i++)
      {
              scanf("%i", &a[counter]);counter++;
              scanf("%i", &b);
              a[counter]=b;
              for(int j=0;j<b;j++)
              {scanf("%i", &a[counter]);x[a[counter]]=1;counter++;}
              m[i+1]=counter;
      }
      int g=0;
      /*for(int i=1;i<n;i++)if(x[i]==0)g=i;
      printf("%i", rekurzija(g,s));cout<<" yyy";
      for(int i=1;i<counter;i++)printf("%i ", a[i]);
      printf("\n");
      for(int i=1;i<counter;i++)printf("%i ", m[i]);
      printf("\n");*/
      printf("%i", s);
      return 0;
}
