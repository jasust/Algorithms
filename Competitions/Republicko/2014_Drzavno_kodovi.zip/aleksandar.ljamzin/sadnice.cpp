#include <iostream>
#include <stdio.h>
using namespace std;
int n;
long long m;
int sk[55];
int skc;
long long tmp;
void simp(){
    tmp=tmp>>1;
    if(m<=1){
        return;
    }
    int c=1;
    m--;
    while(tmp+1<=m){
        m=m-tmp;
        c++;
        tmp=tmp>>1;
    }
    sk[skc]=c;
    skc++;
    simp();
}
int main()
{
    scanf("%d%lld", &n, &m);
    tmp=1<<n;
    simp();
    int cm=0;
    for(int i=0; i<skc; i++){
        cm+=sk[i];
        printf("%d ", cm);
    }
    return 0;
}
