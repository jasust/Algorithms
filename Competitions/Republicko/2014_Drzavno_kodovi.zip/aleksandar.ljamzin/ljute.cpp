#include <iostream>
#include <stdio.h>
using namespace std;
int n, k, rk, hb;
int h[100100];
int st[100100];
int sc, sid;
bool doo=true;
bool collapse(int c){
    if(c==0) return false;
    sc--;
    while(c>=st[sc]&&sc>=0){
        if(sc==sid){
            hb=hb+k-c;
            return true;
        }
        c-=st[sc];
        sc--;
    }
    if(sc<0) { sc++; return false; }
    if(sc==sid){
        if(hb+1<=c){
            hb=k-c+hb;
            return true;
        }
        else{
            hb-=c;
            st[sc]-=c;
        }
    }
    else{
        st[sc]-=c;
    }
    sc++;
    return false;
}
int main()
{
    scanf("%d%d", &n, &k);
    for(int i=0; i<n; i++){
        scanf("%d", &h[i]);
    }
    scanf("%d%d", &rk, &hb);
    if(hb<k) {printf("%d %d", rk, hb); return 0;}
    hb=hb-k;
    for(int i=0; i<n; i++){
        if(k<=h[i]){
            if(i+1==rk) sid=sc;
            st[sc]=h[i]-k+1;
            sc++;

        }
        else{
            if(sc>0) if(collapse(k-h[i]-1)) {rk=i+1; doo=false; break;}
        }
    }
    if(doo) while(sc>0){
        n++;
        if(collapse(k-1)) {rk=n; break;}
    }
    printf("%d %d", rk, hb);
    return 0;
}
