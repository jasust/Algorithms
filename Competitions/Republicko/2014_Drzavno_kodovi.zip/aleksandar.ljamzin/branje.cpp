#include <iostream>
#include <stdio.h>
using namespace std;
int n;
int s[100100];
int z[100100];
int p[100100];
int pc, bg, en;
bool pos;
long long sum, ts, mn, miin;
void add(int b){
    if(b>0){
        if(pos){
            p[pc]+=b;
        }
        else{
            pos=false;
            pc++;
            p[pc]+=b;
        }
    }
    else if(b<0){
        if(!pos){
            p[pc]+=b;
        }
        else{
            pos=true;
            pc++;
            p[pc]+=b;
        }
    }
}
int main()
{
    scanf("%d", &n);
    for(int i=0; i<n; i++){
        cin>>z[i];
    }
    for(int i=0; i<n; i++){
        cin>>s[i];
        sum+=z[i]-s[i];
        //add(z[i]-s[i]);
    }
    printf("%lld", sum);
    /*
    bg=0;
    en=pc-1;
    sum=0;
    for(int i=bg; i<=en; i++){
        sum+=p[i];
    }
    if(p[bg]>0) bg++;
    if(p[en]>0) en--;
    ts=0;
    for(int i=bg; i<=en; i++) {
        mn+=p[i];
        ts=mn;
        if(ts<miin) miin=ts;
        for(int j=bg; j<i; j++){
            ts=ts-p[j]-p[j+1];
            if(ts<miin) miin=ts;
        }
    }
    printf("%lld   %lld", sum, miin); */
    return 0;
}
