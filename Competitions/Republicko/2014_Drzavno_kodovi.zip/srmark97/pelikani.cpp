#include <stdio.h>
#include <algorithm>
using namespace std;

int m[1003][1003],c[1003],r[1003],n,i,j,x,y,q1,q2,p,p1,p2,vn[1003],q,t,yuio,pq;
char cc;

int cmp (int w,int e)
{
    return w>e;
}

int main()
{
    scanf ("%d\n",&n);
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=n;j++)
        {
        scanf ("%c",&cc);
        m[i][j]=cc-48;
        if (m[i][j]==1)
        {
        r[i]++;
        c[j]++;
        }
        }
        scanf ("%c",&cc);
    }
    pq=0;
    q1=0;
    q2=0;
    p1=0;
    p2=0;
    scanf ("%d",&q);
    for (i=1;i<=q;i++)
    {
        scanf ("%d",&t);
        if (t==1)
        {
                 scanf ("%d",&p);
                 if ((p==1)||(p==3))
                 {
                 q1=1;
                 p1=p;
                 }
                 if ((p==2)||(p==4))
                 {
                 q2=1;
                 p2=p;
                 }
                 if (pq==0)
                 {
                 pq=1;
                 if ((q1==1)&&(q2==0))
                 {
                           for (j=1;j<=n;j++)
                           vn[j]=c[j];
                           yuio=n+1;
                           sort (vn+1,vn+yuio,cmp);
                 }
                 if ((q1==0)&&(q2==1))
                 {
                           for (j=1;j<=n;j++)
                           vn[j]=r[j];
                           yuio=n+1;
                           sort (vn+1,vn+yuio,cmp);
                 }
                 }
                           
        }
                 
        if (t==2)
        {
                 scanf ("%d%d",&x,&y);
                 if ((q1==1)&&(q2==1))
                 {
                                      if ((p1==1)&&(p2==2))
                                      {
                                      if (p==1)
                                      {
                                      if (vn[y]<x)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                                      }
                                      if (p==2)
                                      {
                                      if (vn[x]<y)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                                      }
                                      }
                                      if ((p1==1)&&(p2==4))
                                      {
                                      if (p==1)
                                      {
                                      if (vn[n-y+1]<x)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                                      }
                                      if (p==4)
                                      {
                                      if (vn[x]<n-y+1)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                                      }
                                      }
                                      if ((p1==3)&&(p2==2))
                                      {
                                      if (p==3)
                                      {
                                      if (vn[y]<n-x+1)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                                      }
                                      if (p==2)
                                      {
                                      if (vn[n-x+1]<y)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                                      }
                                      }
                                      if ((p1==3)&&(p2==4))
                                      {
                                      if (p==3)
                                      {
                                      if (vn[n-y+1]<n-x+1)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                                      }
                                      if (p==4)
                                      {
                                      if (vn[n-x+1]<n-y+1)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                                      }
                                      }
                 }
                 if ((q1==1)&&(q2==0))
                 {
                                      if (p==1)
                                      {
                                               if (c[y]<x)
                                               printf ("0\n");
                                               else
                                               printf ("1\n");
                                      }
                                      if (p==3)
                                      {
                                               if (c[y]<n-x+1)
                                               printf ("0\n");
                                               else
                                               printf ("1\n");
                                      }
                 }
                 if ((q1==0)&&(q2==1))
                 {
                                      if (p==2)
                                      {
                                               if (r[x]<y)
                                               printf ("0\n");
                                               else
                                               printf ("1\n");
                                      }
                                      if (p==4)
                                      {
                                               if (r[x]<n-y+1)
                                               printf ("0\n");
                                               else
                                               printf ("1\n");
                                      }
                 }
                 if ((q1==0)&&(q2==0))
                 {
                                      if (m[x][y]==0)
                                      printf ("0\n");
                                      else
                                      printf ("1\n");
                 }
        }
    }
    return 0;
    //system ("pause");
}
                                      
