#include <stdio.h>
#include <math.h>
#include <vector>
using namespace std;


vector<int> v[10003];

int maxv,maxm,kc[10003],bk,sbk,st[10003],n,s,najm,x,bf[10003],b,pr[10003],r,sr[10003];

void dfs(int k)
{
     int i,d,j;
     d=v[bf[k]].size();
     if (d>0)
     {
     for (i=0;i<d;i++)
     {
     bf[k+1]=v[bf[k]][i];
     dfs(k+1);
     }
     }
     if (d==0)
     {
              
              maxv=3*s;
              maxm=0;
              for (i=1;i<=s;i++)
              st[i]=0;
              bk=1;
              kc[1]=0;
              for (i=1;i<=k;i++)
              {
                  sbk=bk;
                  for (j=1;j<=sbk;j++)
                  {
                      if (kc[j]+sr[bf[i]]>s)
                      {
                      if (kc[j]+sr[bf[i]]<maxv)
                      maxv=kc[j]+sr[bf[i]];
                      }
                      else
                      {
                      if (st[kc[j]+sr[bf[i]]]==0)
                      {
                      bk++;
                      kc[bk]=kc[j]+sr[bf[i]];
                      }
                      st[kc[j]+sr[bf[i]]]=1;
                      if (kc[j]+sr[bf[i]]>maxm)
                      maxm=kc[j]+sr[bf[i]];
                      }
                  }
              }
              if (s-maxm<=abs(najm-s))
              najm=maxm;
              if (maxv-s<abs(najm-s))
              najm=maxv;
     }
     return;
}
     


int main()
{
      int i,j,dd;
      st[0]=1;
      scanf ("%d%d",&n,&s);
      najm=3*s;
      for (i=1;i<=n;i++)
      {
          scanf ("%d",&sr[i]);
          scanf ("%d",&b);
          for (j=1;j<=b;j++)
          {
          scanf ("%d",&x);
          pr[x]++;
          v[i].push_back(x);
          }
      }
      for (i=1;i<=n;i++)
      {
          if (pr[i]==0)
          {
          r=i;
          break;
          }
      }
      bf[1]=r;
      b=1;
      dfs (1);
      printf ("%d",najm);
      return 0;
      //system ("pause");
}
      
