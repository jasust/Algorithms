#include <iostream>

using namespace std;

int main()
{
    long long N, S, k, t, l;
    cin >> N >> S;
    for(long long i = 0; i < N; i++){
        cin >> k >> t;
        for(long long j = 0; j < t; j++){
            cin >> l;
        }
    }
    cout << S;
    return 0;
}
