#include <iostream>
#include <vector>
#include <string>

using namespace std;

void pomeri(vector<string>& a, int N, int x){
    int k = 1;
    switch(x){
    case 1:
        for(int i = 0; i < N; i++){

            for(int j = 0; j < N; j++){

                while ((a[i-k+1][j] == '1') && (i-k >= 0) && (a[i-k][j] == '0')){
                    a[i-k][j] = '1';
                    a[i-k+1][j] = '0';
                    k++;
                }
                k = 1;
            }
        }

        break;
    case 2:
        for(int j = 0; j < N; j++){

            for(int i = 0; i < N; i++){
                while ((a[i][j-k+1] == '1') && (j-k >= 0) && (a[i][j-k] == '0')){
                    a[i][j-k] = '1';
                    a[i][j-k+1] = '0';
                    k++;
                }
                k = 1;
            }
        }

        break;
    case 3:
        for(int i = N-1; i >= 0; i--){

            for(int j = 0; j < N; j++){

                while ((a[i+k-1][j] == '1') && (i+k < N) && (a[i+k][j] == '0')){
                    a[i+k][j] = '1';
                    a[i+k-1][j] = '0';
                    k++;
                }
                k = 1;
            }
        }

        break;
    case 4:
        for(int j = N-1; j >= 0; j--){

            for(int i = 0; i < N; i++){

                while ((a[i][j+k-1] == '1') && (j+k < N) && (a[i][j+k] == '0')){
                    a[i][j+k] = '1';
                    a[i][j+k-1] = '0';
                    k++;
                }

                k = 1;
            }
        }

        break;
    }
}

int main()
{
    int N, Q;
    cin >> N;

    vector<string> a(N);
    cin.ignore();
    for(int i = 0; i < N; i++){

        getline(cin, a[i]);
    }

    cin >> Q;

    short t;
    int x, y;

    for(int i = 0; i < Q; i++){

        cin >> t;
        if(t == 2){

            cin >> x >> y;
            cout << a[x-1][y-1] << endl;
        }else{
            cin >> x;
            pomeri(a, N, x);
        }
    }


    return 0;
}
