#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

struct bandera{
    long long cena;
    long long duz;
};


void proveri(vector<long long>& kuce, long long x, long long y, long long m, long long &p){

    for(long long i = 0; i < m; i++){
        if((kuce[i] > x) && (kuce[i] < y))
            p++;
    }

}

long long tempC = 0;
long long tempD = 0;

long long izrS(vector<bandera>& povezane, long long C){

    tempC = 0; tempD = 0;
    for(int i = 0; i < povezane.size(); i++){
        tempC += povezane[i].cena;
    }

    for(int i = 0; i < povezane.size() - 1; i++){
        tempD += abs(povezane[i].duz - povezane[i+1].duz);
    }

    return (C-tempC)/tempD;
}

long long izrC(vector<bandera>& povezane, long long S){

    return tempC + S*tempD;

}

int main()
{
    long long n, m, D, C;
    cin >> n >> m >> D >> C;

    vector<bandera> b(n);

    for(long long i = 0; i < n; i++){
        cin >> b[i].cena;
    }

    for(long long i = 0; i < n; i++){
        cin >> b[i].duz;
    }

    vector<long long> kuce(m);

    for(long long i = 0; i < m; i++){
        cin >> kuce[i];
    }

    vector<bandera> povezane;

    long long S = 0;
    long long p = 0;

    for(long long i = 0; i < n; i++){

        for(long long j = i+1; j < n; j++){

            proveri(kuce, b[i].duz, b[j].duz, m, p);

            if((p != 0) && (abs(b[i].duz - b[j].duz) <= D)){

                povezane.push_back(b[i]);
                povezane.push_back(b[j]);
                long long temp = izrS(povezane, C);

                if((izrC(povezane, temp) == C) && (temp > S)){

                    S = temp;
                    povezane.clear();
                    p = 0;
                }
                else if(izrC(povezane, temp) < C){
                    S = 0;
                    povezane.clear();
                    p = 0;
                }
            }
        }

    }
    cout << S;

    return 0;
}
