#include <cstdio>
#include <algorithm>

using namespace std;

int n,m,d;
long long c;
long long mtn[300005];
long long bx[300005];
long long kx[300005];
long long live[300005];
long long dead[300005];
long long dp[300005];
long long fin[300005];
char mark[300005];


int main()
{
    scanf("%d%d%d",&n,&m,&d);
    scanf("%lld",&c);
    for (int i=1; i<=n; i++)
        scanf("%lld",&mtn[i]);
    for (int i=1; i<=n; i++)
        scanf("%lld",&bx[i]);
    for (int i=1; i<=m; i++)
        scanf("%lld",&kx[i]);
    if (d==1000000000)
    {
        kx[m+1]=1123123123;
        long long top,bot,cs;
        top=c;
        bot=1;
        while (top>bot)
        {
            cs=(top+bot)/2;
            int pk=1;
            live[0]=c+1;
            dead[0]=0;
            bx[0]=-c-1;
            for (int i=1; i<=n; i++)
            {
                while (kx[pk]<bx[i-1])
                    pk++;
                if (kx[pk]<bx[i])
                {
                    live[i]=min(dead[i-1]+mtn[i-1]+mtn[i]+(bx[i]-bx[i-1])*cs,live[i-1]-mtn[i-1]+mtn[i]+(bx[i]-bx[i-1])*cs);
                    dead[i]=1ll<<50;
                }
                else
                {
                    live[i]=min(dead[i-1]+mtn[i-1]+mtn[i]+(bx[i]-bx[i-1])*cs,live[i-1]-mtn[i-1]+mtn[i]+(bx[i]-bx[i-1])*cs);
                    dead[i]=min(live[i-1],dead[i-1]);
                }
            }
            long long sol=min(live[n],dead[n]);
            if (sol>c)
                top=cs-1;
            if (sol<c)
                bot=cs+1;
            if (sol==c)
                top=bot=cs;
        }
        printf("%lld\n",top);
        return 0;
    }
    kx[m+1]=1123123123;
    int posk=1;
    for (int i=1; i<=n; i++)
    {
        while (kx[posk]<bx[i-1])
            posk++;
        if (kx[posk]<bx[i])
            mark[i]=1;
    }
    long long top,bot,cs;
    top=c;
    bot=1;
    while (top>bot)
    {
        long long cs=(top+bot)/2;
        fin[1]=0;
        dp[1]=0;
        for (int i=2; i<=n; i++)
        {
            long long mn=1ll<<50;
            dp[i]=1ll<<50;
            for (int j=i-1; j>0; j--)
            {
                if (bx[i]-bx[j]>d)
                    break;
                long long nw;
                nw=mtn[i]+mtn[j]+(bx[i]-bx[j])*cs;
                if (mark[j])
                    nw+=mn;
                else
                    nw+=min(mn,fin[j-1]);
                dp[i]=min(dp[i],nw);
                mn=min(mn,fin[j]);
            }
            fin[i]=dp[i];
            if (mark[i]==0)
                fin[i]=min(fin[i],fin[i-1]);
        }
        long long sol=fin[n];
        if (sol>c)
            top=cs-1;
        if (sol<c)
            bot=cs+1;
        if (sol==c)
            top=bot=cs;
    }
    printf("%lld\n",top);
}
