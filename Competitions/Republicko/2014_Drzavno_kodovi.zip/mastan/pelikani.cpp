#include <cstdio>
#include <algorithm>

using namespace std;

char base[1005][1005];
int n,q;
int ah,av;
int ch[1005];
int cv[1005];

int main()
{
    //freopen("in.txt","r",stdin);
    //freopen("out.txt","w",stdout);
    scanf("%d",&n);
    for (int i=1; i<=n; i++)
        scanf("%s",base[i]+1);
    scanf("%d",&q);
    while (q--)
    {
        int op;
        scanf("%d",&op);
        if (op==2)
        {
            int x,y;
            scanf("%d%d",&x,&y);
            if (ah==0 && av==0)
            {
                printf("%d\n",base[x][y]=='1');
                continue;
            }
            if (ah!=0)
            {
                if (ah==-1)
                    y=n-y+1;
                if (av==-1)
                    x=n-x+1;
                printf("%d\n",ch[x]>=y);
                continue;
            }
            if (av!=0)
            {

                if (ah==-1)
                    y=n-y+1;
                if (av==-1)
                    x=n-x+1;
                printf("%d\n",cv[y]>=x);
                continue;
            }
        }
        else
        {
            int dr;
            scanf("%d",&dr);
            if (dr&1)
            {
                char chek=av==0;
                if (dr==1)
                    av=1;
                else
                    av=-1;
                if (chek)
                {
                    for (int i=1; i<=n; i++)
                    {
                        int p,k;
                        p=1;
                        k=n;
                        while (p<k)
                        {
                            if (base[k][i]>base[p][i])
                                swap(base[p][i],base[k][i]);
                            if (base[p][i]=='1')
                                p++;
                            if (base[k][i]=='0')
                                k--;
                        }
                    }
                    for (int i=1; i<=n; i++)
                        ch[i]=cv[i]=0;
                    for (int i=1; i<=n; i++)
                        for (int j=1; j<=n; j++)
                        {
                            ch[i]+=base[i][j]=='1';
                            cv[j]+=base[i][j]=='1';
                        }
                }
            }
            else
            {
                char chek=ah==0;
                if (dr==2)
                    ah=1;
                else
                    ah=-1;
                if (chek)
                {
                    for (int i=1; i<=n; i++)
                    {
                        int p,k;
                        p=1;
                        k=n;
                        while (p<k)
                        {
                            if (base[i][k]>base[i][p])
                                swap(base[i][p],base[i][k]);
                            if (base[i][p]=='1')
                                p++;
                            if (base[i][k]=='0')
                                k--;
                        }
                    }
                    for (int i=1; i<=n; i++)
                        ch[i]=cv[i]=0;
                    for (int i=1; i<=n; i++)
                        for (int j=1; j<=n; j++)
                        {
                            ch[i]+=base[i][j]=='1';
                            cv[j]+=base[i][j]=='1';
                        }
                }
            }
        }
    }
    /*
    for (int i=1; i<=n; i++)
        printf("%s\n",base[i]+1);
    */
}
