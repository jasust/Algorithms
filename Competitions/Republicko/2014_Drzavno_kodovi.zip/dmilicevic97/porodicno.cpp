#include <cstdio>

#define maxn 10005

int n, s;
int pr[maxn]; // koren ce imati pr[i] = 0
int listovi[maxn], brlistova;
int srecanbr[maxn];
int svesume[maxn], svesumebr, mark[maxn];

int main() {
    scanf("%d%d", &n, &s);

    int brdece, dete;
    for (int i = 1; i <= n; i++) {
        scanf("%d%d", srecanbr+i, &brdece);

        if (brdece == 0) listovi[brlistova++] = i;
        else {
            for (int j = 0; j < brdece; j++) {
                scanf("%d", &dete);
                pr[dete] = i;
            }
        }

        mark[i] = -1;
    }

    int trcvor, najmanjiveciodS = 1000000000, najvecimanjiodS = 0, svesumebrPrim;
    for (int i = 0; i < brlistova; i++) {
        trcvor = listovi[i];
        svesumebr = 1;
        svesume[0] = 0;

        while (pr[trcvor]) {
            svesumebrPrim = svesumebr;
            for (int j = 0; j < svesumebrPrim; j++) {
                if (svesume[j] + srecanbr[trcvor] > s) {
                    if (svesume[j] + srecanbr[trcvor] < najmanjiveciodS)
                        najmanjiveciodS = svesume[j] + srecanbr[trcvor];
                } else if (svesume[j] + srecanbr[trcvor] == s) {
                    printf("%d\n", s);
                    return 0;
                } else {
                    if (mark[svesume[j] + srecanbr[trcvor]] != i) {
                        mark[svesume[j] + srecanbr[trcvor]] = i;
                        svesume[svesumebr] = svesume[j] + srecanbr[trcvor];

                        if (svesume[svesumebr] > najvecimanjiodS)
                            najvecimanjiodS = svesume[svesumebr];

                        svesumebr++;
                    }
                }
            }

            trcvor = pr[trcvor];
        }

        // za koren
        svesumebrPrim = svesumebr;
        for (int j = 0; j < svesumebrPrim; j++) {
                if (svesume[j] + srecanbr[trcvor] > s) {
                    if (svesume[j] + srecanbr[trcvor] < najmanjiveciodS)
                        najmanjiveciodS = svesume[j] + srecanbr[trcvor];
                } else if (svesume[j] + srecanbr[trcvor] > s) {
                    printf("%d\n", s);
                    return 0;
                } else {
                    if (mark[svesume[j] + srecanbr[trcvor]] != i) {
                        mark[svesume[j] + srecanbr[trcvor]] = i;
                        svesume[svesumebr] = svesume[j] + srecanbr[trcvor];

                        if (svesume[svesumebr] > najvecimanjiodS)
                            najvecimanjiodS = svesume[svesumebr];

                        svesumebr++;
                    }
                }
        }
    }

    //printf("%d %d\n", najmanjiveciodS, najvecimanjiodS);

    if (najmanjiveciodS-s < s-najvecimanjiodS) printf("%d\n", najmanjiveciodS);
    else printf("%d\n", najvecimanjiodS);
    return 0;
}
/*
8 20
22 3 2 3 4
7 2 6 5
100 0
1 1 7
10 0
2 1 8
2 0
12 0
*/
