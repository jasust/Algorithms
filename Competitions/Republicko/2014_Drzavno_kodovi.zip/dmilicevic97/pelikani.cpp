#include <cstdio>

#define maxn 1005
int n, q;
char pelikani[maxn][maxn];
int kol[maxn], red[maxn];
int komanda, komanda1, komanda2;
int poslednjaKomanda;
int suma[maxn];

int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%s", pelikani[i]);

        for (int j = 0; j < n; j++)
            if (pelikani[i][j] == '1') kol[j+1]++, red[i+1]++;
    }

    scanf("%d", &q);
   // printf("%d\n", q);
    while (q--) {
        //printf("%d\n", q);
        scanf("%d", &komanda);

        if (komanda == 1) {
            scanf("%d", &komanda1);
            poslednjaKomanda = komanda1;

            for (int i = 1; i <= n; i++) suma[i] = 0;

            if (komanda1 == 1 || komanda1 == 3) {
                for (int i = 1; i <= n; i++) suma[kol[i]]++;

                if (komanda1 == 1) {
                    int trsuma = 0;
                    for (int i = n; i; i--) {
                        trsuma += suma[i];
                        red[i] = trsuma;
                    }
                } else {
                    int trsuma = 0;
                    for (int i = 1; i <= n; i++) {
                        trsuma += suma[n-i+1];
                        red[i] = trsuma;
                    }
                }

            } else {
                for (int i = 1; i <= n; i++) suma[red[i]]++;

                if (komanda == 2) {
                    int trsuma = 0;
                    for (int i = n; i; i--) {
                        trsuma += suma[i];
                        kol[i] = trsuma;
                    }
                } else {
                    int trsuma = 0;
                    for (int i = 1; i <= n; i++) {
                        trsuma += suma[n-i+1];
                        kol[i] = trsuma;
                    }
                }
            }

        } else {
            scanf("%d%d", &komanda1, &komanda2);

            if (poslednjaKomanda == 0) printf("%d\n", pelikani[komanda1-1][komanda2-1] == '1' ? 1 : 0);
            else {
                switch(poslednjaKomanda) {
                    case 1:
                        if (kol[komanda2] >= komanda1) printf("1\n");
                        else printf("0\n");
                        break;
                    case 2:
                        if (red[komanda1] >= komanda2) printf("1\n");
                        else printf("0\n");
                        break;
                    case 3:
                        if (kol[komanda2] >= n-komanda1+1) printf("1\n");
                        else printf("0\n");
                        break;
                    case 4:
                        if (red[komanda1] >= n-komanda2+1) printf("1\n");
                        else printf("0\n");
                        break;
                }
            }
        }
    }

    return 0;
}
