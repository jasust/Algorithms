//elektricar
#include <cstdio>

#define maxn 300000

// neki greedy koji verovatno ne radi

int n, m, d, c;
int cena[maxn], bandera[maxn], kuca[maxn], novekuce[maxn];
int novekucebr;
int sleva[maxn], sdesna[maxn]; // najbolja bandera za svaku kucu

int binarna(int x) {
    int l = 0, d = n-1;
    int mid;

    while (l < d - 1) {
        mid = (l+d)/2;

        if (bandera[mid] < x) l = mid;
        else d = mid-1;
    }

    return bandera[l+1] < x ? l+1 : l;
}

int main() {
    scanf("%d%d%d%d", &n, &m, &d, &c);
    for (int i = 0; i < n; i++) scanf("%d", cena+i);
    for (int i = 0; i < n; i++) scanf("%d", bandera+i);
    for (int i = 0; i < m; i++) scanf("%d", kuca+i);

    novekuce[novekucebr++] = kuca[0];
    for (int i = 1; i < m; i++) {
        int idx = binarna(kuca[i]);

        if (bandera[idx] > novekuce[novekucebr-1])
            novekuce[novekucebr++] = kuca[i];
    }

    int idxbandera = 0, idxkuce = 0;
    int najboljazasada = -1;
    while (idxkuce < novekucebr) {
        if (bandera[idxbandera] < novekuce[idxkuce]) {
            if (novekuce[idxkuce] - bandera[idxbandera] <= d) {
                if (najboljazasada == -1 ||
                    cena[idxbandera] + novekuce[idxkuce] - bandera[idxbandera] <= cena[najboljazasada] + novekuce[idxkuce] - bandera[najboljazasada])
                    najboljazasada = idxbandera;
            }

            idxbandera++;
        } else {
            sleva[idxkuce] = najboljazasada;
            idxkuce++;
        }
    }

    idxbandera = n-1, idxkuce = novekucebr-1;
    najboljazasada = -1;
    while (idxkuce > -1) {
        if (bandera[idxbandera] > novekuce[idxkuce]) {
            if (bandera[idxbandera] - novekuce[idxkuce] <= d) {
                if (najboljazasada == -1 ||
                    cena[idxbandera] - novekuce[idxkuce] + bandera[idxbandera] <= cena[najboljazasada] - novekuce[idxkuce] + bandera[najboljazasada])
                    najboljazasada = idxbandera;
            }

            idxbandera--;
        } else {
            sdesna[idxkuce] = najboljazasada;
            idxkuce--;
        }
    }

    long long cenebandera = 0, ukupnorastojanje = 0;
    idxkuce = 0;
    int bandera1, bandera2;
    while (idxkuce < novekucebr) {
        while (idxkuce < novekucebr && sleva[idxkuce] == sleva[idxkuce+1]) idxkuce++;
        bandera1 = sleva[idxkuce];
        while (idxkuce < novekucebr && sdesna[idxkuce] == sdesna[idxkuce+1]) idxkuce++;
        bandera2 = sdesna[idxkuce];

        idxkuce++;
        cenebandera = cenebandera + cena[bandera1] + cena[bandera2];
        ukupnorastojanje = ukupnorastojanje + bandera[bandera2] - bandera[bandera1];
    }

   printf("%lld\n", (c-cenebandera)/ukupnorastojanje);
    return 0;
}
