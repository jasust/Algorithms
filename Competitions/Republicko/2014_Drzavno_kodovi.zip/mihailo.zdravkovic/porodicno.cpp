#include <iostream>
#include <stdio.h>
#include <math.h>
#include <algorithm>
using namespace std;

long long maksu = 100000000, s;
struct node{
    int cvor;
    int broj;
    node *next;
};
node* t[1000];
int dfs(int cvor, int zbir){
    node *tmp;
    int maks = zbir;
    tmp = t[cvor]->next;
    int help;
    //cout << cvor << " " << zbir << endl;
    while(tmp != NULL){
        if(zbir + t[tmp->cvor]->broj <= s){
            //cout << "puca 1" << endl;
            help = dfs(tmp->cvor, zbir + t[tmp->cvor]->broj);
            //cout << "puca 2" << endl;
            if(abs(s - help) < abs(s - zbir)){
                maks = help;
                //cout << "puca 3" << endl;
            }
        }
        else{
                //cout << "puca 4" << endl;
            if(abs(s - zbir - t[tmp->cvor]->broj) < abs(s - maks)){
                //cout << "puca 5" << endl;
                maks = zbir + t[tmp->cvor]->broj;
            }
        }
        //cout << "puca 6" << endl;
        tmp = tmp->next;
    }
    return maks;
}
int main()
{
    int n, x, y, sk;
    node *tmp;
    scanf("%i%i", &n, &s);
    for(int i = 1; i <= n; i++){
        scanf("%i%i", &sk, &x);
        t[i] = new node();
        t[i]->next = NULL;
        t[i]->broj = sk;
        for(int j = 0; j < x; j++){
            scanf("%i", &y);
            tmp = new node();
            tmp->next = t[i]->next;
            t[i]->next = tmp;
            tmp->cvor = y;
        }
    }
    int help;
    for(int i = 1; i <= n; i++){
        help = dfs(i, t[i]->broj);
        //cout << "radi dfs";
        if(abs(s - help) < abs(s - maksu)){
            if(s - help < 0)
            maksu = help;
        }
    }
    cout << maksu;
    return 0;
}
/*
8 20
22 3 2 3 4
7 2 6 5
100 0
1 1 7
10 0
2 1 8
2 0
12 0
*/
