#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
using namespace std;
int kuce[300000], c, s, d, m, n, px, px1, px2, ukupno;
struct ban{
    int x;
    int cena;
    bool used;
};
ban niz[300000], k[600000];
void trazimo(int x, int y){
    int j = y;
    int i = x;
    px1 = -1;
    px2 = -1;
    int maks = 100000000;
    for(i = x; i < j; i++){
        if(k[i].cena == -1) break;
        for(int j = y; j > i; j--){
            if(k[j].cena == -1) break;
            if((k[i].cena + k[j].cena + ukupno <= c) && (abs(k[j].x - k[i].x) <= d)){
                if(k[i].cena + k[j].cena < maks){
                    px1 = i;
                    px2 = j;
                }
            }
        }
    }
}
void trazimoparad(int x, int y, int par){
    px = -1;
    int maks = 100000000;
    for(int i = x; i < y; i++){
        if(abs(k[par].x - k[i].x) <= d){
            if(k[par].cena + k[i].cena < maks){
                if(k[par].cena + k[i].cena + ukupno <= c){
                maks = k[par].cena + k[i].cena;
                px = i;
                }
            }
        }
    }
}
void trazimoparal(int x, int y, int par){
    px = -1;
    int maks = 100000000;
    for(int i = y; i > x; i--){
        if(abs(k[par].x - k[i].x) <= d){
            if(k[par].cena + k[i].cena < maks){
                if(k[par].cena + k[i].cena + ukupno <= c){
                maks = k[par].cena + k[i].cena;
                px = i;
                }
            }
        }
    }
}

int main()
{
    scanf("%i%i%i%i", &n, &m, &d, &c);
    for(int i = 0; i < n; i++){
        scanf("%i", &niz[i].cena);
    }
    for(int i = 0; i < n; i++){
        scanf("%i", &niz[i].x);
    }
    for(int i = 0; i < m; i++){
        scanf("%i", &kuce[i]);
    }
    int mi = 0, ni = 0, firsthouse;
    for(int i = 0 ; i < n + m; i++){
        if(ni < n){
            if(mi < m){
                if(niz[ni].x < kuce[mi]){
                    k[i].x = niz[ni].x;
                    k[i].cena = niz[ni].cena;
                    ni++;
                    k[i].used = false;
                }
                else{
                    if(mi == 0) firsthouse = i;
                    k[i].x = kuce[mi];
                    k[i].cena = -1;
                    kuce[mi] = i;
                    mi++;
                    k[i].used = false;
                }
            }
            else{
                k[i].x = niz[ni].x;
                k[i].cena = niz[ni].cena;
                ni++;
                k[i].used = false;
            }
        }
        else{
            if(mi < m){
                if(mi == 0) firsthouse = i;
                k[i].x = kuce[mi];
                k[i].cena = -1;
                kuce[mi] = i;
                mi++;
                k[i].used = false;
            }
        }
    }
    int put = 0;
    int realukupno = 0;
    int i = 0;
    int j = m+n;
    while(i < j){
        cout << "ovde se zabijam";
        trazimo(i, j);
        if(px1 == -1){
            ukupno = realukupno;
            trazimoparad(i + 1, j, i);
            if(px != -1){
                realukupno = k[i].cena + k[px].cena + realukupno;
                put = put + abs(k[i].x - k[px].x);
                i = px;
            }
            ukupno = realukupno;
            trazimoparad(i, j-1, j);
            if(px != -1){
                realukupno = k[j].cena + k[px].cena + realukupno;
                put = put + abs(k[j].x - k[px].x);
                j = px;

            }

        }
        else{
            put = put + abs(k[px2].x - k[px1].x);
            i = px1;
            j = px2;
        }
        i++;
        j--;
    }
    printf("%i", (s - realukupno)/put);
    return 0;
}
/*
4 2 12 32
1 5 17 3
1 5 15 17
9 10
*/
