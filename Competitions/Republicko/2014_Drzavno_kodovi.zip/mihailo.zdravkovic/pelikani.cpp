#include <iostream>
#include <stdio.h>
#include <string>

using namespace std;
int mat[1005][1005], n, q;
int numi[1005], numj[1005], resenja[300000];
int smeri, smerj;

void ispis(){
    printf("  ");
    for(int j = 0; j < n; j++) printf("%i ", numj[j+1]);
    cout << endl;
    for(int i = 0; i < n; i++){
        printf("%i ", numi[i+1]);
        for(int j = 0; j < n; j++){
            printf("%i ", mat[i][j]);
        }
        printf("\n");
    }
    printf("smeri %i smerj %i\n", smeri, smerj);
}
int main()
{
    char ucitavanje[1005];
    int count_help;
    char zero = '0';
    scanf("%i", &n);
    for(int i = 0; i < n; i++){
        scanf("%s", &ucitavanje);
        count_help = 0;
        for(int j = 0; j < n; j++){
            mat[i][j] = int(ucitavanje[j]) - int(zero);
            if(mat[i][j] == 1) count_help++;
        }
        numi[i+1] = count_help;
    }
    for(int j = 0; j < n; j++){
        count_help = 0;
        for(int i = 0; i < n; i++){
            if(mat[i][j] == 1) count_help++;
        }
        numj[j+1] = count_help;
    }
    scanf("%i", &q);
    bool pocetak, usedi, usedj;
    pocetak = true;
    usedi = false;
    usedj = false;
    int upit, upit1, upit2i, upit2j, brres;
    brres = -1;
    smeri = 1;
    smerj = 1;
    int gi, gj, ti, tj;
    for(int i = 0; i < q; i++){
        scanf("%i", &upit);
        if(upit == 1){
          pocetak = false;
          scanf("%i", &upit1);
          if(upit1 == 2 || upit1 == 4){
            if(!usedj){
                for(int l = 1; l <= n; l++) numj[l] = 0;
                for(int k = 1; k <= n; k++){
                    for(int l = 1; l <= numi[k]; l++) numj[l]++;
                }
            }
            if(upit1 == 2) smerj = 1;
            else smerj = -1;
            usedi = true;
          }
          if(upit1 == 1 || upit1 == 3){
            if(!usedi){
                for(int l = 1; l <= n; l++) numi[l] = 0;
                for(int k = 1; k <= n; k++){
                    for(int l = 1; l <= numj[k]; l++) numi[l]++;
                }
            }
            if(upit1 == 2) smeri = 1;
            else smeri = -1;
            usedj = true;
          }
        }
        else {
            //cout << "Trazimo pelikana" << endl;
          scanf("%i%i", &upit2i, &upit2j);
          brres++;
        //cout << "Na kordinatama " << upit2i << " " << upit2j << endl;
          if(pocetak){
            resenja[brres] = mat[upit2i][upit2j];
          }
          else{
            if(smerj == -1){
                gj = n + 1 - upit2j;
                if(smeri == -1){
                    gi = n + 1 - upit2i;
                    tj = n + 1 - upit2j;
                    ti = n + 1 - upit2i;
                }
                else{
                  gi = upit2i;
                  tj = n + 1 - upit2j;
                  ti = upit2i;
                }
            }
            else{
                gj = upit2j;
                if(smeri == -1){
                    gi = n + 1 - upit2i;
                    ti = n + 1 - upit2i;
                    tj = upit2j;
                }
                else{
                     gi = upit2i;
                     ti = upit2i;
                     tj = upit2j;
                }
            }
            //cout << "gledamo da li se nalazi u " << gi << " " << gj << endl;
            //cout << "trazimo resenje " << ti << " " << tj << endl;
            //cout << "mi dobijamo " << numi[gi] << " " << numj[gj] << endl;
            //cout << endl << endl;
            if(usedi){
                if(numi[gi] >= tj) resenja[brres] = 1;
                else resenja[brres] = 0;
            }
            else{
                if(usedj){
                    if(numj[gj] >= ti) resenja[brres] = 1;
                    else resenja[brres] = 0;
                }
            }
          }
        }
    }
    //printf("\n");
    for(int i = 0; i <= brres; i++) printf("%i\n", resenja[i]);
    return 0;
}
/*
5
00000
01000
11000
01010
00000
6
2 5 2
1 3
2 5 2
2 3 2
1 4
2 5 2
*/
