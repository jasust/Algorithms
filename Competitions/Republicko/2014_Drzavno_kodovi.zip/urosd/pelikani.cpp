#include<stdio.h>
int n,q,x[1000][1000],sj,iz,y[300000][3],a1[1000],a2[1000],a12[1000],a21[1000],m1,m2,o[300000],k;
char c[1000][1000];
int main()
      {
      scanf("%d\n",&n);
      for (int i=0;i<n;i++)
          gets(c[i]);
      for (int i=0;i<n;i++)
          {
          for (int j=0;j<n;j++)
              {
              if (c[i][j]=='1')
                 x[i][j]=1;
              else
                  x[i][j]=0;
              }
          }
      scanf("%d",&q);
      for (int i=0;i<q;i++)
          {
          scanf ("%d",&y[i][0]);
                if (y[i][0]==1)
                   scanf ("%d",&y[i][1]);
                else 
                     {
                     scanf ("%d",&y[i][1]);
                     scanf ("%d",&y[i][2]);
                     }
          }
      for (int i=0;i<n;i++)
          {
          for (int j=0;j<n;j++)
              {
              if (x[i][j])
                 {
                 a1[j]++;
                 a2[i]++;
                 }
              }
          }
      for (int j=0;j<n;j++)
          {
          for (int i=0;i<n;i++)
              {
              if (a1[i]>j)
                 a12[j]++;
              }
          }
      for (int j=0;j<n;j++)
          {
          for (int i=0;i<n;i++)
              {
              if (a2[i]>j)
                 a21[j]++;
              }
          }
      for (int i=0;i<q;i++)
          {
          if (y[i][0]==1)
             {
             if (m2%2!=y[i][1]%2)
                m1=m2;
             m2=y[i][1];
             if (m2==1 || m2==3)
                {
                if (iz==0 || sj==2)
                   sj=2;
                else 
                     sj=1;
                }
             else 
                  {
                  if (sj==0 || iz==2)
                     iz=2;
                  else
                      iz=1;
                  }            
             }
          else
              {
              if (iz && sj)
                 {
                 if (sj>iz)
                    {
                    if ((m1==1 && m2==2) || (m2==1 && m1==2))
                       {
                       if (a12[y[i][1]-1]>=y[i][2])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    if ((m1==3 && m2==2) || (m2==3 && m1==2))
                       {
                       if (a12[n-y[i][1]]>=y[i][2])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    if ((m1==1 && m2==4) || (m2==1 && m1==4))
                       {
                       if (a12[y[i][1]]>n-y[i][2])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    if ((m1==4 && m2==3) || (m2==4 && m1==3))
                       {
                       if (a12[n-y[i][1]]>n-y[i][2])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    }
                 else 
                    {
                    if ((m1==1 && m2==2) || (m2==1 && m1==2))
                       {
                       if (a21[y[i][2]-1]>=y[i][1])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    if ((m1==3 && m2==2) || (m2==3 && m1==2))
                       {
                       if (a21[y[i][2]-1]>n-y[i][1])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    if ((m1==1 && m2==4) || (m2==1 && m1==4))
                       {
                       if (a21[n-y[i][2]]>=y[i][1])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    if ((m1==4 && m2==3) || (m2==4 && m1==3))
                       {
                       if (a21[n-y[i][2]]>n-y[i][1])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    }
                 }
              else if (sj)
                   {
                    if (m2==1)
                       {
                        if (a1[y[i][2]-1]>=y[i][1])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    else 
                         {
                         if (a1[y[i][2]-1]>n-y[i][1])
                            o[k++]=1;
                         else
                             o[k++]=0;
                           }
                    }
              else if (iz)
                   {
                    if (m2==2)
                       {
                        if (a2[y[i][1]-1]>=y[i][2])
                          o[k++]=1;
                       else
                           o[k++]=0;
                       }
                    else 
                         {
                         if (a2[y[i][1]-1]>n-y[i][2])
                            o[k++]=1;
                         else
                             o[k++]=0;
                           }
                    }
               else
                   {
                   if (x[y[i][1]-1][y[i][2]-1])
                      o[k++]=1;
                      else 
                      o[k++]=0;
                   }
               }                
          }
           for (int i=0;i<k;i++)
           printf("%d\n",o[i]);
           return 0;
      }  
