#include<stdio.h>
#include<iostream>
#include<math.h>
long long n,m,D,C,c[300000],b[300000],k[300000],d[300000],a,db,x;
int main()
      {
      scanf("%lld %lld %lld %lld",&n,&m,&D,&C);
      for (int i=0;i<n;i++)
          scanf("%lld",&c[i]);
      for (int i=0;i<n;i++)
          scanf("%lld",&b[i]);
      for (int i=0;i<m;i++)
          scanf("%lld",&k[i]);
      db=b[n-1]-b[0];
      for (int i=2;i<C;i++)
          if (C%i==0 && i*db<=C*2)
             d[a++]=i;
      x=d[(a-1)/2];
      printf("%lld",x);
      return 0;
      }      
      
      
              
