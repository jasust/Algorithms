//RandomUsername(Nikola Jovanovic)
//Drzavno 2014
//Pelikani

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#include <algorithm>
#define MAXN 1005

using namespace std;


//bazna, i za svaku poziciju
//4MB po matrici, 20MB ukupno
int a[MAXN][MAXN];
int agl[MAXN][MAXN];
int agd[MAXN][MAXN];
int adl[MAXN][MAXN];
int add[MAXN][MAXN];
//tu i tamo neke gluposti
int n,c,kom,qi,qj,qq;
//bilo?
bool gd,ld;
//poslednja tog tipa
int lastgd,lastld;
//s2 set all
bool s2;
//pozicija lastova
int poz; //12 14 32 34
//kog je
int last;//13 24

//izbroj redove i kolone i popuni countere
//O(n^2)
//pointeri su za slabice
//pravi muskarci koriste copy paste
void cnt(int m)
{
    if(m==0)
{
        for(int i=1;i<=n;i++)
     {
         a[i][0]=0;
        for(int j=1;j<=n;j++)
          a[i][0]+=a[i][j];
     }

    for(int j=1;j<=n;j++)
    {
        a[0][j]=0;
         for(int i=1;i<=n;i++)
          a[0][j]+=a[i][j];
    }
}

    if(m==12)
{
        for(int i=1;i<=n;i++)
     {
         agl[i][0]=0;
        for(int j=1;j<=n;j++)
          agl[i][0]+=agl[i][j];
     }

    for(int j=1;j<=n;j++)
    {
        agl[0][j]=0;
         for(int i=1;i<=n;i++)
          agl[0][j]+=agl[i][j];
    }
}

if(m==14)
{
        for(int i=1;i<=n;i++)
     {
         agd[i][0]=0;
        for(int j=1;j<=n;j++)
          agd[i][0]+=agd[i][j];
     }

    for(int j=1;j<=n;j++)
    {
        agd[0][j]=0;
         for(int i=1;i<=n;i++)
          agd[0][j]+=agd[i][j];
    }
}

if(m==32)
{
        for(int i=1;i<=n;i++)
     {
         adl[i][0]=0;
        for(int j=1;j<=n;j++)
          adl[i][0]+=adl[i][j];
     }

    for(int j=1;j<=n;j++)
    {
        adl[0][j]=0;
         for(int i=1;i<=n;i++)
          adl[0][j]+=adl[i][j];
    }
}

if(m==34)
{
        for(int i=1;i<=n;i++)
     {
         add[i][0]=0;
        for(int j=1;j<=n;j++)
          add[i][0]+=add[i][j];
     }

    for(int j=1;j<=n;j++)
    {
        add[0][j]=0;
         for(int i=1;i<=n;i++)
          add[0][j]+=add[i][j];
    }
}

}

//pomeri matru u neku stranu
//a nikad ne pomeramo
//O(n^2)
void move(int c,int m)
{
if(m==12)
{
     if(c==1)
    {
        //gore
        for(int j=1;j<=n;j++)
        {
            for(int i=1;i<=n;i++)
            {
                if(i<=agl[0][j]) agl[i][j]=1;
              else agl[i][j]=0;
            }
        }
    }
    if(c==3)
    {
        //dole
        for(int j=1;j<=n;j++)
        {
            for(int i=n;i>=1;i--)
            {
                if(n-i+1<=agl[0][j]) agl[i][j]=1;
              else agl[i][j]=0;
            }
        }
    }
    if(c==2)
    {
        //levo
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(j<=agl[i][0]) agl[i][j]=1;
              else agl[i][j]=0;
            }
        }
    }
    if(c==4)
    {
        //desno
        for(int i=1;i<=n;i++)
        {
            for(int j=n;j>=1;j--)
            {
                if(n-j+1<=agl[i][0]) agl[i][j]=1;
              else agl[i][j]=0;
            }
        }
    }

}

if(m==14)
{
     if(c==1)
    {
        //gore
        for(int j=1;j<=n;j++)
        {
            for(int i=1;i<=n;i++)
            {
                if(i<=agd[0][j]) agd[i][j]=1;
              else agd[i][j]=0;
            }
        }
    }
    if(c==3)
    {
        //dole
        for(int j=1;j<=n;j++)
        {
            for(int i=n;i>=1;i--)
            {
                if(n-i+1<=agd[0][j]) agd[i][j]=1;
              else agd[i][j]=0;
            }
        }
    }
    if(c==2)
    {
        //levo
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(j<=agd[i][0]) agd[i][j]=1;
              else agd[i][j]=0;
            }
        }
    }
    if(c==4)
    {
        //desno
        for(int i=1;i<=n;i++)
        {
            for(int j=n;j>=1;j--)
            {
                if(n-j+1<=agd[i][0]) agd[i][j]=1;
              else agd[i][j]=0;
            }
        }
    }

}

if(m==32)
{
     if(c==1)
    {
        //gore
        for(int j=1;j<=n;j++)
        {
            for(int i=1;i<=n;i++)
            {
                if(i<=adl[0][j]) adl[i][j]=1;
              else adl[i][j]=0;
            }
        }
    }
    if(c==3)
    {
        //dole
        for(int j=1;j<=n;j++)
        {
            for(int i=n;i>=1;i--)
            {
                if(n-i+1<=adl[0][j]) adl[i][j]=1;
              else adl[i][j]=0;
            }
        }
    }
    if(c==2)
    {
        //levo
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(j<=adl[i][0]) adl[i][j]=1;
              else adl[i][j]=0;
            }
        }
    }
    if(c==4)
    {
        //desno
        for(int i=1;i<=n;i++)
        {
            for(int j=n;j>=1;j--)
            {
                if(n-j+1<=adl[i][0]) adl[i][j]=1;
              else adl[i][j]=0;
            }
        }
    }

}

if(m==34)
{
     if(c==1)
    {
        //gore
        for(int j=1;j<=n;j++)
        {
            for(int i=1;i<=n;i++)
            {
                if(i<=add[0][j]) add[i][j]=1;
              else add[i][j]=0;
            }
        }
    }
    if(c==3)
    {
        //dole
        for(int j=1;j<=n;j++)
        {
            for(int i=n;i>=1;i--)
            {
                if(n-i+1<=add[0][j]) add[i][j]=1;
              else add[i][j]=0;
            }
        }
    }
    if(c==2)
    {
        //levo
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(j<=add[i][0]) add[i][j]=1;
              else add[i][j]=0;
            }
        }
    }
    if(c==4)
    {
        //desno
        for(int i=1;i<=n;i++)
        {
            for(int j=n;j>=1;j--)
            {
                if(n-j+1<=add[i][0]) add[i][j]=1;
              else add[i][j]=0;
            }
        }
    }

}

}

//za input
char pom[MAXN];
int len;

//mejn
int main()
{
    //input
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
           scanf("%s",pom);
           for(int k=0;k<=n-1;k++)
               a[i][k+1]=pom[k]-'0';
    }
    //samo jednom countujemo a
    scanf("%d",&c);
    cnt(0);
    s2=false;
    gd=false;
    ld=false;
    //kveriji
    for(int i=1;i<=c;i++)
    {
        scanf("%d",&kom);
        //ako je kveri pomeranje
        if(kom==1)
        {
            //namesti poziciju, poslednji da li je gd ili ld
            //uvek O(1) osim jednom (goto x)
            //tacno koji je poslednji za svaki
            //ovo se radi uvek
            scanf("%d",&qq);
            if(qq==1 || qq==3)
              { gd=true; lastgd=qq; last=13;}
            else
              { ld=true; lastld=qq; last=24;}
            poz=lastgd*10+lastld;

            //x:
            //ovo samo jednom, kad se sve zdepa
            //generisati one matrice
            //oko 21*n^2=21M se odradi sto je i vise nego bleja
            if(gd && ld && !s2)
            {
                 s2=true;//nemoj opet

                    //gore levo smo
                     if(poz==12)
                     {
                         //svuda kopiraj pocetnu matricu
                         for(int i=1;i<=n;i++)
                            for(int j=1;j<=n;j++)
                                {
                                    agl[i][j]=a[i][j];
                                    adl[i][j]=a[i][j];
                                    add[i][j]=a[i][j];
                                    agd[i][j]=a[i][j];
                                }

                        //kao da je otisao gore pa onda levo
                        if(last==24)//goredole i odjednom levodesno
                        {
                            cnt(12);  move(1,12);
                            cnt(12); move(2,12);

                            cnt(14); move(1,14);
                            cnt(14);  move(4,14);

                            cnt(32);  move(1,32);
                            cnt(32); move(2,32);
                            cnt(32);  move(3,32);

                            cnt(34); move(1,34);
                            cnt(34); move(4,34);
                            cnt(34);  move(3,34);
                        }
                        //isao je levo pa onda gore
                        else
                        {

                       cnt(12);      move(2,12);
                      cnt(12);       move(1,12);

                   cnt(14);         move(2,14);
                   cnt(14);         move(1,14);
                   cnt(14);         move(4,14);

                     cnt(32);       move(2,32);
                    cnt(32);        move(3,32);

                  cnt(34);          move(2,34);
                  cnt(34);          move(3,34);
                 cnt(34);           move(4,34);
                        }

                     }
                     //isto to samo goredesno znaci
                     if(poz==14)
                     {
                         for(int i=1;i<=n;i++)
                            for(int j=1;j<=n;j++)
                                {
                                    agl[i][j]=a[i][j];
                                    adl[i][j]=a[i][j];
                                    add[i][j]=a[i][j];
                                    agd[i][j]=a[i][j];
                                }

                        if(last==24)//gore pa desno
                        {
                     cnt(12);        move(1,12);
                    cnt(12);        move(2,12);

                     cnt(14);       move(1,14);
                    cnt(14);        move(4,14);

                   cnt(32);         move(1,32);
                   cnt(32);         move(2,32);
                   cnt(32);         move(3,32);

                 cnt(34);           move(1,34);
                 cnt(34);           move(4,34);
                  cnt(34);          move(3,34);
                        }
                        else //desno pa gore
                        {
                 cnt(12);            move(4,12);
                 cnt(12);            move(1,12);
                cnt(12);             move(2,12);

                   cnt(14);         move(4,14);
                   cnt(14);         move(1,14);

                   cnt(32);         move(4,32);
                   cnt(32);         move(3,32);
                   cnt(32);         move(2,32);

                   cnt(34);         move(4,34);
                   cnt(34);         move(3,34);
                        }
                     }

                    //dole levo
                     if(poz==32)
                     {
                         for(int i=1;i<=n;i++)
                            for(int j=1;j<=n;j++)
                                {
                                    agl[i][j]=a[i][j];
                                    adl[i][j]=a[i][j];
                                    add[i][j]=a[i][j];
                                    agd[i][j]=a[i][j];
                                }

                        if(last==24)//prvo dole pa levo
                        {
                   cnt(32);         move(3,32);
                   cnt(32);         move(2,32);

                 cnt(34);           move(3,34);
                 cnt(34);           move(4,34);

                cnt(12);             move(3,12);
                cnt(12);             move(2,12);
                 cnt(12);            move(1,12);

                   cnt(14);         move(3,14);
                   cnt(14);         move(4,14);
                    cnt(14);        move(1,14);
                        }
                        else //levo pa dole
                        {
                  cnt(12);           move(2,12);
                  cnt(12);           move(1,12);

                   cnt(14);         move(2,14);
                   cnt(14);         move(1,14);
                   cnt(14);         move(4,14);

                  cnt(32);          move(2,32);
                  cnt(32);          move(3,32);

                cnt(34);            move(2,34);
                cnt(34);            move(3,34);
               cnt(34);             move(4,34);
                        }
                     }
                     if(poz==34) //dole desno
                     {
                         for(int i=1;i<=n;i++)
                            for(int j=1;j<=n;j++)
                                {
                                    agl[i][j]=a[i][j];
                                    adl[i][j]=a[i][j];
                                    add[i][j]=a[i][j];
                                    agd[i][j]=a[i][j];
                                }

                        if(last==24)//dole pa desno
                        {
                  cnt(34);          move(3,34);
                  cnt(34);          move(4,34);

                   cnt(32);         move(3,32);
                  cnt(32);          move(2,32);

                   cnt(14);         move(3,14);
                   cnt(14);         move(4,14);
                   cnt(14);         move(1,14);

                   cnt(12);          move(3,12);
                  cnt(12);           move(2,12);
                  cnt(12);           move(1,12);
                        }
                        else //desno pa dole
                        {
                cnt(34);            move(4,34);
                cnt(34);            move(3,34);

                     cnt(14);        move(4,14);
                     cnt(14);       move(1,14);

                 cnt(32);           move(4,32);
                 cnt(32);           move(3,32);
                 cnt(32);           move(2,32);

                     cnt(12);        move(4,12);
                     cnt(12);        move(1,12);
                     cnt(12);        move(2,12);
                        }
                     }
                }
        }
        if(kom==2)//ako je kveri za ispis O(1) bre!
        {
            scanf("%d %d",&qi,&qj);//ucitaj i j
            if(!gd && !ld)//nije se jos nista desilo ispisi iz a
           {
              printf("%d\n",a[qi][qj]);
           }
            else if(gd && !ld)//samo goredole je bilo
            {
                if(lastgd==1)//poslednj je bilo gore
                {
                    if(qi<=a[0][qj])
                     printf("1\n");
                    else printf("0\n");
                }
                if(lastgd==3) //poslednje je bilo dole
                {
                  //  cout<<a[0][qj]<<" "<<qj<<" "<<n-qj+1<<"!"<<endl;
                    if(n-qi+1<=a[0][qj])
                     printf("1\n");
                    else printf("0\n");
                }
            }
            else if(!gd && ld) //samo levodesno
            {//cout<<"tu"<<lastgd<<endl;
                if(lastld==2) //poslednje je bilo levo
                {
                    if(qj<=a[qi][0])
                     printf("1\n");
                    else printf("0\n");
                }
                if(lastld==4) //poslednje je bilo desno
                {//cout<<"Tu";
                    if(n-qj+1<=a[qi][0])
                     printf("1\n");
                    else printf("0\n");
                }
            }
            else
            {
               //sve je bilo sad citamo iz onih
                if(poz==12)
                 printf("%d\n",agl[qi][qj]);
                if(poz==14)
                 printf("%d\n",agd[qi][qj]);
                if(poz==32)
                 printf("%d\n",adl[qi][qj]);
                if(poz==34)
                 printf("%d\n",add[qi][qj]);
            }
        }
    }
    return 0;
}
