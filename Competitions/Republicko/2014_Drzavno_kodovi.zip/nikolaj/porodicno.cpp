//RandomUsername(Nikola Jovanovic)
//Drzavno 2014
//Porodicno Stablo

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#define MAXN 10005

using namespace std;

//srecni su do 10k za 3 subtaska O(ns) staje
//memorija:moze stane 250k ints, a ja cuvam reda O(n) sto je tu i tamo nesto
struct node
{
    int l;
    vector<int> s;
    int sz;
};

//prva ona dva
int n,ss;
//graf i brojanje
node g[MAXN];
int cnt[2*MAXN];
//za root
bool notrt[MAXN];
//nesto
int pom;
int pom2;
int root;
int best;
int it1,it2;
int ind;

//abs je gej
int aps(int x)
{
    if(x<0) return -x;
    return x;
}

//fishujemo
int curr,last;


void fish()
{

//ne brojimo preko 20k, jer ako je 10k sigurno je do 20k resenje
//ovo je ok jer 20M staje
//do 20k za svaki slucaj
for(int j=0;j<=20000;j++)
{
              if(cnt[j]!=curr && cnt[j]>0)//produzi
              {
                  if(j>=ss) //ne produzuj dobices samo jos gore
                   break;

                  ind=j+g[curr].l; //indeks gde treba
                  if(ind<=20000 && !cnt[ind]) //samo nove koje si dobio
                   cnt[ind]=curr;
              }
}

if(g[curr].sz==0)//list, za svaki list nadji najblizi
{
         it1=ss, it2=ss;
         while( ! (cnt[it1] || cnt[it2] ) )//idi i levo i desno
            {
                it1--;
                it2++;
            }
         if(it2-ss < aps(best-ss) )//ako ima bolje resenje to je to
         {
             if(cnt[it1])
              best=it1;
             else
              best=it2;
         }
}
else//ako nije list
{
    last=curr;
   for(int i=0;i<=g[curr].sz-1;i++)//idemo redom fishujemo svu decu
   {
    curr=g[curr].s[i]; fish();
   }
    curr=last;
}



for(int j=0;j<=20000;j++)//obrisimo
{
              if(cnt[j]==curr)
              {
                  cnt[j]=0;
              }
}

return;
}

int main()
{
    scanf("%d %d",&n,&ss);
    best=0;//moze nula
    for(int i=1;i<=n;i++)
    {
        scanf("%d %d",&g[i].l,&g[i].sz);
        for(int j=1;j<=g[i].sz;j++)
        {
            scanf("%d",&pom2);
            g[i].s.push_back(pom2);
            notrt[pom2]=true;
        }
    }

    for(int i=1;i<=n;i++)
     if(!notrt[i])
        {root=i; break;}

    cnt[0]=300000;
    curr=root;
    fish();
    printf("%d\n",best);
}
