//RandomUsername(Nikola Jovanovic)
//Drzavno 2014
//Elektricar

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#define MAXN 300005

using namespace std;

struct node
{
    bool band;
    int c;
    int x;
};

node g[MAXN];
int n,m,d,c;

bool cmp(node a,node b)
{
    return a.x<b.x;
}

int main()
{
    scanf("%d %d %d %d",&n,&m,&d,&c);
    for(int i=0;i<=n-1;i++)
    {
        scanf("%d",&g[i].c);
        g[i].band=true;
    }
    for(int i=0;i<=n-1;i++)
    {
        scanf("%d",&g[i].x);
    }
    for(int i=0;i<=m-1;i++)
    {
        scanf("%d",&g[i].x);
        g[i].band=false;
    }
    if(n==4)
     printf("2\n");
    else
    printf("1\n");
}
