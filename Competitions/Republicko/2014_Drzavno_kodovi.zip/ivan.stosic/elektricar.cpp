#include <cstdio>
#include <cstring>
#include <algorithm>
#define MAXN 524288
#define OFFS 524287
#define DEBUG (false)
using namespace std;

//A - koordinate bandera
//B - koordinate kuca
//C - cene bandera
//L - okupacija bandere sa leve strane

int A[300005],B[300005],C[300005],N,M,D,CCC,S;
long long Cx,Dp[300005];
long long najponuda;
bool L[300005];

void ucitaj(){
    int i,j;
    scanf("%d%d%d%d",&N,&M,&D,&CCC);
    for (i=1; i<=N; i++) scanf("%d",C+i);
    for (i=1; i<=N; i++) scanf("%d",A+i);
    for (i=1; i<=M; i++) scanf("%d",B+i);
    A[N+1] = 1000000001;
    B[M+1] = 1000000001;
    i=j=1;
    bool kucas=false;
    while (i+j < N+M+2){
        if (A[i] < B[j]){
            L[i] = kucas;
            kucas = false;
            i++;
        } else {
            kucas = true;
            j++;
        }
    }
}

void resi(){
    //nude se samo bandere koje nemaju kucu levo od sebe
    najponuda = C[1] - (long long)A[1]*S;
    Dp[1] = 0;
    int i;
    for (i=2; i<=N; i++){
        if (L[i]){
            Dp[i] = najponuda + C[i] + (long long)A[i]*S;
        } else {
            Dp[i] = min(Dp[i-1],najponuda + C[i] + (long long)A[i]*S);
            najponuda = min(najponuda, Dp[i-1] + C[i] - (long long)A[i]*S);
        }
    }
    Cx = Dp[N];
}

long long Tree[2*MAXN];
int RMC[2*MAXN],PPP,LLL;

void init_tree(){
    int i,j;
    for (i=MAXN; i<2*MAXN; i++) RMC[i] = i;
    for (i=OFFS; i>=1; i--) RMC[i] = RMC[2*i+1];
}

void upisi(int x,long long w){
    x += OFFS;
    Tree[x] = w;
    while (x>1){
        x /= 2;
        Tree[x] = min(Tree[2*x], Tree[2*x+1]);
    }
}

inline long long dobavi(int l,int r){
    l += OFFS;
    r += OFFS;
    long long z = 2000000000000000000ll;
    while (l<=r){
        while (l%2 == 0 && RMC[l/2] <= r) l/=2;
        z = min(z,Tree[l]);
        l = RMC[l]+1;
    }
    return z;
}

void resi_budz(){
    //e sad se sve nude
    memset(Tree,63,sizeof(Tree));
    PPP = 1;
    LLL = 1;
    upisi(1,C[1] - (long long)A[1]*S);
    Dp[1] = 0;
    int i;
    for (i=2; i<=N; i++){
        //izbacivanje
        while (A[i] - A[PPP] > D) PPP++;
        najponuda = dobavi(PPP,i-1);
        if (DEBUG) printf("naj %d %lld\n",i,najponuda);
        if (L[i]){
            Dp[i] = najponuda + C[i] + (long long)A[i]*S;
            //upisi(i,Dp[i-1] + C[i] - (long long)A[i]*S);
        } else {
            Dp[i] = min(Dp[i-1],najponuda + C[i] + (long long)A[i]*S);
            upisi(i,Dp[i-1] + C[i] - (long long)A[i]*S);
        }
    }
    if (DEBUG) for (i=1; i<=N; i++) printf("dp %d %lld\n",i,Dp[i]);
    Cx = Dp[N];
}

int main(){
    ucitaj();
    int l,r,m;
    l=1;
    r=1000000000;
    init_tree();
    while (l<=r){
        m = (l+r)/2;
        S = m;
        if (D==1000000000) resi(); else resi_budz();
        if (DEBUG) printf("m = %d, exp = %d got = %lld\n",m,CCC,Cx);
        if (Cx > CCC){
            r = m-1;
        } else
        if (Cx < CCC){
            l = m+1;
        } else {
            printf("%d\n",m);
            return 0;
        }
    }
    printf("1\n");
    return 0;
}
