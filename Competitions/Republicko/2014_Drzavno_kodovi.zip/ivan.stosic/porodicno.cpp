#include <cstdio>
#include <cstring>
#include <algorithm>
#define MOD1 1000100009
#define MOD2 1000100007
#define DOUBLES (false)
using namespace std;

int H1[10005],H2[10005];

int O[10005],N,S,PA[10005],A[10005],la=MOD2,hb=0,rn;
bool Root[10005];

void ucitajisredi(){
    int i,c,tot=0,j;
    scanf("%d%d",&N,&S);
    for (i=1; i<=N; i++) Root[i] = true;
    for (i=1; i<=N; i++){
        scanf("%d%d",A+i,&c);
        PA[i] = tot+1;
        for (j=1; j<=c; j++){
            scanf("%d",&O[tot+j]);
            //printf("not root %d\n",O[tot+j]);
            Root[O[tot+j]] = false;
        }
        tot += c;
    }
    for (i=1; i<=N; i++) if (Root[i]) rn = i;
    PA[N+1] = tot+1;
}

inline bool ima2(int x){
    return (H1[x]!=0)||(H2[x]!=0);
}

inline bool ima1(int x){
    return H1[x]!=0;
}

void rek(int x){
    //printf("rek %d\n",x);
    int i,j;
    //dinamicki ubacimo
    for (i=S; i>=0; i--){
        j = i+A[x];
        if (DOUBLES){
            if (!ima2(i)) continue;
        } else {
            if (!ima1(i)) continue;
        }
        //printf("ima %d %d hb = %d\n",i,j,hb);
        if (j > S){
            la = min(la,j);
        } else {
            H1[j] += H1[i];
            if (H1[j] >= MOD1) H1[j] -= MOD1;
            if (DOUBLES){
                H2[j] += H2[i];
                if (H2[j] >= MOD2) H2[j] -= MOD2;
            }
            hb = max(hb,j);
        }
    }

    if (hb==S){
        printf("%d\n",S);
        exit(0);
    }

    //rekurzija
    for (i=PA[x]; i<PA[x+1]; i++) rek(O[i]);
    //vratimo se
    for (i=A[x]; i<=S; i++){
        j = i-A[x];
        //potencijalno obrisi ovaj red
        if (DOUBLES){
            if (!ima2(j)) continue;
        } else {
            if (!ima1(j)) continue;
        }
        H1[i] -= H1[j];
        if (H1[i] < 0) H1[i] += MOD1;
        if (DOUBLES){
            H2[i] -= H2[j];
            if (H2[i] < 0) H2[i] += MOD2;
        }
    }
}

int main(){
    //freopen("porodicno.in","r",stdin);
    H1[0] = 1;
    H2[0] = 1;
    ucitajisredi();
    //printf("%d\n",rn);
    rek(rn);
    //printf("%d %d\n",hb,la);
    if (S-hb <= la-S){
        printf("%d\n",hb);
    } else {
        printf("%d\n",la);
    }
    return 0;
}

