#include <cstdio>
#include <cstring>
#include <algorithm>
#define DEBUG (false)
using namespace std;

bool gore,dole,levo,desno,hpak,vpak;

int N;
char A[1005][1005];
int Red[1005],Kolona[1005];

void ucitaj(){
    scanf("%d",&N);
    int i;
    for (i=1; i<=N; i++) scanf("%s",A[i]+1);
}

void prebroji(){
    int i,j;
    //redove
    for (i=1; i<=N; i++){
        Red[i] = 0;
        for (j=1; j<=N; j++) if (A[i][j] == '1') Red[i]++;
    }
    //kolone
    for (j=1; j<=N; j++){
        Kolona[j] = 0;
        for (i=1; i<=N; i++) if (A[i][j] == '1') Kolona[j]++;
    }
}

//mrzim da kucam jedno isto 4 puta

void prepakuj_h(){
    if (hpak) return;
    hpak = true;
    int i,j;
    prebroji();
    memset(A,'0',sizeof(A));
    for (i=1; i<=N; i++){
        for (j=1; j<=Red[i]; j++) A[i][j] = '1';
    }
    prebroji();
}

void prepakuj_v(){
    if (vpak) return;
    vpak = true;
    int i,j;
    prebroji();
    memset(A,'0',sizeof(A));
    for (j=1; j<=N; j++){
        for (i=1; i<=Kolona[j]; i++) A[i][j] = '1';
    }
    prebroji();
}

void prepakuj_levo(){
    prepakuj_h();
    levo = true;
    desno = false;
}

void prepakuj_desno(){
    prepakuj_h();
    levo = false;
    desno = true;
}

void prepakuj_gore(){
    prepakuj_v();
    gore = true;
    dole = false;
}

void prepakuj_dole(){
    prepakuj_v();
    gore = false;
    dole = true;
}

inline void stampaj(char x){
    if (x) puts("1"); else puts("0");
}

inline bool resi_polje(int b,int c){
    if (desno) c = N+1-c;
    if (dole) b = N+1-b;
    if (hpak){
        return Red[b]>=c;
    } else
    if (vpak){
        return Kolona[c]>=b;
    } else {
        return A[b][c] == '1';
    }
}

void resavaj(){
    int Q,a,b,c;
    scanf("%d",&Q);
    while (Q--){
        if (DEBUG){
            for (int i=1; i<=N; i++){
                for (int j=1; j<=N; j++){
                    printf("%c",resi_polje(i,j)?'1':'0');
                }
                puts("");
            }
        }
        scanf("%d",&a);
        if (a==1){
            scanf("%d",&b);
            if (b==1) prepakuj_gore(); else
            if (b==2) prepakuj_levo(); else
            if (b==3) prepakuj_dole(); else
            if (b==4) prepakuj_desno();
        } else {
            scanf("%d%d",&b,&c);
            stampaj(resi_polje(b,c));
        }
    }
}

int main(){
    ucitaj();
    resavaj();
    return 0;
}
