#include <cstdio>

const int MaxN = 1005;
bool pelikan[MaxN][MaxN];
bool gore, prvoG;
bool levo, prvoL;
bool isaoHor, isaoVer;
int N, Q;
int com, a, b;
char red[MaxN];
int x, y;

void OutputMatrix()
{
    for (int i = 1; i <= N; i++)
    {
        for (int j = 1; j <= N; j++)
            printf("%d ", pelikan[i][j]);
        printf("\n");
    }
}

void MrdajLevo()
{
    prvoL = true;
    levo = true;
    for (int i = 1; i <= N; i++)
    {
        int prviBrojac = 1;
        while (prviBrojac <= N && pelikan[i][prviBrojac])
            prviBrojac++;
        int drugiBrojac = prviBrojac + 1;
        while (drugiBrojac <= N)
            if (pelikan[i][drugiBrojac])
            {
                pelikan[i][prviBrojac] = true;
                pelikan[i][drugiBrojac] = false;
                prviBrojac++;
                drugiBrojac++;
            }
            else
                drugiBrojac++;
    }
    // OutputMatrix();
}

void MrdajDesno()
{
    prvoL = false;
    levo = false;
    for (int i = 1; i <= N; i++)
    {
        int prviBrojac = N;
        while (prviBrojac >= 1 && pelikan[i][prviBrojac])
            prviBrojac--;
        int drugiBrojac = prviBrojac - 1;
        while (drugiBrojac >= 1)
            if (pelikan[i][drugiBrojac])
            {
                pelikan[i][prviBrojac] = true;
                pelikan[i][drugiBrojac] = false;
                prviBrojac--;
                drugiBrojac--;
            }
            else
                drugiBrojac--;
    }
    // OutputMatrix();
}

void MrdajGore()
{
    prvoG = true;
    gore = true;
    for (int i = 1; i <= N; i++)
    {
        int prviBrojac = 1;
        while (prviBrojac <= N && pelikan[prviBrojac][i])
            prviBrojac++;
        int drugiBrojac = prviBrojac + 1;
        while (drugiBrojac <= N)
            if (pelikan[drugiBrojac][i])
            {
                pelikan[prviBrojac][i] = true;
                pelikan[drugiBrojac][i] = false;
                prviBrojac++;
                drugiBrojac++;
            }
            else
                drugiBrojac++;
    }
    // OutputMatrix();
}

void MrdajDole()
{
    prvoG = false;
    gore = false;
    for (int i = 1; i <= N; i++)
    {
        int prviBrojac = N;
        while (prviBrojac >= 1 && pelikan[prviBrojac][i])
            prviBrojac--;
        int drugiBrojac = prviBrojac - 1;
        while (drugiBrojac >= 1)
            if (pelikan[drugiBrojac][i])
            {
                pelikan[prviBrojac][i] = true;
                pelikan[drugiBrojac][i] = false;
                prviBrojac--;
                drugiBrojac--;
            }
            else
                drugiBrojac--;
    }
    // OutputMatrix();
}

int main()
{
    scanf("%d", &N);
    for (int j = 1; j <= N; j++)
    {
        scanf("%s", &red);
        for (int i = 1; i <= N; i++)
            pelikan[j][i] = (red[i - 1] == '1');
    }
    scanf("%d", &Q);
    for (int k = 1; k <= Q; k++)
    {
        scanf("%d", &com);
        if (com == 1)
        {
            scanf("%d", &a);
            switch (a)
            {
                case 1:
                    if (isaoVer)
                        gore = true;
                    else
                    {
                        if (isaoHor)
                            if (levo)
                                MrdajLevo();
                            else
                                MrdajDesno();
                        MrdajGore();
                        isaoVer = true;
                    }
                    break;
                case 2:
                    if (isaoHor)
                        levo = true;
                    else
                    {
                        if (isaoVer)
                            if (gore)
                                MrdajGore();
                            else
                                MrdajDole();
                        MrdajLevo();
                        isaoHor = true;
                    }
                    break;
                case 3:
                    if (isaoVer)
                        gore = false;
                    else
                    {
                        if (isaoHor)
                            if (levo)
                                MrdajLevo();
                            else
                                MrdajDesno();
                        MrdajDole();
                        isaoVer = true;
                    }
                    break;
                case 4:
                    if (isaoHor)
                        levo = false;
                    else
                    {
                        if (isaoVer)
                            if (gore)
                                MrdajGore();
                            else
                                MrdajDole();
                        MrdajDesno();
                        isaoHor = true;
                    }
                    break;
            }
        }
        else
        {
            scanf("%d %d", &a, &b);
            if (!isaoHor && !isaoVer)
                printf("%d\n", pelikan[a][b]);
            if (isaoHor && !isaoVer)
                if(prvoL == levo)
                    printf("%d\n", pelikan[a][b]);
                else
                    printf("%d\n", pelikan[a][N - b + 1]);
            if (!isaoHor && isaoVer)
                if(prvoG == gore)
                    printf("%d\n", pelikan[a][b]);
                else
                    printf("%d\n", pelikan[N - a + 1][b]);
            if (isaoHor && isaoVer)
            {
                if (prvoL == levo)
                    x = b;
                else
                    x = N - b + 1;
                if (prvoG == gore)
                    y = a;
                else
                    y = N - a + 1;
                printf("%d\n", pelikan[y][x]);
            }
        }
    }
    return 0;
}
