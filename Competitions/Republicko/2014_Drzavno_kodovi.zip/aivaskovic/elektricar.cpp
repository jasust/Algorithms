#include <cstdio>
#include <queue>

using namespace std;

const int maxN = 300005;

struct BandS
{
    int X;
    int V;
};

bool operator <(BandS a, BandS b)
{
    return a.V > b.V;
}

int n, m, D;
int C;
int tryS, gotC;
int leftBound, rightBound;
int kucaX[maxN], banderaC[maxN], banderaX[maxN];
int idxKuce;
int sol[maxN];
BandS novi;
int prviMoguci;

int FindC(int S)
{
    int tryC;
    idxKuce = 1;
    while (idxKuce <= m && kucaX[idxKuce] < banderaX[1])
        idxKuce++;
    priority_queue <BandS> DP;
    for (int i = 1; i <= n; i++)
    {
        while (!DP.empty() && banderaX[i] - DP.top().X > D)
            DP.pop();
        if (!DP.empty())
            sol[i] = DP.top().V + banderaC[i] + S * banderaX[i];
        if (idxKuce <= m && kucaX[idxKuce] < banderaX[i])
        {
            while (idxKuce <= m && kucaX[idxKuce] < banderaX[i])
                idxKuce++;
            if (idxKuce == m + 1)
                prviMoguci = i + 1;
        }
        else
        {
            novi.X = banderaX[i];
            novi.V = sol[i - 1] + banderaC[i] - S * banderaX[i];
            DP.push(novi);
        }
    }
    tryC = sol[prviMoguci];
    for (int i = prviMoguci + 1; i <= n; i++)
        if (tryC > sol[prviMoguci])
            tryC = sol[prviMoguci];
    return tryC;
}

int main()
{
    scanf("%d %d %d %d", &n, &m, &D, &C);
    for (int i = 1; i <= n; i++)
        scanf("%d", &banderaC[i]);
    for (int i = 1; i <= n; i++)
        scanf("%d", &banderaX[i]);
    for (int i = 1; i <= m; i++)
        scanf("%d", &kucaX[i]);
    leftBound = 1;
    rightBound = C / (n - 1);
    while (leftBound < rightBound)
    {
        tryS = (leftBound + rightBound) / 2;
        gotC = FindC(tryS);
        if (gotC == C)
        {
            leftBound = tryS;
            rightBound = tryS;
        }
        else
            if (C < gotC)
                rightBound = tryS - 1;
            else
                leftBound = tryS + 1;
    }
    printf("%d", leftBound);
    return 0;
}
