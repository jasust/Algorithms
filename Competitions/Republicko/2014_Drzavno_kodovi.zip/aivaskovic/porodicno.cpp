/*
    Da se zna da sve do poslednjih 45 minuta
    nisam primetio da se biraju samo neki sa
    puta. Zato idemo na 30 poena!
*/

#include <cstdio>

const int MaxN = 10005;
const int MaxVal = 100005;
const int MaxS = 10005;

struct TreeNode
{
    TreeNode * parent;
    int val;
};

int abs(int a)
{
    return a > 0? a : -a;
}

int diff(int a, int b)
{
    return abs(a - b);
}

int N;
int S;
int k, idx;
int currClosest = MaxVal;
bool canReach[MaxVal];
TreeNode * node[MaxN];

void TraverseBack(TreeNode * bottom)
{
    if (bottom != NULL)
    {
        for (int i = MaxS; i > 0; i--)
            if (i - bottom -> val >= 0 && canReach[i - bottom -> val])
                canReach[i] = true;
        TraverseBack(bottom -> parent);
    }
}

void FindSol(TreeNode * bottom)
{
    for (int i = 1; i < MaxS; i++)
        canReach[i] = false;
    canReach[0] = true;
    canReach[bottom -> val] = true;
    TraverseBack(bottom -> parent);
    for (int i = 1; i <= MaxS; i++)
        if (canReach[i] && diff(i, S) <= diff(currClosest, S) && i <= currClosest)
            currClosest = i;
}

int main()
{
    scanf("%d %d", &N, &S);
    for (int i = 1; i <= N; i++)
    {
        node[i] = new TreeNode;
        node[i] -> val = 0;
        node[i] -> parent = NULL;
    }
    for (int i = 1; i <= N; i++)
    {
        scanf("%d %d", &node[i] -> val, &k);
        for (int j = 0; j < k; j++)
        {
            scanf("%d", &idx);
            node[idx] -> parent = node[i];
        }
        if (diff(node[i] -> val, S) <= diff(currClosest, S) && node[i] -> val <= currClosest)
            currClosest = node[i] -> val;
    }
    for (int i = 1; i <= N; i++)
        FindSol(node[i]);
    printf("%d", currClosest);
    return 0;
}
