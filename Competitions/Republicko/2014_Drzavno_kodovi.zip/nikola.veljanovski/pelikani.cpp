#include <stdio.h>
#include <cstdlib>
#include <iostream>

using namespace std;

char niz[1005][1005];
int redovi[1005][3], kolone[1005][3];
char izlaz[300005];

int main()
{
    int n, komande, tip, a, b, strana, provera = 1, br = 0;
    scanf("%d", &n);
    redovi[0][0] = kolone[0][0] = 1;
    for(int i = 0; i < n; i++)
    {
            redovi[i][0] = 0;
            kolone[i][0] = 0;
    }
    
    for(int i = 0; i < n; i++)
    {
            scanf("%s", niz[i]);
            for(int k = 0; k < n; k++)
            {
                    if(niz[i][k] == '1')
                    {
                            redovi[i][0]++;
                            kolone[k][0]++;          
                    }
            }
    }
    
    scanf("%d", &komande);
    
    while(komande--)
    {
            scanf("%d", &tip);
            /*if(tip == 2)
            {
                    scanf("%d %d", &a, &b);
                    //if(niz[a-1][b-1] == '1')
                    //{
                      //      printf("1\n");
                    //}
            }*/
            
            if(tip == 1)
            {
                    provera = 0;
                    scanf("%d", &strana);
                    if(strana == 1)
                    {
                            for(int i = 0; i < n; i++)
                                    redovi[i][0] = 0;  
                            for(int i = 0; i < n; i++)
                                    for(int k = 0; k < kolone[i][0]; k++)
                                            redovi[k][0]++;
                            kolone[0][1] = 1;
                    }
                    
                    else if(strana == 3)
                    {
                            for(int i = 0; i < n; i++)
                                    redovi[i][0] = 0;
                            for(int i = 0; i < n; i++)
                                    for(int k = 0; k < kolone[i][0]; k++)
                                            redovi[n-k-1][0]++;
                            kolone[0][1] = 3;
                    }
                    
                    else if(strana == 2)
                    {
                            for(int i = 0; i < n; i++)
                                    kolone[i][0] = 0;
                            for(int i = 0; i < n; i++)
                                    for(int k = 0; k < redovi[i][0]; k++)
                                            kolone[k][0]++;
                            redovi[0][1] = 2;
                    }
                    
                    else
                    {
                            for(int i = 0; i < n; i++)
                                    kolone[i][0] = 0;
                            for(int i = 0; i < n; i++)
                                    for(int k = 0; k < redovi[i][0]; k++)
                                            kolone[n-k-1][0]++;
                            redovi[0][1] = 4;
                    }
                    
                    /*for(int i = 0; i < n; i++)
                            printf("%d ", redovi[i][0]);
                    printf("\n");
                    for(int i = 0; i < n; i++)
                            printf("%d ", kolone[i][0]);
                    printf("\n");*/
            }
            
            else if(provera)
            {
                    scanf("%d %d", &a, &b);
                    izlaz[br] = niz[a-1][b-1];
                    br++;
            }
            
            else
            {
                    scanf("%d %d", &a, &b);
                    //printf("%d %d  ||  %d %d\n", redovi[a-1][0], redovi[0][1], kolone[b-1][0], kolone[0][1]);
                    
                    if(redovi[0][1] == 2)
                    {
                            if(redovi[a-1][0] >= b)
                                    izlaz[br] = '1';
                            else
                                    izlaz[br] = '0';
                    }
                    
                    else if(redovi[0][1] == 4)
                    {
                            if(n - redovi[a-1][0] < b)
                                    izlaz[br] = '1';
                            else
                                    izlaz[br] = '0';
                    }
                    
                    else if(kolone[0][1] == 1)
                    {
                            if(kolone[b-1][0] >= a)
                                    izlaz[br] = '1';
                            else
                                    izlaz[br] = '0';
                    }
                    
                    else if(kolone[0][1] == 3)
                    {
                            if(n - kolone[b-1][0] < a)
                                    izlaz[br] = '1';
                            else
                                    izlaz[br] = '0';
                    }
                    br++;
            }
    }
    
    for(int i = 0; i < br; i++)
    {
            printf("%c\n", izlaz[i]);
    }
    
    //system("PAUSE");
    //return EXIT_SUCCESS;
    return 0;
}
