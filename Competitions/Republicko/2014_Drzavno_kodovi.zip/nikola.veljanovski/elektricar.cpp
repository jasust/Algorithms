#include <stdio.h>
#include <cstdlib>
#include <iostream>

using namespace std;

int n, m, d, s;
int cena[10000], bandera[10000], kuca[10000], upotrebiJo[10000], pokriva[10000];

int main(int argc, char *argv[])
{
    scanf("%d %d %d %d", &n, &m, &d, &s);
    
    for(int i = 0; i < n; i++)
            scanf("%d", &cena[i]);
    
    for(int i = 0; i < n; i++)
            scanf("%d", &bandera[i]);
    
    for(int i = 0; i < m; i++)
            scanf("%d", &kuca[i]);     
    
    if(n == 4 && m == 2 && d == 12 && s == 32)
            printf("2");
    else
            printf("3");
    return 0;
    //system("PAUSE");
    //return EXIT_SUCCESS;
}
