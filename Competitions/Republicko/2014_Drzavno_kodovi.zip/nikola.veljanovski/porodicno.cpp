#include <stdio.h>
#include <cstdlib>
#include <iostream>

using namespace std;

int srecan[10005], niz[10000][10000], dece[10000], n, s;
int pot[100000], najmanji = -1, naj, kraj = 1, izlaz;
void f(int a, int koliko)
{
    //printf("%d %d %d %d   %d  ||  ", pot[koliko - 1], koliko, a, naj, najmanji); 
    int b = koliko; 
    if(kraj)
    {
            for(int i = 0; i < b; i++)
            {
                    if(srecan[a] + pot[i] < najmanji && srecan[a] + pot[i] < s + naj && srecan[a] > 0)
                    {
                            pot[koliko] = srecan[a] + pot[i];
                            koliko++;
                    }
                    if(s - pot[koliko - 1] <= naj && pot[koliko - 1] <= s)
                    {
                            naj = s - pot[koliko - 1];
                            izlaz = pot[koliko - 1];
                    }
                    else if(pot[koliko - 1] - s < naj && pot[koliko - 1] >= s)
                    {
                            izlaz = pot[koliko - 1];
                            naj = pot[koliko - 1] - s;
                    }
                    //printf("%d %d %d %d ||  ", pot[koliko - 1], koliko, a, naj);
            }
    }
    if(srecan[a] > 0)
    {
            pot[koliko] = srecan[a];
            koliko++;
            if(s - pot[koliko - 1] <= naj && pot[koliko - 1] <= s)
            {
                    naj = s - pot[koliko - 1];
                    izlaz = pot[koliko - 1];
            }
            else if(pot[koliko - 1] - s < naj && pot[koliko - 1] >= s)
            {
                    izlaz = pot[koliko - 1];
                    naj = pot[koliko - 1] - s;
            }
            //printf("%d %d %d %d ||  ", pot[koliko - 1], koliko, a, naj);
    }
    //printf("\n");
    if(naj == 0)
    {
           //printf("SADASDASDSAD \n");
            kraj = 0;
            izlaz = s;
    }
    else
    {
            for(int i = 1; i <= dece[a]; i++)
                    f(niz[a][i], koliko);
    }
}

int main()
{
    int provera = 1, br = 0;
    scanf("%d %d", &n, &s);
    
    for(int i = 1; i <= n; i++)
    {
            scanf("%d %d", &srecan[i], &dece[i]);
            if(srecan[i] >= s && (najmanji > srecan[i] || najmanji == -1))
            {
                    najmanji = srecan[i];
                    br++;
            }
            for(int k = 1; k <= dece[i]; k++)
            {
                    scanf("%d", &niz[i][k]);
                    //niz[niz[i][k]] = i;
            }
    }
    naj = s;
    //printf("%d %d\n", najmanji, naj);
    if(najmanji - s < s && najmanji >= s)
    {
            izlaz = najmanji;
            naj = najmanji - s;
    }
    //printf("%d \n", naj);
    if(najmanji == s)
    {
            printf("%d", s);
    }
    else if(br == n)
    {
            if(s <= najmanji - s)
                    printf("0");
            else
                    printf("%d", najmanji);
    }
    
    else
    {
            if(najmanji >= s)
            {
                    for(int i = 1; i <= n; i++)
                            if(srecan[i] >= najmanji)
                                    srecan[i] = 0;
            }
            else 
                    najmanji = s * 2;
            
            f(1, 0);
            
            printf("%d", izlaz);
    }
    return 0;
    //system("PAUSE");
    //return EXIT_SUCCESS;
}
