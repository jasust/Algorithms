#include<cstdio>
#include<algorithm>
using namespace std;

int n, i, j, q, red[1005], kol[1005], josjednosranje, x, y, upit;
char ch[1005];
bool k, r, a[1005][1005];

int main()
{
    scanf("%d", &n);
    for (i=1; i<=n; i++) red[i] = kol[i] = 0;
    for (i=1; i<=n; i++)
    {
        scanf("%s", ch);
        for (j=0; j<n; j++)
            if (ch[j]=='1')
            {
                red[i]++;
                kol[j+1]++;
                a[i][j+1] = 1;
            } else a[i][j+1] = 0;
    }
    r = false; k = false;
    josjednosranje = 0;
    scanf("%d", &q);
    while (q)
    {
        scanf("%d", &upit);
        q--;
        if (upit == 2)
        {
            scanf("%d %d", &x, &y);
            printf("%d\n", a[x][y]);
        }
        else break;
    }
    if (q) {
    scanf("%d", &x);
    if (x&1)
    {
        josjednosranje = 1;
        if (x==3) k = true;
        for (i=1; i<=n; i++)
        {
            red[i] = 0;
            for (j=1; j<=n; j++)
             if (kol[j]>=i) red[i]++;
        }
    } else
    {
        josjednosranje = 2;
        if (x==4) r = true;
        for (i=1; i<=n; i++)
        {
            kol[i] = 0;
            for (j=1; j<=n; j++)
             if (red[j]>=i) kol[i]++;
        }
    }
    while (q--)
    {
        scanf("%d", &upit);
        if (upit == 1)
        {
            scanf("%d", &x);
            if ((josjednosranje==1) && ((x==2)||(x==4)))
            {
                josjednosranje = 3;
                for (i=1; i<=n; i++)
                {
                    kol[i] = 0;
                    for (j=1; j<=n; j++)
                     if (red[j]>=i) kol[i]++;
                }
                if (x==4) r = true; else r = false;
            }
            else if ((josjednosranje==2) && ((x==3)||(x==1)))
            {
                josjednosranje = 3;
                if (x==3) k = true; else k = false;
                for (i=1; i<=n; i++)
                {
                    red[i] = 0;
                    for (j=1; j<=n; j++)
                     if (kol[j]>=i) red[i]++;
                }
            }
            else
            if (x==1) k = false; else
            if (x==3) k = true; else
            if (x==2) r = false; else
            if (x==4) r = true;
        }
        else
        {
            scanf("%d %d", &x, &y);
            if ((josjednosranje == 1))
            {
                if (!k) if (kol[y]>=x) printf("1\n"); else printf("0\n");
                if (k) if (kol[y]+x>n) printf("1\n"); else printf("0\n");
            } else
            if (josjednosranje == 2)
            {
                if (!r) if (red[x]>=y) printf("1\n"); else printf("0\n");
                if (r) if (red[x]+y>n) printf("1\n"); else printf("0\n");
            }
            else
            {
                if (!r) if (red[x]>=y) printf("1\n"); else printf("0\n");
                if (r) if (red[x]+y>n) printf("1\n"); else printf("0\n");
            }
        }
    }
    }
    return 0;
}
