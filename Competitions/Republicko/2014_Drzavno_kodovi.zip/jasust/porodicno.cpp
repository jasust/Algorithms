//daj sta das, bar 10pts
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<vector>
using namespace std;

long long sum;
int n, s, i, j, v[10005], dubina, sol = 0, x, y, cale;
vector<int> sinovi[10005];
bool otac[10005];

void DFS(int idx)
{
    dubina++;
    if (i & (1LL<<(dubina-1))) sum += v[idx];
    if (sinovi[idx].empty()) {
     if (abs(sol-s)>abs(sum-s) || ((abs(sol-s)==abs(sum-s)) && sum<sol)) sol=sum; }
    else for (j=0; j<sinovi[idx].size(); j++) DFS(sinovi[idx][j]);
    if (i & (1LL<<(dubina-1))) sum -= v[idx];
    dubina--;
}

int main()
{
    scanf("%d %d", &n, &s);
    for (i=1; i<=n; i++) otac[i] = false;
    for (i=1; i<=n; i++)
    {
        scanf("%d %d", v + i, &x);
        for (j=1; j<=x; j++)
        {
            scanf("%d", &y);
            otac[y] = true;
            sinovi[i].push_back(y);
        }
    }
    if (n<=20)
    {
        for (i=1; i<=n; i++) if (!otac[i]) { cale=i;  break; }
        for (i=0; i<(1LL<<10); i++) { sum = 0; dubina = 0; DFS(cale); }
        printf("%d", sol);
    } else printf("0");
    return 0;
}
