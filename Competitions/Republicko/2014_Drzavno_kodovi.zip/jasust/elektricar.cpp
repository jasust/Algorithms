//mizerija
#include <cstdio>
using namespace std;

int main()
{
    printf("1");
}
