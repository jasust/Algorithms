#include <stdio.h>

long h[1000005], k;

long raz(long ind){
    if (h[ind] >= k) return h[ind]-k+1;
    return 0;
}

int main()
{
    long n, i, j, rk, hb, maxh=0, iter=0;
    scanf ("%ld %ld",&n, &k);
    for (i=0; i<n; i++){
        scanf("%ld", &h[i]);
        if (h[i] > maxh) maxh = h[i];
    }
    scanf("%ld %ld", &rk, &hb);
    rk--;
    if (k>hb){
        printf("%lld %lld", rk+1, hb);
        return 0;
    }
    while (hb >= k){
        for (i=n-1; i>=iter; i--){
            //for (j=0; j<n; j++){
            //    printf ("%ld ", h[j]);
            //}
            //printf ("\n%ld\n", hb);
            if (i==n-1){
                if (raz(i)>0) n++;
                h[i+1] = raz(i);
                if (raz(i) > 0) h[i] = k-1;
                if (i == rk){
                    rk++;
                    hb = hb - k + 1;
                }
            } else {
                if (i == rk){
                    rk++;
                    hb = hb - k + h[i+1] + 1;
                }
                h[i+1] += raz(i);
                if (raz(i) > 0) h[i] = k-1;
            }
            //printf ("asd\n");
        }
        iter++;
    }
    //for (i=0; i<n; i++){
    //    printf ("%ld ", h[i]);
    //}
    //printf ("\n");
    printf ("%ld %ld", rk+1, hb);
    return 0;
}
