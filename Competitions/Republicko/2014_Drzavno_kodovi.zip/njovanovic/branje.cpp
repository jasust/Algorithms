#include <stdio.h>

long long r[1000005], u[1000005], j, zmax, m1z, m2z;

int main()
{
    long n, i, j, s1, s2, e1, e2, uind=0, max1=-9999, max2=-9999;
    scanf("%ld", &n);
    for (i=0; i<n; i++) scanf ("%lld", &r[i]);
    for (i=0; i<n; i++){
        scanf ("%lld", &j);
        r[i] -= j;
        if (max1 < r[i]){
            max2 = max1;
            max1 = r[i];
        } else if (max2 < r[i]) max2 = r[i];
    }
    u[0] = r[0];
    for (i=1; i<n; i++){
        if (r[i]*u[uind] > 0){
            u[uind] += r[i];
        } else {
            //printf ("%lld ", u[uind]);
            if (u[uind] > 0 && uind>1){
                max1 = u[uind];
                max2 = 0;
            }
            uind++;
            u[uind] = r[i];
        }
    }
    zmax = max1+max2;
    for (s1=0; s1<uind; s1++){
        m1z=0;
        if (u[s1] < 0) s1++;
        for (e1=s1; e1<uind; e1++){
            m1z += u[e1];
            if (u[e1] < 0) continue;
            for (s2=e1+1; s2<=uind; s2++){
                m2z = 0;
                if (u[s2] < 0) s2++;
                for (e2=s2; e2<=uind; e2++){
                    m2z += u[e2];
                    if (zmax < m1z+m2z){
                        zmax = m1z + m2z;
                        //printf ("%ld %ld %ld %ld\n", s1, e1, s2, e2);
                    }
                }
            }
        }
    }
    printf ("%lld", zmax);
    return 0;
}
