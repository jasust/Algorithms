#include <stdio.h>

int main()
{
    long n, m, i, j, x=2, b=1;
    scanf ("%ld %ld", &n, &m);
    if (m == 1)return 0;
    for (i=1; i<n; i++) x = x * 2;
    while (x > 1){
        //printf ("ad %ld\n", b);
        if (m < x/2+1+b && m > b) printf ("%ld ", b);
        x = x / 2;
        if (x+b < m) m = m - x + 1;
        b++;
    }
    return 0;
}
