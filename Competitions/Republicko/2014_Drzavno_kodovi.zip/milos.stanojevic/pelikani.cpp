#include <stdio.h>

using namespace std;

int N, Q;
bool field[1005][1005];
int begDirX = 0, begDirY = 0;   // direction of the first ever bread giver per coordinate
int currDirX = 0, currDirY = 0; // direction of consecutive bread givers per coordinate

void clearfield()
{
    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= N; j++)
            field[i][j] = false;
}

void printfield()
{
    for(int i = 1; i <= N; i++)
    {
        for(int j = 1; j <= N; j++)
            if(field[i][j])
                printf("1");
            else
                printf("0");
        printf("\n");
    }
}

void fullFieldUpdate(int dir)
{
    int tmpcnt = 0;
    switch(dir)
    {
        case 1:
            for(int j = 1; j <= N; j++)
            {
                tmpcnt = 0;
                for(int i = 1; i <= N; i++)
                    if(field[i][j])
                    {
                        field[i][j] = false;
                        tmpcnt++;
                    }
                for(int i = 1; i <= tmpcnt; i++)
                    field[i][j] = true;
            }
            break;
        case 2:
            for(int i = 1; i <= N; i++)
            {
                tmpcnt = 0;
                for(int j = 1; j <= N; j++)
                    if(field[i][j])
                    {
                        field[i][j] = false;
                        tmpcnt++;
                    }
                for(int j = 1; j <= tmpcnt; j++)
                    field[i][j] = true;
            }
            break;
        case 3:
            for(int j = 1; j <= N; j++)
            {
                tmpcnt = 0;
                for(int i = 1; i <= N; i++)
                    if(field[i][j])
                    {
                        field[i][j] = false;
                        tmpcnt++;
                    }
                for(int i = N; i > N - tmpcnt; i--)
                    field[i][j] = true;
            }
            break;
        case 4:
            for(int i = 1; i <= N; i++)
            {
                tmpcnt = 0;
                for(int j = 1; j <= N; j++)
                    if(field[i][j])
                    {
                        field[i][j] = false;
                        tmpcnt++;
                    }
                for(int j = N; j > N - tmpcnt; j--)
                    field[i][j] = true;
            }
            break;
    }
}

int main()
{
    scanf("%d", &N);
    char s[1001];
    clearfield();
    for(int i = 1; i <= N; i++)
    {
        scanf("%s", s);
        for(int j = 1; j <= N; j++)
            switch(s[j-1])
            {
                case '1': field[i][j] = true;  break;
                case '0': field[i][j] = false; break;
            }
    }
    int qtype;    // type of querry, can be 1 or 2
    int x, y;     // coordinates if qtype is 2
    int dir = -1; // the direction from which a person is throwing bread
    scanf("%d", &Q);
    for(int q = 0; q < Q; q++)
    {
        scanf("%d", &qtype);
        switch(qtype)
        {
            case 1:
                scanf("%d", &dir);
                switch(dir)
                {
                    case 1: currDirX = 1; break;
                    case 2: currDirY = 2; break;
                    case 3: currDirX = 3; break;
                    case 4: currDirY = 4; break;
                }
                if(begDirX == 0 && begDirY == 0)
                {
                    begDirX = currDirX;
                    begDirY = currDirY;
                    fullFieldUpdate(dir);
                }
                else if(begDirX > 0 && begDirY == 0)
                {
                    if(currDirY > 0)
                    {
                        if(currDirX != begDirX)
                            fullFieldUpdate(currDirX);
                        fullFieldUpdate(currDirY);
                        begDirX = currDirX;
                        begDirY = currDirY;
                    }
                }
                else if(begDirX == 0 && begDirY > 0)
                {
                    if(currDirX > 0)
                    {
                        if(currDirY != begDirY)
                            fullFieldUpdate(currDirY);
                        fullFieldUpdate(currDirX);
                        begDirX = currDirX;
                        begDirY = currDirY;
                    }
                }
                break;
            case 2:
                scanf("%d%d", &x, &y);
                if(currDirX != begDirX)
                    x = N - x + 1;
                if(currDirY != begDirY)
                    y = N - y + 1;
                if(field[x][y])
                    printf("1\n");
                else
                    printf("0\n");
                break;
        }
    }
    return 0;
}
/*
5
00000
01000
11000
01010
00000
6
2 5 2
1 3
2 5 2
2 3 2
1 4
2 5 2

8
00101010
01010001
00000000
10111100
00001000
01010000
00110001
00000100
10
2 4 3
2 6 6
1 2
1 2
2 4 6
2 4 5
1 4
2 3 5
1 3
2 1 8

6
101001
010100
010000
000100
001000
010001
6
1 1
2 5 2
1 3
2 5 2
1 4
2 1 6

6
101001
000100
010000
010100
011000
010001
8
2 5 2
1 1
2 5 2
1 3
2 1 6
1 2
1 4
2 1 1
*/
