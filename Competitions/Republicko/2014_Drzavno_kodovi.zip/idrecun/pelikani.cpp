#include <iostream>
#include <cstdio>

const int maxN = 1001;

int mat[maxN][maxN];
char str[maxN];
int a[maxN],b[maxN];

//int mode: 1-pre bilo koje transformacije, 2-posle transformacija po samo jednoj osi, 3-posle transformacija po obe ose
//int side: za mode=2, 1-gore, 2-levo, 3-dole, 4-desno
//int side: za mode=3, side&1-simetricno po i, side&2-simetricno po j

int sided[4];

int main()
{
    int n,q;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
            scanf("%s", str);
            for(int j=0;j<n;j++)
            {
                    mat[i][j] = str[j]-'0';
                    a[i] += mat[i][j];
                    b[j] += mat[i][j];
            }
    }
    scanf("%d", &q);
    int mode = 1;
    int side = 1;
    for(int qq=0;qq<q;qq++)
    {
            int qqq;
            scanf("%d", &qqq);
            if(qqq == 2)
            {
                   int ci,cj;
                   scanf("%d%d",&ci,&cj);
                   ci--;
                   cj--;
                   if(mode == 1) printf("%d\n",mat[ci][cj]);
                   else if(mode == 2)
                   {
                        int pr = 0;
                        if(side == 1) pr = ci < b[cj];
                        else if(side == 2) pr = cj < a[ci];
                        else if(side == 3) pr = n-ci-1 < b[cj];
                        else pr = n-cj-1 < a[ci];
                        printf("%d\n",pr);
                   }
                   else
                   {
                       if(side & 1) ci = n-ci-1;
                       if(side & 2) cj = n-cj-1;
                       printf("%d\n", mat[ci][cj]);
                   }
            }
            else
            {
                if(mode == 1)
                {
                        scanf("%d", &side);
                        mode++;
                }
                else if(mode == 2)
                {
                     int s;
                     scanf("%d", &s);
                     if(side&1==s&1)side = s;
                     else
                     {
                         //ruzno
                         for(int i=0;i<n;i++) for(int j=0;j<n;j++) mat[i][j]=0;
                         if(side == 1) for(int j=0;j<n;j++) for(int i=0;i<b[j];i++) mat[i][j] = 1;
                         else if(side == 2) for(int i=0;i<n;i++) for(int j=0;j<a[i];j++) mat[i][j] = 1;
                         else if(side == 3) for(int j=0;j<n;j++) for(int i=n-1;n-i-1<b[j];i--) mat[i][j] = 1;
                         else for(int i=0;i<n;i++) for(int j=n-1;n-j-1<a[i];j--) mat[i][j] = 1;
                         //DEBUG
                         /*for(int i=0;i<n;i++)
                         {
                                 for(int j=0;j<n;j++) printf("%d",mat[i][j]);
                                 printf("\n");
                                 system("pause");
                         }*/
                         //DEBUG 
                         for(int i=0;i<n;i++) {a[i]=0;b[i]=0;}
                         for(int i=0;i<n;i++) for(int j=0;j<n;j++) {a[i]+=mat[i][j];b[j]+=mat[i][j];}
                         for(int i=0;i<n;i++) for(int j=0;j<n;j++) mat[i][j]=0;
                         if(s == 1) for(int j=0;j<n;j++) for(int i=0;i<b[j];i++) mat[i][j] = 1;
                         else if(s == 2) for(int i=0;i<n;i++) for(int j=0;j<a[i];j++) mat[i][j] = 1;
                         else if(s == 3) for(int j=0;j<n;j++) for(int i=n-1;n-i-1<b[j];i--) mat[i][j] = 1;
                         else for(int i=0;i<n;i++) for(int j=n-1;n-j-1<a[i];j--) mat[i][j] = 1;
                         
                         if(side==1)
                         {
                                    sided[0]=0;
                                    sided[2]=1;
                         }
                         else if(side==2)
                         {
                              sided[1]=0;
                              sided[3]=1;
                         }
                         else if(side==3)
                         {
                              sided[0]=1;
                              sided[2]=0;
                         }
                         else
                         {
                             sided[1]=1;
                             sided[3]=0;
                         }
                         if(s==1)
                         {
                                    sided[0]=0;
                                    sided[2]=1;
                         }
                         else if(s==2)
                         {
                              sided[1]=0;
                              sided[3]=1;
                         }
                         else if(s==3)
                         {
                              sided[0]=1;
                              sided[2]=0;
                         }
                         else
                         {
                             sided[1]=1;
                             sided[3]=0;
                         }
                         mode++;
                         side = 0;
                         //DEBUG
                         //for(int i=0;i<4;i++) printf("%d",sided[i]);
                         //DEBUG
                     }
                }
                else
                {
                    int s;
                    scanf("%d",&s);
                    if(s&1) side=(side&2)+sided[s-1];
                    else side=(side&1)+2*sided[s-1];
                    //DEBUG
                    //printf("%d\n",side);
                    //DEBUG
                }
            }
    }
    //system("pause");
    return 0;
}
