#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

const int maxN = 10001;

struct mp
{
       mp(){a=0;b=0;}
       int a,b;
};

std::vector<int> tree[maxN];
int par[maxN];
int d[maxN];
int cnt[maxN];
std::vector<int> dp[maxN];
mp depth[maxN];

void gdepth(int pos, int dpt)
{
     depth[pos].a=dpt;
     depth[pos].b=pos;
     for(int i=0;i<cnt[pos];i++)
             gdepth(tree[pos][i],dpt+1);
}

bool comp(mp a,mp b)
{
     if(a.a>b.a) return true;
     if(a.a<b.a) return false;
     return par[a.b] < par[b.b];
}

inline int myabs(int a)
{
       return a>0?a:-a;
}

inline int min(int a,int b)
{
       return a<b?a:b;
}

int main()
{
    int n,s;
    scanf("%d%d",&n,&s);
    for(int i=0;i<n;i++)
    {
            int l;
            scanf("%d%d",d+i,&l);
            for(int j=0;j<l;j++)
            {
                    int curr;
                    scanf("%d",&curr);
                    tree[i].push_back(curr-1);
                    par[curr-1] = i;
            }
            cnt[i]=l;
    }
    int root;
    for(int i=0;i<n;i++)
            if(cnt[i]==0)
            {
                         root=i;
                         break;
            }
    gdepth(root,0);
    std::sort(depth,depth+n,comp);
    int ld = -1;
    int ldi = 0;
    for(int i=0;i<n;i++)
    {
            if(ld != depth[i].a)
            {
                  ld++;
                  while(depth[ldi].a==ld-2)
                  {
                                           dp[depth[ldi].b].clear();
                                           ldi++;
                  } 
            }
            int ci = depth[i].b;
            for(int j=0;j<s;j++)
            {
                    dp[ci].push_back(d[ci]);
                    for(int k=0;k<cnt[ci];k++)
                    {
                            int abc = (j-d[ci]>=0)?dp[tree[ci][k]][j-d[ci]]:0;
                            int x;
                            if(myabs(dp[tree[ci][k]][j]-s) < myabs(abc+d[ci]-s))
                                                       x = dp[tree[ci][k]][j];
                            else if(myabs(dp[tree[ci][k]][j]-s) > myabs(abc+d[ci]-s))
                                 x = abc+d[ci];
                            else x = min(dp[tree[ci][k]][j],abc+d[ci]);
                            if(myabs(x-s)<myabs(dp[ci][j]-s))
                            dp[ci][j] = x;
                            else if(myabs(x-s)==myabs(dp[ci][j]-s) && x<dp[ci][j])
                            dp[ci][j] = x;
                    }
                    if(cnt[ci] == 0 && s < myabs(dp[ci][j]-s) || (s==myabs(dp[ci][j]-s) && s<dp[ci][j])) dp[ci][j] = 0;
            }
    }
    printf("%d",dp[root][s]);
    return 0;
}
