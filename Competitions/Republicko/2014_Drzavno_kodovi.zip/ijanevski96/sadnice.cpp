#include <iostream>
#include <stdint.h>
#include <math.h>
#define MAXX 50
using namespace std;
//KAKO SAM GA IZMANERVISAO
int64_t POZICIJE[MAXX];

int64_t pozicija(int at, int x){

}

int64_t fun(int N, int M, int P){
    int64_t pp = 0;
    if (P!=0){
        pp = fun(N,M,P-1);
        //cout<<"."<<POZICIJE[pp]<<endl;
        M+=POZICIJE[pp]-POZICIJE[pp-1];
        M-=P;
        cout<<P<<"="<<pp<<" ";
    }
    //return the shit
    int64_t pn = (int64_t)pow(2,N+1);
    int64_t ret = N-(int64_t)log2(pn-M-1)+1;
    if (ret<-1 || ret<=P) return 0;
    if (P>0 && ret<=pp) return 0;
    return ret;
}

int main(){
    int64_t N=4, M=1, l=(int64_t)pow(2,N-1);
    POZICIJE[0] = 0;
    POZICIJE[1] = l;
    for (int i=2;i<N+1;++i){
        POZICIJE[i] = POZICIJE[i-1]+(l>>=1);
    }
    //cin>>N>>M;
    --N; --M;
    fun(N,M,1);
    for (int i=0;i<(int)pow(2,N+1);++i){
        cout<<endl;
        //cout<<fun(N,i,2);
        //fun(N,i,1);

        //cout<<POZICIJE[i]<<" ";
        //int64_t f1 = fun(N,i,0);
        //int64_t f2 = fun(N,i,1);
        int64_t f3 = fun(N,i,2);
        //int64_t f4 = fun(N,i,3);

        //cout<<f1<<" "<<f2<<" "<<f3<<" "<<f4<<endl;
    }
    return 0;
}
