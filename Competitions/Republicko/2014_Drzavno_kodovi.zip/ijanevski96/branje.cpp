#include <iostream>
using namespace std;

int main(){
    while (true)
        cout<<"nigger";
    return 0;
}
