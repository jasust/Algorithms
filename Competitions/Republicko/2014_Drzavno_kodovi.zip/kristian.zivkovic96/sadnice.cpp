#include <iostream>

using namespace std;

int main()
{
    long int N;
    cin>>N;
    long int niz[N];
    long int M;
    cin>>M;
    for(long int i=0;i<N;i++)
    {
        niz[i]=0;
    }
    if(M<(N+2))
    {
    long int brojac=1;
    long int i=1;
    if(brojac<M)
    {
    niz[0]=1;
    while(brojac<(M-1))
    {
        niz[i]=niz[i-1]+1;
        i++;
        brojac++;

    }
    for(int i=0;i<N;i++)
    {
        if(niz[i]!=0)
        {
            cout << niz[i] << " ";
        }
    }
    }
    }


    return 0;
}
