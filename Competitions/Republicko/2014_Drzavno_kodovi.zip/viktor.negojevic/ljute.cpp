#include <cstdlib>
#include <iostream>
#include<stdio.h>
int main()
{
 int v[490000],n,vr,pr,k,i,j;
 scanf("%d %d",&n,&k);
 for(i=0;i<n;i++)
 scanf("%d",&v[i]);
 scanf("%d %d",&pr,&vr);
 i=0;
 while(vr>=k){ 
  for(;i<n;i++){
   if(v[i]>=k){
    j=i+1;
    while(v[j]>=k){
      j++;              
    }
    for(;j>i;j--){
     if(j==n){
      v[j]=0;
      n++;
     }
     if(j==pr){
     pr++;
     vr=vr-k+1+v[j];
     }
     v[j]=v[j]+v[j-1]-k+1;
     v[j-1]=k-1;              
    } 
    v[i]=k-1;           
    break;
   }
  }
 }
 printf("%d %d",pr,vr);
 return EXIT_SUCCESS;
}
