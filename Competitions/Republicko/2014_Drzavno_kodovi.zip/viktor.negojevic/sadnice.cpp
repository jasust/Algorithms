#include <cstdlib>
#include <iostream>
#include<stdio.h>
int main()
{
 int i,n,m;
 scanf("%d %d",&n,&m);
 if(m<=n+1)
 for(i=1;i<=m-1;i++){
  printf("%d ",i);                    
 }
 system("PAUSE");
 return EXIT_SUCCESS;
}
