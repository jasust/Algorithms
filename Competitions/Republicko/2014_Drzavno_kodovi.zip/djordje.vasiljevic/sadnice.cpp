#include<cstdio>
#include<iostream>
#include<vector>
#include<cmath>

using namespace std;



long long n,m;
	vector <int> a;
	int l;


void ispisi()
{
	for(int i=0;i<l;i++)
		printf("%d ",a[i]);
	cout<<endl;
	
}


int main()
{
	scanf("%lld %lld",&n,&m);
	a.push_back(1);
	l=1;
	long long x= (long long)(powl(2,n));
	if(m==2)
		cout<<1;
	else
	for(long long i=3;i<x+1;i++)
	{
		//printf("%lld:\n",i);
		

		if(!a.empty())
		{
			if( a[l-1]!=n && l!=n)
			{
					a.push_back(a[l-1]+1);
					l++;
				//	cout<<"cao\n";
				}
			else if(a[l-1]==n)
				{
					a.pop_back();
					l--;
					a[l-1]++;
				}
			
		}
		if(i==m)
			{
                ispisi();
                break;
            }
	}
	
	return 0;
}
