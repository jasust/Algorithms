#include<cstdio>
#include<iostream>

using namespace std;

int n,a[1000000],l1,r1,l2,r2,ml1,mr1;

int main()
{

cin>>n;
for(int i=0;i<n;i++)
        cin>>a[i];
for(int i=0;i<n;i++)
{
        int p;
        cin>>p;
        a[i]+=p;
}
long long zbir=0,maks=LLONG_MIN,max1=LLONG_MIN;
for(int l1=0;l1<n;l1++)
{
     zbir=0;
     for(int r1=r1;r1<n;r1++)
     {
             zbir+=a[r1];
             if(zbir>maks)
              {
                   maks=zbir;
                   ml1=l1;
                   mr1=r1;
              }
     }        
}

//for(int l2=0;l2<n;l2++)
//{
 //    zbir=0;
 //    for(int r2=l2;l2<n;l2++)
 //    {
 //            zbir+=r1;
 //            if(zbir>maks1 &&)
 //              {
 //                maks1=zbir;
 //              }
 //    }        
//}

cout<<maks;


    
 return 0;    
}
