#include<cstdio>
#include<iostream>
#include<vector>

using namespace std;


int n,k,rk,hb;
vector<int> gore,dole;
bool nagrada_dole;


void dodaj(int i,int x)
{
	dole[i]+=x;
	if(dole[i]>=k-1)
	{
		gore[i]=dole[i]-(k-1);
		dole[i]=k-1;

	}
}
bool prazan()
{
	for(int i=0;i<gore.size();i++)
		if(gore[i]>=0)
			return false;
	return true;

}
void gurni()
{
	if(gore[gore.size()-1]!=0)
		{
			dole.push_back(0);
			gore.push_back(0);
		}

	for(int i=dole.size()-2;i>=rk-1;i--)
	{
		if(i==rk-1)
		{
			rk++;
			hb=hb-(k-1-dole[i+1]);
			if(hb<k)
				nagrada_dole=true;
		}
		dodaj(i+1,gore[i]);
		gore[i]=0;
	}
}

int main()
{

	
	scanf("%d %d",&n,&k);

	gore.resize(n,0);
	dole.resize(n,0);

	int p;

	nagrada_dole=false;

	for(int i=0;i<n;i++)
	{
		scanf("%d",&p);
		dodaj(i,p);
	}
	scanf("%d %d",&rk,&hb);
	if(hb<k)
		nagrada_dole=true;
	//cout<<prazan();
	while(prazan!=0 && !nagrada_dole)
			{
				//cout<<"cao";
				gurni();
			}

	
	printf("%d %d",rk,hb);
	return 0;
}
