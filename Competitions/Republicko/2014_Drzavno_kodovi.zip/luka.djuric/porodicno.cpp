#include <iostream>
#include <cstdio>
//_@v
//ULAZIM U KLUB, KARAM PORODICNO DRVO
//OCES DA MI BUDES DRUG? KARAJ PORODICNO DRVO PRVO
//NE KARAS PORODICNO DRVO? NISI MI DRUG
//EVO TI, BRATE, KURAC DUG
//HA HA HA, SAMO SE SALIM
//TI NISI PORODICNO DRVO, PEDERU MALI
struct Cvor
{
    int srecnibroj;
    int brdece;
    int deca[1001];
};
Cvor cvorovi[1000];
int niz[100001];
void Nadji_sve_sume(int i,int s)
{
    int k=s+cvorovi[i].srecnibroj;
    niz[cvorovi[i].srecnibroj]=1;
    //printf("%d x \n",k);
    if(k<=100000)
    {
        niz[k]=1;
    }
    for(int j=0;j<cvorovi[i].brdece;j++)
    {
        Nadji_sve_sume(cvorovi[i].deca[j]-1,s);
        if(k<=100000)
        {
            Nadji_sve_sume(cvorovi[i].deca[j]-1,k);
        }
    }
}
int main()
{
    int n,s,srbr,brd,br;
    int *t;
    scanf("%d%d",&n,&s);
    if(n>1000)
    {
        printf("%d\n",s);
        return 0;
    }
    for(int i=0;i<n;i++)
    {
        scanf("%d%d",&srbr,&brd);
        cvorovi[i].srecnibroj=srbr;
        cvorovi[i].brdece=brd;
        for(int j=0;j<brd;j++)
        {
            scanf("%d",&br);
            cvorovi[i].deca[j]=br;
        }
    }
    niz[0]=1;
    Nadji_sve_sume(0,0);
    /*for(int i=0;i<100;i++)
    {
        printf("%d %d\n",i,niz[i]);
    }*/
    for(int i=0;i<10000;i++)
    {
        if(niz[s-i]==1)
        {
            printf("%d",s-i);
            break;
        }
        if(niz[s+i]==1)
        {
            printf("%d",s+i);
            break;
        }
    }
    return 0;
}
