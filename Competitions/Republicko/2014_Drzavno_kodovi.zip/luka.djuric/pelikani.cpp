#include <iostream>
#include <cstdio>
//_@v
using namespace std;
int jezero[1001][1001];
void pomeri(int smer,int n)
{
    int s;
    //OOO KAKO VOLIM SLUCAJEVE
    //SLUCAJEVI ME PALE
    if(smer==1)
    {
        for(int j=1;j<=n;j++)
        {
            s=0;
            for(int i=1;i<=n;i++)
            {
                s+=jezero[i][j];
            }
            for(int i=1;i<=n;i++)
            {
                jezero[i][j]=0;
            }
            for(int i=1;i<=s;i++)
            {
                jezero[i][j]=1;
            }
        }
    }
    if(smer==2)
    {
        for(int i=1;i<=n;i++)
        {
            s=0;
            for(int j=1;j<=n;j++)
            {
                s+=jezero[i][j];
            }
            for(int j=1;j<=n;j++)
            {
                jezero[i][j]=0;
            }
            for(int j=1;j<=s;j++)
            {
                jezero[i][j]=1;
            }
        }
    }
    if(smer==3)
    {
        for(int j=1;j<=n;j++)
        {
            s=0;
            for(int i=1;i<=n;i++)
            {
                s+=jezero[i][j];
            }
            for(int i=1;i<=n;i++)
            {
                jezero[i][j]=0;
            }
            for(int i=n;i>n-s;i--)
            {
                jezero[i][j]=1;
            }
        }
    }
    if(smer==4)
    {
        for(int i=1;i<=n;i++)
        {
            s=0;
            for(int j=1;j<=n;j++)
            {
                s+=jezero[i][j];
            }
            for(int j=1;j<=n;j++)
            {
                jezero[i][j]=0;
            }
            for(int j=n;j>n-s;j--)
            {
                jezero[i][j]=1;
            }
        }
    }
    /*for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            printf("%d",jezero[i][j]);
        }
        printf("\n");
    }*/
    
}
int main()
{
    int n,q,tip,pi,pj,smer,prvismer,smer1=0,smer2=0;
    bool prvi=true,sabijeni=false,kontra=false;
    char s[1001];
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%s",&s);
        for(int j=1;j<=n;j++)
        {
            jezero[i][j]=s[j-1]-'0';
        }
    }
    scanf("%d",&q);
    for(int i=0;i<q;i++)
    {
        //OOO JOS SLUCAJEVA
        //JESSSSSS
        //O KAKO SAM SE NAPALIO
        if(prvi)
        {
            scanf("%d",&tip);
            if(tip==2)
            {
                scanf("%d %d",&pi,&pj);
                printf("%d\n",jezero[pi][pj]);
            }
            if(tip==1)
            {
                scanf("%d",&smer);
                prvismer=smer;
                pomeri(smer,n);
                prvi=false;
            }
            continue;
        }
        if(!sabijeni)
        {
            scanf("%d",&tip);
            if(tip==1)
            {
                scanf("%d",&smer);
                //much cases
                //such horny
                //wow
                if(prvismer==1)
                {
                    if(smer==3)
                    {
                        kontra=true;
                    }
                    if(smer==2 || smer==4)
                    {
                        sabijeni=true;
                        if(kontra)
                        {
                            pomeri(3,n);
                        }
                        pomeri(smer,n);
                    }
                    if(smer==1)
                    {
                        kontra=false;
                    }
                }
                if(prvismer==2)
                {
                    if(smer==4)
                    {
                        kontra=true;
                    }
                    if(smer==1 || smer==3)
                    {
                        sabijeni=true;
                        if(kontra)
                        {
                            pomeri(4,n);
                        }
                        pomeri(smer,n);
                    }
                    if(smer==2)
                    {
                        kontra=false;
                    }
                }
                if(prvismer==3)
                {
                    if(smer==1)
                    {
                        kontra=true;
                    }
                    if(smer==2 || smer==4)
                    {
                        sabijeni=true;
                        if(kontra)
                        {
                            pomeri(1,n);
                        }
                        pomeri(smer,n);
                    }
                    if(smer==3)
                    {
                        kontra=false;
                    }
                }
                if(prvismer==4)
                {
                    if(smer==2)
                    {
                        kontra=true;
                    }
                    if(smer==1 || smer==3)
                    {
                        sabijeni=true;
                        if(kontra)
                        {
                            pomeri(2,n);
                        }
                        pomeri(smer,n);
                    }
                    if(smer==4)
                    {
                        kontra=false;
                    }
                }
            }
            if(tip==2)
            {
                scanf("%d%d",&pi,&pj);
                if(kontra)
                {
                    //SO MANY CASES
                    //JIZZ
                    if(prvismer==1)
                    {
                        printf("%d\n",jezero[n-pi+1][pj]);
                    }
                    if(prvismer==2)
                    {
                        printf("%d\n",jezero[pi][n-pj+1]);
                    }
                    if(prvismer==3)
                    {
                        printf("%d\n",jezero[n-pi+1][pj]);
                    }
                    if(prvismer==4)
                    {
                        printf("%d\n",jezero[pi][n-pj+1]);
                    }
                }
                else
                {
                    printf("%d\n",jezero[pi][pj]);
                }
            }
            continue;
        }
        else
        {
            scanf("%d",&tip);
            if(tip==1)
            {
                scanf("%d",&smer);
                //OMG JIZZ #2
                if(smer==1)
                {
                    if(smer1==0)
                    {
                        smer1=1;
                    }
                    if(smer1==3)
                    {
                        smer1=0;
                    }
                }
                if(smer==2)
                {
                    if(smer2==0)
                    {
                        smer2=2;
                    }
                    if(smer2==4)
                    {
                        smer2=0;
                    }
                }
                if(smer==3)
                {

                    if(smer1==0)
                    {
                        smer1=3;
                    }
                    if(smer1==1)
                    {
                        smer1=0;
                    }
                }
                if(smer==4)
                {
                    if(smer2==0)
                    {
                        smer2=4;
                    }
                    if(smer2==2)
                    {
                        smer2=0;
                    }
                }
                //printf("%d %d\n",smer1,smer2);
            }
            if(tip==2)
            {
                scanf("%d%d",&pi,&pj);
                //WTF IS THIS
                //ONLY 2 CASES
                //ME SAD :(
                if(smer1==1 || smer1==3)
                {
                    pi=n-pi+1;
                }
                if(smer2==2 || smer2==4)
                {
                    pj=n-pj+1;
                }
                printf("%d\n",jezero[pi][pj]);
            }
        }
    }
    //TL;DR: SOOOOOO MANYYYYY CASEEEEEEESSSSSSS
    //P.S. JIZZZZZZZZ
    return 0;
}

