#include <cstdio>

using namespace std;

long long p2[50];
long long pow2(int x) {
     if(p2[x] == -1) {
          if(x == 0) p2[0] = 1;
          long long r = pow2(x / 2);
          p2[x] = r * r * (x % 2 == 0 ? 1 : 2);
     }
     return p2[x];
}

int prva_cifra(long long m, int n) {
    m = pow2(n) - m;
    int l = 0;
    int h = n;
    int sr = n / 2;
    while(l + 1 < h) {
            sr = (l + h) / 2;
            if(m >= pow2(sr)) l = sr;
            else h = sr - 1;
    }
    if(m >= pow2(h)) return n - h;
    else return n - l;
}

void resi(long long m, int n, int* a) {
     if(m == 1) return;
     else if(n == 1) { a[0] = 1; return; }
     m--;
     a[0] = prva_cifra(m, n);
     m -= pow2(n);
     m += pow2(n - a[0] + 1);     
     resi(m, n - a[0], &a[1]);
     for(int i = 1; a[i] != -1; i++)
             a[i] += a[0];
}

int main() {
    int n;
    long long m;
    scanf("%d %lld", &n, &m);
    for(int i = 0; i <= n; i++) p2[i] = -1;
    int* a = new int[n + 2];
    for(int i = 0; i < n + 2; i++) a[i] = -1;
    resi(m, n, a);
    for(int i = 0; a[i] != -1; i++) printf("%d ", a[i]);
    return 0;
}
