#include <cstdio>
#include <cstdlib>

using namespace std;

long max_index(long long* c, long p, long q){
     long m = p;
     for(long i = p; i <= q; i++)
         if(c[i] > c[m]) m = i;
     return m;
}

long min_index(long long* c, long p, long q){
     long m = p;
     for(long i = p; i <= q; i++)
         if(c[i] < c[m]) m = i;
     return m;
}

long long max_d(long long* c, long p, long q) {
     if(p == q) return 0;
     long max = max_index(c, p, q);
     long min = min_index(c, p, q);
     if(max == p && min == q) return max_d(c, p + 1, q - 1); 
     long long md = (max > 0 ? c[max] - c[max - 1] : c[min + 1] - c[min]);
     for(long i = p; i < max; i++)
         if(c[max] - c[i] > md) md = c[max] - c[i];
     for(long i = min + 1; i <= q; i++)
         if(c[i] - c[min] > md) md = c[i] - c[min];
     return md;
}
int main() {
    long n;
    scanf("%ld", &n);
    long long* sz = new long long[n];
    long long* t = new long long[n + 1];
    long s = 0;
    long x;
    for(long i = 0; i < n; i++) {
            scanf("%ld", &x);
            s += x;
            sz[i] = s;
    }
    s = 0;
    t[0] = 0;
    for(long i = 0; i < n; i++) {
             scanf("%ld", &x);
             s += x;
             t[i + 1] = sz[i] - s;
    }
    long long max_p = max_d(t, 0, 1) + max_d(t, 2, n - 1);
    for(long i = 1; i + 1 < n - 1; i++) {
             long long p = max_d(t, 0, i) + max_d(t, i + 1, n - 1);
             if(p > max_p) max_p = p;
    }
    printf("%lld", max_p);
    return 0;
}
