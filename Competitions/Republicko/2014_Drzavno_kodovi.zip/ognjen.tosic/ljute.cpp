#include <cstdio>
#include <vector>
#include <cstdlib>

using namespace std;

int main() {
    
    long n, k;
    scanf("%ld %ld", &n, &k);
    vector<long> h(n);
    for(long i = 0; i < n; i++) scanf("%ld", &(h[i]));
    long rk, hb;
    scanf("%ld %ld", &rk, &hb);
    rk--;
    vector<long> visak;
    for(long i = 0; i < h.size(); i++) visak.push_back(0);
    while(hb > k - 1) {
           for(long i = 0; i < h.size(); i++) visak[i] = (h[i] - k + 1);
           if(hb <= k - 1) break;
           rk++;
           if(rk < h.size()) { if(h[rk] < k - 1) hb = h[rk] + hb - k + 1; }
           else hb = hb - k + 1;
           long j;
           for(j = 0; j < h.size() && visak[j] <= 0; j++);
           if(j == h.size()) break;
           h[j] = k - 1;
           for(long i = j + 1; i < h.size(); i++) {
               if(visak[i - 1] >= 0) { 
                          if(h[i] >= k - 1) h[i] = k - 1 + visak[i - 1]; 
                          else h[i] += visak[i - 1];
               }
               else { 
                    if(h[i] >= k - 1) h[i] = k - 1;
               }
           }
           if(visak[h.size() - 1] > 0) h.push_back(visak[h.size() - 1]);
    }
    printf("%ld %ld", rk + 1, hb);
    return 0;
}
