#include<iostream>
#define N 1000005
using namespace std;

long long n, m1, m2;
long long s[N], z[N];
long long p[N];
long long up;

long long maxsuma1(long long n, long long a[])
{
    long long maks = p[0], suma = 0, presuma = 0;
    for(int i = 0; i < n; i++)
    {
            if(p[i] > maks) maks = p[i];
            
            suma += p[i];

            if(suma > maks) maks = suma;
            
            if(suma > presuma) 
            {
                    presuma = suma;
            }
            
            else
            {
                suma = 0;
                presuma = 0;   
            }
    }        
    
    return maks;
}

int maxsuma2(long long n, long long a[])
{
    long long maks = p[0], suma = 0, presuma = 0, premaks = 0;
    for(int i = 0; i < n; i++)
    {
            if(p[i] > maks)
            {
                    premaks = maks;
                    maks = p[i];
            }
            
            suma += p[i];
            
            if(suma > maks) 
            {
                    premaks = maks;
                    maks = suma;
            }
            
            if(suma > presuma) 
            {
                    presuma = suma;
            }
            
            else
            {
                suma = 0;
                presuma = 0;   
            }
    }        
    
    return premaks;
}

int main()
{
    
    cin >> n;
    
    for(int i = 0; i < n; i++)
            cin >> z[i];
            
    for(int i = 0; i < n; i++)
    {
            cin >> s[i];
            p[i] = z[i] - s[i];
    }

    m1 = maxsuma1(n, p);
    m2 = maxsuma2(n, p);
    
    up = m1 + m2;
    
    cout << up;
    
    return 0;
}
