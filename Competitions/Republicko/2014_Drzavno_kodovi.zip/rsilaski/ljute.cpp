#include<iostream>
#include<cstdlib>
#define N 1000001
using namespace std;

long long  v, r, n;
long long k, h[N], rk, hb;

int main()
{
    
    cin >> n >> k;
    
    for(int i = 0; i < n; i++)
            cin >> h[i];
            
    cin >> rk >> hb;
    
    if(n == 1)
    {
         if(k > hb) v = hb, r = 1;
         else v = h[0] - k + 1 - (h[0] - hb), r = 2;   
    }
    

    cout << r <<  " " << v;
    
    system("pause");
    
    return 0;
}

/*
1 3
7
1 5
*/
