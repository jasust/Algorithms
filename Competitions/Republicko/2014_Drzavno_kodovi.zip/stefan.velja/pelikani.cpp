#include <iostream>
#include <cstdio>

using namespace std;

const int N=1005;

int n;
int a[N][N];
int data[N][N][5]; // Obicno, samo levo, samo gore, levo + gore, gore+levo, flipovanje
int mode, flipx, flipy;

void transf(int x)
{
    if(x==3)
        {
            for(int j=0; j<n; j++)
            {
                int br=0;
                for(int ii=0; ii<n; ii++)
                    if(a[ii][j])
                    {
                        br++;
                        a[ii][j]=0;
                    }
                for(int ii=0; ii<br; ii++)
                    a[n-ii-1][j]=1;
            }
        }
        else if(x==4)
        {
            for(int ii=0; ii<n; ii++)
            {
                int br=0;
                for(int j=0; j<n; j++)
                    if(a[ii][j])
                    {
                        br++;
                        a[ii][j]=0;
                    }
                for(int j=0; j<br; j++)
                    a[ii][n-1-j]=1;
            }
        }
        else if(x==1)
        {
            for(int j=0; j<n; j++)
            {
                int br=0;
                for(int ii=0; ii<n; ii++)
                    if(a[ii][j])
                    {
                        br++;
                        a[ii][j]=0;
                    }
                for(int ii=0; ii<br; ii++)
                    a[ii][j]=1;
            }
        }
        else if(x==2)
        {
            for(int ii=0; ii<n; ii++)
            {
                int br=0;
                for(int j=0; j<n; j++)
                    if(a[ii][j])
                    {
                        br++;
                        a[ii][j]=0;
                    }
                for(int j=0; j<br; j++)
                    a[ii][j]=1;
            }
        }
}

void init()
{
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            data[i][j][0]=a[i][j]; // obicno
    transf(1);
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            data[i][j][1]=a[i][j]; // gore
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            a[i][j]=data[i][j][0];
    transf(2);
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            data[i][j][2]=a[i][j]; //levo
    transf(1);
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            data[i][j][3]=a[i][j]; // levo+gore
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            a[i][j]=data[i][j][1];
    transf(2);
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            data[i][j][4]=a[i][j]; // gore+levo
}


int main()
{
    bool DEBUG=false;
    scanf("%i", &n);
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
        {
            char c;
            scanf(" %c", &c);
            a[i][j]=c-'0';
        }
    init();
    if(DEBUG)
        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                a[i][j]=data[i][j][0];
    /*for(int ti=0; ti<5; ti++)
    {
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<n; j++)
                printf("%i", data[i][j][ti]);
            cout << endl;
        }
        cout << endl << endl;
    }*/
    int q, x, y, type;
    scanf("%i", &q);
    if(DEBUG) cout << endl;
    for(int qi=0; qi<q; qi++)
    {
        scanf("%i", &type);
        if(type==1)
        {
            scanf("%i", &x);
            if(DEBUG)
            {
                transf(x);
                for(int i=0; i<n; i++)
                {
                    for(int j=0; j<n; j++)
                        printf("%i", a[i][j]);
                    cout << endl;
                }
                cout << endl;

            }
            if(x==1)
            {
                if(mode==0) mode = 1;
                else if(mode == 2) mode = 3;
                flipy=0;
            }
            else if(x==3)
            {
                if(mode==0) mode = 1;
                else if(mode==2) mode = 3;
                flipy=1;
            }
            else if(x==2)
            {
                if(mode==0) mode=2;
                if(mode==1) mode=4;
                flipx=0;
            }
            else if(x==4)
            {
                if(mode==0) mode=2;
                if(mode==1) mode=4;
                flipx=1;
            }

        }
        else if(type==2)
        {
            scanf("%i %i", &y, &x);
            y--;
            x--;
            if(flipx) x=n-x-1;
            if(flipy) y=n-y-1;
            printf("%i\n", data[y][x][mode]);
        }
    }

    return 0;
}
/*
1
1
0


5
00010
01111
11010
01010
00000
8
2 4 2
1 2
2 4 2
1 1
2 4 2
1 3
2 1 5
2 2 4



5
00010
01111
11010
01010
00000
10
2 2 2
1 3
2 2 2
1 1
2 2 2
1 2
2 2 2
1 4
2 2 2
2 1 5

5
00000
01000
11000
01010
00000
6
2 5 2
1 3
2 5 2
2 3 2
1 4
2 5 2


*/
