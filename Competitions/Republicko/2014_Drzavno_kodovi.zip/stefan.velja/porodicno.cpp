#include <iostream>
#include <cstdio>

using namespace std;

struct node
{
    node *next;
    int son;
    node();
};

node::node()
{
    next=NULL;
}

const int N=10005;
const int D=100005;

int n, s;
int max1;
int d[N], d2[N]; // Na koliko nacina trenutno mogu dobiti i
node *a[N];
int num[N]; // Srecni brojevi
int bio[N];// Uzeo u obzir za d
int br;
int minr, minindex;
int root_ne_moze[N];
int root;

void read_init()
{
    scanf("%i %i", &n, &s);
    minr=s;
    minindex=0;
    int k, x;
    for(int i=0; i<n; i++)
        a[i]=new node;
    for(int i=0; i<n; i++)
    {
        scanf("%i %i", &num[i], &k);
        for(int j=0; j<k; j++)
        {
            scanf("%i", &x);
            node *tmp=new node;
            tmp->next=a[i]->next;
            a[i]->next=tmp;
            tmp->son=x-1;
            root_ne_moze[x-1]=1;
        }
    }
    for(int i=0; i<n; i++)
        if(!root_ne_moze[i])
        {
            root=i;
        }
}

void dfs(int curr)
{
    //printf("Curr: %i %i\n", curr+1, max1);
    if(minr==0) return;
    for(int i=0; i<=max1; i++)
        d2[i]=d[i];
    for(int i=0; i<=max1; i++)
    {
        if(i+num[curr]>2*s) break;
        if(d2[i]) d[i+num[curr]]++;
        if(d2[i])
        {
        if(i+num[curr]>s)
        {
            if(i+num[curr]-s<minr)
            {
                minr=i+num[curr]-s;
                minindex=s+minr;
            }
        }
        else
        {
            if(s-i-num[curr]<=minr)
            {
                minr=s-i-num[curr];
                minindex=s-minr;
            }
            if(minr==0) return;
        }
        }
    }
    if(num[curr]<=2*s)
    {
        int i=0;
        d[num[curr]]++;
        if(i+num[curr]>s)
        {
            if(i+num[curr]-s<minr)
            {
                minr=i+num[curr]-s;
                minindex=s+minr;
            }
        }
        else
        {
            if(s-i-num[curr]<=minr)
            {
                minr=s-i-num[curr];
                minindex=s-minr;
            }
            if(minr==0) return;
        }
    }
    /*for(int j=0; j<30; j++)
            printf("%i ", d[j]);
        cout << endl;*/
    max1+=num[curr];
    node*tmp=a[curr]->next;
    while(tmp)
    {
        //printf("!");
        dfs(tmp->son);
        tmp=tmp->next;
    }
    //for(int i=0; i<max1; i++)
        //d2[i]=d[i];
    for(int i=num[curr]; i<=max1; i++)
        if(d2[i-num[curr]]) d[i]--;
    if(num[curr]<=2*s) d[num[curr]]--;
    /*printf("Curr: %i Izasao\n", curr);
    for(int j=0; j<30; j++)
            printf("%i ", d[j]);
        cout << endl;*/
    max1-=num[curr];
}

int main()
{
    read_init();
    //printf("%i\n", root+1);
    dfs(root);
    //printf("%i %i\n", minindex, minr);
    printf("%i\n", minindex);
    return 0;
}

/*
8 20
22 3 2 3 4
7 2 6 5
100 0
1 1 7
10 0
2 1 8
2 0
12 0

12 20
12 3 2 3 4
5 2 5 6
6 1 9
7 3 10 11 12
10 0
2 2 7 8
12 0
6 0
5 0
4 0
5 0
10 0

9 99
2 0
4 1 3
2 1 4
5 1 5
8 1 6
3 1 7
8 1 8
100 1 9
98 1 1

9 100
5 0
3 0
30 1 9
4 2 1 2
1 3 3 7 8
2 2 4 5
40 0
20 0
11 0
*/
