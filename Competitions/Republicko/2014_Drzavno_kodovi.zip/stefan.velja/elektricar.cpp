#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

const int N=600005;

struct objekat
{
    int pos;
    int type; // 1-bandera, 2-kuca
    int cena; // Samo za bandere
};

bool operator<(objekat o1, objekat o2)
{
    return o1.pos<o2.pos;
}

int n, m, d, c;
int curr_b, curr_s; // Trenutna cena bandere i broj s-ova
objekat a[N];

void read_init()
{
    scanf("%i %i %i %i", &n, &m, &d, &c);
    for(int i=0; i<n; i++)
    {
        a[i].type=1;
        scanf("%i", &a[i].cena);
    }
    for(int i=0; i<n; i++)
        scanf("%i", &a[i].pos);
    for(int i=0; i<m; i++)
    {
        a[i+n].type=2;
        scanf("%i", &a[i+n].pos);
    }
    d=1000000000;
    sort(a, a+n+m);
}

int main()
{
    read_init();
    printf("%i\n", (c/(2*n+3*m)));



    return 0;
}

/*
8 4 10000 101
1 15 7 6 22 2 7 12
1 5 11 12 14 16 18 20
8 9 13 19

4 2 12 32
1 5 17 3
1 5 15 17
9 10
*/
