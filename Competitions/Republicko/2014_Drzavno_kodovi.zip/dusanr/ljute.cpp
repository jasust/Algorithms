#include <iostream>

using namespace std;

int main()
{
    int i,j,n,h,x,y,visina[2000000]; // promeni
    cin >> n >> h;
    for (i=1;i<=n;i++) cin >> visina[i];
    cin >> x >> y;
    if (y>=h)
    {
        for (i=1;i<=n;i++)
        {
            j=i;
            while (visina[j]>=h) j++;
            if (j>n)
            {
                n++;
                visina[n]=0;
            }
            if (j-1==x)
            {
                x=j;
                y=y-h+1+visina[j];
                if (y<h) i=n+1; // Claw
            }
            visina[j]+=visina[j-1]-h+1;
            visina[j-1]=h-1;
            if (x<j-1) x++;
            for (j=j-1;j>i;j--)
            {
                visina[j]=visina[j-1];
            }
        }
    }
    cout << x << ' ' << y;
    return 0;
}
