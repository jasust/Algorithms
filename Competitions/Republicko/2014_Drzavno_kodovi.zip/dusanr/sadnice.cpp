#include <iostream>

using namespace std;

int main()
{
    long long m,k;
    int n,i,razmak;
    cin >> n >> m;
    k=1;
    for (i=1;i<=n;i++)
    {
        k=k*2;
    }
    k--;
    m--;
    razmak=0;
    for (i=1;i<=n;i++)
    {
        if (m<=(k+1)/2 & m>0)
        {
            if (razmak) cout << ' ';
            cout << i;
            razmak=1;
        }
        k=(k-1)/2;
        m=m-1;
        if (m>k) m-=k;
    }
    return 0;
}
