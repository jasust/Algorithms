#include <iostream>

using namespace std;

int main()
{
    int n,i,j,struja,sum,dux1,dux2,dux,duz1,polje1,profit[1000001]; // promeni
    cin >> n;
    for (i=1;i<=n;i++) cin >> profit[i];
    for (i=1;i<=n;i++)
    {
        cin >> struja;
        profit[i]-=struja;
    }
    // prvi deo - optimalan niz
    dux1=-10000000;
    polje1=1;
    duz1=1;
    for (i=1;i<=n;i++)
    {
        sum=profit[i];
        if (dux1<sum)
        {
            dux1=sum;
            polje1=i;
            duz1=1;
        }
        for (j=i+1;j<=n;j++)
        {
            sum+=profit[j];
            if (dux1<sum)
            {
                dux1=sum;
                polje1=i;
                duz1=j-i+1;
            }
        }
    }
    // drugi deo - leva strana
    dux2=-10000000;
    for (i=1;i<polje1;i++)
    {
        sum=profit[i];
        if (dux2<sum) dux2=sum;
        for (j=i+1;j<polje1;j++)
        {
            sum+=profit[j];
            if (dux2<sum) dux2=sum;
        }
    }
    // treci deo - desna strana
    for (i=polje1+duz1;i<=n;i++)
    {
        sum=profit[i];
        if (dux2<sum) dux2=sum;
        for (j=i+1;j<=n;j++)
        {
            sum+=profit[j];
            if (dux2<sum) dux2=sum;
        }
    }
    dux=dux1+dux2;
    if (dux1>dux && duz1>1) dux=dux1;
    cout << dux;
    return 0;
}
