#include <iostream>
#include <cstdio>
#include <vector>
#include <queue>
#include <fstream>
#define MAXN 51
using namespace std;
vector<int> sol;
long long fastpow(long long a,long long b)
{
    if(b==0) return 1;
    else if(b%2==0) return fastpow(a,b/2)*fastpow(a,b/2);
    else return fastpow(a,b/2)*fastpow(a,b/2)*a;
}
void solve(int poc,int kr,long long num)
{
    //printf("Pozvan solve za %d %d %d\n",poc,kr,num);
    int non=kr-poc+1;
    if(num==0) return;
    if(poc==kr)
    {   sol.push_back(poc);
        if(num==1) return ;

    }

    else
    {
        long long step=fastpow(2,non-1);
        int i=0;
        while(num-step>0)
        {
            num-=step;
            step/=2;
            i++;
        }
        sol.push_back(poc+i);
        //printf("U sol je pushbackovan %d\n",poc+i);
        solve(poc+i+1,kr,num-1);
    }
}
int main()
{
    //freopen("in.txt","r",stdin);
        int n;
    long long m;
    for(int i=0;i<MAXN;i++)
    sol.push_back(-1);
    scanf("%d %lld",&n,&m);
    solve(1,n,m-1);
    if(m==1) puts("");
    else{
    for(int i=0;i<sol.size()-1;i++)
    {
        if(sol[i]!=-1)printf("%d ",sol[i]);
    }
    printf("%d\n",sol[sol.size()-1]);
    }

    return 0;
}
