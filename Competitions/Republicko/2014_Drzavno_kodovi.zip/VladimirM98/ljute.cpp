#include <iostream>
#include <cstdio>
#define MAXN 1000010
using namespace std;
long long niz[MAXN];
bool poceo=false;
bool gotovo=false;
long long mymod(long long a,long long b)
{
    if(a%b==0) return b;
    else return a%b;
}
long long mydiv(long long a,long long b)
{
    if(a%b==0) return a/b;
    else return a/b+1;
}
int main()
{
   long long n,h,rk,hb,x;
    long long polja=0;
    scanf("%lld %lld",&n,&h);
    //printf("%lld %lld\n",n,h);
    for(int i=0;i<n;i++)
    {
        scanf("%lld",&niz[i]);
    }
    scanf("%lld%lld",&rk,&hb);
    --rk;
    --h;
    for(long long i=0;i<n;i++)
    {
        //puts("USAO OVDE");
        if(rk==i){polja+=hb-h;poceo=true;/*printf("POCEO JE ZA i=%lld\n",i)*/;}
        else if (poceo) polja+=niz[i]-h;
        //printf("Jos polja:%d\n",polja);
        if(poceo&&polja<=0)
        {
            //puts("GOTOVOOO");
            gotovo=true;
            polja-=niz[i]-h;
            rk=i+1;
            hb=niz[i]+polja;
        }
        if(gotovo) break;

    }
    if(!gotovo) {rk=n+mydiv(polja,h);hb=mymod(polja,h);}
    printf("%lld %lld\n",rk,hb);

    return 0;
}

