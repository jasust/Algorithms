#include <iostream>
using namespace std;

int n, k, rk, hb, *h, *p, prvi, poslednji, d;

int main()
{
    cin >> n >> k;
    h = new int[n];
    for (int i = 0; i < n; i++)
        cin >> h[i];
    cin >> rk >> hb;
    
    while (hb >= k)
    {
        if (h[n - 1] >= k)
        {
            p = h;
            h = new int[++n];
            h = p;
            h[n - 1] = 0;
        }
        
        prvi = -1;
        poslednji = -1;
        for (int i = 0; i < n; i++)
        {
            if (prvi == -1 && h[i] >= k) prvi = i;
            else if (prvi > -1 && h[i] < k)
            {
                 d = k - 1 - h[i];
                 h[i] += h[i - 1] - k + 1;
                 poslednji = i - 1;
                 break;
            }
        }
        
        for (int i = poslednji; i > prvi; i--)
            h[i] = h[i - 1];
        h[prvi] = k - 1;
        
        if (rk - 1 <= poslednji)
        {
            if (rk - 1 == poslednji) hb -= d;
            rk++;
        }
    }
    
    cout << rk << " " << hb;
    return 0;
}
