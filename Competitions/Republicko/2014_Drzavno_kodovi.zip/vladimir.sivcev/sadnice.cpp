#include <iostream>
using namespace std;

int n, m, *a, idx;

int main()
{
    cin >> n >> m;
    a = new int[n + 2];
    for (int i = 0; i < n + 2; i++) a[i] = 0;
    
    for (int i = 2; i <= m; i++)
    {
        if (i == 2)
        {
            a[1] = 1;
            idx = 2;
            continue;
        }
        
        a[idx] = a[idx - 1] + 1;
        
        if (i == m) break;
        
        if (a[idx] == n)
        {
            a[idx] = 0;
            a[--idx]++;
            i++;
            
            if (i == m) break;
            
            a[idx] = 0;
            a[idx - 1]++;
            i++;
        }
        else idx++;
    }
    
    for (int i = 1; a[i] > 0 && a[i] <= n; i++)
        cout << a[i] << " ";
    return 0;
}
