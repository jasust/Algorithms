#include <iostream>
using namespace std;

int n, *z, *s, sf, max1 = -1000000007, max2 = -1000000007, m1p = -1, m1k = -1, m2p = -1, m2k = -1, mtp, mtk;

void trazi(int idx, int k)
{
    if (idx + k > n)
    {
        if (k < n) trazi(0, k + 1);
        return;
    }
    
    mtp = idx;
    mtk = idx + k - 1;
    
    sf = 0;
    
    for (int i = idx; i < idx + k; i++)
        sf += z[i] - s[i];
    
    if (sf > max1)
    {
        if (m1k < mtp || mtk < m1p)
        {
            max2 = max1;
            m2p = m1p;
            m2k = m1k;
            
            max1 = sf;
            m1p = mtp;
            m1k = mtk;
        }
        else if (m2k < mtp || mtk < m2p)
        {
            max1 = sf;
            m1p = mtp;
            m1k = mtk;
        }
    }
    else if (sf <= max1 && sf > max2)
    {
        if (m1k < mtp || mtk < m1p)
        {
            max2 = sf;
            m2p = mtp;
            m2k = mtk;
        }
    }
    
    trazi(idx + 1, k);
}

int main()
{
    cin >> n;
    z = new int[n];
    s = new int[n];
    for (int i = 0; i < n; i++) cin >> z[i];
    for (int i = 0; i < n; i++) cin >> s[i];
    
    trazi(0, 1);
    cout << (max1 + max2);
    return 0;
}
