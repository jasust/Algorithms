#include<stdio.h>

int n,m,d,c,ci[300000],b[300000],k[300000],i;

int main()
{
 scanf("%d%d%d%d",&n,&m,&d,&c);
 
 for(i=0;i<n;i++)
  scanf("%d",&ci[i]);
 for(i=0;i<n;i++)
  scanf("%d",&b[i]);
 for(i=0;i<m;i++)
  scanf("%d",&k[i]);
 
 int p=c-ci[0]-ci[n-1];
 if(p%(b[n-1]-b[0])==0)
 {
  int pp=p/(b[n-1]-b[0]);
  printf("%d\n",pp);
 }
 else
 {
  for(i=2;i*i<p;i++)
   if(p%i==0)
   {
    printf("%d\n",i);
    break;
   }  
 }
  
 //getchar();
 //getchar();
 return 0; 
}
/*
4 2 12 32
1 4 17 3
1 5 15 17
9 10
*/
