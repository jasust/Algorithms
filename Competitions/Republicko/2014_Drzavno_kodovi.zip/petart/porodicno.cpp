#include<stdio.h>

int n,z,s[15000],v[15000],p[15000],d[15000],i,j,t,res,mr,o[15000];

int spoji(int a[],int b[],int na[],int br)
{
 int pa=0;
 int pb=0;
 int nbr=0;
 while(pa<br || pb<br)
 {
  if(pb>=br || ( pa<br && a[pa]<b[pb]))
  {
   na[nbr]=a[pa];
   pa++;
  }
  else
  {
   if(pa>=br ||(pb<br && a[pa]>b[pb]))
   {
    na[nbr]=b[pb];
    pb++;
   }
   else
   {
    if(a[pa]==b[pb])
    {
     na[nbr]=b[pb];
     pb++;
     pa++;
    }
   }
  }
  //printf("%d ",na[nbr]);
  nbr++;
  if(na[nbr-1]>=z)
   break;
 }
 
 return nbr;
}

void izracunaj(int c,int a[],int br)
{
 
 int b[15000],na[15000];
 for(int ii=0;ii<br;ii++)
 {
  b[ii]=a[ii]+s[c];
  //printf("%d ",a[ii]);
 }
 //printf("\n");
 
 int nbr=spoji(a,b,na,br);
 
 if(d[c]!=0)
 {
  for(int ii=p[c];ii<p[c]+d[c];ii++)
  {
   izracunaj(v[ii],na,nbr);
  }
 }
 else
 {
  int tren=0;
  for(int ii=0;ii<nbr;ii++)
  {
   tren=z-na[ii];
   if(tren<0)
   tren*=-1;
   
   if(tren<mr)
   {
    mr=tren;
    res=na[ii];
   }
  }
 }
}

int main()
{
 scanf("%d%d",&n,&z);
 for(i=0;i<n;i++)
 {
  scanf("%d%d",&s[i],&d[i]);
  p[i]=t;
  for(j=0;j<d[i];j++)
  {
   scanf("%d",&v[t]);
   v[t]--;
   o[v[t]]=1;
   t++;
  }
 }
 
 int a[15000];
 for(i=0;i<14000;i++)
  a[i]=0;
  
 int br=1;
 
 mr=z;
 
 int poc;
 for(i=0;i<n;i++)
 if(o[i]==0)
  poc=i;
 
 //printf("%d %d %d\n",poc,a[0],br);
 
 izracunaj(poc,a,br);
 
 printf("%d\n",res);
 
 //getchar();
 //getchar();
 return 0;
}
/*
8 20
12 0
22 2 3 4
7 2 7 6
100 0
1 1 8
10 1 5
2 1 1
2 0
*/
