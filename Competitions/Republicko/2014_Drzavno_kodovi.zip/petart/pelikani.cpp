#include<stdio.h>

int n,a[1100][1100],q,i,j,brx[1100],bry[1100],tx,ty,pp,nbrx[1100],nbry[1100];

void pomeri(int x[],int y[])
{
 for(int ii=0;ii<n;ii++)
  for(int jj=0;jj<x[ii];jj++)
   y[jj]++;
}

int main()
{
 scanf("%d",&n);
 
 for(i=0;i<n;i++)
 {
  char s[1100];
  
  scanf("%s",s);
  
  for(j=0;j<n;j++)
  {
   a[i][j]=s[j]-'0';
   
   if(a[i][j]==1)
   {
    brx[j]++;
    bry[i]++;
   }
  }
 }
 
 /*for(j=0;j<n;j++)
     printf("%d ",brx[j]);
    printf("\n"); 
    for(j=0;j<n;j++)
     printf("%d ",bry[j]);
    printf("\n");*/
 
 scanf("%d",&q);
 
 for(i=0;i<q;i++)
 {
  int p;
  scanf("%d",&p);
  
  if(p==1)
  {
   int k;
   scanf("%d",&k);
   
   if(k==1)
    ty=1;
   if(k==2)
    tx=1;
   if(k==3)
    ty=2;
   if(k==4)
    tx=2; 
     
   if(tx!=0 && ty!=0 && pp==0)
   {
    pp=1;
    
    if(k%2==0)
    {
     pomeri(brx,nbry);
     pomeri(nbry,nbrx);
    } 
    else
    {
     pomeri(bry,nbrx);
     pomeri(nbrx,nbry);
    }
    
    /*for(j=0;j<n;j++)
     printf("%d ",nbrx[j]);
    printf("\n"); 
    for(j=0;j<n;j++)
     printf("%d ",nbry[j]);
    printf("\n");*/
   } 
   //printf("%d %d %d\n",tx,ty,pp);
  }
  
  if(p==2)
  {
   int k,l;
   scanf("%d%d",&k,&l);
   
   if(pp==0)
   {
    if(tx==0 && ty==0)
     if(a[k-1][l-1]==1)
      printf("1\n");
     else
      printf("0\n");
    
    if(tx==1)
     if(l<=bry[k-1])
      printf("1\n");
     else
      printf("0\n");
    
    if(tx==2)
     if(l>=n-bry[k-1])
      printf("1\n");
     else
      printf("0\n");
      
    if(ty==1)
     if(k<=brx[l-1])
      printf("1\n");
     else
      printf("0\n");
      
    if(ty==2)
     if(k>=n-brx[l-1])
      printf("1\n");
     else
      printf("0\n");          
   }
   else
   {
    if(tx==1 && ty==1)
     if(l<=nbry[k-1])
      printf("1\n");
     else
      printf("0\n");
    
    if(tx==1 && ty==2)
     if(l<=nbry[n-k])
      printf("1\n");
     else
      printf("0\n");
     
    if(tx==2 && ty==1)
     if(l>=n-nbry[k-1]+1)
      printf("1\n");
     else
      printf("0\n");
    
    if(tx==2 && ty==2)
     if(l>=n-nbry[n-k]+1)
      printf("1\n");
     else
      printf("0\n");    
   }
  }
 }
 
 //getchar();
 //getchar();
 return 0;
}
/*
5
00000
01000
11000
01010
00000
7
2 5 2
1 3
2 5 2
2 3 2
1 4
2 5 2
2 5 3

3
000
010
100
10
1 4
2 2 3
2 3 3
1 2
2 2 1
2 3 1
1 3
2 2 1
2 3 1

4
0000
0100
0010
0000
14
2 2 2 
2 3 3
1 4
2 2 4
2 3 4
1 2
2 2 1
2 3 1
1 3
2 3 1
2 4 1
1 1
2 1 1
2 2 1
*/
