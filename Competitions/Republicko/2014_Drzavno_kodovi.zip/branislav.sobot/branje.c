#include <stdio.h>

long long a[1000005],b[1000005],c[1000005],d[1000005]={0};


int main()

{
    int n,i,j,k,l,m,p;
    long long max=-999999999;
    
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
      scanf("%lld",&a[i]);
    }
    for(i=0;i<n;i++)
    {
      scanf("%lld",&b[i]);
    }
    for(i=0;i<n;i++)
    {
       c[i]=a[i]-b[i];
    }
    d[0]=c[0];
    for(i=1;i<n;i++)
    {
       d[i]=d[i-1]+c[i];
    }
    for(i=0;i<n-1;i++)
       for(j=i;j<n;j++)
          for(k=j+1;k<n;k++)
             for(l=k;l<n;l++)
             {
                long long o=0;
                o+=d[j]-d[i-1];
                o+=d[l]-d[k-1];
                if(max<o)
                {
                  max=o;
                }
             }
    printf("%lld\n",max);
    return 0;
}
/*
11
5 6 3 14 9 7 11 3 8 1 4
1 5 11 4 6 4 4 5 4 8 2
*/
