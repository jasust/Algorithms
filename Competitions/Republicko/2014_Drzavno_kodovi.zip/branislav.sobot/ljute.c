#include <stdio.h>

long long a[100000005];

int main()
{
    int n,r,s;

    long long rk,i,j,k,o,u,hk;

    scanf("%d %lld",&n,&k);

    for(i=0;i<n;i++)
    {
       scanf("%lld",&a[i]);
    }
    for(i=n;i<4*n;i++)
    {
       a[i]=0;
    }
    scanf("%lld %lld",&rk,&hk);
    if(hk<k)
    {
       printf("%lld %lld \n",rk,hk);
    }
    else
    {
        long long w=n;
        for(i=0;i<2*n;i++)
        {
             if(a[i]>k-1)
             {
                  r=0;
                  o=0;
                  u=0;
                  if(a[w-1]>k)
                  {
                      w++;
                  }
                  for(j=i;j<w;j++)
                  {
                      if(a[j]>k-1)
                      {
                          if(rk-1==j)
                          {
                              o=1;
                          }
                          s=a[j]-k+1;
                          a[j]=k-1+r;
                          r=s;
                      }
                      else
                      {
                           if(rk==j-1)
                           {
                               o=1;
                               u=k-a[j]-1;
                               //printf("%d %d %d\n",u,j,i);
                           }
                           a[j]+=r;
                           //printf("%d\n",i);
                           break;
                      }

                  }
                  rk+=o;
                  hk-=u;

               }
               printf("%lld %lld\n",rk,hk);
        }
    }
    return 0;
}
/*
3 4
6 7 1
1 6
*/
