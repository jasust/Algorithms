#include <stdio.h>

long long StepenDvojke(a)
{
     int i;
     long long y=1;
     for(i=0;i<a;i++)
     {
        y=y*2;
     }
     return y;
}
void PravljenjeNiza(int n,int m,int j)
{
     if(j<=n)
     {
         int r=1;
         long long s=StepenDvojke(n-j)+1;
         int y=0;
         while(r!=0)
         {
            //printf("%d \n",m);
            if(m==1)
            {
                    r=0;
            }
            else
            {
                if(y==0)
                {
                        m--;
                        s--;
                }
                if(m<=s)
                {
                    r=0;
                    printf("%d ",j);
                    j++;
                    //printf("%d %d\n",m,j);
                    PravljenjeNiza(n,m,j);
                }
                else
                {
                    j++;
                    m-=s;
                    s=StepenDvojke(n-j);
                }
            }
            y++;
         }
     }
}

int main()
{
    int n,i,j;
    long long m;
    scanf("%d %d",&n,&m);
    if(m>1)
    {
     j=1;
     PravljenjeNiza(n,m,j);
    }
    printf("\n");
    return 0;
}
