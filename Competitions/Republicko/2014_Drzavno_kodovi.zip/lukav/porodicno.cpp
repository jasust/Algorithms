#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <vector>

using namespace std;
struct cvor
{
    int vr, par;
    vector <int> deca;
}niz[10001];
//vector <int> list;
bool pom1[20000],res[20000];
int n, s,x,p,koren;
void radi (int poc)
{


    bool pom2[20000];
    for(int i=0;i<2*s;i++)
        pom2[i]=pom1[i];
    for(int i=0;i<2*s;i++)
    {
        if(pom1[i]&&niz[poc].vr+i<2*s)
        {
            //cout<<niz[poc].vr+i<<endl;
            pom2[niz[poc].vr+i]=1;
        }
    }
    for(int i=0;i<2*s;i++)
        pom1[i]=pom2[i];
   /* if(poc==1)
    {
        for(int i=0;i<2*s;i++)
            cout<<i<<" "<<pom1[i]<<endl;
        cout<<endl;
    }*/
    if(niz[poc].deca.empty())
    {
        for(int i=0;i<2*s;i++)
            if(pom1[i])
                res[i]=1;
    }
    /*if(pom1[19])
        cout<<"napokon jebote";*/
    else
    {
        for(int i=0;i<niz[poc].deca.size();i++)
        {
            radi(niz[poc].deca[i]);
            for(int i=0;i<2*s;i++)
                pom1[i]=pom2[i];
        }
    }

}
int main()
{
    cin>>n>>s;
    for(int i=0;i<n;i++)
    {
        cin>>niz[i].vr>>x;
        if(x!=0)
        {
            niz[i].par=x;
            for(int j=0;j<x;j++)
            {
                cin>>p;
                pom1[p-1]=1;
                niz[i].deca.push_back(p-1);
            }
        }
    }

    for(int i=0;i<n;i++)
        if(!pom1[i])
            koren=i;

    for(int i=0;i<=s;i++)
        pom1[i]=false;
    pom1[0]=1;
    radi(koren);
   // for(int i=0;i<s*2;i++)
   // cout<<i<<" "<<res[i]<<endl;
    int tren=s;
    bool pr0=false;
    while (true)
    {
        if(res[tren])
        {
            cout<<tren;
            return 0;
        }
        if(tren<s)
            tren=s-tren+s;
        else
            tren=s-tren+s-1;
    }

    return 0;
}
/*
8 20
22 3 2 3 4
7 2 6 5
100 0
1 1 7
10 0
2 1 8
2 0
12 0
*/
