#include <iostream>

using namespace std;
int n, m, D, C;
int main()
{
    cin>>n>>m>>D>>C;
    for(int i=0;i<2*n;i++)
    {
        int p;
        cin>>p;
    }
    for(int i=0;i<m;i++)
    {
        int p;
        cin>>p;
    }
    cout<<2;
    return 0;
}
