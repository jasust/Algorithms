#include <iostream>
#include <stdio.h>
using namespace std;
int n, q;
bool mat[9][1001][1001],res[300000];
int pom[1005], posl,br,ur;
void promeni1 ()
{
                    for(int j=0;j<n;j++) //gore
                    {
                        int tu=0;
                        for(int i=0;i<n;i++)
                        {
                            if(mat[0][i][j]==1)
                            {
                                mat[1][tu][j]=1;
                                tu++;
                            }
                        }
                    }
                    for(int i=0;i<n;i++) //levo
                    {
                        int tu=0;
                        for(int j=0;j<n;j++)
                        {
                            if(mat[0][i][j]==1)
                            {
                                mat[2][i][tu]=1;
                                tu++;
                            }
                        }
                    }
                    for(int j=0;j<n;j++) //dole
                    {
                        int tu=n-1;
                        for(int i=n-1;i>=0;i--)
                        {
                            if(mat[0][i][j]==1)
                            {
                                mat[3][tu][j]=1;
                                tu--;
                            }
                        }
                    }
                    for(int i=0;i<n;i++) //desno
                    {
                        int tu=n-1;
                        for(int j=n-1;j>=0;j--)
                        {
                            if(mat[0][i][j]==1)
                            {
                                mat[4][i][tu]=1;
                                tu--;
                            }
                        }
                    }
}
void promeni2 (int d)
{
                if(d==1||d==3)
                {
                    for(int i=0;i<n;i++) //levo
                    {
                        int tu=0;
                        for(int j=0;j<n;j++)
                        {
                            if(mat[1][i][j]==1)
                            {
                                mat[5][i][tu]=1;
                                tu++;
                            }
                        }
                    }
                    for(int i=0;i<n;i++) //levo
                    {
                        int tu=0;
                        for(int j=0;j<n;j++)
                        {
                            if(mat[3][i][j]==1)
                            {
                                mat[6][i][tu]=1;
                                tu++;
                            }
                        }
                    }
                    for(int i=0;i<n;i++) //desno
                    {
                        int tu=n-1;
                        for(int j=n-1;j>=0;j--)
                        {
                            if(mat[3][i][j]==1)
                            {
                                mat[7][i][tu]=1;
                                tu--;
                            }
                        }
                    }
                    for(int i=0;i<n;i++) //desno
                    {
                        int tu=n-1;
                        for(int j=n-1;j>=0;j--)
                        {
                            if(mat[1][i][j]==1)
                            {
                                mat[8][i][tu]=1;
                                tu--;
                            }
                        }
                    }

                }
                if(d==2||d==4)
                {
                    for(int j=0;j<n;j++) //gore
                    {
                        int tu=0;
                        for(int i=0;i<n;i++)
                        {
                            if(mat[2][i][j]==1)
                            {
                                mat[5][tu][j]=1;
                                tu++;
                            }
                        }
                    }
                    for(int j=0;j<n;j++) //dole
                    {
                        int tu=n-1;
                        for(int i=n-1;i>=0;i--)
                        {
                            if(mat[2][i][j]==1)
                            {
                                mat[6][tu][j]=1;
                                tu--;
                            }
                        }
                    }
                    for(int j=0;j<n;j++) //dole
                    {
                        int tu=n-1;
                        for(int i=n-1;i>=0;i--)
                        {
                            if(mat[4][i][j]==1)
                            {
                                mat[7][tu][j]=1;
                                tu--;
                            }
                        }
                    }
                    for(int j=0;j<n;j++) //gore
                    {
                        int tu=0;
                        for(int i=0;i<n;i++)
                        {
                            if(mat[4][i][j]==1)
                            {
                                mat[8][tu][j]=1;
                                tu++;
                            }
                        }
                    }
                }
}
int main()
{
    scanf("%d", &n);
    for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
    {
        char c;
        cin>>c;
        mat[0][i][j]=c-'0';
    }
    promeni1();
    scanf("%d", &q);
    for(int i=0;i<q;i++)
    {
        int x;
        scanf("%d", &x);
        if(x==2)
        {
            int a,b;
            scanf("%d %d", &a, &b);
            res[br++]=mat[posl][a-1][b-1];
        }
        else
        {
            int d;
            scanf("%d", &d);
            if(ur==0)
            {
                promeni2(d);
                ur++;
                posl=d;
            }
            else
            {
                if(ur==1)
                {
                    if(d%2==posl%2)
                        posl=d;
                    else
                    {
                        ur++;
                        if(posl==1&&d==2||posl==2&&d==1)
                            posl=5;
                        if(posl==1&&d==4||posl==4&&d==1)
                            posl=8;
                        if(posl==3&&d==2||posl==2&&d==3)
                            posl=6;
                        if(posl==3&&d==4||posl==4&&d==3)
                            posl=7;
                    }
                }
                else
                {
                    if(d==1)
                    {
                        if(posl==6)
                            posl=5;
                        if(posl==7)
                            posl=8;
                    }
                    if(d==2)
                    {
                        if(posl==8)
                            posl=5;
                        if(posl==7)
                            posl=6;
                    }
                    if(d==3)
                    {
                        if(posl==5)
                            posl=6;
                        if(posl==8)
                            posl=7;
                    }
                    if(d==4)
                    {
                        if(posl==5)
                            posl=8;
                        if(posl==6)
                            posl=7;
                    }
                }
            }
        }
    }
    /*for(int s=0;s<9;s++)
    {
        cout<<s<<endl;
        for(int i=0;i<n;i++)
        {
            cout<<endl;
            for(int j=0;j<n;j++)
                cout<<mat[s][i][j];
        }
        cout<<endl;
    }*/
    for(int i=0;i<br;i++)
        cout<<res[i]<<endl;
    return 0;
}
//WOW
//SUCH CODE
//VERY LINES
//MUCH SMART
//SO DOGE
//WOW
/*
5
00000
01000
11000
01010
00000
6
2 5 2
1 3
2 5 2
2 3 2
1 4
2 5 2
3
000
011
000
3
2 2 2
1 2
2 2 3
5
00100
01010
11100
01010
10000
6
1 3
2 3 3
2 4 3
1 2
2 4 2
2 3 1
*/
