#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

int n, q;
char b[1024][1024];
int row_count[1024], col_count[1024];

int cnt[1024];

int cosak, height;

int main()
{
    scanf("%d", &n);
    for(int i=0;i<n;i++)
    {
        scanf("%s", b[i]);
    }

    for(int i=0;i<n;i++)
    {
        for(int j = 0; j < n; j++)
        {
            row_count[i]+=(b[i][j]=='1');
            col_count[j]+=(b[i][j]=='1');
        }
    }

    scanf("%d", &q);

    bool had_horizontal = false, had_vertical = false;
    int side_horizontal = 0, side_vertical = 0, second_horizontal = 0, second_vertical = 0;

    int prev_dir = 0;

    int _q = 0;
    while(!(had_horizontal && had_vertical) && _q<q)
    {
        int c;
        scanf("%d",&c);
        if(c==1)
        {
            int dir;
            /**1 - sever, 2 - zapad, 3 - jug, 4 - istok**/
            scanf("%d", &dir);
            if(had_horizontal)
            {
                if(dir == 1 || dir == 3)
                {
                    side_vertical = (dir == 3);
                    had_vertical = true;
                    second_vertical = true;
                }
                else
                {
                    side_horizontal = (dir == 4);
                }
            }
            else if(had_vertical)
            {
                if(dir == 2 || dir == 4)
                {
                    side_horizontal = (dir == 4);
                    had_horizontal = true;
                    second_horizontal = true;
                }
                else
                {
                    side_vertical = (dir == 3);
                }
            }
            else
            {
                if(dir == 1 || dir == 3)
                {
                    side_vertical = (dir == 3);
                    had_vertical = true;
                }
                else
                {
                    side_horizontal = (dir == 4);
                    had_horizontal = true;
                }
            }
        }
        else
        {
            int i, j;
            scanf("%d%d", &i, &j); i--; j--;
            if(had_horizontal)
            {
                if(side_horizontal) //desno su
                {
                    j = n - j - 1;
                }
                printf("%d\n", row_count[i]>j);
            }
            else if(had_vertical)
            {
                if(side_vertical) //dole su
                {
                    i = n - i - 1;
                }
                printf("%d\n", col_count[j]>i);
            }
            else
            {
                printf("%c\n", b[i][j]);
            }
        }
        _q++;
    }

    height = 0;
    if(!second_horizontal)
    {
        memset(b, 0, sizeof(b));
        memset(col_count, 0 , sizeof(col_count));
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<row_count[i];j++)
            {
                col_count[j]++;
            }
        }
        for(int j=0;j<n;j++)
        {
            for(int i=0;i<col_count[j];i++)
            {
                b[i][j] = 1;
            }
        }
    }
    else //prvo vertikala
    {
        memset(b, 0, sizeof(b));
        memset(row_count, 0 , sizeof(row_count));
        for(int j=0;j<n;j++)
        {
            for(int i=0;i<col_count[j];i++)
            {
                row_count[i]++;
            }
        }
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<row_count[i];j++)
            {
                b[i][j] = 1;
            }
        }
    }

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++) cnt[i]+=b[i][j];
        if(cnt[i]) height++;
    }
    while(_q<q)
    {
        int c;
        scanf("%d",&c);
        if(c==1)
        {
            int dir; /**1 - sever, 2 - zapad, 3 - jug, 4 - istok**/
            scanf("%d", &dir);
            switch(dir)
            {
                case 1: side_vertical = 0; break;
                case 2: side_horizontal = 0; break;
                case 3: side_vertical = 1; break;
                case 4: side_horizontal = 1; break;
            }
        }
        else
        {
            int i, j;
            scanf("%d%d", &i, &j); i--; j--;
            if(side_vertical) i = n - i - 1;
            if(side_horizontal) j = n - j - 1;
            printf("%d\n", cnt[i]>j);
        }
        _q++;
    }

    return 0;
}
