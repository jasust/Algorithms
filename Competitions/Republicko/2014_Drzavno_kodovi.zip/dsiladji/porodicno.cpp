#include <cstdio>
#include <algorithm>
#include <bitset>

using namespace std;

const int N = 10001;

int n, s, min_sr = 100000, res = 0;
short sr[N]; // 2N
short* children[N]; //4N+2N
short n_children[N]; //2N
short parent[N]; //2N
short root;
short d[N]; //2N
bool had_small = false;

void dfs(short x, short lvl)
{
    for(short i = N - sr[x] - 1; i>=0; i--)
    {
        int c = i+sr[x];
        if(d[i] && c<N)
        {
            if(!d[c]) d[c] = lvl;
        }
    }

    for(short i = 0; i < n_children[x]; i++)
    {
        dfs(children[x][i], lvl+1);
    }

    if(n_children[x]==0 && had_small)
    {
        for(short i=1;i<N;i++)
        {
            if(d[i])
            {
                if(abs(i-s)<abs(res - s)) res = i;
            }
        }
    }
    for(short i = 0; i + sr[x] < N; i++)
    {
        int c = i+sr[x];
        if(c<N)
        {
            if(d[c]==lvl) d[c] = 0;
        }
    }
}

int main()
{
    scanf("%d%d", &n, &s);
    for(int i=1; i<=n; i++)
    {
        int _sr;
        scanf("%d%d", &_sr, &n_children[i]);
        min_sr = min(min_sr, _sr);
        if(_sr<=10000)
        {
            sr[i] = _sr;
            had_small = true;
        }
        children[i] = new short[n_children[i]];
        for(int j=0; j<n_children[i]; j++)
        {
            scanf("%d", &children[i][j]);
            parent[children[i][j]] = i;
        }
    }
    root = 1;
    while(parent[root]) root = parent[root];

    d[0] = 1;
    dfs(root, 1);

    if(abs(min_sr-s)<abs(res - s)) res = min_sr;

    printf("%d\n",res);

    return 0;
}
