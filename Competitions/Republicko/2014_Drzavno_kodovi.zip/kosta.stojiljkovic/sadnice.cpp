#include <cstdlib>
#include <iostream>
#include <string.h>
#include <stdio.h>
using namespace std;

int n,br;
string a[1000];
int pom;

int main()
{
    cin>>n;
    cin>>br;
    
    if(n==1)
    {
           if(br==1)
           cout<<"";
           else
           cout<<1;   
    }
    if(n==2)
    {
            if(br==1)
            cout<<"";
            else
            {
                a[2]="1";
                a[3]="12";
                a[4]="2";
                for(int i=0;i<a[br].length();i++)
                {putchar(a[br][i]);cout<<" ";}
               
                
            }
    }
        if(n==3)
    {
            if(br==1)
            cout<<"";
            else
            {
                a[2]="1";
                a[3]="12";
                a[4]="123";
                a[5]="13";
                a[6]="2";
                a[7]="23";
                a[8]="3";
         for(int i=0;i<a[br].length();i++)
                {putchar(a[br][i]);cout<<" ";}

            }
            
    }
            if(n==4)
    {
            if(br==1)
            cout<<"";
            else
            {
                a[2]="1";
                a[3]="12";
                a[4]="123";
                a[5]="1234";
                a[6]="124";
                a[7]="13";
                a[8]="134";
                a[9]="14";
                a[10]="2";
                a[11]="23";
                a[12]="234";
                a[13]="24";
                a[14]="3";
                a[15]="34";
                a[16]="4";
                
         for(int i=0;i<a[br].length();i++)
                {cout<<a[br][i];cout<<" ";}
     
            }
    }
    
         if(n==5)
         
   {
         if(br==1)
         cout<<"";
         else
         {
             a[2]="1";
             a[3]="12";
             a[4]="123";
             a[5]="1234";
             a[6]="12345";
             a[7]="1235";
             a[8]="124";
             a[9]="1245";
             a[10]="125";
             a[11]="13";
             a[12]="134";
             a[13]="1345";
             a[14]="135";
             a[15]="14";
             a[16]="145";
             a[17]="15";
             a[18]="2";
             a[19]="23";
             a[20]="234";
             a[21]="2345";
             a[22]="235";
             a[23]="24";
             a[24]="245";
             a[25]="25";
             a[26]="3";
             a[27]="34";      
             a[28]="345";
             a[29]="35";
             a[30]="4";
             a[31]="45";
             a[32]="5";
    for(int i=0;i<a[br].length();i++)
                {putchar(a[br][i]);cout<<" ";}
    
}

}
    

return 0;    

}
