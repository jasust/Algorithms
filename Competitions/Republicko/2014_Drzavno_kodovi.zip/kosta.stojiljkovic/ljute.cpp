#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;

int n,k,rk,hb;
int pr=0;
int kraj=0;
int a[2000000];
int pom;
int pom2;
int trt,htr;
int procedura=0;

void radi(int p)
{
  if((p==rk-1)&&(pr==0)&&(hb>k-1))
  {rk++;pr=1;}
     
 
      
     if(a[p+1]>=k)
     {
                 pom2=a[p+1]-k+1;
                 a[p+1]=k-1+pom;
                 pom=pom2;
                 pom2=0;
                 
                 if(pr==1)
                 pr=2;
                 
                 radi(p+1);   
                                              
     }     
     else
     if(a[p+1]==0)
     {
     a[p+1]+=pom;
     n++;
     if(pr==1)
     {hb=hb-k+1;pr=2;}
     }
     else
     {
         if(pr==1)
         {hb=hb-(k-1)+a[p+1];pr=2;}
         a[p+1]+=pom;
     
     }
     
     

}

int moze()
{
     for(int i=0;i<n;i++)
     {
             if(a[i]>=k)
             {
                        
                        pom=a[i]-k+1;
                        a[i]=k-1;  
                        pr=0;
                        
  
                        radi(i);
  //                       for(int i=0;i<n;i++)
//    {cout<<a[i]<<"\n";}
 //                       cout<<rk<<" "<<hb<<"\n";
                        return 1;
             }
     }
     return 0;
}






int main()
{
    scanf("%d %d",&n,&k);
    
    for(int i=0;i<n;i++)
    {
            scanf("%d",&a[i]);
    }

    
    scanf("%d %d",&rk,&hb);
    
    if(n==1)
    procedura=1;
    
        trt=a[0];
    for(int i=1;i<n;i++)
    {
            if(trt!=a[i])  
            break;
            if(i=n-1)
            procedura=2;          
    }
    
    
    if(procedura==0)
    {
                    
    while(moze())
{}
}

    if(procedura==1)
    {
                    while(hb>k-1)
                    {hb=hb-(k-1);rk++;}
    }
cout<<rk<<" "<<hb;

return 0;

}
