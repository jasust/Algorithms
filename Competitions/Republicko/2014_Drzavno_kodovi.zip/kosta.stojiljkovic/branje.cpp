#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

int n;
int a[1000000];
int b[1000000];
int max1=-1000000000;
int max2=-1000000000;
int zbir=-1000000000;
int test;
int pom;
int poc1,poc2,br1,br2;


int main()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
            scanf("%d",&a[i]);
    }   
        for(int i=0;i<n;i++)
    {
            scanf("%d",&b[i]);
    } 






for(int i=1;i<n;i++)    
    for(int j=0;j<n-i;j++)
    {test=0;
            for(int p=j;p<j+i;p++)
            {
                    pom=pom+a[p]-b[p];  
                         
            }
                        
            max1=pom;poc1=j;br1=i;
           test+=max1;
            pom=0; 
           //////MASINA 2//////////////////////////////  
    for(int i1=1;i1<poc1+1;i1++)    
    for(int j1=0;j1<poc1+1-i1;j1++)
    {
            for(int p1=j1;p1<j1+i1;p1++)
            {
                    pom=pom+a[p1]-b[p1]; 
                                
            }
                 if(pom>max2)
           { max2=pom;}
           pom=0;   
           
    }
 

     for(int i2=1;i2<n+1-(br1+poc1);i2++)    
    for(int j2=poc1+br1;j2<n+1-i2;j2++)
    {
            for(int p2=j2;p2<j2+i2;p2++)
            {
                    pom=pom+a[p2]-b[p2];  
                          
            }
                      if(pom>max2)
           { max2=pom;}
           pom=0;   
           
    }
 
   test+=max2;
/////////MASINA 2 KRAJ////////////////
         
           
             if(test>zbir)
          { zbir=test;
}
           pom=0; 
           max1=0;max2=0;
           
           
    }
    

  
    cout<<zbir;

return 0;
}
