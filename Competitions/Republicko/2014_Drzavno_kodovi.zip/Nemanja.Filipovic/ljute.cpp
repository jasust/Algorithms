#include <stdio.h>
long int n,k;
long int *kule  = new long int[1000001], *renorm_kule = new long int[1000001];
long int rk, hb;
long int nova_duzina, sum;

void renormalizuj(){
   for(long int i = rk - 1; i<n; i++){
      renorm_kule[i-rk+1] = kule[i];
    }
     nova_duzina = n - rk + 1;

   return;
}

void pronadji_mesta(){
    int ukupno = renorm_kule[0]-k;
    for(int i = 1; i<nova_duzina; i++){
       ukupno += renorm_kule[i] - k;
        if(ukupno<=0)
       {
          printf("%ld %ld", n - nova_duzina  + i + 1, k+ukupno);
          return;
       }
    }
    if(ukupno % k !=0 ){printf("%ld %ld", n + ((int) ukupno / k) + 1, ukupno % k);} else {printf("%ld %ld", n + ((int) ukupno / k), 0);}
    return;
}

int main(){

    scanf("%ld %ld\n", &n, &k);
    k = k-1;
    for(long int i = 0; i<n; i++)
        scanf("%ld", &kule[i]);

    scanf("%ld %ld", &rk, &hb);
    kule[rk-1] = hb;


    renormalizuj();

    pronadji_mesta();

    return 0;
}
