#include <stdio.h>
  long long n;
  long long m;



long long pov(long long n){
  long long ret = 1;
  for(long long i = 0; i<n; i++) ret*=2;
  return ret;

}

void nadji(){
  long long n1 = n-1;
  long long uk = 1;

  while(uk!=m){

    while(uk < m){
        uk+=pov(n1);
        n1--;

    }
    printf("%ld ", n - n1-1);
    uk-=pov(n1 + 1);
    uk++;


  }


  return;

}
int main(){

  scanf("%lld", &n);
  scanf("%lld", &m);

  nadji();

  return 0;
}
