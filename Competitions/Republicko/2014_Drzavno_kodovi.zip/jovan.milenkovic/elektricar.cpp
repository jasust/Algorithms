#include <cstdio>
struct bandera
{
    int x,cena;
} ban[300000];
int k[300000];
int main()
{
    int n,m,d,c,i;
    scanf("%d%d%d%d",&n,&m,&d,&c);
    for(i=0;i<n;i++)
        scanf("%d",&ban[i].cena);
    for(i=0;i<n;i++)
        scanf("%d",&ban[i].x);
    for(i=0;i<m;i++)
        scanf("%d",k+i);
    printf("2");
    return 0;
}
