#include <cstdio>
int a[1005];
int min(int a,int b,int sol)
{
    int p,q,r;
    p=sol-a;
    q=sol-b;
    r=sol-a-b;
    if(p<0)
        p*=-1;
    if(q<0)
        q*=-1;
    if(r<0)
        r*=-1;
    if(p<q)
    {
        if(p<=r)
            return a;
        else
            return a+b;
    }
    else
    {
        if(q<=r)
            return b;
        else
            return a+b;
    }
}
int main()
{
    int i,j,n,s,x,y,pom;
    scanf("%d%d",&n,&s);
    for(i=0;i<n;i++)
    {
        scanf("%d%d",a+i,&x);
        for(j=0;j<x;j++)
        scanf("%d",&y);
    }
    if(n==1)
        printf("%d",a[0]);
    else if(n==2)
        printf("%d",min(a[0],a[1],s));
    else
        printf("%d",s);
    return 0;
}
