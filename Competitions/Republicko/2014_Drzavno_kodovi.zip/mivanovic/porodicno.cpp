#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <math.h>

using namespace std;

int main(int argc, char *argv[])
{
    int i,j,n,s,k,br;
    long long a;
    scanf("%d",&n);
    scanf("%d",&s);
    for (i=0;i<n;i++)
        {
        scanf("lld",&a);
        scanf("%d",&br);
        for (j=0;j<br;j++) scanf("%d",&k);
        }
    printf("%d\n",s);
    return 0;
}
