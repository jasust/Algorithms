#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <cstdlib>
bool m[1001][1001];
int n,a[300001][3];
long long q;
void citaj()
{
     int i,j;
     for (i=1;i<=n;i++)
         {
         for (j=1;j<=n;j++)
             if (getchar()=='1') m[i][j]=true;
             else m[i][j]=false;
         while (getchar()!='\n');
         }
}
void citajNiz()
{
     long long i;
     for (i=1;i<=q;i++)
         {
         scanf("%d",&a[i][0]);
         if (a[i][0]==1) scanf("%d",&a[i][1]);
         else 
              {
              scanf("%d",&a[i][1]);
              scanf("%d",&a[i][2]);
              }
         }
}
void istok()
{
     int i,j,k;
     for (i=1;i<=n;i++)
         {
         k=n;
         for (j=n;j>=1;j--)
             if (m[i][j])
                {
                m[i][j]=false;
                m[i][k]=true;
                k--;
                }
         }
}
void zapad()
{
     int i,j,k;
     for (i=1;i<=n;i++)
         {
         k=1;
         for (j=1;j<=n;j++)
             if (m[i][j])
                {
                m[i][j]=false;
                m[i][k]=true;
                k++;
                }
         }
}
void sever()
{
     int i,j,k;
     for (j=1;j<=n;j++)
         {
         k=1;
         for (i=1;i<=n;i++)
             if (m[i][j])
                {
                m[i][j]=false;
                m[k][j]=true;
                k++;
                }
         }
}
void jug()
{
     int i,j,k;
     for (j=1;j<=n;j++)
         {
         k=n;
         for (i=n;i>=1;i--)
             if (m[i][j])
                {
                m[i][j]=false;
                m[k][j]=true;
                k--;
                }
         }
}
void koraci()
{
     long long i;
     int x,y;
     for (i=1;i<=q;i++)
         if (a[i][0]==1)
            {
            if (a[i][1]==1) sever();
            else
                if (a[i][1]==2) zapad();
                else
                    if (a[i][1]==3) jug();
                    else
                        istok();
            }
         else
             {
             x=a[i][1];
             y=a[i][2];
             if (m[x][y]) printf("1\n");
             else printf("0\n");
             }
}
using namespace std;

int main(int argc, char *argv[])
{
    scanf("%d",&n);
    while (getchar()!='\n');
    citaj();
    scanf("%lld",&q);
    citajNiz();
    koraci();
    return 0;
}
