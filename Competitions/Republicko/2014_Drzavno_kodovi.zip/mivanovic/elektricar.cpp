#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char *argv[])
{ 
    int m,n,d,c,a,i;
    scanf("%d%d%d%d",&n,&m,&d,&c);
    for (i=0;i<n;i++) scanf("%d",&a);
    for (i=0;i<n;i++) scanf("%d",&a);
    for (i=0;i<m;i++) scanf("%d",&a);
    printf("10\n");
    return 0;
}
