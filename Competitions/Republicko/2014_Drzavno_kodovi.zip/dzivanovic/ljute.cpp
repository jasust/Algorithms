#include <cstdio>
int a[1000010];
int main()
{
    int n,k;
    int x,y;
    long long over = 0;
    scanf("%d %d",&n,&k);
    for(int i = 0; i<n; i++)
        scanf("%d",&a[i]);
    scanf("%d %d",&x,&y);
    for(int i = 0; i < n; i++)
    {
        int h = a[i];
        if (i+1 < x)
            continue;
        if (i+1 == x)
        {
            if (k > y)
            {
                printf("%d %d\n",x,y);
                return 0;
            }
            else
                over+=y-k+1;
        }
        else
        {
            over+=h-k+1;
            if (over <= 0)
            {
                printf("%d %d\n",i+1,k+over-1);
                return 0;
            }
        }
    }
    long long w = over/(k-1);
    over -= w*(k-1);
    if (over == 0)
        printf("%lld %d\n",n+w,k-1);
    else
        printf("%lld %d\n",n+w+1,over);
    return 0;
}
