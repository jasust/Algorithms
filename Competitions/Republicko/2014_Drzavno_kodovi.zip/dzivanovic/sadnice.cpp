#include <cstdio>

void doit(long long n, long long m, long long k)
{
    if (m == 1)
        return;
    m--;
    for(int i = 1; i <= n; i++)
    {
        if (m > ((long long)1<<(n-i)))
            m-=((long long)1<<(n-i));
        else
        {
            printf("%d ", i+k);
            doit(n-i,m,i+k);
            return;
        }
    }
}

int main()
{
    long long n,m;
    scanf("%lld %lld",&n,&m);
    doit(n,m,0);
    printf("\n");
    return 0;
}
