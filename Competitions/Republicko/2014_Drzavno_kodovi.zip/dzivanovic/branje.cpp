#include <cstdio>
#define INF 2000000000000000
int c[1000010];
long long pre[1000010], suf[1000010];

int main()
{
    int n;
    scanf("%d",&n);
    for(int i=0; i < n; i++)
        scanf("%d",&c[i]);
    for(int i=0; i < n; i++)
    {
        int x;
        scanf("%d",&x);
        c[i]-=x;
    }
    long long tren = 0;
    long long mx = -INF;
    for(int i = 0; i < n; i++)
    {
        tren += c[i];
        if (tren > mx)
            mx = tren;
        pre[i] = mx;
        if (tren < 0)
            tren = 0;
    }
    tren = 0;
    mx = -INF;
    for(int i = n-1; i >= 0; i--)
    {
        tren += c[i];
        if (tren > mx)
            mx = tren;
        suf[i] = mx;
        if (tren < 0)
            tren = 0;
    }
    long long sol = -INF;
    for(int i = 1; i < n; i++)
    {
        if (pre[i-1]+suf[i] > sol)
            sol = pre[i-1]+suf[i];
    }
    printf("%lld\n",sol);
    return 0;
}

/*
11
5 6 3 14 9 7 11 3 8 1 4
1 5 11 4 6 4 4 5 4 8 2
*/
